const CACHE_NAME = 'limsist-v9-pwa-opcional-autoria';

// Instalar: ativa imediatamente
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

// Activar: limpa caches antigos e assume controlo
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) =>
      Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) return caches.delete(cacheName);
        })
      )
    ).then(() => self.clients.claim())
  );
});

// Estratégia:
// - HTML (document): Network First com timeout curto (para apanhar deploys)
// - JS/CSS/imagens/fonts: Cache First (ultra rápido) + revalida em background
// - Supabase e cross-origin: passa direto sem interferir
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  if (event.request.url.includes('supabase.co')) return;

  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  const isDocument = event.request.destination === 'document' ||
                     event.request.mode === 'navigate';

  if (isDocument) {
    // Network First com timeout 2s para HTML
    event.respondWith(
      Promise.race([
        fetch(event.request).then((response) => {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((c) => c.put(event.request, clone));
          return response;
        }),
        new Promise((resolve) => setTimeout(() => {
          caches.match(event.request).then((cached) => {
            if (cached) resolve(cached);
          });
        }, 2000))
      ]).catch(() =>
        caches.match(event.request).then((cached) =>
          cached || caches.match('/index.html')
        )
      )
    );
    return;
  }

  // Cache First para assets estáticos (JS/CSS/img/fonts)
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) {
        // Stale-while-revalidate: atualiza cache em background sem bloquear
        fetch(event.request).then((response) => {
          if (response && response.ok) {
            caches.open(CACHE_NAME).then((c) => c.put(event.request, response));
          }
        }).catch(() => {});
        return cached;
      }
      // Não está em cache: busca da rede e guarda
      return fetch(event.request).then((response) => {
        if (response && response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((c) => c.put(event.request, clone));
        }
        return response;
      }).catch(() => caches.match(event.request));
    })
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});
