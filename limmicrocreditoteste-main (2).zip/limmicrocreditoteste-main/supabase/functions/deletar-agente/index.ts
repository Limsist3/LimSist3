import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    // Verificar autenticação do usuário
    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);

    if (userError || !user) {
      throw new Error('Não autenticado');
    }

    const { agente_id } = await req.json();

    // Verificar se o agente pertence ao usuário mãe ou se é superadmin
    const { data: profileData, error: profileError } = await supabaseAdmin
      .from('user_profiles')
      .select('usuario_mae_id, was_user_mae, full_name, email')
      .eq('user_id', agente_id)
      .maybeSingle();

    if (profileError || !profileData) {
      throw new Error('Agente não encontrado');
    }

    // Verificar se o usuário tem permissão (é o usuário mãe ou superadmin)
    const { data: userRoleData } = await supabaseAdmin
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .maybeSingle();

    const isSuperAdmin = userRoleData?.role === 'superadmin';
    const isOwner = profileData.usuario_mae_id === user.id;

    if (!isOwner && !isSuperAdmin) {
      throw new Error('Você não tem permissão para deletar este agente');
    }

    // Se era originalmente um usuário mãe, restaurar ao invés de deletar
    if (profileData.was_user_mae) {
      // Restaurar o perfil como usuário normal
      const { error: restoreError } = await supabaseAdmin
        .from('user_profiles')
        .update({
          role: 'user',
          usuario_mae_id: null,
          was_user_mae: false,
          estado: 'Ativo'
        })
        .eq('user_id', agente_id);

      if (restoreError) {
        console.error('Erro ao restaurar perfil:', restoreError);
        throw restoreError;
      }

      // Restaurar role em user_roles
      const { error: roleRestoreError } = await supabaseAdmin
        .from('user_roles')
        .update({ role: 'user' })
        .eq('user_id', agente_id);

      if (roleRestoreError) {
        console.error('Erro ao restaurar role:', roleRestoreError);
      }

      // Registrar atividade
      await supabaseAdmin.rpc('registrar_atividade_agente', {
        p_agente_id: user.id,
        p_descricao: `Restaurou usuário mãe: ${profileData.full_name} (${profileData.email})`
      });

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Conta de usuário mãe restaurada com sucesso. O usuário pode acessar o sistema normalmente.',
          restored: true
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Deletar o usuário normalmente se não era um usuário mãe
    const { error: deleteError } = await supabaseAdmin.auth.admin.deleteUser(agente_id);

    if (deleteError) {
      console.error('Erro ao deletar usuário:', deleteError);
      throw deleteError;
    }

    return new Response(
      JSON.stringify({ success: true, message: 'Agente deletado com sucesso' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error('Erro:', error);
    const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
