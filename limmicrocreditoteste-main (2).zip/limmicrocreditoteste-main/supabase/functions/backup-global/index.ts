import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "https://limsistema.vercel.app",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS, PUT, DELETE",
};

// Ordem de dependência (pais antes dos filhos)
const TABLES = [
  "user_profiles",
  "user_roles",
  "pacotes_plataforma",
  "configuracao_pagamento",
  "payment_keys",
  "links_ativacao",
  "cupoes_acesso",
  "configuracoes_empresa",
  "contas_financeiras",
  "capital_global",
  "capital_mensal",
  "entradas_capital",
  "clientes",
  "emprestimos",
  "pagamentos",
  "despesas",
  "movimentos_conta",
  "arquivos",
  "central_risco",
  "agente_atividades",
  "grupos_poupanca",
  "membros_poupanca",
  "poupancas_investimento",
  "poupanca_investimento_ganhos",
  "pg_grupos",
  "pg_membros",
  "pg_emprestimos",
  "pg_depositos",
  "pg_pagamentos",
  "pg_movimentos",
  "declaracoes_ispc",
  "notificacoes",
  "subscription_requests",
  "subscriptions",
  "historico_renovacoes",
  "pagamentos_plataforma",
  "link_ativacao_uso",
  "mensagens_chat",
] as const;

// aliases para aceitar backups de outras origens/nomenclaturas
const ALIASES: Record<string, string> = {
  clients: "clientes", customers: "clientes",
  loans: "emprestimos", creditos: "emprestimos",
  payments: "pagamentos", recebimentos: "pagamentos",
  expenses: "despesas",
  contas: "contas_financeiras",
  settings: "configuracoes_empresa", config: "configuracoes_empresa",
  configuracoes: "configuracoes_empresa", empresa: "configuracoes_empresa",
  grupos: "grupos_poupanca", poupancas: "grupos_poupanca",
  membros: "membros_poupanca",
  files: "arquivos", documentos: "arquivos",
  risco: "central_risco",
  agentes: "agente_atividades", gestao_agentes: "agente_atividades",
  perfis: "user_profiles", profiles: "user_profiles",
  roles: "user_roles",
};

const DEFAULT_PASSWORD = "123456";

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const admin = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    { auth: { autoRefreshToken: false, persistSession: false } },
  );

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return json({ error: "Não autenticado" }, 401);
    const { data: { user }, error: uErr } = await admin.auth.getUser(authHeader.replace("Bearer ", ""));
    if (uErr || !user) return json({ error: "Não autenticado" }, 401);

    const { data: isSuper } = await admin.rpc("is_superadmin", { _user_id: user.id });
    if (!isSuper) return json({ error: "Apenas o superadministrador pode usar o backup geral" }, 403);

    const body = await req.json().catch(() => ({}));
    const action = body?.action === "import" ? "import" : "export";

    const userClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } }, auth: { persistSession: false } },
    );

    if (action === "export") return json(await doExport(admin, userClient));
    return json(await doImport(admin, body?.backupData ?? body?.data ?? body));
  } catch (e) {
    console.error("[backup-global]", e);
    return json({ error: e instanceof Error ? e.message : "Erro no backup geral" }, 400);
  }
});

async function doExport(admin: any, userClient: any) {
  const tables: Record<string, unknown[]> = {};

  for (const table of TABLES) {
    const rows: unknown[] = [];
    let from = 0;
    const size = 1000;
    // paginação para não perder nada
    for (;;) {
      const { data, error } = await admin.from(table).select("*").range(from, from + size - 1);
      if (error) { console.warn(`export ${table}: ${error.message}`); break; }
      rows.push(...(data ?? []));
      if (!data || data.length < size) break;
      from += size;
    }
    tables[table] = rows;
  }

  // contas de autenticação (para restaurar logins)
  // inclui o hash da senha para que os logins fiquem EXACTAMENTE iguais no restauro
  let authUsers: Array<Record<string, unknown>> = [];
  const { data: rpcUsers, error: rpcErr } = await userClient.rpc("export_auth_users");
  if (!rpcErr && Array.isArray(rpcUsers)) {
    authUsers = rpcUsers as Array<Record<string, unknown>>;
  } else {
    console.warn("export_auth_users:", rpcErr?.message);
    for (let page = 1; page <= 50; page++) {
      const { data, error } = await admin.auth.admin.listUsers({ page, perPage: 200 });
      if (error || !data?.users?.length) break;
      for (const u of data.users) {
        authUsers.push({
          id: u.id,
          email: u.email,
          phone: u.phone,
          created_at: u.created_at,
          raw_user_meta_data: u.user_metadata ?? {},
        });
      }
      if (data.users.length < 200) break;
    }
  }

  return {
    success: true,
    version: "2.0-global",
    scope: "global",
    exportDate: new Date().toISOString(),
    authUsers,
    tables,
    counts: Object.fromEntries(Object.entries(tables).map(([k, v]) => [k, v.length])),
  };
}

function findTables(raw: any): Record<string, Record<string, unknown>[]> {
  const out: Record<string, Record<string, unknown>[]> = {};
  const candidates = [raw?.tables, raw?.data, raw?.backup, raw];
  for (const cand of candidates) {
    if (!cand || typeof cand !== "object" || Array.isArray(cand)) continue;
    for (const [key, value] of Object.entries(cand as Record<string, unknown>)) {
      const norm = key.toLowerCase().replace(/[^a-z_]/g, "");
      const table = (TABLES as readonly string[]).includes(norm) ? norm : ALIASES[norm];
      if (!table || out[table]?.length) continue;
      let rows: unknown = value;
      if (value && typeof value === "object" && !Array.isArray(value)) {
        const nested = value as Record<string, unknown>;
        rows = nested.data ?? nested.rows ?? null;
      }
      if (Array.isArray(rows)) {
        const clean = rows.filter((r) => r && typeof r === "object" && !Array.isArray(r)) as Record<string, unknown>[];
        if (clean.length) out[table] = clean;
      }
    }
  }
  return out;
}

/** Upsert tolerante: remove colunas inexistentes indicadas pelo erro e volta a tentar. */
async function tolerantUpsert(admin: any, table: string, rows: Record<string, unknown>[]) {
  let payload = rows.map((r) => ({ ...r }));
  for (let attempt = 0; attempt < 12; attempt++) {
    const { error } = await admin.from(table).upsert(payload as never, { onConflict: "id", ignoreDuplicates: false });
    if (!error) return { ok: payload.length, failed: 0, error: null as string | null };

    const msg = error.message || "";
    const col = msg.match(/'([^']+)' column/)?.[1] ?? msg.match(/column "([^"]+)"/)?.[1];
    if (col) {
      payload = payload.map((r) => { const c = { ...r }; delete c[col]; return c; });
      continue;
    }
    // fallback: linha a linha
    let ok = 0; let failed = 0; let lastErr: string | null = null;
    for (const row of payload) {
      const { error: e1 } = await admin.from(table).upsert(row as never, { onConflict: "id" });
      if (!e1) { ok++; continue; }
      const { id: _drop, ...noId } = row as Record<string, unknown>;
      const { error: e2 } = await admin.from(table).insert(noId as never);
      if (!e2) ok++; else { failed++; lastErr = e2.message?.slice(0, 140) ?? null; }
    }
    return { ok, failed, error: lastErr };
  }
  return { ok: 0, failed: payload.length, error: "Falha após várias tentativas" };
}

async function doImport(admin: any, raw: any) {
  const tables = findTables(raw);
  if (!Object.keys(tables).length) return { error: "Backup inválido — nenhuma tabela reconhecida" };

  // 1) restaurar contas de autenticação
  const existing = new Map<string, string>(); // email -> id
  const existingIds = new Set<string>();
  for (let page = 1; page <= 50; page++) {
    const { data, error } = await admin.auth.admin.listUsers({ page, perPage: 200 });
    if (error || !data?.users?.length) break;
    for (const u of data.users) {
      if (u.email) existing.set(u.email.toLowerCase(), u.id);
      existingIds.add(u.id);
    }
    if (data.users.length < 200) break;
  }

  const authSource: Array<Record<string, any>> = Array.isArray(raw?.authUsers) ? raw.authUsers : [];
  // se o backup não tiver authUsers, derivar dos perfis
  if (!authSource.length) {
    for (const p of (tables.user_profiles ?? []) as any[]) {
      if (p?.user_id) authSource.push({ id: p.user_id, email: p.email, user_metadata: { full_name: p.full_name } });
    }
  }

  const idMap = new Map<string, string>();
  let createdUsers = 0;
  let restoredPasswords = 0;
  const authErrors: string[] = [];

  for (const au of authSource) {
    const email = typeof au.email === "string" ? au.email.toLowerCase() : null;
    const oldId = typeof au.id === "string" ? au.id : null;
    const hash = typeof au.encrypted_password === "string" && au.encrypted_password.length > 10
      ? au.encrypted_password
      : null;
    const meta = au.raw_user_meta_data ?? au.user_metadata ?? {};

    // conta já existente: reforça a senha original do backup (nada é alterado)
    const targetId = oldId && existingIds.has(oldId)
      ? oldId
      : (email && existing.has(email) ? existing.get(email)! : null);

    if (targetId) {
      if (oldId && oldId !== targetId) idMap.set(oldId, targetId);
      if (hash) {
        const { error: upErr } = await admin.auth.admin.updateUserById(targetId, {
          password_hash: hash,
          email_confirm: true,
          user_metadata: meta,
        } as never);
        if (!upErr) restoredPasswords++;
        else if (authErrors.length < 5) authErrors.push(`${email ?? targetId}: ${upErr.message?.slice(0, 100)}`);
      }
      continue;
    }
    if (!email) continue;

    const payload: Record<string, unknown> = {
      email,
      email_confirm: true,
      user_metadata: meta,
    };
    // preserva a senha exacta; a padrão só entra se o backup não trouxer credenciais
    if (hash) payload.password_hash = hash;
    else payload.password = DEFAULT_PASSWORD;
    if (oldId) payload.id = oldId;

    let { data: created, error } = await admin.auth.admin.createUser(payload as never);
    if (error && hash) {
      delete payload.password_hash;
      payload.password = DEFAULT_PASSWORD;
      const retryHash = await admin.auth.admin.createUser(payload as never);
      created = retryHash.data; error = retryHash.error;
    }
    if (error && oldId) {
      // alguns ambientes não aceitam id fixo — cria sem id e remapeia
      delete payload.id;
      const retry = await admin.auth.admin.createUser(payload as never);
      created = retry.data; error = retry.error;
      if (created?.user && oldId && created.user.id !== oldId) idMap.set(oldId, created.user.id);
    }
    if (created?.user) {
      createdUsers++;
      if (hash) restoredPasswords++;
      existingIds.add(created.user.id);
      existing.set(email, created.user.id);
    } else if (error && authErrors.length < 5) {
      authErrors.push(`${email}: ${error.message?.slice(0, 100)}`);
    }
  }

  const remap = (v: unknown) => (typeof v === "string" && idMap.has(v) ? idMap.get(v)! : v);
  const USER_COLS = ["user_id", "usuario_mae_id", "agente_id", "issued_by", "target_user_id", "enviado_por", "registrado_por", "resgatado_por", "criado_por", "sender_id", "receiver_id", "validado_por", "submetido_por"];

  // 2) restaurar dados
  const summary: Array<{ table: string; imported: number; failed: number; error?: string | null }> = [];
  for (const table of TABLES) {
    const rows = tables[table];
    if (!rows?.length) continue;

    const prepared = rows.map((r) => {
      const row: Record<string, unknown> = { ...r };
      for (const c of USER_COLS) if (c in row) row[c] = remap(row[c]);
      if (!row.id) row.id = crypto.randomUUID();
      for (const [k, v] of Object.entries(row)) if (v === "") row[k] = null;
      return row;
    });

    // lotes de 200
    let imported = 0; let failed = 0; let lastError: string | null = null;
    for (let i = 0; i < prepared.length; i += 200) {
      const res = await tolerantUpsert(admin, table, prepared.slice(i, i + 200));
      imported += res.ok; failed += res.failed;
      if (res.error) lastError = res.error;
    }
    summary.push({ table, imported, failed, error: lastError });
  }

  // 3) garantir contas operacionais (perfis activos e papéis coerentes)
  for (const p of (tables.user_profiles ?? []) as any[]) {
    const uid = remap(p?.user_id) as string | undefined;
    if (!uid || !p?.role) continue;
    await admin.from("user_roles").upsert({ user_id: uid, role: p.role }, { onConflict: "user_id,role" });
  }

  return {
    success: true,
    createdUsers,
    restoredPasswords,
    authErrors,
    summary,
    importedTables: summary.filter((s) => s.imported > 0).length,
    totalImportedRows: summary.reduce((s, i) => s + i.imported, 0),
    totalFailedRows: summary.reduce((s, i) => s + i.failed, 0),
    defaultPassword: createdUsers > restoredPasswords ? DEFAULT_PASSWORD : null,
  };
}
