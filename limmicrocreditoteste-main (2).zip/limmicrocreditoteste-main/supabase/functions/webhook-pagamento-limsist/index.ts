// Webhook público chamado pelo limsist.site quando um pagamento é confirmado.
// Segurança: header `x-webhook-secret` deve corresponder a LIMSIST_WEBHOOK_SECRET.
// Payload esperado (JSON):
// { email: string, valor: number, codigo_transacao: string, pacote?: string, metodo?: string }
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-webhook-secret",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const secret = Deno.env.get("LIMSIST_WEBHOOK_SECRET");
    const provided = req.headers.get("x-webhook-secret");
    if (!secret || provided !== secret) {
      return json({ success: false, error: "unauthorized" }, 401);
    }

    const body = await req.json().catch(() => ({}));
    const email = String(body.email || "").trim().toLowerCase();
    const valor = Number(body.valor || body.amount || 0);
    const codigo = String(body.codigo_transacao || body.transaction_id || body.reference || "").trim();
    const pacoteHint = String(body.pacote || body.package || "").trim();
    const metodo = String(body.metodo || body.method || "limsist").trim();

    if (!email || !valor || !codigo) {
      return json({ success: false, error: "missing_fields", required: ["email","valor","codigo_transacao"] }, 400);
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Audit log
    const { data: logRow } = await supabase
      .from("webhook_pagamentos_recebidos")
      .insert({ email, valor, codigo_transacao: codigo, pacote_nome: pacoteHint, payload: body })
      .select("id").single();
    const logId = logRow?.id;

    const fail = async (msg: string, status = 400) => {
      if (logId) await supabase.from("webhook_pagamentos_recebidos").update({ erro: msg }).eq("id", logId);
      return json({ success: false, error: msg }, status);
    };

    // Idempotência - mesmo código já processado?
    const { data: existing } = await supabase
      .from("subscription_requests")
      .select("id, status")
      .eq("codigo_submetido", codigo)
      .eq("status", "aprovado")
      .maybeSingle();
    if (existing) {
      if (logId) await supabase.from("webhook_pagamentos_recebidos").update({ processado: true, erro: "duplicate" }).eq("id", logId);
      return json({ success: true, duplicated: true });
    }

    // Encontrar utilizador pelo email
    const { data: profile } = await supabase
      .from("user_profiles")
      .select("user_id, full_name, email, expires_at")
      .ilike("email", email)
      .maybeSingle();
    if (!profile) return await fail("user_not_found", 404);

    // Encontrar pacote pelo preço (ou pelo nome se vier no payload)
    const { data: pacotes } = await supabase
      .from("pacotes_plataforma").select("*").eq("ativo", true);
    let pacote = pacotes?.find((p: any) =>
      pacoteHint && p.nome.toLowerCase() === pacoteHint.toLowerCase()
    ) || pacotes?.find((p: any) => Number(p.preco) === valor);
    if (!pacote) return await fail("pacote_not_found_for_value");

    const dias = Number(pacote.duracao_dias);
    const baseDate = profile.expires_at && new Date(profile.expires_at) > new Date()
      ? new Date(profile.expires_at) : new Date();
    const dataFim = new Date(baseDate.getTime() + dias * 24 * 60 * 60 * 1000);

    // Criar request aprovado (mantém o painel do superadmin coerente)
    const { data: subReq, error: reqErr } = await supabase
      .from("subscription_requests")
      .insert({
        user_id: profile.user_id,
        plano: pacote.nome,
        valor_esperado: pacote.preco,
        metodo_pagamento: metodo,
        codigo_submetido: codigo,
        status: "aprovado",
      })
      .select("id").single();
    if (reqErr) return await fail("request_insert_failed: " + reqErr.message, 500);

    // Criar subscription activa
    await supabase.from("subscriptions").insert({
      user_id: profile.user_id,
      plano: pacote.nome,
      data_fim: dataFim.toISOString(),
      status: "activo",
      request_id: subReq.id,
    });

    // Activar conta
    await supabase.from("user_profiles").update({
      status: "active",
      expires_at: dataFim.toISOString(),
      usage_days: dias,
    }).eq("user_id", profile.user_id);

    // Histórico de renovações
    await supabase.from("historico_renovacoes").insert({
      user_id: profile.user_id,
      tipo: "automatico",
      pacote_nome: pacote.nome,
      dias_adicionados: dias,
      data_inicio: baseDate.toISOString(),
      data_fim: dataFim.toISOString(),
      valor: pacote.preco,
      observacoes: `Pagamento confirmado via webhook limsist.site (cód: ${codigo})`,
    });

    // Notificar utilizador
    await supabase.from("notificacoes").insert({
      user_id: profile.user_id,
      titulo: "✅ Pagamento confirmado",
      mensagem: `O seu pacote ${pacote.nome} foi activado. Acesso válido até ${dataFim.toLocaleDateString("pt-PT")}.`,
      tipo: "success",
    });

    // Notificar superadmin
    const { data: sa } = await supabase.from("user_roles").select("user_id").eq("role", "superadmin").limit(1).maybeSingle();
    if (sa?.user_id) {
      await supabase.from("notificacoes").insert({
        user_id: sa.user_id,
        titulo: "💰 Novo pagamento recebido (limsist.site)",
        mensagem: `${profile.full_name || email} pagou ${pacote.preco} MT - pacote ${pacote.nome}. Cód: ${codigo}`,
        tipo: "info",
      });
    }

    if (logId) await supabase.from("webhook_pagamentos_recebidos").update({ processado: true, user_id: profile.user_id }).eq("id", logId);

    return json({ success: true, expires_at: dataFim.toISOString(), pacote: pacote.nome });
  } catch (e) {
    return json({ success: false, error: (e as Error).message }, 500);
  }
});

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
