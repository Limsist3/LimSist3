import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function json(body: any, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function normalizePhone(phone: string): string {
  const digits = phone.replace(/\D/g, "");
  if (digits.length === 9) return `258${digits}`;
  if (digits.length === 11 && digits.startsWith("258")) return digits;
  return digits;
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") || "";
    const HEXMO_API_KEY = Deno.env.get("HEXMO_API_KEY") || "";
    const HEXMO_SENDER_ID = Deno.env.get("HEXMO_SENDER_ID") || "HEXMO";

    const token = req.headers.get("authorization")?.replace("Bearer ", "");
    if (!token) return json({ error: "Autenticação requerida" }, 401);

    const supabaseAuth = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: { autoRefreshToken: false, persistSession: false },
    });
    const { data: { user } } = await supabaseAuth.auth.getUser(token);
    if (!user) return json({ error: "Utilizador não autenticado" }, 401);

    const body = await req.json().catch(() => ({}));
    const tipo = String(body?.tipo || "");
    if (!["sms_recarga", "subscricao"].includes(tipo)) {
      return json({ error: "Tipo inválido" }, 400);
    }
    const pacote = String(body?.pacote || "").slice(0, 60);
    const valor = Number(body?.valor || 0);
    const metodo = String(body?.metodo || "").slice(0, 20);

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const [{ data: config }, { data: profile }] = await Promise.all([
      supabase.from("configuracao_pagamento").select("numero_notificacoes").maybeSingle(),
      supabase.from("user_profiles").select("full_name, telefone, email").eq("user_id", user.id).maybeSingle(),
    ]);

    const destino = (config as any)?.numero_notificacoes;
    if (!destino) {
      // Sem número configurado: não é erro para o utilizador, o pedido fica pendente no painel
      return json({ success: false, skipped: true, error: "Número de notificações não configurado" });
    }
    if (!HEXMO_API_KEY) {
      return json({ success: false, skipped: true, error: "Gateway SMS não configurado" });
    }

    const nome = (profile as any)?.full_name || (profile as any)?.email || user.email || "Utilizador";
    const contacto = (profile as any)?.telefone || "";
    const titulo = tipo === "sms_recarga" ? "PEDIDO RECARGA SMS" : "PEDIDO SUBSCRICAO";
    const mensagem = [
      `${titulo}`,
      `Cliente: ${nome}`,
      contacto ? `Tel: ${contacto}` : null,
      pacote ? `Pacote: ${pacote}` : null,
      valor ? `Valor: ${valor} MT` : null,
      metodo ? `Metodo: ${metodo}` : null,
      "Aprove no painel de superadministrador.",
    ].filter(Boolean).join("\n");

    const response = await fetch("https://hexmo.net/api/v3/sms/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": `Bearer ${HEXMO_API_KEY}`,
      },
      body: JSON.stringify({
        recipient: normalizePhone(destino),
        sender_id: HEXMO_SENDER_ID,
        type: "plain",
        message: mensagem,
      }),
    });

    const text = await response.text();
    let parsed: any = {};
    try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
    const failed = parsed?.success === false || (typeof parsed?.status === "string" && /fail|error/i.test(parsed.status));
    const ok = response.ok && !failed;

    if (!ok) {
      console.error(`[notificar-pedido-superadmin] Hexmo ${response.status}: ${text.slice(0, 300)}`);
    }

    return json({ success: ok, status: response.status, details: ok ? undefined : text.slice(0, 300) });
  } catch (e: any) {
    console.error("[notificar-pedido-superadmin] Error:", e);
    return json({ error: e.message || "Erro desconhecido" }, 500);
  }
});
