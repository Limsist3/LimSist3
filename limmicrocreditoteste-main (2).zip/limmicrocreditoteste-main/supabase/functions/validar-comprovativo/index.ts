import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    // Sem IA disponível (chave ausente/créditos esgotados) o fluxo continua:
    // o comprovativo segue para revisão manual em vez de falhar.
    const aiDisponivel = !!LOVABLE_API_KEY;

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { pagamento_id, imagem_url, valor_esperado, codigo_transacao } = await req.json();

    if (!pagamento_id || !imagem_url) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Validate file is an image (not PDF or other unsupported format)
    const urlLower = imagem_url.toLowerCase();
    const supportedExtensions = ['.png', '.jpg', '.jpeg', '.webp', '.gif'];
    const isImage = supportedExtensions.some(ext => urlLower.includes(ext));
    if (!isImage) {
      // Update payment status to manual review
      const SUPABASE_URL_CHECK = Deno.env.get("SUPABASE_URL")!;
      const SUPABASE_KEY_CHECK = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
      const sbCheck = createClient(SUPABASE_URL_CHECK, SUPABASE_KEY_CHECK);
      
      await sbCheck.from("pagamentos_plataforma").update({
        status: "pendente",
        motivo_rejeicao: "Formato de ficheiro não suportado para validação automática. Será analisado manualmente.",
        updated_at: new Date().toISOString(),
      }).eq("id", pagamento_id);

      return new Response(JSON.stringify({ 
        aprovado: false, 
        score: 0, 
        checks: ["✘ Formato de ficheiro não suportado para OCR. Apenas imagens (PNG, JPEG, WebP, GIF) são aceites para validação automática.", "ℹ O comprovativo será analisado manualmente pelo administrador."],
        manual_review: true
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch config
    const { data: config } = await supabase
      .from("configuracao_pagamento")
      .select("*")
      .limit(1)
      .single();

    const tempoMaxMin = config?.tempo_maximo_pagamento_min || 20;
    const scoreMinimo = config?.score_minimo || 70;
    const tempoValidacaoHoras = config?.tempo_validacao_horas || 48;

    if (!aiDisponivel) {
      await supabase.from("pagamentos_plataforma").update({
        status: "pendente",
        motivo_rejeicao: "Validação automática indisponível. Será analisado manualmente.",
        updated_at: new Date().toISOString(),
      }).eq("id", pagamento_id);

      return new Response(JSON.stringify({
        aprovado: false,
        score: 0,
        ai_unavailable: true,
        manual_review: true,
        checks: ["ℹ Validação automática por imagem temporariamente indisponível.", "ℹ O comprovativo será analisado manualmente pelo administrador."],
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Call Lovable AI to analyze the receipt image
    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: `You are an OCR specialist that analyzes mobile payment receipts (M-Pesa, e-Mola) from Mozambique. 
Extract the following from the image and return ONLY a JSON object (no markdown):
{
  "id_transacao": "transaction ID found",
  "valor": numeric value found,
  "data": "date found in ISO format",
  "texto_completo": "full text extracted",
  "contem_padrao_oficial": true/false (if it looks like an official receipt),
  "codigo_interno_encontrado": "internal code if found, or null"
}`
          },
          {
            role: "user",
            content: [
              { type: "text", text: `Analyze this payment receipt. Expected value: ${valor_esperado} MZN. Internal code to look for: ${codigo_transacao}` },
              { type: "image_url", image_url: { url: imagem_url } }
            ]
          }
        ],
        tools: [{
          type: "function",
          function: {
            name: "extract_receipt_data",
            description: "Extract structured data from a payment receipt image",
            parameters: {
              type: "object",
              properties: {
                id_transacao: { type: "string", description: "Transaction ID from the receipt" },
                valor: { type: "number", description: "Payment amount in MZN" },
                data: { type: "string", description: "Transaction date in ISO format" },
                texto_completo: { type: "string", description: "Full text extracted from receipt" },
                contem_padrao_oficial: { type: "boolean", description: "Whether receipt appears official" },
                codigo_interno_encontrado: { type: "string", description: "Internal code found, or empty" }
              },
              required: ["id_transacao", "valor", "data", "texto_completo", "contem_padrao_oficial"]
            }
          }
        }],
        tool_choice: { type: "function", function: { name: "extract_receipt_data" } }
      }),
    });

    if (!aiResponse.ok) {
      const errText = await aiResponse.text();
      console.error("AI error:", aiResponse.status, errText);

      // Degradação suave: sem IA o comprovativo segue para revisão manual
      await supabase.from("pagamentos_plataforma").update({
        status: "pendente",
        motivo_rejeicao: "Validação automática indisponível. Será analisado manualmente.",
        updated_at: new Date().toISOString(),
      }).eq("id", pagamento_id);

      return new Response(JSON.stringify({
        aprovado: false,
        score: 0,
        ai_unavailable: true,
        manual_review: true,
        checks: ["ℹ Validação automática por imagem temporariamente indisponível.", "ℹ O comprovativo será analisado manualmente pelo administrador."],
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const aiResult = await aiResponse.json();
    let ocrData: any;

    try {
      const toolCall = aiResult.choices?.[0]?.message?.tool_calls?.[0];
      if (toolCall) {
        ocrData = JSON.parse(toolCall.function.arguments);
      } else {
        // Fallback: try parsing from content
        const content = aiResult.choices?.[0]?.message?.content || "";
        ocrData = JSON.parse(content);
      }
    } catch {
      ocrData = { id_transacao: "", valor: 0, data: "", texto_completo: "", contem_padrao_oficial: false };
    }

    // Calculate validation score
    let score = 0;
    const checks: string[] = [];

    // 1. Value matches (30 points)
    if (ocrData.valor && Math.abs(ocrData.valor - valor_esperado) < 1) {
      score += 30;
      checks.push("✔ Valor corresponde");
    } else {
      checks.push(`✘ Valor não corresponde (encontrado: ${ocrData.valor}, esperado: ${valor_esperado})`);
    }

    // 2. Recent date (20 points)
    if (ocrData.data) {
      const receiptDate = new Date(ocrData.data);
      const now = new Date();
      const diffMin = (now.getTime() - receiptDate.getTime()) / (1000 * 60);
      if (diffMin <= tempoMaxMin) {
        score += 20;
        checks.push("✔ Data recente");
      } else {
        checks.push(`✘ Data não recente (${Math.round(diffMin)} min atrás)`);
      }
    }

    // 3. Transaction ID not empty (15 points)
    if (ocrData.id_transacao && ocrData.id_transacao.length > 3) {
      score += 15;
      checks.push("✔ ID transação encontrado");

      // Check if ID was already used
      const { data: existing } = await supabase
        .from("pagamentos_plataforma")
        .select("id")
        .eq("id_transacao_externo", ocrData.id_transacao)
        .neq("id", pagamento_id)
        .limit(1);

      if (existing && existing.length > 0) {
        score -= 30;
        checks.push("✘ ID transação já utilizado!");
      } else {
        checks.push("✔ ID transação único");
      }
    }

    // 4. Official pattern (20 points)
    if (ocrData.contem_padrao_oficial) {
      score += 20;
      checks.push("✔ Padrão oficial detectado");
    }

    // 5. Internal code found (15 points)
    if (ocrData.codigo_interno_encontrado && ocrData.codigo_interno_encontrado.includes(codigo_transacao)) {
      score += 15;
      checks.push("✔ Código interno encontrado");
    } else {
      checks.push("✘ Código interno não encontrado");
    }

    score = Math.max(0, Math.min(100, score));
    const aprovado = score >= scoreMinimo;

    // Update payment record
    const updateData: any = {
      score,
      ocr_resultado: { ...ocrData, checks, score },
      id_transacao_externo: ocrData.id_transacao || null,
      updated_at: new Date().toISOString(),
    };

    if (aprovado) {
      updateData.status = "temporario";
      updateData.data_limite_validacao = new Date(Date.now() + tempoValidacaoHoras * 60 * 60 * 1000).toISOString();
    } else {
      updateData.status = "rejeitado_auto";
      updateData.motivo_rejeicao = `Score automático insuficiente: ${score}/${scoreMinimo}. ${checks.filter(c => c.startsWith("✘")).join("; ")}`;
    }

    await supabase
      .from("pagamentos_plataforma")
      .update(updateData)
      .eq("id", pagamento_id);

    // Payment approved by OCR but requires superadmin manual activation
    // The superadmin must review and activate the user from the Administration page
    if (aprovado) {
      // Send notification to superadmins about pending payment approval
      const { data: superadmins } = await supabase
        .from("user_roles")
        .select("user_id")
        .eq("role", "superadmin");

      const { data: pagamentoInfo } = await supabase
        .from("pagamentos_plataforma")
        .select("user_id")
        .eq("id", pagamento_id)
        .single();

      const { data: userProfile } = pagamentoInfo ? await supabase
        .from("user_profiles")
        .select("full_name, email")
        .eq("user_id", pagamentoInfo.user_id)
        .single() : { data: null };

      if (superadmins && superadmins.length > 0) {
        for (const admin of superadmins) {
          await supabase.from("notificacoes").insert({
            user_id: admin.user_id,
            titulo: "Pagamento pendente de aprovação",
            mensagem: `O utilizador ${userProfile?.full_name || userProfile?.email || 'desconhecido'} enviou um comprovativo de pagamento (Score: ${score}). Acesse a Administração para aprovar e ativar a conta.`,
            tipo: "alerta",
            enviado_por: pagamentoInfo?.user_id || null,
          });
        }
      }
    }

    return new Response(JSON.stringify({ 
      aprovado, 
      score, 
      checks,
      ocr_data: ocrData 
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("Error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
