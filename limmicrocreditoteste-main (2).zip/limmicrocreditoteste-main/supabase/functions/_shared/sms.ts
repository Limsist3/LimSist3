import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

export interface SendSmsInput {
  user_id: string;
  telefone: string;
  mensagem: string;
  nome_remetente?: string;
  tipo?: string;
  cliente_id?: string;
  emprestimo_id?: string;
  referencia_data?: string;
}

function normalizePhone(phone: string): string {
  const digits = phone.replace(/\D/g, "");
  if (digits.length === 9) return `+258${digits}`;
  if (digits.length === 11 && digits.startsWith("258")) return `+${digits}`;
  if (digits.startsWith("+")) return digits;
  return digits;
}

export async function sendSms(
  supabase: ReturnType<typeof createClient>,
  input: SendSmsInput,
  hexmoApiKey: string,
  defaultSenderId: string
): Promise<{ success: boolean; providerId?: string; error?: string; status?: string }> {
  const to = normalizePhone(input.telefone);
  if (!to || to.length < 9) {
    return { success: false, error: "Número de telefone inválido" };
  }

  const senderId = input.nome_remetente || defaultSenderId || "HEXMO";
  const message = input.mensagem.trim();
  if (!message) {
    return { success: false, error: "Mensagem vazia" };
  }

  // 1. Consumir saldo (bloqueia linha para evitar race)
  const { data: consumeResult } = await supabase.rpc("sms_consumir", {
    p_user_id: input.user_id,
    p_quantidade: 1,
  });

  if (!consumeResult || consumeResult.success === false) {
    return {
      success: false,
      error: consumeResult?.error || "Sem saldo de SMS",
      status: "sem_saldo",
    };
  }

  // 2. Enviar via Hexmo (API v3 - Bearer token)
  try {
    const response = await fetch("https://hexmo.net/api/v3/sms/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": `Bearer ${hexmoApiKey}`,
      },
      body: JSON.stringify({
        recipient: to.replace(/\+/g, ""),
        sender_id: senderId,
        type: "plain",
        message,
      }),
    });

    const responseText = await response.text();
    let responseBody: any = {};
    try {
      responseBody = JSON.parse(responseText);
    } catch {
      responseBody = { raw: responseText };
    }

    const providerFailed =
      responseBody?.success === false ||
      (typeof responseBody?.status === "string" && /fail|error/i.test(responseBody.status));
    const ok = response.ok && !providerFailed;

    const status = ok ? "enviado" : "falhou";
    const error = ok ? undefined : `Hexmo ${response.status}: ${responseText.slice(0, 300)}`;
    const providerId = responseBody?.data?.uid || responseBody?.message_id || responseBody?.id;


    // 3. Log no histórico
    await supabase.from("sms_envios").insert({
      user_id: input.user_id,
      cliente_id: input.cliente_id || null,
      emprestimo_id: input.emprestimo_id || null,
      telefone: to,
      mensagem: message,
      tipo: input.tipo || "manual",
      referencia_data: input.referencia_data || null,
      status,
      erro: error || null,
    });

    if (!ok) {
      // Reembolsar o saldo debitado em caso de falha técnica
      await supabase.rpc("sms_creditar", {
        p_user_id: input.user_id,
        p_quantidade: 1,
        p_dias: 0,
      });
    }

    return {
      success: ok,
      providerId,
      error,
      status,
    };
  } catch (err: any) {
    // Em caso de exceção de rede, loga falha e devolve saldo
    await supabase.from("sms_envios").insert({
      user_id: input.user_id,
      cliente_id: input.cliente_id || null,
      emprestimo_id: input.emprestimo_id || null,
      telefone: to,
      mensagem: message,
      tipo: input.tipo || "manual",
      referencia_data: input.referencia_data || null,
      status: "falhou",
      erro: err.message || "Erro de rede",
    });

    await supabase.rpc("sms_creditar", {
      p_user_id: input.user_id,
      p_quantidade: 1,
      p_dias: 0,
    });

    return {
      success: false,
      error: err.message || "Erro ao enviar SMS",
      status: "falhou",
    };
  }
}
