import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { sendSms } from "../_shared/sms.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function json(body: any, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const HEXMO_API_KEY = Deno.env.get("HEXMO_API_KEY") || "";
    const HEXMO_SENDER_ID = Deno.env.get("HEXMO_SENDER_ID") || "LIMSist";

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const authHeader = req.headers.get("authorization")?.replace("Bearer ", "");
    if (!authHeader) {
      return json({ error: "Autenticação requerida" }, 401);
    }

    const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") || "";
    const supabaseAuth = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: { autoRefreshToken: false, persistSession: false },
    });
    const { data: { user } } = await supabaseAuth.auth.getUser(authHeader);
    if (!user) {
      return json({ error: "Utilizador não autenticado" }, 401);
    }

    const body = await req.json();
    const { telefone, mensagem, cliente_id, emprestimo_id, referencia_data, tipo } = body;

    if (!telefone || !mensagem) {
      return json({ error: "Telefone e mensagem são obrigatórios" }, 400);
    }

    if (!HEXMO_API_KEY) {
      return json({ error: "Gateway SMS não configurado" }, 503);
    }

    const { data: config } = await supabase
      .from("sms_config")
      .select("nome_remetente")
      .eq("user_id", user.id)
      .maybeSingle();

    const result = await sendSms(
      supabase,
      {
        user_id: user.id,
        telefone,
        mensagem,
        nome_remetente: config?.nome_remetente,
        tipo: tipo || "manual",
        cliente_id,
        emprestimo_id,
        referencia_data,
      },
      HEXMO_API_KEY,
      HEXMO_SENDER_ID,
    );

    return json(result, result.success ? 200 : 400);
  } catch (e: any) {
    console.error("[enviar-sms] Error:", e);
    return json({ error: e.message || "Erro desconhecido" }, 500);
  }
});
