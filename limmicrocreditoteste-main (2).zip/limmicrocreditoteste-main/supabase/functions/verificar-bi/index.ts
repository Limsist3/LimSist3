import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "https://limsistema.vercel.app",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS, PUT, DELETE",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { user_id, bi_url, full_name } = await req.json();

    if (!full_name || !bi_url) {
      return new Response(
        JSON.stringify({ match: false, error: "Nome e URL do BI são obrigatórios" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 400 }
      );
    }

    // Use Lovable AI to analyze the BI document
    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");
    
    if (!lovableApiKey) {
      // Fallback: return that automatic verification is not available
      return new Response(
        JSON.stringify({ 
          match: false, 
          error: "Verificação automática não disponível. Use verificação manual.",
          extracted_name: null,
          manual_review: true
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Call AI to extract name from BI image
    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${lovableApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `Analisa este documento de identificação (BI - Bilhete de Identidade de Moçambique). 
                Extrai APENAS o nome completo que aparece no documento. 
                Responde APENAS com o nome completo, sem mais nada. 
                Se não conseguires ler o nome, responde com "ILEGÍVEL".`
              },
              {
                type: "image_url",
                image_url: { url: bi_url }
              }
            ]
          }
        ],
        max_tokens: 200,
      }),
    });

    if (!aiResponse.ok) {
      const status = aiResponse.status;
      const semCreditos = status === 402 || status === 429;
      return new Response(
        JSON.stringify({
          match: false,
          error: semCreditos
            ? "Verificação automática temporariamente indisponível. Será verificado manualmente."
            : "Erro na análise do documento",
          extracted_name: null,
          manual_review: true,
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const aiData = await aiResponse.json();
    const extractedName = aiData.choices?.[0]?.message?.content?.trim() || "ILEGÍVEL";

    if (extractedName === "ILEGÍVEL") {
      return new Response(
        JSON.stringify({ match: false, extracted_name: "ILEGÍVEL", error: "Nome não legível no documento" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Compare names (case-insensitive, normalize spaces)
    const normalize = (name: string) => 
      name.toLowerCase().trim().replace(/\s+/g, " ").normalize("NFD").replace(/[\u0300-\u036f]/g, "");

    const normalizedExtracted = normalize(extractedName);
    const normalizedFullName = normalize(full_name);

    // Check if names match (exact or one contains the other)
    const match = normalizedExtracted === normalizedFullName || 
                  normalizedExtracted.includes(normalizedFullName) || 
                  normalizedFullName.includes(normalizedExtracted);

    return new Response(
      JSON.stringify({ match, extracted_name: extractedName }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ match: false, error: error.message, extracted_name: null }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
    );
  }
});
