import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    // Verificar autenticação do usuário
    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);

    if (userError || !user) {
      throw new Error('Não autenticado');
    }

    const { email, password, full_name, usuario_mae_id, role = 'agente' } = await req.json();

    // Validar role
    const LIMITES: Record<string, number> = {
      agente: 10,
      secretariado: 1,
      contabilista: 2,
      auditor: 2,
      visualizador: 5,
    };
    const validRoles = Object.keys(LIMITES);
    if (!validRoles.includes(role)) {
      return new Response(
        JSON.stringify({ error: 'Role inválido.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verificar limite por tipo de membro
    {
      const { count, error: countError } = await supabaseAdmin
        .from('user_profiles')
        .select('*', { count: 'exact', head: true })
        .eq('usuario_mae_id', usuario_mae_id)
        .eq('role', role);

      if (!countError && (count || 0) >= LIMITES[role]) {
        return new Response(
          JSON.stringify({ error: `Limite de ${LIMITES[role]} ${role}(s) atingido.` }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Herdar "genética" do usuário mãe: expires_at + status (mesmo tempo de uso e data de expiração)
    const { data: maeProfile } = await supabaseAdmin
      .from('user_profiles')
      .select('expires_at, status')
      .eq('user_id', usuario_mae_id)
      .maybeSingle();
    const inheritedExpires = maeProfile?.expires_at ?? null;
    const inheritedStatus = maeProfile?.status ?? 'active';

    // Verificar se o email é igual ao do usuário mãe
    if (user.email && user.email.toLowerCase() === email.toLowerCase()) {
      return new Response(
        JSON.stringify({ error: `O email do ${role} deve ser diferente do email do usuário mãe. Use outro email.` }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verificar se o usuário já existe
    const { data: existingUsers, error: listError } = await supabaseAdmin.auth.admin.listUsers();
    
    if (listError) {
      console.error('Erro ao listar usuários:', listError);
      throw listError;
    }

    const existingUser = existingUsers.users.find(u => u.email === email);

    let agentUserId: string;
    let wasOriginallyUser = false;

    if (existingUser) {
      const { data: profileData, error: profileError } = await supabaseAdmin
        .from('user_profiles')
        .select('usuario_mae_id, role')
        .eq('user_id', existingUser.id)
        .maybeSingle();

      if (profileError) {
        console.error('Erro ao verificar perfil:', profileError);
        throw profileError;
      }

      if (profileData && profileData.usuario_mae_id && profileData.usuario_mae_id !== usuario_mae_id) {
        return new Response(
          JSON.stringify({ error: 'Este email já está vinculado a outro usuário. Use outro email.' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (profileData && profileData.role === 'user' && !profileData.usuario_mae_id) {
        wasOriginallyUser = true;
      }

      agentUserId = existingUser.id;

      const { error: updateError } = await supabaseAdmin
        .from('user_profiles')
        .update({
          full_name,
          usuario_mae_id,
          role,
          estado: 'Ativo',
          status: inheritedStatus,
          expires_at: inheritedExpires,
          ...(wasOriginallyUser && { was_user_mae: true })
        })
        .eq('user_id', existingUser.id);

      if (updateError) {
        console.error('Erro ao atualizar perfil:', updateError);
        throw updateError;
      }

    } else {
      const { data: newUserData, error: signUpError } = await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: {
          full_name,
        },
      });

      if (signUpError) {
        console.error('Erro ao criar usuário:', signUpError);
        throw signUpError;
      }

      if (!newUserData.user) {
        throw new Error('Erro ao criar usuário');
      }

      agentUserId = newUserData.user.id;

      await new Promise(resolve => setTimeout(resolve, 1000));

      const { error: updateError } = await supabaseAdmin
        .from('user_profiles')
        .update({
          full_name,
          usuario_mae_id,
          role,
          estado: 'Ativo',
          status: inheritedStatus,
          expires_at: inheritedExpires
        })
        .eq('user_id', agentUserId);

      if (updateError) {
        console.error('Erro ao atualizar perfil:', updateError);
        throw updateError;
      }
    }

    // Atualizar user_roles
    const { error: roleError } = await supabaseAdmin
      .from('user_roles')
      .upsert({
        user_id: agentUserId,
        role
      });

    if (roleError) {
      console.error('Erro ao atualizar role:', roleError);
    }

    const roleLabel = role;

    // Registrar atividade
    const { error: atividadeError } = await supabaseAdmin.rpc('registrar_atividade_agente', {
      p_agente_id: usuario_mae_id,
      p_descricao: `Cadastrou novo ${roleLabel}: ${full_name} (${email})${wasOriginallyUser ? ' [Era usuário mãe]' : ''}`
    });

    if (atividadeError) {
      console.error('Erro ao registrar atividade:', atividadeError);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        user_id: agentUserId,
        message: existingUser ? `Membro (${roleLabel}) vinculado com sucesso` : `Membro (${roleLabel}) criado com sucesso`
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error('Erro:', error);
    const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
