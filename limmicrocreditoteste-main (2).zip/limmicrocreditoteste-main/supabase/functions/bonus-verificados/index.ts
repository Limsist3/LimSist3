import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "https://limsistema.vercel.app",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS, PUT, DELETE",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    const now = new Date();
    const currentMonth = now.getMonth() + 1; // 1-12
    const isDecember = currentMonth === 12;

    const results: any[] = [];

    // Bónus de expiração (+1 dia) foi DESACTIVADO conforme decisão do produto.
    // Apenas o bónus anual de Dezembro permanece activo.

    // December bonus: +7 days for verified users (once per year)
    if (isDecember) {
      const { data: verifiedUsers, error: decError } = await supabase
        .from("user_profiles")
        .select("user_id, full_name, expires_at, verificado, status")
        .eq("verificado", true)
        .eq("status", "active");

      if (!decError && verifiedUsers) {
        for (const user of verifiedUsers) {
          // Check if already received December bonus this year
          const yearStart = `${now.getFullYear()}-12-01T00:00:00.000Z`;
          const { data: existingDecBonus } = await supabase
            .from("historico_renovacoes")
            .select("id")
            .eq("user_id", user.user_id)
            .eq("tipo", "automatico")
            .like("observacoes", "%Dezembro%")
            .gte("created_at", yearStart)
            .limit(1);

          if (existingDecBonus && existingDecBonus.length > 0) continue;

          const currentExpiry = new Date(user.expires_at);
          const newExpiry = new Date(currentExpiry.getTime() + 7 * 24 * 60 * 60 * 1000);

          await supabase
            .from("user_profiles")
            .update({ expires_at: newExpiry.toISOString() } as any)
            .eq("user_id", user.user_id);

          await supabase.from("historico_renovacoes").insert({
            user_id: user.user_id,
            tipo: "automatico",
            pacote_nome: "Bónus de Dezembro",
            dias_adicionados: 7,
            data_inicio: currentExpiry.toISOString(),
            data_fim: newExpiry.toISOString(),
            valor: 0,
            observacoes: `Bónus automático de Dezembro ${now.getFullYear()}: +7 dias grátis para conta verificada`,
          } as any);

          await supabase.from("notificacoes").insert({
            user_id: user.user_id,
            titulo: "🎄 Bónus de Dezembro!",
            mensagem: `Feliz Dezembro! Como tem conta verificada, oferecemos +7 dias grátis! Nova expiração: ${newExpiry.toLocaleDateString("pt-PT")}.`,
            tipo: "success",
            global: false,
          });

          results.push({ user_id: user.user_id, bonus: 7, reason: "december_bonus" });
        }
      }
    }

    return new Response(
      JSON.stringify({ success: true, processed: results.length, results }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
    );
  }
});
