import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Cutoff: 6 meses atrás
    const cutoff = new Date();
    cutoff.setMonth(cutoff.getMonth() - 6);
    const cutoffISO = cutoff.toISOString();

    // Buscar perfis inativos há mais de 6 meses (excluindo superadmins)
    const { data: inativos, error: selErr } = await supabase
      .from("user_profiles")
      .select("user_id, role, status, expires_at, updated_at")
      .neq("role", "superadmin")
      .eq("status", "inactive")
      .lt("expires_at", cutoffISO);

    if (selErr) throw selErr;

    const alvos = (inativos || []).filter((p: any) => {
      const ref = p.updated_at || p.expires_at;
      return ref && new Date(ref) < cutoff;
    });

    let apagados = 0;
    const erros: string[] = [];

    for (const p of alvos) {
      const uid = p.user_id;
      try {
        // Apagar dados relacionados (cascata manual em tabelas sem FK)
        await supabase.from("pagamentos").delete().eq("usuario_mae_id", uid);
        await supabase.from("emprestimos").delete().eq("user_id", uid);
        await supabase.from("clientes").delete().eq("user_id", uid);
        await supabase.from("despesas").delete().eq("user_id", uid);
        await supabase.from("arquivos").delete().eq("user_id", uid);
        await supabase.from("grupos_poupanca").delete().eq("user_id", uid);
        await supabase.from("contas_financeiras").delete().eq("user_id", uid);
        await supabase.from("movimentos_conta").delete().eq("user_id", uid);
        await supabase.from("entradas_capital").delete().eq("user_id", uid);
        await supabase.from("capital_global").delete().eq("user_id", uid);
        await supabase.from("capital_mensal").delete().eq("user_id", uid);
        await supabase.from("configuracoes_empresa").delete().eq("user_id", uid);
        await supabase.from("notificacoes").delete().eq("user_id", uid);
        await supabase.from("mensagens_chat").delete().or(`sender_id.eq.${uid},receiver_id.eq.${uid}`);
        await supabase.from("historico_renovacoes").delete().eq("user_id", uid);
        await supabase.from("link_ativacao_uso").delete().eq("user_id", uid);
        await supabase.from("user_roles").delete().eq("user_id", uid);
        await supabase.from("user_profiles").delete().eq("user_id", uid);

        // Apagar usuário do auth
        const { error: delAuthErr } = await supabase.auth.admin.deleteUser(uid);
        if (delAuthErr) throw delAuthErr;

        apagados++;
      } catch (e) {
        erros.push(`${uid}: ${String(e)}`);
        console.error(`Erro ao apagar ${uid}:`, e);
      }
    }

    return new Response(
      JSON.stringify({
        message: `Limpeza concluída: ${apagados} contas inativas (>6 meses) apagadas.`,
        candidatos: alvos.length,
        apagados,
        erros,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Erro geral:", error);
    return new Response(JSON.stringify({ error: String(error) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
