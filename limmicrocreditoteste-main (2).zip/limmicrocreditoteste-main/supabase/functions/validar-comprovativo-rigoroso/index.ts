// Validação rigorosa de comprovativos M-Pesa / e-Mola via IA multimodal
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "https://limsistema.vercel.app",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS, PUT, DELETE",
};

const SUPORTE = "856696100";
const MAX_AGE_MIN = 20;
const FUTURE_TOLERANCE_MIN = 5;
const AMOUNT_TOLERANCE = 0.5;
const ATTEMPT_WINDOW_MIN = 30;
const MAX_ATTEMPTS = 3;

const RX_MPESA = /^[A-Z0-9]{10,11}$/;
const RX_EMOLA = /^PP\d{6}\.\d{4}\.[A-Za-z]\d+$/;

function json(body: any, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function normalizeName(s: string) {
  return (s || "")
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function similarity(a: string, b: string): number {
  // Dice coefficient on bigrams
  if (!a || !b) return 0;
  if (a === b) return 1;
  const bigrams = (s: string) => {
    const r = new Set<string>();
    for (let i = 0; i < s.length - 1; i++) r.add(s.substring(i, i + 2));
    return r;
  };
  const A = bigrams(a), B = bigrams(b);
  let common = 0;
  for (const x of A) if (B.has(x)) common++;
  return (2 * common) / (A.size + B.size || 1);
}

function nameMatches(extracted: string, expected: string): boolean {
  if (!expected) return true; // sem configuração, não bloqueia
  if (!extracted) return false;
  const e = normalizeName(extracted);
  const x = normalizeName(expected);
  if (!e || !x) return false;
  if (x.includes("*")) return true;
  if (e === x) return true;
  const ew = e.split(" ").filter(Boolean);
  const xw = x.split(" ").filter(Boolean);
  // primeiro ou último nome bate
  if (xw[0] && ew.includes(xw[0])) return true;
  if (xw.length > 1 && ew.includes(xw[xw.length - 1])) return true;
  // parcialmente presente
  if (e.includes(x) || x.includes(e)) return true;
  // similaridade >= 0.6
  return similarity(e, x) >= 0.6;
}

function normalizeNumber(s: string) {
  return (s || "").replace(/\D/g, "").slice(-9);
}

async function uploadToStorage(supabase: any, userId: string, dataUrl: string): Promise<string | null> {
  try {
    const m = dataUrl.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
    if (!m) return null;
    const mime = m[1];
    const ext = mime.split("/")[1].replace("jpeg", "jpg");
    const bytes = Uint8Array.from(atob(m[2]), c => c.charCodeAt(0));
    const path = `${userId}/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("comprovativos").upload(path, bytes, { contentType: mime, upsert: false });
    if (error) { console.error("upload err:", error); return null; }
    return path;
  } catch (e) { console.error("upload exception:", e); return null; }
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabase = createClient(SUPABASE_URL, SERVICE_KEY);

    // Auth do utilizador
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json({ error: "Não autenticado" }, 401);
    const userClient = createClient(SUPABASE_URL, ANON_KEY, { global: { headers: { Authorization: authHeader } } });
    const { data: claims } = await userClient.auth.getClaims(authHeader.replace("Bearer ", ""));
    if (!claims?.claims?.sub) return json({ error: "Não autenticado" }, 401);
    const userId = claims.claims.sub as string;
    const userEmail = (claims.claims as any).email || null;

    const body = await req.json();
    const { pacote_id, metodo, image_data_url, customer_name } = body;
    if (!pacote_id || !metodo || !image_data_url) return json({ error: "Dados em falta" }, 400);
    if (!["mpesa", "emola"].includes(metodo)) return json({ error: "Método inválido" }, 400);

    // 1. Limite de tentativas
    const { data: att } = await supabase.from("payment_attempts")
      .select("*").eq("user_id", userId).eq("pacote_id", pacote_id).maybeSingle();
    const now = new Date();
    if (att?.blocked_until && new Date(att.blocked_until) > now) {
      return json({
        approved: false, rejected: true, code: "blocked",
        message: "Você atingiu o limite de tentativas. Entre em contacto com o suporte para continuar.",
        whatsapp: SUPORTE,
      });
    }
    let attemptCount = att?.attempt_count || 0;
    let windowStart = att?.window_started_at ? new Date(att.window_started_at) : now;
    if ((now.getTime() - windowStart.getTime()) > ATTEMPT_WINDOW_MIN * 60000) {
      attemptCount = 0; windowStart = now;
    }

    // 2. Carregar configuração + pacote
    const [{ data: pacote }, { data: config }] = await Promise.all([
      supabase.from("pacotes_plataforma").select("*").eq("id", pacote_id).maybeSingle(),
      supabase.from("configuracao_pagamento").select("*").maybeSingle(),
    ]);
    if (!pacote) return json({ error: "Pacote não encontrado" }, 404);
    if (!config) return json({ error: "Configuração de pagamento ausente" }, 500);

    const expectedAmount = Number(pacote.preco);
    const expectedNumber = metodo === "mpesa" ? config.numero_mpesa : config.numero_emola;
    const expectedName = metodo === "mpesa"
      ? (config.nome_titular_mpesa || config.nome_titular)
      : (config.nome_titular_emola || config.nome_titular);

    if (!expectedNumber) {
      return json({ error: "Número do destinatário não configurado para " + metodo }, 500);
    }

    // 3. Upload do screenshot
    const screenshotPath = await uploadToStorage(supabase, userId, image_data_url);

    // Helper para registar tentativa falhada
    const registerFailure = async (code: string, reason: string, extracted: any = null, fraudSuspected = false, fraudReason: string | null = null) => {
      attemptCount += 1;
      const blocked_until = attemptCount >= MAX_ATTEMPTS ? new Date(now.getTime() + ATTEMPT_WINDOW_MIN * 60000).toISOString() : null;
      await supabase.from("payment_attempts").upsert({
        user_id: userId, pacote_id, attempt_count: attemptCount,
        window_started_at: windowStart.toISOString(),
        blocked_until, last_reason: code, updated_at: now.toISOString(),
      }, { onConflict: "user_id,pacote_id" });

      await supabase.from("payment_proofs").insert({
        user_id: userId, pacote_id, customer_email: userEmail, customer_name,
        operator: metodo,
        transaction_id: extracted?.transaction_id || null,
        amount_paid: extracted?.amount ?? null,
        fee: extracted?.fee ?? 0,
        recipient_name: extracted?.recipient_name || null,
        recipient_number: extracted?.recipient_number || null,
        transaction_datetime: extracted?.transaction_datetime || null,
        screenshot_url: screenshotPath,
        ai_raw_response: extracted || null,
        fraud_suspected: fraudSuspected,
        fraud_reason: fraudReason,
        validation_status: "rejected",
        rejection_reason: reason,
        rejection_code: code,
        attempt_number: attemptCount,
        rejected_at: now.toISOString(),
      });

      const remaining = MAX_ATTEMPTS - attemptCount;
      const messages: Record<string, string> = {
        duplicate: "Este comprovativo já foi usado anteriormente. Envie um comprovativo novo.",
        expired: "Este comprovativo expirou. Envie um pagamento feito nos últimos 20 minutos.",
        amount_mismatch: "O valor pago não corresponde ao valor do plano seleccionado.",
        method_mismatch: "O método de pagamento do comprovativo não corresponde ao método seleccionado.",
        recipient_mismatch: "O pagamento foi enviado para uma conta diferente da conta configurada.",
        recipient_name_mismatch: "O nome do destinatário não corresponde ao titular configurado.",
        invalid_id: "O ID da transacção no comprovativo é inválido.",
        fraud: "Comprovativo suspeito de manipulação. Envie o screenshot original sem edições.",
        extraction_failed: "Não foi possível ler os dados do comprovativo. Envie um screenshot mais nítido.",
      };
      const baseMsg = messages[code] || "Não foi possível validar o comprovativo. Verifique se enviou o comprovativo correcto, recente e sem alterações.";
      let suffix = "";
      if (remaining === 1) suffix = " Último aviso: tem mais 1 tentativa.";
      else if (remaining <= 0) suffix = " Limite de tentativas atingido. Contacte o suporte.";

      return json({
        approved: false, rejected: true, code,
        message: baseMsg + suffix,
        attempts_left: Math.max(0, remaining),
        whatsapp: SUPORTE,
        extracted,
      });
    };

    // Alternativa SEM IA (créditos esgotados / IA indisponível):
    // o utilizador valida com o código de confirmação do SMS (validar_pagamento_manual).
    // Não conta como tentativa falhada e não bloqueia o utilizador.
    const aiUnavailable = (motivo: string) => {
      console.warn("[validar] IA indisponível:", motivo);
      return json({
        approved: false,
        ai_unavailable: true,
        code: "ai_unavailable",
        message: "Validação automática por imagem temporariamente indisponível. Introduza o código de confirmação do SMS para validar o pagamento.",
        whatsapp: SUPORTE,
        screenshot_url: screenshotPath,
      });
    };

    if (!LOVABLE_API_KEY) return aiUnavailable("LOVABLE_API_KEY ausente");

    // 4. IA multimodal — extracção + detecção de fraude
    const aiPrompt = `Analyze this Mozambican mobile payment SMS screenshot (M-Pesa or e-Mola). Return STRICT JSON via the tool.

EXAMPLES:
M-Pesa: "Confirmado DEM7K7LWS4Z. Transferiste 2.00MT e a taxa foi de 0.00MT para 844605098 - LUCIO aos 22/5/26 as 12:55 PM."
e-Mola: "ID da transacao PP260523.1323.q87917. Transferiste 1.00MT para conta 874183064, nome: PENARDINA LUCIA aas 13:23:00 de 23/05/2026. Taxa: 0.00MT."

CONVERT date/time to ISO 8601 with Mozambique timezone (UTC+2). Years like "26" mean 2026.

FRAUD DETECTION — set fraud_suspected=true ONLY when there is CLEAR visual evidence of manipulation:
- Different fonts/weights/sizes in critical fields (id, amount, time, date)
- Pixel halos, blurry edges, retouching on digits
- Background discontinuity behind critical fields
- Mismatched baseline alignment
- ID format clearly violates operator pattern
- Impossible date/time

DO NOT mark fraud for: OCR confusions (O/0, l/1, S/5, B/8, Z/2, G/6, Q/0, I/1), normal Android antialiasing, JPEG compression blur, multiple SMS visible (analyze the most recent), small kerning variance, lower vs upper case in e-Mola IDs (both are valid).`;

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: aiPrompt },
          { role: "user", content: [
            { type: "text", text: `Expected amount: ${expectedAmount} MZN. Expected operator: ${metodo}. Expected recipient number: ${expectedNumber}.` },
            { type: "image_url", image_url: { url: image_data_url } },
          ]},
        ],
        tools: [{ type: "function", function: {
          name: "extract_proof",
          description: "Extract payment proof data",
          parameters: {
            type: "object",
            properties: {
              transaction_id: { type: "string", description: "Transaction ID from SMS, exactly as shown" },
              amount: { type: "number", description: "Amount transferred in MZN" },
              fee: { type: "number", description: "Fee/taxa in MZN" },
              recipient_name: { type: "string", description: "Recipient name" },
              recipient_number: { type: "string", description: "Recipient phone number, digits only" },
              transaction_datetime: { type: "string", description: "ISO 8601 with timezone" },
              operator: { type: "string", enum: ["mpesa", "emola"] },
              fraud_suspected: { type: "boolean" },
              fraud_reason: { type: "string", description: "Detailed reason if fraud_suspected, else empty" },
              raw_text: { type: "string", description: "Full SMS text visible in screenshot" },
            },
            required: ["transaction_id", "amount", "recipient_number", "operator", "fraud_suspected"],
          },
        }}],
        tool_choice: { type: "function", function: { name: "extract_proof" } },
      }),
    });

    if (!aiRes.ok) {
      const t = await aiRes.text();
      console.error("AI error", aiRes.status, t);
      if (aiRes.status === 429 || aiRes.status === 402 || aiRes.status >= 500) {
        return aiUnavailable(`status ${aiRes.status}`);
      }
      return registerFailure("extraction_failed", "Falha na chamada à IA: " + t);
    }

    const aiData = await aiRes.json();
    let extracted: any = null;
    try {
      const tc = aiData.choices?.[0]?.message?.tool_calls?.[0];
      if (tc) extracted = JSON.parse(tc.function.arguments);
    } catch (e) { console.error("parse ai:", e); }

    if (!extracted || !extracted.transaction_id || !extracted.amount || !extracted.operator || !extracted.recipient_number) {
      return registerFailure("extraction_failed", "Dados essenciais não extraídos", extracted);
    }

    console.log("[validar] extracted:", JSON.stringify(extracted));

    // 5. Validações (ordem rigorosa)
    // 5.1 Método/operador
    if (extracted.operator !== metodo) {
      return registerFailure("method_mismatch", `Operador extraído (${extracted.operator}) ≠ seleccionado (${metodo})`, extracted);
    }

    // 5.2 Formato do ID
    const rx = metodo === "mpesa" ? RX_MPESA : RX_EMOLA;
    if (!rx.test(extracted.transaction_id)) {
      return registerFailure("invalid_id", `ID '${extracted.transaction_id}' não segue padrão ${metodo}`, extracted);
    }

    // 5.3 ID único
    const { data: existing } = await supabase.from("payment_proofs")
      .select("id").eq("transaction_id", extracted.transaction_id).eq("validation_status", "approved").limit(1);
    if (existing && existing.length > 0) {
      return registerFailure("duplicate", "ID de transacção já usado anteriormente", extracted);
    }

    // 5.4 Fraude visual
    if (extracted.fraud_suspected === true && extracted.fraud_reason) {
      return registerFailure("fraud", extracted.fraud_reason, extracted, true, extracted.fraud_reason);
    }

    // 5.5 Valor
    if (Math.abs(Number(extracted.amount) - expectedAmount) > AMOUNT_TOLERANCE) {
      return registerFailure("amount_mismatch", `Valor pago ${extracted.amount} ≠ esperado ${expectedAmount}`, extracted);
    }

    // 5.6 Data/hora
    if (!extracted.transaction_datetime) {
      return registerFailure("expired", "Data/hora ilegível", extracted);
    }
    const txDate = new Date(extracted.transaction_datetime);
    if (isNaN(txDate.getTime())) {
      return registerFailure("expired", "Data/hora inválida", extracted);
    }
    const diffMin = (now.getTime() - txDate.getTime()) / 60000;
    if (diffMin > MAX_AGE_MIN) {
      return registerFailure("expired", `Comprovativo com ${Math.round(diffMin)} min (máx ${MAX_AGE_MIN})`, extracted);
    }
    if (diffMin < -FUTURE_TOLERANCE_MIN) {
      return registerFailure("expired", `Data no futuro (${Math.round(-diffMin)} min)`, extracted);
    }

    // 5.7 Número do destinatário (match exacto últimos 9 dígitos)
    if (normalizeNumber(extracted.recipient_number) !== normalizeNumber(expectedNumber)) {
      return registerFailure("recipient_mismatch", `Número ${extracted.recipient_number} ≠ esperado ${expectedNumber}`, extracted);
    }

    // 5.8 Nome do destinatário (flexível)
    if (expectedName && !nameMatches(extracted.recipient_name || "", expectedName)) {
      return registerFailure("recipient_name_mismatch", `Nome '${extracted.recipient_name}' não corresponde a '${expectedName}'`, extracted);
    }

    // 6. APROVADO — inserir proof pending e chamar RPC atómica
    const { data: proofRow, error: proofErr } = await supabase.from("payment_proofs").insert({
      user_id: userId, pacote_id, customer_email: userEmail, customer_name,
      operator: metodo,
      transaction_id: extracted.transaction_id,
      amount_paid: extracted.amount,
      fee: extracted.fee || 0,
      recipient_name: extracted.recipient_name,
      recipient_number: extracted.recipient_number,
      transaction_datetime: txDate.toISOString(),
      screenshot_url: screenshotPath,
      ai_raw_response: extracted,
      fraud_suspected: false,
      validation_status: "pending",
    }).select("id").single();

    if (proofErr) {
      // Pode ser conflict no unique parcial (race condition) → tratar como duplicate
      if (proofErr.code === "23505") {
        return registerFailure("duplicate", "ID de transacção já usado (race)", extracted);
      }
      console.error("proof insert err:", proofErr);
      return json({ error: "Erro ao registar comprovativo" }, 500);
    }

    const { data: rpcRes, error: rpcErr } = await supabase.rpc("aprovar_pagamento_rigoroso", {
      p_user_id: userId,
      p_pacote_id: pacote_id,
      p_proof_id: proofRow.id,
      p_transaction_id: extracted.transaction_id,
      p_amount: extracted.amount,
      p_operator: metodo,
      p_paid_at: txDate.toISOString(),
    });

    if (rpcErr) {
      console.error("rpc err:", rpcErr);
      // rollback parcial: marcar proof como rejeitado para não ficar pending
      await supabase.from("payment_proofs").update({
        validation_status: "rejected",
        rejection_code: "activation_failed",
        rejection_reason: rpcErr.message,
        rejected_at: now.toISOString(),
      }).eq("id", proofRow.id);
      return json({ error: "Erro ao activar o plano: " + rpcErr.message }, 500);
    }

    return json({
      approved: true,
      message: "Pagamento confirmado com sucesso. O seu plano foi activado e o acesso já está disponível.",
      result: rpcRes,
    });
  } catch (e) {
    console.error("[validar-rigoroso] fatal:", e);
    return json({ error: e instanceof Error ? e.message : "Erro desconhecido" }, 500);
  }
});
