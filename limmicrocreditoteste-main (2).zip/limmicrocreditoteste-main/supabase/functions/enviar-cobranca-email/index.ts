import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface EmailCobrancaRequest {
  nome: string;
  email: string;
  valorDevido: number;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { nome, email, valorDevido }: EmailCobrancaRequest = await req.json();

    console.log(`Enviando email de cobrança para ${email}...`);

    const emailResponse = await resend.emails.send({
      from: "Sistema de Cobrança <onboarding@resend.dev>",
      to: [email],
      subject: "Lembrete de Pagamento em Atraso",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9;">
          <div style="background-color: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <h1 style="color: #d32f2f; margin-bottom: 20px;">Lembrete de Pagamento</h1>
            <p style="font-size: 16px; color: #333; margin-bottom: 15px;">Olá <strong>${nome}</strong>,</p>
            <p style="font-size: 16px; color: #333; margin-bottom: 15px;">
              Este é um lembrete amigável sobre o pagamento em atraso de seu empréstimo.
            </p>
            <div style="background-color: #fff3cd; padding: 15px; border-left: 4px solid #ffc107; margin: 20px 0;">
              <p style="margin: 0; font-size: 18px; color: #856404;">
                <strong>Valor em Atraso:</strong> ${valorDevido.toLocaleString('pt-MZ')} MT
              </p>
            </div>
            <p style="font-size: 16px; color: #333; margin-bottom: 15px;">
              Por favor, regularize sua situação o mais breve possível para evitar juros adicionais.
            </p>
            <p style="font-size: 16px; color: #333; margin-bottom: 15px;">
              Em caso de dúvidas, entre em contato conosco.
            </p>
            <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
            <p style="font-size: 14px; color: #666; margin: 0;">
              Atenciosamente,<br>
              <strong>Equipe de Gestão</strong>
            </p>
          </div>
        </div>
      `,
    });

    console.log("Email enviado com sucesso:", emailResponse);

    return new Response(JSON.stringify(emailResponse), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Erro ao enviar email:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
