import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Read body flexibly
    const body = await readBody(req);
    const mensagem = getString(body, [
      "mensagem",
      "sms_text",
      "smsText",
      "sms_message",
      "smsMessage",
      "message",
      "body",
      "text",
      "msg",
      "sms",
      "notification_text",
      "notificationText",
      "conteudo",
      "conteúdo",
      "texto",
    ]) || getFirstLongString(body);
    const metodoRaw = getString(body, ["metodo", "method", "provider"]) || "mpesa";
    const metodo = metodoRaw.toLowerCase().includes("emola") ? "emola" : "mpesa";

    const codigoFromBody = getString(body, [
      "codigo_transacao",
      "codigoTransacao",
      "codigo",
      "transaction_id",
      "transactionId",
      "txid",
      "ref",
      "reference",
      "id_transacao",
    ]);
    const valorFromBody = getNumber(body, ["valor", "amount", "value", "montante"]);
    const origemFromBody = normalizePhone(
      getString(body, ["numero_origem", "numeroOrigem", "origem", "from", "sender", "msisdn", "phone"]),
    );
    const destinoFromBody = normalizePhone(
      getString(body, ["numero_destino", "numeroDestino", "destino", "to", "recipient"]),
    );

    console.log("[SMS] Recebido:", JSON.stringify({
      metodo,
      hasMensagem: !!mensagem,
      codigoFromBody,
      valorFromBody,
      bodyKeys: Object.keys(body || {}).slice(0, 20),
    }));

    // Extract transaction code
    const codigoTransacao = codigoFromBody || extractTransactionCode(mensagem || "");
    // Extract value
    const valor = valorFromBody ?? extractValor(mensagem || "");
    // Extract phone numbers
    const phones = collectPhones([mensagem, origemFromBody, destinoFromBody]);
    const numeroOrigem = origemFromBody || phones[0] || null;
    const numeroDestino = destinoFromBody || phones.find((p) => p !== numeroOrigem) || null;

    console.log("[SMS] Parsed:", JSON.stringify({ codigoTransacao, valor, numeroOrigem, numeroDestino }));

    if (!codigoTransacao) {
      return json({
        error: "Código de transação não encontrado",
        detalhes: "Envie 'mensagem' completa do SMS ou inclua 'codigo_transacao' no body do webhook.",
      }, 422);
    }

    if (!valor || valor <= 0) {
      return json({
        error: "Valor não encontrado",
        detalhes: "Envie 'mensagem' completa do SMS ou inclua 'valor' no body do webhook.",
      }, 422);
    }

    // Check duplicate
    const { data: existing } = await supabase
      .from("incoming_payments")
      .select("id, status")
      .eq("codigo_transacao", codigoTransacao)
      .limit(1);

    if (existing && existing.length > 0) {
      return json({
        success: true,
        duplicate: true,
        id: existing[0].id,
        codigo: codigoTransacao,
        status: existing[0].status,
      });
    }

    // Match against active packages
    const { data: pacotes } = await supabase
      .from("pacotes_plataforma")
      .select("nome, preco, duracao_dias")
      .eq("ativo", true);

    const pacote = (pacotes || []).find((p: any) => Math.abs(Number(p.preco) - valor) < 1);
    const status = "disponivel";

    // Save payment
    const { data: inserted, error: insertError } = await supabase
      .from("incoming_payments")
      .insert({
        metodo,
        numero_origem: numeroOrigem,
        numero_destino: numeroDestino,
        valor,
        codigo_transacao: codigoTransacao,
        mensagem_original: mensagem || null,
        status,
        pacote_nome: pacote?.nome || null,
        valido: true,
      })
      .select("id")
      .single();

    if (insertError) {
      console.error("[SMS] DB Error:", insertError.message);
      return json({ error: insertError.message }, 500);
    }

    console.log("[SMS] Salvo ID:", inserted.id, "Status:", status);

    // Auto-match with pending subscription requests
    let autoMatched = false;
    if (pacote) {
      const { data: matchReq } = await supabase
        .from("subscription_requests")
        .select("*")
        .eq("codigo_submetido", codigoTransacao)
        .eq("status", "pendente")
        .limit(1);

      if (matchReq && matchReq.length > 0) {
        const request = matchReq[0];
        const duracaoDias = pacote.duracao_dias;
        const dataFim = duracaoDias === -1
          ? new Date("2099-12-31")
          : new Date(Date.now() + duracaoDias * 86400000);

        await supabase.from("subscriptions").insert({
          user_id: request.user_id,
          plano: pacote.nome,
          data_inicio: new Date().toISOString(),
          data_fim: dataFim.toISOString(),
          status: "activo",
          request_id: request.id,
        });

        await supabase.from("subscription_requests")
          .update({ status: "aprovado" })
          .eq("id", request.id);

        await supabase.from("user_profiles")
          .update({
            status: "active",
            expires_at: dataFim.toISOString(),
            usage_days: duracaoDias === -1 ? 36500 : duracaoDias,
          })
          .eq("user_id", request.user_id);

        await supabase.from("incoming_payments")
          .update({ status: "usado" })
          .eq("id", inserted.id);

        await supabase.from("historico_renovacoes").insert({
          user_id: request.user_id,
          dias_adicionados: duracaoDias === -1 ? 36500 : duracaoDias,
          data_inicio: new Date().toISOString(),
          data_fim: dataFim.toISOString(),
          valor,
          tipo: "automatico",
          pacote_nome: pacote.nome,
          observacoes: `Activação automática via SMS - Código: ${codigoTransacao}`,
        });

        autoMatched = true;
        console.log("[SMS] AUTO-MATCH! User:", request.user_id);
      }
    }

    return json({
      success: true,
      id: inserted.id,
      codigo: codigoTransacao,
      valor,
      status,
      pacote: pacote?.nome || null,
      auto_matched: autoMatched,
    });
  } catch (e) {
    console.error("[SMS] Error:", e);
    return json({ error: e instanceof Error ? e.message : "Erro desconhecido" }, 500);
  }
});

function json(body: any, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function extractTransactionCode(msg: string): string | null {
  if (!msg || !msg.trim()) return null;

  // Try specific patterns first
  const patterns = [
    /(?:Trans\.?\s*ID|Ref\.?|ID\s*Transa[cç][aã]o|ID\s*da\s*Transa[cç][aã]o|Transac[çc][aã]o|Receipt|Referencia|C[oó]digo)[:\s#-]*([A-Z0-9]{6,24})/i,
    /\b([A-Z]{2,8}\d{4,16}|\d{2,8}[A-Z]{2,8}\d{2,8})\b/,
  ];
  for (const p of patterns) {
    const m = msg.match(p);
    if (m) return m[1].trim();
  }

  const tokens = msg.toUpperCase().match(/\b[A-Z0-9]{8,24}\b/g) || [];
  for (const t of tokens) {
    if (/[A-Z]/.test(t) && /\d/.test(t)) return t;
  }

  return null;
}

function extractValor(msg: string): number | null {
  if (!msg || !msg.trim()) return null;

  const patterns = [
    /(\d[\d\s.,]*)\s*(?:MT|MZN|Meticais)/i,
    /(?:MT|MZN|Meticais)\s*(\d[\d\s.,]*)/i,
    /(?:valor|montante|amount|recebeu|transferiu|enviou)[:\s]*(\d[\d\s.,]*)/i,
    /(\d{1,3}(?:[\s.,]\d{3})*(?:[.,]\d{2})?)/,
  ];
  for (const p of patterns) {
    const m = msg.match(p);
    if (m) {
      const val = parseMoney(m[1]);
      if (!isNaN(val) && val > 0) return val;
    }
  }
  return null;
}

function parseMoney(raw: string): number {
  const s = String(raw || "").replace(/\s/g, "");
  if (!s) return NaN;

  const hasDot = s.includes(".");
  const hasComma = s.includes(",");

  if (hasDot && hasComma) {
    if (s.lastIndexOf(",") > s.lastIndexOf(".")) {
      return parseFloat(s.replace(/\./g, "").replace(",", "."));
    }
    return parseFloat(s.replace(/,/g, ""));
  }

  if (hasComma) {
    const parts = s.split(",");
    if (parts[1] && parts[1].length <= 2) return parseFloat(s.replace(/\./g, "").replace(",", "."));
    return parseFloat(s.replace(/,/g, ""));
  }

  if (hasDot) {
    const parts = s.split(".");
    if (parts[1] && parts[1].length <= 2) return parseFloat(s);
    return parseFloat(s.replace(/\./g, ""));
  }

  return parseFloat(s);
}

async function readBody(req: Request): Promise<any> {
  const ct = req.headers.get("content-type") || "";
  if (ct.includes("application/json")) {
    try { return await req.json(); } catch { return {}; }
  }
  if (ct.includes("application/x-www-form-urlencoded")) {
    const text = await req.text();
    return Object.fromEntries(new URLSearchParams(text).entries());
  }
  if (ct.includes("multipart/form-data")) {
    const fd = await req.formData();
    return Object.fromEntries(fd.entries());
  }
  const raw = await req.text();
  if (!raw.trim()) return {};
  try { return JSON.parse(raw); } catch {
    if (raw.includes("=")) return Object.fromEntries(new URLSearchParams(raw).entries());
    return { mensagem: raw };
  }
}

function getString(obj: any, keys: string[]): string {
  if (!obj || typeof obj !== "object") return "";
  // Check top level
  for (const k of keys) {
    if (typeof obj[k] === "string" && obj[k].trim()) return obj[k].trim();
  }
  // Check nested objects
  const nested = ["payload", "data", "params", "request", "sms", "body", "notification", "content"];
  for (const n of nested) {
    if (obj[n] && typeof obj[n] === "object") {
      for (const k of keys) {
        if (typeof obj[n][k] === "string" && obj[n][k].trim()) return obj[n][k].trim();
      }
    }
    if (typeof obj[n] === "string" && obj[n].trim().startsWith("{")) {
      try {
        const parsed = JSON.parse(obj[n]);
        for (const k of keys) {
          if (typeof parsed[k] === "string" && parsed[k].trim()) return parsed[k].trim();
        }
      } catch {
        // ignore
      }
    }
  }
  return "";
}

function getNumber(obj: any, keys: string[]): number | null {
  const text = getString(obj, keys);
  if (text) {
    const n = parseMoney(text);
    if (!Number.isNaN(n) && n > 0) return n;
  }

  if (!obj || typeof obj !== "object") return null;
  for (const k of keys) {
    const v = obj[k];
    if (typeof v === "number" && Number.isFinite(v) && v > 0) return v;
  }
  return null;
}

function getFirstLongString(obj: any): string {
  if (!obj || typeof obj !== "object") return "";

  const queue: any[] = [obj];
  const visited = new Set<any>();

  while (queue.length > 0) {
    const current = queue.shift();
    if (!current || typeof current !== "object" || visited.has(current)) continue;
    visited.add(current);

    for (const value of Object.values(current)) {
      if (typeof value === "string" && value.trim().length >= 12) return value.trim();
      if (value && typeof value === "object") queue.push(value);
    }
  }

  return "";
}

function normalizePhone(raw: string): string {
  if (!raw) return "";
  const digits = raw.replace(/\D/g, "");
  if (digits.length >= 9) return digits.slice(-9);
  return "";
}

function collectPhones(values: Array<string | null | undefined>): string[] {
  const found = new Set<string>();
  for (const v of values) {
    const text = String(v || "");
    const matches = text.match(/(?:\+?258)?\s*8[4-7]\d{7}/g) || [];
    for (const m of matches) {
      const n = normalizePhone(m);
      if (n) found.add(n);
    }
  }
  return Array.from(found);
}
