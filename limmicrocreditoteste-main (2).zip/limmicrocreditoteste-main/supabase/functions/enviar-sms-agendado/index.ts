import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { sendSms } from "../_shared/sms.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "https://limsistema.vercel.app",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS, PUT, DELETE",
};

function addDays(date: Date, days: number): Date {
  const result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
}

function formatDate(date: Date): string {
  return date.toLocaleDateString("pt-PT", { day: "2-digit", month: "2-digit", year: "numeric" });
}

function parseDate(d: string | Date | null): Date | null {
  if (!d) return null;
  const dt = new Date(d);
  return isNaN(dt.getTime()) ? null : dt;
}

function normalizeTemplate(template: string, vars: Record<string, string>): string {
  return template.replace(/\{(\w+)\}/g, (_, key) => vars[key] || "");
}

async function acquireLock(supabase: ReturnType<typeof createClient>, name: string, ttlMin = 30): Promise<boolean> {
  const { data: existing } = await supabase
    .from("admin_commands")
    .select("id, created_at")
    .eq("command", name)
    .eq("status", "running")
    .gt("created_at", new Date(Date.now() - ttlMin * 60 * 1000).toISOString())
    .limit(1)
    .maybeSingle();

  if (existing) return false;

  await supabase.from("admin_commands").insert({
    target_user_id: "00000000-0000-0000-0000-000000000000",
    issued_by: "00000000-0000-0000-0000-000000000000",
    command: name,
    payload: { started_at: new Date().toISOString() },
    status: "running",
  });

  return true;
}

async function releaseLock(supabase: ReturnType<typeof createClient>, name: string) {
  await supabase
    .from("admin_commands")
    .update({ status: "completed", executed_at: new Date().toISOString() })
    .eq("command", name)
    .eq("status", "running");
}

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const HEXMO_API_KEY = Deno.env.get("HEXMO_API_KEY") || "";
    const HEXMO_SENDER_ID = Deno.env.get("HEXMO_SENDER_ID") || "LIMSist";

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const lockName = "sms-agendado";
    const locked = await acquireLock(supabase, lockName, 30);
    if (!locked) {
      return new Response(JSON.stringify({ skipped: true, reason: "Lock ativo" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    try {
      if (!HEXMO_API_KEY) {
        return new Response(JSON.stringify({ error: "Gateway SMS não configurado" }), {
          status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const currentHour = new Date().getHours();

      const { data: configs } = await supabase
        .from("sms_config")
        .select("*, user_id")
        .eq("ativo", true)
        .lte("hora_envio", currentHour + 1)
        .gte("hora_envio", currentHour - 1);

      if (!configs || configs.length === 0) {
        return new Response(JSON.stringify({ sent: 0, reason: "Nenhuma configuração ativa" }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      let totalSent = 0;
      let totalFailed = 0;
      const errors: string[] = [];

      for (const config of configs) {
        const userId = config.user_id;

        // Verificar saldo e validade
        const { data: saldo } = await supabase
          .from("sms_saldos")
          .select("saldo, expira_em")
          .eq("user_id", userId)
          .maybeSingle();

        if (!saldo || saldo.saldo <= 0 || (saldo.expira_em && new Date(saldo.expira_em) < new Date())) {
          continue;
        }

        const { data: empresa } = await supabase
          .from("configuracoes_empresa")
          .select("nome_empresa")
          .eq("user_id", userId)
          .maybeSingle();

        const instituicao = config.nome_remetente || empresa?.nome_empresa || "LIMSist";

        const { data: emprestimos } = await supabase
          .from("emprestimos")
          .select("id, cliente_id, valor, parcela_mensal, valor_total, valor_pago, data_reembolso, status, clientes(nome_completo, telefone)")
          .eq("user_id", userId)
          .eq("status", "Ativo")
          .not("data_reembolso", "is", null);

        if (!emprestimos || emprestimos.length === 0) continue;

        for (const emprestimo of emprestimos as any[]) {
          const cliente = emprestimo.clientes || {};
          if (!cliente.telefone) continue;

          const reembolso = parseDate(emprestimo.data_reembolso);
          if (!reembolso) continue;
          reembolso.setHours(0, 0, 0, 0);

          const daysDiff = Math.ceil((reembolso.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
          const refDate = reembolso.toISOString().split("T")[0];

          let tipo: string | null = null;
          let template = "";

          if (daysDiff === 3 && config.aviso_3_dias_antes) {
            tipo = "antes_3_dias";
            template = config.template_antes;
          } else if (daysDiff === 0 && config.aviso_no_dia) {
            tipo = "dia_vencimento";
            template = config.template_dia;
          } else if (daysDiff === -2 && config.aviso_2_dias_depois) {
            tipo = "depois_2_dias";
            template = config.template_depois;
          }

          if (!tipo) continue;

          // Verificar duplicado
          const { data: existing } = await supabase
            .from("sms_envios")
            .select("id")
            .eq("user_id", userId)
            .eq("emprestimo_id", emprestimo.id)
            .eq("tipo", tipo)
            .eq("referencia_data", refDate)
            .limit(1)
            .maybeSingle();

          if (existing) continue;

          const valorPrestacao = emprestimo.parcela_mensal || ((emprestimo.valor_total || 0) - (emprestimo.valor_pago || 0));
          const mensagem = normalizeTemplate(template, {
            nome: cliente.nome_completo || "Cliente",
            valor: (valorPrestacao > 0 ? valorPrestacao.toLocaleString("pt-PT", { minimumFractionDigits: 2 }) : (emprestimo.valor || 0).toLocaleString("pt-PT", { minimumFractionDigits: 2 })),
            data: formatDate(reembolso),
            dias: String(Math.abs(daysDiff)),
            instituicao,
          });

          const result = await sendSms(
            supabase,
            {
              user_id: userId,
              telefone: cliente.telefone,
              mensagem,
              nome_remetente: config.nome_remetente,
              tipo,
              cliente_id: emprestimo.cliente_id,
              emprestimo_id: emprestimo.id,
              referencia_data: refDate,
            },
            HEXMO_API_KEY,
            HEXMO_SENDER_ID,
          );

          if (result.success) {
            totalSent++;
          } else {
            totalFailed++;
            errors.push(`${cliente.telefone}: ${result.error}`);
          }

          // Pequena pausa para evitar rate limits
          await new Promise((resolve) => setTimeout(resolve, 250));
        }
      }

      return new Response(JSON.stringify({ sent: totalSent, failed: totalFailed, errors: errors.slice(0, 20) }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    } finally {
      await releaseLock(supabase, lockName);
    }
  } catch (e: any) {
    console.error("[enviar-sms-agendado] Error:", e);
    return new Response(JSON.stringify({ error: e.message || "Erro desconhecido" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
}

serve(handler);

