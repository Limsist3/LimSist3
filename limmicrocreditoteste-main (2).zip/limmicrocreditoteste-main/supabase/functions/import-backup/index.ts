import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "https://limsistema.vercel.app",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS, PUT, DELETE",
};

// Ordem de dependência (pais antes dos filhos). Tabelas não listadas são importadas no fim.
const importOrder = [
  "configuracoes_empresa",
  "contas_financeiras",
  "capital_global",
  "capital_mensal",
  "entradas_capital",
  "clientes",
  "emprestimos",
  "pagamentos",
  "despesas",
  "movimentos_conta",
  "arquivos",
  "central_risco",
  "agente_atividades",
  "grupos_poupanca",
  "membros_poupanca",
  "poupancas_investimento",
  "poupanca_investimento_ganhos",
  "pg_grupos",
  "pg_membros",
  "pg_emprestimos",
  "pg_depositos",
  "pg_pagamentos",
  "pg_movimentos",
  "declaracoes_ispc",
  "notificacoes",
];

// Tabelas que nunca são importadas por um utilizador normal (plataforma/segurança)
const BLOCKED = new Set([
  "user_profiles",
  "user_roles",
  "subscriptions",
  "subscription_requests",
  "pagamentos_plataforma",
  "payment_proofs",
  "payment_keys",
  "payment_attempts",
  "incoming_payments",
  "pacotes_plataforma",
  "configuracao_pagamento",
  "cupoes_acesso",
  "links_ativacao",
  "link_ativacao_uso",
  "historico_renovacoes",
  "admin_commands",
  "user_data_quarantine",
  "user_error_logs",
  "webhook_pagamentos_recebidos",
  "mensagens_chat",
]);

// aliases para aceitar backups de outras origens/nomenclaturas
const ALIASES: Record<string, string> = {
  clients: "clientes", customers: "clientes",
  loans: "emprestimos", creditos: "emprestimos",
  payments: "pagamentos", recebimentos: "pagamentos",
  expenses: "despesas",
  contas: "contas_financeiras",
  settings: "configuracoes_empresa", config: "configuracoes_empresa",
  configuracoes: "configuracoes_empresa", empresa: "configuracoes_empresa",
  painel: "configuracoes_empresa",
  grupos: "grupos_poupanca", poupancas: "grupos_poupanca",
  membros: "membros_poupanca",
  files: "arquivos", documentos: "arquivos",
  risco: "central_risco",
  agentes: "agente_atividades", gestao_agentes: "agente_atividades",
  investimentos: "poupancas_investimento",
  capital: "capital_global",
};

// sinónimos de colunas comuns (backups de outras origens)
const COLUMN_ALIASES: Record<string, string[]> = {
  nome_completo: ["nome", "name", "full_name", "cliente_nome"],
  telefone: ["phone", "contacto", "celular", "telemovel"],
  valor: ["amount", "montante", "value"],
  descricao: ["description", "descricion", "obs", "observacao"],
  data: ["date", "data_movimento", "created_at"],
  taxa_juros: ["juros", "interest_rate", "taxa"],
  duracao_meses: ["prazo_meses", "meses", "duracao"],
  data_desembolso: ["data_emprestimo", "data_inicio", "disbursement_date"],
  data_pagamento: ["data", "payment_date"],
  categoria: ["category", "tipo_despesa"],
  nome: ["name", "titulo", "nome_completo"],
  email: ["mail", "e_mail"],
};

type ColumnMeta = {
  name: string;
  type: string;          // string | integer | number | boolean | object | array
  format: string;        // uuid, timestamp, date, numeric, text, jsonb, enum...
  required: boolean;     // NOT NULL sem default
  hasDefault: boolean;
  enumValues?: string[];
  maxLength?: number;
};

type TableMeta = { columns: Record<string, ColumnMeta> };

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

// Descobre dinamicamente as colunas reais e respectivos tipos (OpenAPI do PostgREST)
async function loadSchema(url: string, key: string): Promise<Record<string, TableMeta>> {
  const res = await fetch(`${url}/rest/v1/`, {
    headers: { apikey: key, Authorization: `Bearer ${key}`, Accept: "application/openapi+json" },
  });
  if (!res.ok) return {};
  const spec = await res.json();
  const defs = spec?.definitions || spec?.components?.schemas || {};
  const out: Record<string, TableMeta> = {};
  for (const [table, def] of Object.entries<any>(defs)) {
    const props = def?.properties;
    if (!props) continue;
    const required: string[] = Array.isArray(def?.required) ? def.required : [];
    const columns: Record<string, ColumnMeta> = {};
    for (const [name, p] of Object.entries<any>(props)) {
      const description = String(p?.description ?? "");
      const hasDefault = /Default Value/i.test(description) || description.includes("default");
      columns[name] = {
        name,
        type: String(p?.type ?? "string"),
        format: String(p?.format ?? ""),
        required: required.includes(name) && !hasDefault,
        hasDefault,
        enumValues: Array.isArray(p?.enum) ? p.enum.map(String) : undefined,
        maxLength: typeof p?.maxLength === "number" ? p.maxLength : undefined,
      };
    }
    if (Object.keys(columns).length) out[table] = { columns };
  }
  return out;
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
    const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const supabaseAdmin = createClient(SUPABASE_URL, SERVICE_KEY, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("Não autenticado");
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);
    if (userError || !user) throw new Error("Não autenticado");

    const schema = await loadSchema(SUPABASE_URL, SERVICE_KEY);
    if (Object.keys(schema).length === 0) throw new Error("Não foi possível ler o esquema da base de dados");

    const body = await req.json();
    const rawData = body?.backupData || body;
    const tableData = findTableData(rawData, schema);

    if (!tableData || Object.keys(tableData).length === 0) {
      return json({ error: "Ficheiro de backup inválido - nenhuma tabela encontrada" }, 400);
    }

    const backupUserId = rawData?.userId || rawData?.user_id || null;

    // ordem: conhecidas primeiro, depois quaisquer outras encontradas
    const tables = [
      ...importOrder.filter((t) => tableData[t]?.length),
      ...Object.keys(tableData).filter((t) => !importOrder.includes(t)),
    ];

    // ─── SUBSTITUIÇÃO TOTAL ───────────────────────────────────────────────
    // Antes de importar, apaga os dados actuais do utilizador nos módulos
    // suportados, para que fique apenas a informação do backup (sem duplicados).
    const wipeOrder = [...importOrder].reverse();
    const wiped: string[] = [];

    // filhos sem user_id: apagar primeiro pelos pais deste utilizador
    const { data: gruposDoUser } = await supabaseAdmin
      .from("grupos_poupanca").select("id").eq("user_id", user.id);
    const grupoIds = (gruposDoUser || []).map((g: any) => g.id);
    if (grupoIds.length) {
      await supabaseAdmin.from("membros_poupanca").delete().in("grupo_id", grupoIds);
    }

    const { data: agentesDoUser } = await supabaseAdmin
      .from("user_profiles").select("user_id").eq("usuario_mae_id", user.id);
    const agenteIds = (agentesDoUser || []).map((a: any) => a.user_id);
    if (agenteIds.length) {
      await supabaseAdmin.from("agente_atividades").delete().in("agente_id", agenteIds);
    }

    for (const table of wipeOrder) {
      const meta = schema[table];
      if (!meta || BLOCKED.has(table)) continue;
      if (table === "membros_poupanca" || table === "agente_atividades") continue;

      let del = supabaseAdmin.from(table).delete();
      if (meta.columns.user_id) del = del.eq("user_id", user.id);
      else if (meta.columns.usuario_mae_id) del = del.eq("usuario_mae_id", user.id);
      else continue;

      const { error } = await del;
      if (!error) wiped.push(table);
      else console.warn(`[import-backup] limpeza falhou em ${table}: ${error.message}`);
    }
    // ──────────────────────────────────────────────────────────────────────


    const summary: Array<{ table: string; imported: number; skipped: number; repaired: number; errors: string[] }> = [];
    // linhas que falharam por dependências: reprocessadas ao fim (pais já existem)
    const deferred: Array<{ table: string; row: Record<string, unknown> }> = [];

    const stats: Record<string, { imported: number; skipped: number; repaired: number; errors: Set<string> }> = {};
    const stat = (t: string) => (stats[t] ??= { imported: 0, skipped: 0, repaired: 0, errors: new Set<string>() });

    // Insere/actualiza uma linha reparando-a automaticamente conforme os erros da BD
    async function upsertWithRepair(table: string, original: Record<string, unknown>, allowDefer: boolean) {
      const meta = schema[table];
      let row = { ...original };
      let repaired = false;

      for (let attempt = 0; attempt < 8; attempt++) {
        const { error } = await supabaseAdmin.from(table).upsert(row as never, { onConflict: "id" });
        if (!error) {
          const s = stat(table);
          s.imported++;
          if (repaired) s.repaired++;
          return true;
        }

        const msg = `${error.message || ""} ${(error as any).details || ""} ${(error as any).hint || ""}`;
        const code = (error as any).code || "";
        const fix = repairRow(row, msg, code, meta);

        if (fix === "defer" && allowDefer) {
          deferred.push({ table, row });
          return true; // tentado novamente no fim
        }
        if (!fix || fix === "defer") {
          // último recurso: inserir sem id (novo registo) para não perder o dado
          const { id: _omit, ...noId } = row;
          const { error: e2 } = await supabaseAdmin.from(table).insert(noId as never);
          const s = stat(table);
          if (!e2) { s.imported++; s.repaired++; return true; }
          s.skipped++;
          if (s.errors.size < 3) s.errors.add(String(error.message).substring(0, 140));
          return false;
        }
        row = fix as Record<string, unknown>;
        repaired = true;
      }

      const s = stat(table);
      s.skipped++;
      return false;
    }

    // Tabelas cujos valores devem ficar EXACTAMENTE iguais ao backup.
    // São reaplicadas no fim porque os triggers da BD (empréstimos, pagamentos,
    // despesas, entradas) recalculam capital e saldos durante a importação.
    const EXACT_TABLES = ["capital_global", "capital_mensal", "contas_financeiras", "configuracoes_empresa"];
    const exactRows: Record<string, Record<string, unknown>[]> = {};

    for (const table of tables) {
      const rows = tableData[table];
      if (!rows?.length) continue;
      const meta = schema[table];
      if (!meta) continue;

      const cleaned = rows.map((r) => cleanRow(meta, r, user.id, backupUserId));
      if (EXACT_TABLES.includes(table)) exactRows[table] = cleaned;

      // 1ª tentativa em lote (rápido); se falhar, repara linha a linha
      const CHUNK = 200;
      for (let i = 0; i < cleaned.length; i += CHUNK) {
        const batch = cleaned.slice(i, i + CHUNK);
        const { error } = await supabaseAdmin.from(table).upsert(batch as never, { onConflict: "id" });
        if (!error) {
          stat(table).imported += batch.length;
          continue;
        }
        for (const row of batch) {
          await upsertWithRepair(table, row, true);
        }
      }
    }

    // Reprocessar linhas diferidas (dependências já importadas)
    for (let pass = 0; pass < 2 && deferred.length; pass++) {
      const queue = deferred.splice(0, deferred.length);
      for (const item of queue) {
        await upsertWithRepair(item.table, item.row, pass === 0);
      }
    }

    // Reaplicar valores exactos do backup (gestão de capital, contas e painel)
    for (const table of EXACT_TABLES) {
      const rows = exactRows[table];
      if (!rows?.length) continue;
      const { error } = await supabaseAdmin.from(table).upsert(rows as never, { onConflict: "id" });
      if (error) {
        for (const row of rows) {
          const { error: e1 } = await supabaseAdmin.from(table).upsert(row as never, { onConflict: "id" });
          if (!e1) continue;
          // fallback: actualizar pela chave natural (ex.: user_id + mes_ano / tipo)
          const { id: _omit, ...values } = row as Record<string, unknown>;
          let q = supabaseAdmin.from(table).update(values as never).eq("user_id", user.id);
          if (table === "capital_mensal" && row.mes_ano) q = q.eq("mes_ano", row.mes_ano as string);
          if (table === "contas_financeiras" && row.tipo) q = q.eq("tipo", row.tipo as string);
          await q;
        }
      }

    }


    for (const [table, s] of Object.entries(stats)) {
      if (s.imported > 0 || s.skipped > 0) {
        summary.push({ table, imported: s.imported, skipped: s.skipped, repaired: s.repaired, errors: [...s.errors].slice(0, 3) });
      }
    }

    return json({
      success: true,
      summary,
      importedTables: summary.filter((s) => s.imported > 0).length,
      totalImportedRows: summary.reduce((s, i) => s + i.imported, 0),
      totalSkippedRows: summary.reduce((s, i) => s + i.skipped, 0),
      totalRepairedRows: summary.reduce((s, i) => s + i.repaired, 0),
    });
  } catch (error) {
    console.error("[import-backup]", error);
    return json({ error: error instanceof Error ? error.message : "Erro ao importar backup" }, 400);
  }
});

/**
 * Analisa o erro devolvido pela base de dados e devolve a linha corrigida,
 * "defer" quando depende de outra tabela ainda não importada, ou null se irreparável.
 */
function repairRow(
  row: Record<string, unknown>,
  msg: string,
  code: string,
  meta: TableMeta | undefined,
): Record<string, unknown> | "defer" | null {
  const next = { ...row };
  const colFrom = (re: RegExp) => {
    const m = msg.match(re);
    return m?.[1] ?? null;
  };

  // coluna inexistente
  const unknownCol = colFrom(/column "([^"]+)" of relation .* does not exist/i)
    || colFrom(/Could not find the '([^']+)' column/i);
  if (unknownCol && unknownCol in next) { delete next[unknownCol]; return next; }

  // chave estrangeira em falta -> anular se possível, senão diferir
  if (code === "23503") {
    const col = colFrom(/Key \(([^)]+)\)=/i) || colFrom(/foreign key constraint "([^"]+)"/i);
    const candidates = col ? col.split(",").map((c) => c.trim()) : [];
    for (const c of candidates) {
      const cm = meta?.columns[c];
      if (cm && !cm.required && c in next) { next[c] = null; return next; }
    }
    return "defer";
  }

  // valor duplicado numa chave única -> gerar novo id / limpar coluna duplicada
  if (code === "23505") {
    const col = colFrom(/Key \(([^)]+)\)=/i);
    const cols = col ? col.split(",").map((c) => c.trim()) : [];
    if (cols.length === 1 && cols[0] !== "id" && meta?.columns[cols[0]] && !meta.columns[cols[0]].required) {
      next[cols[0]] = null;
      return next;
    }
    if (meta?.columns.id) { next.id = crypto.randomUUID(); return next; }
    return null;
  }

  // NOT NULL em falta -> preencher com valor neutro do tipo
  if (code === "23502") {
    const col = colFrom(/column "([^"]+)"/i);
    if (col && meta?.columns[col]) {
      next[col] = neutralValue(meta.columns[col]);
      return next;
    }
  }

  // tipo/sintaxe inválidos (uuid, numeric, date, enum, json) -> converter ou anular
  if (code === "22P02" || code === "22007" || code === "22008" || code === "22003" || /invalid input/i.test(msg)) {
    const col = colFrom(/column "([^"]+)"/i);
    // enum inválido
    const enumMatch = msg.match(/invalid input value for enum [^:]*: "([^"]*)"/i);
    if (enumMatch && meta) {
      const bad = enumMatch[1];
      for (const [name, cm] of Object.entries(meta.columns)) {
        if (cm.enumValues && next[name] === bad) {
          next[name] = cm.enumValues.includes("user") ? "user" : cm.enumValues[0];
          return next;
        }
      }
    }
    if (col && meta?.columns[col]) {
      const cm = meta.columns[col];
      const coerced = coerce(next[col], cm);
      if (coerced !== next[col]) { next[col] = coerced; return next; }
      next[col] = cm.required ? neutralValue(cm) : null;
      return next;
    }
    // sem coluna identificada: forçar coerção total
    if (meta) {
      let changed = false;
      for (const [name, cm] of Object.entries(meta.columns)) {
        if (!(name in next)) continue;
        const coerced = coerce(next[name], cm);
        if (coerced !== next[name]) { next[name] = coerced; changed = true; }
      }
      if (changed) return next;
    }
  }

  // valor demasiado longo
  if (code === "22001" && meta) {
    let changed = false;
    for (const [name, cm] of Object.entries(meta.columns)) {
      if (cm.maxLength && typeof next[name] === "string" && (next[name] as string).length > cm.maxLength) {
        next[name] = (next[name] as string).slice(0, cm.maxLength);
        changed = true;
      }
    }
    if (changed) return next;
  }

  // violação de CHECK -> anular coluna opcional mencionada
  if (code === "23514" && meta) {
    const constraint = colFrom(/constraint "([^"]+)"/i) || "";
    for (const [name, cm] of Object.entries(meta.columns)) {
      if (constraint.includes(name) && name in next) {
        next[name] = cm.required ? neutralValue(cm) : null;
        return next;
      }
    }
  }

  return null;
}

function isUuid(v: unknown) {
  return typeof v === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
}

function neutralValue(cm: ColumnMeta): unknown {
  if (cm.enumValues?.length) return cm.enumValues.includes("user") ? "user" : cm.enumValues[0];
  if (cm.format === "uuid") return crypto.randomUUID();
  if (cm.type === "integer" || cm.type === "number" || /numeric|double|real|int/.test(cm.format)) return 0;
  if (cm.type === "boolean") return false;
  if (/timestamp/.test(cm.format)) return new Date().toISOString();
  if (cm.format === "date") return new Date().toISOString().split("T")[0];
  if (cm.type === "object" || /json/.test(cm.format)) return {};
  if (cm.type === "array") return [];
  return "N/D";
}

function coerce(value: unknown, cm: ColumnMeta): unknown {
  if (value === null || value === undefined || value === "") {
    return cm.required ? neutralValue(cm) : null;
  }

  // numérico
  if (cm.type === "integer" || cm.type === "number" || /numeric|double|real|^int/.test(cm.format)) {
    if (typeof value === "number") return cm.type === "integer" ? Math.round(value) : value;
    const n = Number(String(value).replace(/[^\d.,-]/g, "").replace(/\.(?=\d{3}\b)/g, "").replace(",", "."));
    if (Number.isFinite(n)) return cm.type === "integer" ? Math.round(n) : n;
    return cm.required ? 0 : null;
  }

  // boolean
  if (cm.type === "boolean") {
    if (typeof value === "boolean") return value;
    const s = String(value).toLowerCase();
    if (["true", "1", "sim", "yes", "t", "y"].includes(s)) return true;
    if (["false", "0", "nao", "não", "no", "f", "n"].includes(s)) return false;
    return cm.required ? false : null;
  }

  // datas
  if (/timestamp/.test(cm.format) || cm.format === "date") {
    const d = new Date(String(value));
    if (!isNaN(d.getTime())) {
      return cm.format === "date" ? d.toISOString().split("T")[0] : d.toISOString();
    }
    return cm.required ? neutralValue(cm) : null;
  }

  // uuid
  if (cm.format === "uuid") {
    if (isUuid(value)) return value;
    return cm.required ? crypto.randomUUID() : null;
  }

  // enum
  if (cm.enumValues?.length) {
    const s = String(value);
    const hit = cm.enumValues.find((e) => e.toLowerCase() === s.toLowerCase());
    if (hit) return hit;
    return cm.required ? neutralValue(cm) : null;
  }

  // json
  if (cm.type === "object" || cm.type === "array" || /json/.test(cm.format)) {
    if (typeof value === "object") return value;
    try { return JSON.parse(String(value)); } catch { return cm.type === "array" ? [] : {}; }
  }

  // texto
  if (typeof value === "object") return JSON.stringify(value);
  const s = String(value);
  return cm.maxLength && s.length > cm.maxLength ? s.slice(0, cm.maxLength) : s;
}

function resolveTable(key: string, schema: Record<string, TableMeta>): string | null {
  const norm = key.toLowerCase().replace(/[^a-z0-9_]/g, "");
  if (schema[norm] && !BLOCKED.has(norm)) return norm;
  const alias = ALIASES[norm];
  if (alias && schema[alias] && !BLOCKED.has(alias)) return alias;
  return null;
}

function findTableData(
  raw: unknown,
  schema: Record<string, TableMeta>,
): Record<string, Record<string, unknown>[]> | null {
  if (!raw || typeof raw !== "object") return null;
  const source = raw as Record<string, unknown>;
  const result: Record<string, Record<string, unknown>[]> = {};

  const candidates = [source.tables, source.data, source.backup, source];

  for (const candidate of candidates) {
    if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) continue;
    for (const [key, value] of Object.entries(candidate as Record<string, unknown>)) {
      const table = resolveTable(key, schema);
      if (!table || result[table]?.length) continue;

      if (Array.isArray(value)) {
        const rows = value.filter((v) => v && typeof v === "object" && !Array.isArray(v)) as Record<string, unknown>[];
        if (rows.length) result[table] = rows;
      } else if (value && typeof value === "object") {
        const nested = value as Record<string, unknown>;
        const arr = (nested.data ?? nested.rows ?? nested.records) as unknown;
        if (Array.isArray(arr)) {
          const rows = arr.filter((v) => v && typeof v === "object" && !Array.isArray(v)) as Record<string, unknown>[];
          if (rows.length) result[table] = rows;
        }
      }
    }
  }

  return Object.keys(result).length > 0 ? result : null;
}

/** Normaliza uma linha do backup para o esquema real: mapeia sinónimos, converte tipos e preenche obrigatórios. */
function cleanRow(
  meta: TableMeta,
  row: Record<string, unknown>,
  userId: string,
  backupUserId: string | null,
): Record<string, unknown> {
  const cols = meta.columns;
  const clean: Record<string, unknown> = {};

  // índice case/format-insensitive das chaves da origem
  const normKey = (k: string) => k.toLowerCase().replace(/[^a-z0-9]/g, "");
  const source: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(row)) source[normKey(k)] = v;

  for (const [name, cm] of Object.entries(cols)) {
    let value: unknown = undefined;
    if (normKey(name) in source) {
      value = source[normKey(name)];
    } else {
      for (const alt of COLUMN_ALIASES[name] ?? []) {
        if (normKey(alt) in source) { value = source[normKey(alt)]; break; }
      }
    }
    if (value === undefined) continue;
    clean[name] = coerce(value, cm);
  }

  // obrigatórios em falta -> valor neutro (nada fica de fora por falta de campo)
  for (const [name, cm] of Object.entries(cols)) {
    if (cm.required && (clean[name] === undefined || clean[name] === null)) {
      clean[name] = neutralValue(cm);
    }
  }

  if (cols.id && !clean.id) clean.id = crypto.randomUUID();

  // Remapeia a propriedade para o utilizador actual
  if (cols.user_id) clean.user_id = userId;
  if (cols.usuario_mae_id && (!clean.usuario_mae_id || clean.usuario_mae_id === backupUserId)) {
    clean.usuario_mae_id = userId;
  }
  if (cols.agente_id && clean.agente_id === backupUserId) clean.agente_id = userId;

  return clean;
}
