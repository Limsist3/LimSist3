# Modo Offline - Documentação

## Visão Geral

O aplicativo agora suporta funcionalidade offline completa para as seções básicas:
- ✅ Simulador
- ✅ Clientes
- ✅ Empréstimos
- ✅ Pagamentos
- ✅ Despesas

## Como Funciona

### 1. Detecção Automática
O aplicativo detecta automaticamente quando você está offline e mostra um indicador visual no canto inferior direito da tela.

### 2. Armazenamento Local
Quando offline, todas as operações (criar, editar, deletar) são salvas localmente usando IndexedDB.

### 3. Sincronização Automática
Quando a conexão é restaurada, o aplicativo sincroniza automaticamente todas as alterações pendentes com o servidor.

## Componentes Principais

### OfflineIndicator
Mostra o status da conexão e operações pendentes:
- **Verde (Online)**: Conectado ao servidor
- **Amarelo (Offline)**: Modo offline ativo
- **Contador**: Número de operações pendentes de sincronização

### useOfflineSync Hook
Gerencia o estado offline/online e sincronização:

\`\`\`typescript
import { useOfflineSync } from '@/hooks/useOfflineSync';

function MyComponent() {
  const { 
    isOnline,          // Status da conexão
    isSyncing,         // Status de sincronização
    pendingCount,      // Número de operações pendentes
    addPendingOperation, // Adicionar operação à fila
    syncPendingOperations // Forçar sincronização
  } = useOfflineSync();
}
\`\`\`

### useOfflineData Hook
Simplifica o gerenciamento de dados com suporte offline:

\`\`\`typescript
import { useOfflineData } from '@/hooks/useOfflineData';

function MyPage() {
  const {
    data,           // Array de dados
    loading,        // Status de carregamento
    createItem,     // Criar novo item
    updateItem,     // Atualizar item
    deleteItem,     // Deletar item
    reload          // Recarregar dados
  } = useOfflineData({
    table: 'clientes',
    select: '*',
    orderBy: { column: 'created_at', ascending: false }
  });

  // Criar novo cliente
  const handleCreate = async () => {
    await createItem({
      nome_completo: 'João Silva',
      telefone: '841234567'
    });
  };

  // Atualizar cliente
  const handleUpdate = async (id: string) => {
    await updateItem(id, {
      telefone: '849876543'
    });
  };

  // Deletar cliente
  const handleDelete = async (id: string) => {
    await deleteItem(id);
  };
}
\`\`\`

## Exemplo de Integração

### Antes (apenas online):
\`\`\`typescript
const loadClientes = async () => {
  const { data, error } = await supabase
    .from('clientes')
    .select('*');
  
  if (error) throw error;
  setClientes(data);
};

const handleCreate = async (cliente) => {
  const { error } = await supabase
    .from('clientes')
    .insert([cliente]);
    
  if (error) throw error;
  loadClientes();
};
\`\`\`

### Depois (com suporte offline):
\`\`\`typescript
const {
  data: clientes,
  loading,
  createItem,
  reload
} = useOfflineData({
  table: 'clientes',
  orderBy: { column: 'created_at', ascending: false }
});

const handleCreate = async (cliente) => {
  try {
    await createItem(cliente);
    toast.success('Cliente criado com sucesso!');
  } catch (error) {
    toast.error('Erro ao criar cliente');
  }
};
\`\`\`

## Service Worker

O Service Worker foi atualizado para implementar a estratégia "Network First, Fallback to Cache":

1. Tenta buscar da rede primeiro
2. Se bem-sucedido, atualiza o cache
3. Se falhar (offline), busca do cache
4. Ignora requisições do Supabase para não interferir com sincronização

## Armazenamento Local

### IndexedDB
Duas bases de dados IndexedDB são usadas:

1. **limsist_offline**: Armazena operações pendentes de sincronização
2. **limsist_data**: Armazena cache de dados (clientes, empréstimos, etc.)

### Estrutura de Operação Pendente
\`\`\`typescript
{
  id: string;           // ID único da operação
  type: 'INSERT' | 'UPDATE' | 'DELETE';
  table: string;        // Nome da tabela
  data: any;           // Dados da operação
  timestamp: number;   // Timestamp da operação
}
\`\`\`

## Fluxo de Sincronização

1. **Operação Offline**:
   - Operação é salva no IndexedDB
   - Operação é adicionada à fila de sincronização
   - UI é atualizada imediatamente

2. **Conexão Restaurada**:
   - Evento "online" é detectado
   - Toast de notificação é exibido
   - Sincronização automática inicia

3. **Processo de Sincronização**:
   - Operações são processadas em ordem (FIFO)
   - Cada operação bem-sucedida é removida da fila
   - Falhas são registradas e operação permanece na fila
   - Toast de sucesso/erro é exibido ao final

## Limitações

1. **Autenticação**: O usuário deve estar autenticado antes de ficar offline
2. **Conflitos**: Não há resolução automática de conflitos (última escrita vence)
3. **Anexos**: Upload de arquivos não funciona offline
4. **Relatórios**: Geração de PDFs requer conexão online
5. **Simulador**: Funciona completamente offline (apenas cálculos locais)

## Troubleshooting

### Operações Não Sincronizam
1. Verifique se está online
2. Clique no botão de sincronização manual no indicador
3. Verifique o console para erros

### Cache Corrompido
Para limpar todos os dados offline:
\`\`\`javascript
// No console do navegador:
indexedDB.deleteDatabase('limsist_data');
indexedDB.deleteDatabase('limsist_offline');
\`\`\`

### Service Worker Não Atualiza
1. Feche todas as abas do aplicativo
2. Reabra o aplicativo
3. Ou force atualização: Ctrl+Shift+R (Windows) / Cmd+Shift+R (Mac)

## Testes

### Testar Modo Offline
1. Abra DevTools (F12)
2. Vá para Network tab
3. Selecione "Offline" no throttling dropdown
4. Tente criar/editar/deletar dados
5. Volte para "Online"
6. Verifique se sincronização ocorre automaticamente

### Testar Service Worker
1. Abra DevTools > Application > Service Workers
2. Verifique se o SW está ativo
3. Clique em "Unregister" e recarregue para testar reinstalação

## Melhorias Futuras

- [ ] Resolução de conflitos inteligente
- [ ] Compressão de dados offline
- [ ] Sincronização em background
- [ ] Notificações de sincronização
- [ ] Modo somente leitura offline para relatórios
- [ ] Exportar/importar dados offline
- [ ] Indicador de progresso de sincronização
- [ ] Retry automático com exponential backoff
