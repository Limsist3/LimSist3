// Amortization calculation utilities for Price and SAC systems

export interface ParcelaAmortizacao {
  numero: number;
  dataVencimento: string;
  prestacao: number;       // Total payment for this installment
  amortizacao: number;     // Principal portion
  juros: number;           // Interest portion
  saldoDevedor: number;    // Remaining balance after this payment
}

export type SistemaAmortizacao = 'price' | 'sac';

/**
 * Generate amortization schedule
 * @param valor - Loan principal
 * @param taxaJurosMensal - Monthly interest rate (e.g. 5 for 5%)
 * @param duracaoMeses - Duration in months
 * @param modalidadeReembolso - Repayment frequency
 * @param dataDesembolso - Disbursement date (ISO string)
 * @param sistema - 'price' (fixed installments) or 'sac' (constant amortization)
 * @param tipoJuros - 'Simples' or 'Composto'
 */
export function gerarTabelaAmortizacao(
  valor: number,
  taxaJurosMensal: number,
  duracaoMeses: number,
  modalidadeReembolso: string = 'mensal',
  dataDesembolso: string,
  sistema: SistemaAmortizacao = 'price',
  tipoJuros: string = 'Composto'
): ParcelaAmortizacao[] {
  const taxa = taxaJurosMensal / 100;
  
  // Calculate total number of installments based on modality
  let totalParcelas = duracaoMeses;
  let diasEntreparcelas = 30;
  if (modalidadeReembolso === 'diaria') { totalParcelas = duracaoMeses * 30; diasEntreparcelas = 1; }
  else if (modalidadeReembolso === 'semanal') { totalParcelas = duracaoMeses * 4; diasEntreparcelas = 7; }
  else if (modalidadeReembolso === 'quinzenal') { totalParcelas = duracaoMeses * 2; diasEntreparcelas = 15; }

  // Adjust interest rate for the period
  let taxaPeriodo = taxa;
  if (modalidadeReembolso === 'diaria') taxaPeriodo = taxa / 30;
  else if (modalidadeReembolso === 'semanal') taxaPeriodo = taxa / 4;
  else if (modalidadeReembolso === 'quinzenal') taxaPeriodo = taxa / 2;

  const parcelas: ParcelaAmortizacao[] = [];
  const dataBase = new Date(dataDesembolso);

  if (tipoJuros === 'Simples') {
    // Simple/Flat interest: total interest = P * r * n (using monthly rate * months)
    const jurosTotal = valor * taxa * duracaoMeses;
    const valorTotal = valor + jurosTotal;
    const prestacaoFixa = valorTotal / totalParcelas;
    const amortizacaoPorParcela = valor / totalParcelas;
    const jurosPorParcela = jurosTotal / totalParcelas;

    let saldo = valor;
    for (let i = 1; i <= totalParcelas; i++) {
      saldo -= amortizacaoPorParcela;
      const dataVenc = calcularDataVencimento(dataBase, i, diasEntreparcelas, modalidadeReembolso);
      parcelas.push({
        numero: i,
        dataVencimento: dataVenc,
        prestacao: round2(prestacaoFixa),
        amortizacao: round2(amortizacaoPorParcela),
        juros: round2(jurosPorParcela),
        saldoDevedor: round2(Math.max(0, saldo)),
      });
    }
    return parcelas;
  }

  // "SobreSaldo" - Interest calculated on remaining balance (decreasing balance method)
  if (tipoJuros === 'SobreSaldo') {
    const amortizacaoConstante = valor / totalParcelas;
    let saldo = valor;

    for (let i = 1; i <= totalParcelas; i++) {
      const jurosDoPeriodo = saldo * taxaPeriodo;
      const prestacao = amortizacaoConstante + jurosDoPeriodo;
      saldo -= amortizacaoConstante;
      const dataVenc = calcularDataVencimento(dataBase, i, diasEntreparcelas, modalidadeReembolso);

      parcelas.push({
        numero: i,
        dataVencimento: dataVenc,
        prestacao: round2(prestacao),
        amortizacao: round2(amortizacaoConstante),
        juros: round2(jurosDoPeriodo),
        saldoDevedor: round2(Math.max(0, saldo)),
      });
    }
    return parcelas;
  }

  // Compound interest
  if (sistema === 'price') {
    // Price System: Fixed installments (PMT = PV * [i(1+i)^n] / [(1+i)^n - 1])
    const fator = Math.pow(1 + taxaPeriodo, totalParcelas);
    const prestacaoFixa = valor * (taxaPeriodo * fator) / (fator - 1);
    
    let saldo = valor;
    for (let i = 1; i <= totalParcelas; i++) {
      const jurosDoPeriodo = saldo * taxaPeriodo;
      const amortizacao = prestacaoFixa - jurosDoPeriodo;
      saldo -= amortizacao;
      const dataVenc = calcularDataVencimento(dataBase, i, diasEntreparcelas, modalidadeReembolso);
      
      parcelas.push({
        numero: i,
        dataVencimento: dataVenc,
        prestacao: round2(prestacaoFixa),
        amortizacao: round2(amortizacao),
        juros: round2(jurosDoPeriodo),
        saldoDevedor: round2(Math.max(0, saldo)),
      });
    }
  } else {
    // SAC System: Constant amortization, decreasing installments
    const amortizacaoConstante = valor / totalParcelas;
    let saldo = valor;

    for (let i = 1; i <= totalParcelas; i++) {
      const jurosDoPeriodo = saldo * taxaPeriodo;
      const prestacao = amortizacaoConstante + jurosDoPeriodo;
      saldo -= amortizacaoConstante;
      const dataVenc = calcularDataVencimento(dataBase, i, diasEntreparcelas, modalidadeReembolso);

      parcelas.push({
        numero: i,
        dataVencimento: dataVenc,
        prestacao: round2(prestacao),
        amortizacao: round2(amortizacaoConstante),
        juros: round2(jurosDoPeriodo),
        saldoDevedor: round2(Math.max(0, saldo)),
      });
    }
  }

  return parcelas;
}

/**
 * Calculate totals from amortization schedule
 */
export function calcularTotaisAmortizacao(parcelas: ParcelaAmortizacao[]) {
  const totalPrestacoes = parcelas.reduce((s, p) => s + p.prestacao, 0);
  const totalJuros = parcelas.reduce((s, p) => s + p.juros, 0);
  const totalAmortizacao = parcelas.reduce((s, p) => s + p.amortizacao, 0);
  return { totalPrestacoes: round2(totalPrestacoes), totalJuros: round2(totalJuros), totalAmortizacao: round2(totalAmortizacao) };
}

function calcularDataVencimento(dataBase: Date, parcela: number, diasEntre: number, modalidade: string): string {
  const d = new Date(dataBase);
  if (modalidade === 'mensal') {
    d.setMonth(d.getMonth() + parcela);
  } else {
    d.setDate(d.getDate() + parcela * diasEntre);
  }
  return d.toISOString().split('T')[0];
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

/**
 * Determine which installment is being paid based on valor_pago
 */
export function getParcelaAtual(parcelas: ParcelaAmortizacao[], valorPago: number): number {
  let acumulado = 0;
  for (const p of parcelas) {
    acumulado += p.prestacao;
    if (valorPago < acumulado) return p.numero;
  }
  return parcelas.length; // All paid
}

export function formatModalidade(mod: string): string {
  const map: Record<string, string> = {
    diaria: 'Diária',
    semanal: 'Semanal',
    quinzenal: 'Quinzenal',
    mensal: 'Mensal',
  };
  return map[mod] || mod;
}

export function formatSistema(sys: SistemaAmortizacao): string {
  return sys === 'price' ? 'Parcelas Fixas (Price)' : 'Parcelas Variáveis (SAC)';
}
