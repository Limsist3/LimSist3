import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { loadLetterhead, applyLetterheadAllPages, LETTERHEAD_CONTENT_TOP, LETTERHEAD_CONTENT_BOTTOM } from "@/lib/letterhead";

const fmt = (v: number) => new Intl.NumberFormat("pt-MZ", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v || 0);
const fmtDate = (d?: string | null) => d ? new Date(d).toLocaleDateString("pt-PT") : "-";

export function calcularCronogramaInvestimento(poupanca: any) {
  const capital = Number(poupanca.valor_capital) || 0;
  const taxa = (Number(poupanca.taxa_mensal) || 0) / 100;
  const meses = Number(poupanca.periodo_meses) || 0;
  const dataInicio = poupanca.data_inicio ? new Date(poupanca.data_inicio) : new Date();

  const rows: { mes: number; data: string; ganho: number; acumulado: number; capital: number }[] = [];
  let acumulado = 0;
  for (let i = 1; i <= meses; i++) {
    const ganho = capital * taxa;
    acumulado += ganho;
    const d = new Date(dataInicio);
    d.setMonth(d.getMonth() + i);
    rows.push({
      mes: i,
      data: d.toISOString().slice(0, 10),
      ganho,
      acumulado,
      capital: i === meses ? capital : 0,
    });
  }
  const totalGanhos = capital * taxa * meses;
  const dataFim = new Date(dataInicio);
  dataFim.setMonth(dataFim.getMonth() + meses);
  const diasTotais = Math.round((dataFim.getTime() - dataInicio.getTime()) / (1000 * 60 * 60 * 24));
  return { rows, totalGanhos, capital, dataFim: dataFim.toISOString().slice(0, 10), diasTotais };
}

export async function gerarContratoInvestimento(poupanca: any) {
  const lh = await loadLetterhead();
  const doc = new jsPDF({ compress: true });
  const pageW = doc.internal.pageSize.getWidth();
  let y = LETTERHEAD_CONTENT_TOP;

  const cronograma = calcularCronogramaInvestimento(poupanca);
  const empresa = lh.config.nome_empresa || "A Instituição";

  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text("CONTRATO DE POUPANÇA - INVESTIMENTO", pageW / 2, y, { align: "center" });
  y += 10;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  const clausulas = [
    `Entre ${empresa} (adiante designada "Instituição") e ${poupanca.cliente_nome} (adiante designado "Investidor"), portador do NUIT ${poupanca.nuit || "-----"}, celebra-se o presente contrato nos seguintes termos:`,
    "",
    "CLÁUSULA 1ª (OBJECTO): O presente contrato tem por objecto a aplicação, por parte do Investidor, de um valor de capital junto da Instituição, com rendimento mensal fixo, sendo o capital devolvido ao final do período contratado.",
    `CLÁUSULA 2ª (CAPITAL): O Investidor entrega à Instituição o montante de ${fmt(cronograma.capital)} MZN.`,
    `CLÁUSULA 3ª (PRAZO): O presente contrato vigora por ${poupanca.periodo_meses} meses (${cronograma.diasTotais} dias), com início em ${fmtDate(poupanca.data_inicio)} e término em ${fmtDate(cronograma.dataFim)}.`,
    `CLÁUSULA 4ª (RENDIMENTO): A Instituição pagará mensalmente ao Investidor o valor de ${fmt(cronograma.capital * (Number(poupanca.taxa_mensal) / 100))} MZN, correspondente a uma taxa mensal de ${Number(poupanca.taxa_mensal).toFixed(2)}% sobre o capital aplicado.`,
    `CLÁUSULA 5ª (TOTAL DE GANHOS): O total previsto de rendimentos ao longo do período é de ${fmt(cronograma.totalGanhos)} MZN.`,
    `CLÁUSULA 6ª (DEVOLUÇÃO DO CAPITAL): No final do prazo, a Instituição procederá à devolução integral do capital aplicado ao Investidor.`,
    "CLÁUSULA 7ª (RESCISÃO ANTECIPADA): A rescisão antecipada por qualquer das partes obriga ao cumprimento das condições acordadas por escrito entre ambas.",
    "CLÁUSULA 8ª (FORO): Para dirimir quaisquer dúvidas decorrentes do presente contrato, as partes elegem o foro da comarca da sede da Instituição.",
  ];
  clausulas.forEach((t) => {
    const lines = doc.splitTextToSize(t, pageW - 28);
    if (y + lines.length * 5 > 250) { doc.addPage(); y = LETTERHEAD_CONTENT_TOP; }
    doc.text(lines, 14, y);
    y += lines.length * 5 + 2;
  });

  y += 10;
  if (y > 240) { doc.addPage(); y = LETTERHEAD_CONTENT_TOP; }
  doc.text("____________________________", 30, y + 20);
  doc.text("____________________________", pageW - 90, y + 20);
  doc.text("A Instituição", 45, y + 26);
  doc.text("O Investidor", pageW - 78, y + 26);

  // Cronograma
  doc.addPage();
  y = LETTERHEAD_CONTENT_TOP;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.text("CRONOGRAMA DE RENDIMENTOS", pageW / 2, y, { align: "center" });
  y += 6;
  autoTable(doc, {
    startY: y,
    head: [["Mês", "Data", "Ganho (MZN)", "Acumulado (MZN)", "Devolução Capital"]],
    body: cronograma.rows.map(r => [
      String(r.mes), fmtDate(r.data), fmt(r.ganho), fmt(r.acumulado), r.capital > 0 ? fmt(r.capital) : "-"
    ]),
    margin: { bottom: LETTERHEAD_CONTENT_BOTTOM },
    styles: { fontSize: 9 },
    headStyles: { fillColor: [91, 79, 191] },
  });

  applyLetterheadAllPages(doc, lh);
  doc.save(`contrato-investimento-${poupanca.cliente_nome.replace(/\s+/g, "_")}.pdf`);
}

export async function gerarRelatorioInvestimento(poupanca: any, ganhos: any[]) {
  const lh = await loadLetterhead();
  const doc = new jsPDF({ compress: true });
  const pageW = doc.internal.pageSize.getWidth();
  let y = LETTERHEAD_CONTENT_TOP;
  const cronograma = calcularCronogramaInvestimento(poupanca);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(15);
  doc.text("RELATÓRIO DE POUPANÇA - INVESTIMENTO", pageW / 2, y, { align: "center" });
  y += 8;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.text(`Emitido em: ${new Date().toLocaleString("pt-PT")}`, pageW / 2, y, { align: "center" });
  y += 8;

  autoTable(doc, {
    startY: y,
    theme: "grid",
    body: [
      ["Investidor", poupanca.cliente_nome],
      ["Tipo", poupanca.cliente_tipo === "instituicao" ? "Instituição" : "Individual"],
      ["NUIT", poupanca.nuit || "-"],
      ["Contacto", poupanca.contacto || "-"],
      ["Capital Investido", `${fmt(poupanca.valor_capital)} MZN`],
      ["Taxa Mensal", `${Number(poupanca.taxa_mensal).toFixed(2)} %`],
      ["Período", `${poupanca.periodo_meses} meses (${cronograma.diasTotais} dias)`],
      ["Data Início", fmtDate(poupanca.data_inicio)],
      ["Data Fim", fmtDate(cronograma.dataFim)],
      ["Ganho Mensal", `${fmt(poupanca.valor_capital * (poupanca.taxa_mensal/100))} MZN`],
      ["Ganhos Totais Previstos", `${fmt(cronograma.totalGanhos)} MZN`],
      ["Status", poupanca.status?.toUpperCase() || "ACTIVO"],
    ],
    styles: { fontSize: 10 },
    margin: { bottom: LETTERHEAD_CONTENT_BOTTOM },
  });

  const finalY = (doc as any).lastAutoTable?.finalY || y + 60;
  autoTable(doc, {
    startY: finalY + 8,
    head: [["#", "Mês Ref.", "Data Prevista", "Ganho", "Pago?", "Data Pagamento"]],
    body: cronograma.rows.map((r, i) => {
      const g = ganhos.find(x => x.mes_referencia === r.data.slice(0, 7));
      return [
        String(r.mes), r.data.slice(0, 7), fmtDate(r.data), fmt(r.ganho),
        g?.pago ? "Sim" : "Não", g?.data_pagamento ? fmtDate(g.data_pagamento) : "-"
      ];
    }),
    styles: { fontSize: 9 },
    headStyles: { fillColor: [91, 79, 191] },
    margin: { bottom: LETTERHEAD_CONTENT_BOTTOM },
  });

  const totalPago = ganhos.filter(g => g.pago).reduce((s, g) => s + Number(g.valor_ganho || 0), 0);
  const yTot = (doc as any).lastAutoTable?.finalY || y + 100;
  doc.setFont("helvetica", "bold");
  doc.text(`Total Ganhos Pagos: ${fmt(totalPago)} MZN`, 14, yTot + 8);
  doc.text(`Ganhos por Pagar: ${fmt(cronograma.totalGanhos - totalPago)} MZN`, 14, yTot + 14);

  applyLetterheadAllPages(doc, lh);
  doc.save(`relatorio-investimento-${poupanca.cliente_nome.replace(/\s+/g, "_")}.pdf`);
}
