import { supabase } from "@/integrations/supabase/client";

export interface FechoAgregado {
  // Empréstimos (concedidos no período)
  qtdEmprestimos: number;
  valorEmprestado: number;      // capital desembolsado
  totalAPagar: number;          // valor_total dos empréstimos do período
  // Pagamentos no período
  qtdPagamentos: number;
  capitalRecebido: number;
  jurosRecebidos: number;
  multasRecebidas: number;
  totalRecebido: number;
  // Despesas
  totalDespesas: number;
  despesasPorCategoria: Record<string, number>;
  // Receitas diversas (entradas de capital)
  receitasDiversas: number;
  receitasPorDescricao: Record<string, number>;
  // Clientes
  novosClientes: number;
}

const zero = (): FechoAgregado => ({
  qtdEmprestimos: 0,
  valorEmprestado: 0,
  totalAPagar: 0,
  qtdPagamentos: 0,
  capitalRecebido: 0,
  jurosRecebidos: 0,
  multasRecebidas: 0,
  totalRecebido: 0,
  totalDespesas: 0,
  despesasPorCategoria: {},
  receitasDiversas: 0,
  receitasPorDescricao: {},
  novosClientes: 0,
});

const num = (v: any) => Number(v) || 0;

/** Agrega (somente leitura) todos os movimentos do período. */
export async function agregarPeriodo(ini: string, fim: string): Promise<FechoAgregado> {
  const out = zero();

  const [emp, pag, desp, ent, cli] = await Promise.all([
    supabase.from("emprestimos").select("valor, valor_total").gte("data_desembolso", ini).lte("data_desembolso", fim),
    supabase.from("pagamentos").select("valor, tipo").gte("data_pagamento", ini).lte("data_pagamento", fim),
    supabase.from("despesas").select("valor, categoria").gte("data", ini).lte("data", fim),
    supabase.from("entradas_capital").select("valor, descricao").gte("data", ini).lte("data", fim),
    supabase.from("clientes").select("id", { count: "exact", head: true }).gte("created_at", ini).lte("created_at", `${fim}T23:59:59`),
  ]);

  (emp.data || []).forEach((e: any) => {
    out.qtdEmprestimos++;
    out.valorEmprestado += num(e.valor);
    out.totalAPagar += num(e.valor_total);
  });

  (pag.data || []).forEach((p: any) => {
    const t = String(p.tipo || "").toLowerCase();
    const v = num(p.valor);
    out.qtdPagamentos++;
    out.totalRecebido += v;
    if (t.includes("mora")) out.multasRecebidas += v;
    else if (t.includes("juros")) out.jurosRecebidos += v;
    else out.capitalRecebido += v;
  });

  (desp.data || []).forEach((d: any) => {
    const v = num(d.valor);
    const c = d.categoria || "Outros";
    out.totalDespesas += v;
    out.despesasPorCategoria[c] = (out.despesasPorCategoria[c] || 0) + v;
  });

  (ent.data || []).forEach((e: any) => {
    const v = num(e.valor);
    const c = e.descricao || "Outras receitas";
    out.receitasDiversas += v;
    out.receitasPorDescricao[c] = (out.receitasPorDescricao[c] || 0) + v;
  });

  out.novosClientes = cli.count || 0;
  return out;
}

export interface CarteiraSnapshot {
  qtdPagos: number;
  qtdAtivos: number;
  qtdVencidos: number;
  qtdIncumprimento: number;
  emDivida: number;
  capitalAtraso: number;
  capitalCirculacao: number;
  totalCarteira: number;
  totalPagoCarteira: number;
}

/** Situação da carteira até à data de fecho (somente leitura). */
export async function carteiraAte(fim: string): Promise<CarteiraSnapshot> {
  const s: CarteiraSnapshot = {
    qtdPagos: 0, qtdAtivos: 0, qtdVencidos: 0, qtdIncumprimento: 0,
    emDivida: 0, capitalAtraso: 0, capitalCirculacao: 0, totalCarteira: 0, totalPagoCarteira: 0,
  };
  const { data } = await supabase
    .from("emprestimos")
    .select("valor, valor_total, valor_pago, status, data_reembolso")
    .lte("data_desembolso", fim);

  const limite = new Date(`${fim}T23:59:59`);
  (data || []).forEach((e: any) => {
    const total = num(e.valor_total) || num(e.valor);
    const pago = num(e.valor_pago);
    const divida = Math.max(0, total - pago);
    s.totalCarteira += total;
    s.totalPagoCarteira += pago;
    s.emDivida += divida;

    if (divida <= 0.01) { s.qtdPagos++; return; }
    const venc = e.data_reembolso ? new Date(e.data_reembolso) : null;
    const atrasado = venc ? venc < limite : false;
    if (atrasado) {
      s.qtdVencidos++;
      s.capitalAtraso += divida;
      const dias = venc ? Math.floor((limite.getTime() - venc.getTime()) / 86400000) : 0;
      if (dias > 90) s.qtdIncumprimento++;
    } else {
      s.qtdAtivos++;
      s.capitalCirculacao += divida;
    }
  });
  return s;
}

export type PeriodoPreset =
  | "hoje" | "ontem" | "semana" | "semana-passada" | "mes" | "mes-passado"
  | "trimestre" | "ano" | "personalizado";

const iso = (d: Date) => d.toISOString().slice(0, 10);

export function calcularPeriodo(preset: PeriodoPreset): { ini: string; fim: string } {
  const h = new Date();
  const d = (base: Date, days: number) => { const x = new Date(base); x.setDate(x.getDate() + days); return x; };
  switch (preset) {
    case "hoje": return { ini: iso(h), fim: iso(h) };
    case "ontem": { const y = d(h, -1); return { ini: iso(y), fim: iso(y) }; }
    case "semana": { const dow = (h.getDay() + 6) % 7; const s = d(h, -dow); return { ini: iso(s), fim: iso(d(s, 6)) }; }
    case "semana-passada": { const dow = (h.getDay() + 6) % 7; const s = d(h, -dow - 7); return { ini: iso(s), fim: iso(d(s, 6)) }; }
    case "mes": return { ini: iso(new Date(h.getFullYear(), h.getMonth(), 1)), fim: iso(new Date(h.getFullYear(), h.getMonth() + 1, 0)) };
    case "mes-passado": return { ini: iso(new Date(h.getFullYear(), h.getMonth() - 1, 1)), fim: iso(new Date(h.getFullYear(), h.getMonth(), 0)) };
    case "trimestre": { const q = Math.floor(h.getMonth() / 3); return { ini: iso(new Date(h.getFullYear(), q * 3, 1)), fim: iso(new Date(h.getFullYear(), q * 3 + 3, 0)) }; }
    case "ano": return { ini: iso(new Date(h.getFullYear(), 0, 1)), fim: iso(new Date(h.getFullYear(), 11, 31)) };
    default: return { ini: iso(new Date(h.getFullYear(), h.getMonth(), 1)), fim: iso(h) };
  }
}

/** Período imediatamente anterior com a mesma duração. */
export function periodoAnterior(ini: string, fim: string) {
  const a = new Date(ini), b = new Date(fim);
  const dias = Math.round((b.getTime() - a.getTime()) / 86400000) + 1;
  const novoFim = new Date(a); novoFim.setDate(novoFim.getDate() - 1);
  const novoIni = new Date(novoFim); novoIni.setDate(novoIni.getDate() - dias + 1);
  return { ini: iso(novoIni), fim: iso(novoFim) };
}

/** Mesmo período do ano anterior. */
export function periodoAnoAnterior(ini: string, fim: string) {
  const a = new Date(ini), b = new Date(fim);
  a.setFullYear(a.getFullYear() - 1);
  b.setFullYear(b.getFullYear() - 1);
  return { ini: iso(a), fim: iso(b) };
}
