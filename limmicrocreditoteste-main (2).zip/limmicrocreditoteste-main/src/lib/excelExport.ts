import * as XLSX from "xlsx";

export interface ExcelSection {
  title?: string;
  headers?: string[];
  data: (string | number)[][];
  mergeHeaderCols?: number;
}

/**
 * Cria um Excel formatado com layout estruturado idêntico ao PDF
 * Inclui cabeçalho da empresa, seções com títulos e tabelas
 */
export function createFormattedExcel(
  sections: ExcelSection[],
  filename: string,
  sheetName: string = "Relatório",
  companyHeader?: {
    nomeEmpresa?: string;
    endereco?: string;
    telefone?: string;
    email?: string;
    nuit?: string;
    titulo?: string;
    subtitulo?: string;
    data?: string;
  }
) {
  const wb = XLSX.utils.book_new();
  const allData: (string | number)[][] = [];
  const merges: XLSX.Range[] = [];
  let currentRow = 0;
  const defaultCols = 6;

  // Cabeçalho da empresa
  if (companyHeader) {
    if (companyHeader.nomeEmpresa) {
      allData.push([companyHeader.nomeEmpresa]);
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: defaultCols - 1 } });
      currentRow++;
    }
    if (companyHeader.endereco) {
      allData.push([companyHeader.endereco]);
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: defaultCols - 1 } });
      currentRow++;
    }
    if (companyHeader.telefone || companyHeader.email) {
      const contacto = `Tel: ${companyHeader.telefone || ''} | Email: ${companyHeader.email || ''}`;
      allData.push([contacto]);
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: defaultCols - 1 } });
      currentRow++;
    }
    if (companyHeader.nuit) {
      allData.push([`NUIT: ${companyHeader.nuit}`]);
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: defaultCols - 1 } });
      currentRow++;
    }
    allData.push([]);
    currentRow++;

    if (companyHeader.titulo) {
      allData.push([companyHeader.titulo]);
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: defaultCols - 1 } });
      currentRow++;
    }
    if (companyHeader.subtitulo) {
      allData.push([companyHeader.subtitulo]);
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: defaultCols - 1 } });
      currentRow++;
    }
    if (companyHeader.data) {
      allData.push([`Data: ${companyHeader.data}`]);
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: defaultCols - 1 } });
      currentRow++;
    }
    allData.push([]);
    currentRow++;
  }

  // Processar seções
  sections.forEach((section) => {
    if (section.title) {
      allData.push([section.title]);
      const mergeCols = section.mergeHeaderCols || defaultCols;
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: mergeCols - 1 } });
      currentRow++;
      allData.push([]);
      currentRow++;
    }

    if (section.headers) {
      allData.push(section.headers);
      currentRow++;
    }

    section.data.forEach((row) => {
      allData.push(row);
      currentRow++;
    });

    // Espaço entre seções
    allData.push([]);
    currentRow++;
  });

  // Criar worksheet
  const ws = XLSX.utils.aoa_to_sheet(allData);
  ws['!merges'] = merges;

  // Definir larguras de colunas
  ws['!cols'] = [
    { wch: 35 }, { wch: 25 }, { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 20 }
  ];

  XLSX.utils.book_append_sheet(wb, ws, sheetName);
  XLSX.writeFile(wb, filename);
}

/**
 * Formata valor em MZN
 */
export function formatMZN(value: number): string {
  return `${value.toFixed(2)} MZN`;
}

/**
 * Formata data em português
 */
export function formatDatePT(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('pt-PT');
}
