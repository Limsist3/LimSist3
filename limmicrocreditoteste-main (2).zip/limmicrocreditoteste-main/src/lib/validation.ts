import { z } from 'zod';

// Client validation schema
export const clienteSchema = z.object({
  nome_completo: z.string()
    .trim()
    .min(3, "Nome deve ter pelo menos 3 caracteres")
    .max(100, "Nome deve ter no máximo 100 caracteres"),
  telefone: z.string()
    .trim()
    .regex(/^[+]?[0-9]{9,15}$/, "Telefone inválido (9-15 dígitos)"),
  email: z.string()
    .trim()
    .email("E-mail inválido")
    .max(255, "E-mail muito longo")
    .optional()
    .or(z.literal("")),
  nuit: z.string()
    .trim()
    .regex(/^[0-9]{9}$/, "NUIT deve ter 9 dígitos")
    .optional()
    .or(z.literal("")),
  bi: z.string()
    .trim()
    .min(5, "BI é obrigatório (mínimo 5 caracteres)")
    .max(30, "BI muito longo"),
  data_nascimento: z.string()
    .min(1, "Data de nascimento é obrigatória")
    .refine((v) => {
      const d = new Date(v);
      if (isNaN(d.getTime())) return false;
      const hoje = new Date();
      let idade = hoje.getFullYear() - d.getFullYear();
      const m = hoje.getMonth() - d.getMonth();
      if (m < 0 || (m === 0 && hoje.getDate() < d.getDate())) idade--;
      return idade > 17 && idade < 100;
    }, "O cliente deve ter mais de 17 anos"),
  genero: z.string().optional(),
  provincia: z.string().optional(),
  distrito: z.string().max(100).optional(),
  bairro: z.string().max(100).optional(),
  rua: z.string().max(200).optional(),
});

// Loan validation schema
export const emprestimoSchema = z.object({
  valor: z.number()
    .positive("Valor deve ser positivo")
    .max(1000000000, "Valor muito alto"),
  taxa_juros: z.number()
    .min(0, "Taxa de juros não pode ser negativa")
    .max(100, "Taxa de juros deve ser menor que 100%"),
  taxa_mora: z.number()
    .min(0, "Taxa de mora não pode ser negativa")
    .max(100, "Taxa de mora deve ser menor que 100%"),
  duracao_meses: z.number()
    .int("Duração deve ser um número inteiro")
    .min(1, "Duração mínima é 1 mês")
    .max(360, "Duração máxima é 360 meses"),
  tipo_juros: z.enum(["Simples", "Composto", "SobreSaldo"]),
  modalidade_desembolso: z.string().max(50).optional(),
  tipo_garantia: z.string().max(100).optional(),
  detalhes_garantia: z.string().max(500).optional(),
  observacoes: z.string().max(1000).optional(),
  data_desembolso: z.string().min(1, "Data de desembolso é obrigatória"),
});

// Expense validation schema
export const despesaSchema = z.object({
  categoria: z.string()
    .min(1, "Categoria é obrigatória")
    .max(50, "Categoria muito longa"),
  descricao: z.string()
    .trim()
    .min(3, "Descrição deve ter pelo menos 3 caracteres")
    .max(500, "Descrição muito longa"),
  valor: z.number()
    .positive("Valor deve ser positivo")
    .max(1000000000, "Valor muito alto"),
  data: z.string().min(1, "Data é obrigatória"),
});

// Password validation schema
export const passwordSchema = z.string()
  .min(8, "Senha deve ter pelo menos 8 caracteres")
  .regex(/[a-z]/, "Senha deve conter pelo menos uma letra minúscula")
  .regex(/[A-Z]/, "Senha deve conter pelo menos uma letra maiúscula")
  .regex(/[0-9]/, "Senha deve conter pelo menos um número")
  .regex(/[@$!%*?&#]/, "Senha deve conter pelo menos um caractere especial (@$!%*?&#)");

// Notification validation schema
export const notificationSchema = z.object({
  titulo: z.string()
    .trim()
    .min(3, "Título deve ter pelo menos 3 caracteres")
    .max(100, "Título muito longo"),
  mensagem: z.string()
    .trim()
    .min(10, "Mensagem deve ter pelo menos 10 caracteres")
    .max(1000, "Mensagem muito longa"),
  tipo: z.enum(["info", "aviso", "urgente"]),
  global: z.boolean(),
});
