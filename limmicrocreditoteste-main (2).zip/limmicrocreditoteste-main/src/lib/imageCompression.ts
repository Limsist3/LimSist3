/**
 * Compressão automática e agressiva de ficheiros antes de upload.
 *
 * Imagens (BI, comprovativos, fotos, logos):
 *  - Redimensiona para máx. 1000px no maior lado
 *  - Converte para WebP com qualidade adaptativa (0.72 → 0.35)
 *  - Alvo: ≤ 120 KB por ficheiro (redução típica de 90-98%)
 *
 * PDFs:
 *  - Re-gravados com object streams (remove metadados e duplicados)
 *
 * Fallback sempre seguro: se algo falhar, devolve o ficheiro original.
 */

import { PDFDocument } from 'pdf-lib';

const MAX_DIMENSION = 1000;
const TARGET_BYTES = 120 * 1024; // 120 KB
const MIN_SIZE_TO_COMPRESS = 40 * 1024; // 40 KB
const QUALITY_STEPS = [0.72, 0.6, 0.5, 0.42, 0.35];
const COMPRESSIBLE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/bmp', 'image/tiff'];

export interface CompressionResult {
  file: File;
  originalSize: number;
  compressedSize: number;
  compressed: boolean;
}

/**
 * Comprime uma imagem de forma iterativa até atingir o alvo de tamanho.
 * Ficheiros pequenos (<40KB), SVG e GIF ficam intactos.
 */
export async function compressImage(file: File): Promise<CompressionResult> {
  const originalSize = file.size;
  const baseResult: CompressionResult = {
    file,
    originalSize,
    compressedSize: originalSize,
    compressed: false,
  };

  if (
    !COMPRESSIBLE_TYPES.includes(file.type.toLowerCase()) ||
    file.size < MIN_SIZE_TO_COMPRESS
  ) {
    return baseResult;
  }

  try {
    const dataUrl = await fileToDataUrl(file);
    const img = await loadImage(dataUrl);

    // Calcular novas dimensões mantendo proporção
    let { width, height } = img;
    if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
      if (width > height) {
        height = Math.round((height * MAX_DIMENSION) / width);
        width = MAX_DIMENSION;
      } else {
        width = Math.round((width * MAX_DIMENSION) / height);
        height = MAX_DIMENSION;
      }
    }

    let best: Blob | null = null;

    for (const quality of QUALITY_STEPS) {
      const blob = await renderToBlob(img, width, height, quality);
      if (!blob) continue;
      if (!best || blob.size < best.size) best = blob;
      if (blob.size <= TARGET_BYTES) {
        best = blob;
        break;
      }
    }

    // Se ainda for grande, reduzir também as dimensões (segunda passagem)
    if (best && best.size > TARGET_BYTES && Math.max(width, height) > 700) {
      const scale = 700 / Math.max(width, height);
      const w2 = Math.max(1, Math.round(width * scale));
      const h2 = Math.max(1, Math.round(height * scale));
      const smaller = await renderToBlob(img, w2, h2, 0.5);
      if (smaller && smaller.size < best.size) best = smaller;
    }

    if (!best || best.size >= originalSize) {
      return baseResult;
    }

    const originalName = file.name.replace(/\.[^.]+$/, '');
    const compressedFile = new File([best], `${originalName}.webp`, {
      type: 'image/webp',
      lastModified: Date.now(),
    });

    return {
      file: compressedFile,
      originalSize,
      compressedSize: best.size,
      compressed: true,
    };
  } catch (err) {
    console.warn('[imageCompression] Falhou, usando original:', err);
    return baseResult;
  }
}

/**
 * Re-grava um PDF removendo metadados e usando object streams.
 */
export async function compressPdf(file: File): Promise<CompressionResult> {
  const originalSize = file.size;
  const baseResult: CompressionResult = {
    file,
    originalSize,
    compressedSize: originalSize,
    compressed: false,
  };

  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    return baseResult;
  }

  try {
    const bytes = await file.arrayBuffer();
    const pdf = await PDFDocument.load(bytes, { ignoreEncryption: true, updateMetadata: false });
    pdf.setTitle('');
    pdf.setAuthor('');
    pdf.setSubject('');
    pdf.setKeywords([]);
    pdf.setProducer('');
    pdf.setCreator('');
    const out = await pdf.save({ useObjectStreams: true, addDefaultPage: false });
    const buffer = new Uint8Array(out).slice().buffer as ArrayBuffer;

    if (out.byteLength >= originalSize) return baseResult;

    const compressedFile = new File([buffer], file.name, {
      type: 'application/pdf',
      lastModified: Date.now(),
    });

    return {
      file: compressedFile,
      originalSize,
      compressedSize: out.byteLength,
      compressed: true,
    };
  } catch (err) {
    console.warn('[pdfCompression] Falhou, usando original:', err);
    return baseResult;
  }
}

/**
 * Comprime qualquer ficheiro suportado (imagem ou PDF) e devolve o File final.
 */
export async function compressAnyFile(file: File): Promise<File> {
  if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) {
    return (await compressPdf(file)).file;
  }
  return (await compressImage(file)).file;
}

/**
 * Atalho que devolve directamente o File (comprimido ou original).
 */
export async function compressIfImage(file: File): Promise<File> {
  return compressAnyFile(file);
}

function renderToBlob(
  img: HTMLImageElement,
  width: number,
  height: number,
  quality: number,
): Promise<Blob | null> {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return Promise.resolve(null);
  ctx.drawImage(img, 0, 0, width, height);
  return new Promise((resolve) => canvas.toBlob(resolve, 'image/webp', quality));
}

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}
