import { supabase } from "@/integrations/supabase/client";

let installed = false;
let lastReport = 0;
const MIN_INTERVAL = 2000; // anti-spam: máx 1 erro / 2s

async function report(message: string, stack?: string, context?: Record<string, unknown>) {
  try {
    const now = Date.now();
    if (now - lastReport < MIN_INTERVAL) return;
    lastReport = now;

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase.from("user_error_logs").insert([{
      user_id: user.id,
      message: String(message).slice(0, 1000),
      stack: stack ? String(stack).slice(0, 4000) : null,
      url: window.location.href,
      user_agent: navigator.userAgent.slice(0, 500),
      context: (context ?? null) as any,
    }]);
  } catch {
    // silencioso — nunca rebentar dentro do reporter
  }
}

export function installErrorReporter() {
  if (installed) return;
  installed = true;

  window.addEventListener("error", (e) => {
    report(e.message || "window error", e.error?.stack, {
      filename: e.filename,
      lineno: e.lineno,
      colno: e.colno,
    });
  });

  window.addEventListener("unhandledrejection", (e) => {
    const reason: any = e.reason;
    report(
      reason?.message || String(reason) || "unhandled rejection",
      reason?.stack,
      { type: "unhandledrejection" }
    );
  });
}

export const reportError = report;
