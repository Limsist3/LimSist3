/**
 * Decompõe o valor pago de um empréstimo em capital e juros (proporcional),
 * sem alterar nenhum dado — apenas cálculo para apresentação.
 */
export interface DecomposicaoPagamento {
  valor: number;
  total: number;
  juros: number;
  pago: number;
  capitalPago: number;
  jurosPagos: number;
  capitalEmDivida: number;
  jurosEmDivida: number;
  divida: number;
  pct: number;
  liquidado: boolean;
}

export function decomporPagamento(emp: {
  valor?: number | null;
  valor_total?: number | null;
  valor_pago?: number | null;
}): DecomposicaoPagamento {
  const valor = Number(emp.valor || 0);
  const total = Number(emp.valor_total || 0) || valor;
  const juros = Math.max(0, total - valor);
  const pago = Math.min(Number(emp.valor_pago || 0), total);

  const ratio = total > 0 ? pago / total : 0;
  const capitalPago = round2(valor * ratio);
  const jurosPagos = round2(Math.max(0, pago - capitalPago));
  const divida = round2(Math.max(0, total - pago));

  return {
    valor,
    total,
    juros: round2(juros),
    pago: round2(pago),
    capitalPago,
    jurosPagos,
    capitalEmDivida: round2(Math.max(0, valor - capitalPago)),
    jurosEmDivida: round2(Math.max(0, juros - jurosPagos)),
    divida,
    pct: total > 0 ? Math.min(100, (pago / total) * 100) : 0,
    liquidado: divida <= 0.01,
  };
}

function round2(n: number) {
  return Math.round(n * 100) / 100;
}
