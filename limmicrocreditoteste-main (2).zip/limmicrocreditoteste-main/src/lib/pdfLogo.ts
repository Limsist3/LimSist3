import jsPDF from "jspdf";

/**
 * Carrega o logotipo da empresa em base64 a partir de uma URL.
 * Retorna null se não houver logo ou se ocorrer erro.
 */
export async function loadLogoDataUrl(logoUrl?: string | null): Promise<{ dataUrl: string; format: string } | null> {
  if (!logoUrl) return null;
  try {
    const res = await fetch(logoUrl);
    const blob = await res.blob();
    const dataUrl: string = await new Promise((resolve) => {
      const r = new FileReader();
      r.onloadend = () => resolve(r.result as string);
      r.readAsDataURL(blob);
    });
    const format = (dataUrl.match(/data:image\/(\w+);/)?.[1] || "png").toUpperCase();
    return { dataUrl, format };
  } catch (e) {
    console.warn("Logo não carregado:", e);
    return null;
  }
}

/**
 * Adiciona o logotipo da empresa centrado no topo do PDF.
 * Retorna o novo Y (posição vertical) para conteúdo subsequente.
 */
export async function addCompanyLogoToPdf(
  doc: jsPDF,
  logoUrl: string | null | undefined,
  startY: number = 10,
  size: number = 20
): Promise<number> {
  const logo = await loadLogoDataUrl(logoUrl);
  if (!logo) return startY;
  try {
    const pageWidth = doc.internal.pageSize.getWidth();
    doc.addImage(logo.dataUrl, logo.format, pageWidth / 2 - size / 2, startY, size, size);
    return startY + size + 2;
  } catch (e) {
    console.warn("Erro ao adicionar logo:", e);
    return startY;
  }
}
