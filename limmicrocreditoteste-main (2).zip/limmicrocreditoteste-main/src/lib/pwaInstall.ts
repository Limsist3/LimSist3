// Singleton para capturar e partilhar o evento beforeinstallprompt
// entre os vários componentes de instalação PWA.

export interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

type Listener = (event: BeforeInstallPromptEvent | null) => void;

let deferred: BeforeInstallPromptEvent | null = null;
const listeners = new Set<Listener>();
let initialized = false;

function notify() {
  listeners.forEach((l) => l(deferred));
}

export function initPWAInstallCapture() {
  if (initialized || typeof window === "undefined") return;
  initialized = true;

  window.addEventListener("beforeinstallprompt", (e: Event) => {
    e.preventDefault();
    deferred = e as BeforeInstallPromptEvent;
    notify();
  });

  window.addEventListener("appinstalled", () => {
    deferred = null;
    try {
      localStorage.setItem("pwa-installed", "true");
    } catch {}
    notify();
  });
}

export function getDeferredPrompt() {
  return deferred;
}

export function consumeDeferredPrompt() {
  const p = deferred;
  deferred = null;
  notify();
  return p;
}

export function subscribePWAInstall(l: Listener): () => void {
  listeners.add(l);
  l(deferred);
  return () => {
    listeners.delete(l);
  };
}

export function isAppInstalled(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as any).standalone === true ||
      document.referrer.includes("android-app://");
    if (standalone) return true;
    return localStorage.getItem("pwa-installed") === "true";
  } catch {
    return false;
  }
}
