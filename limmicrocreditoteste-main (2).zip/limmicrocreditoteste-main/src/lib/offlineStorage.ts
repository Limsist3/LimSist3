const DB_NAME = 'limsist_data';
const DB_VERSION = 2; // Atualizado para suportar novas stores de capital

interface Store {
  name: string;
  keyPath: string;
}

const STORES: Store[] = [
  { name: 'clientes', keyPath: 'id' },
  { name: 'emprestimos', keyPath: 'id' },
  { name: 'pagamentos', keyPath: 'id' },
  { name: 'despesas', keyPath: 'id' },
  { name: 'capital_global', keyPath: 'id' },
  { name: 'capital_mensal', keyPath: 'id' },
  { name: 'entradas_capital', keyPath: 'id' },
];

export class OfflineStorage {
  private db: IDBDatabase | null = null;

  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event: any) => {
        const db = event.target.result;
        
        STORES.forEach(store => {
          if (!db.objectStoreNames.contains(store.name)) {
            db.createObjectStore(store.name, { keyPath: store.keyPath });
          }
        });
      };
    });
  }

  async saveData(storeName: string, data: any[]): Promise<void> {
    if (!this.db) await this.init();
    
    const tx = this.db!.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    
    // Limpar dados existentes
    await store.clear();
    
    // Adicionar novos dados
    for (const item of data) {
      await store.add(item);
    }
  }

  async getData(storeName: string): Promise<any[]> {
    if (!this.db) await this.init();
    
    const tx = this.db!.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    
    return new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  async addItem(storeName: string, item: any): Promise<void> {
    if (!this.db) await this.init();
    
    const tx = this.db!.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    await store.add(item);
  }

  async updateItem(storeName: string, item: any): Promise<void> {
    if (!this.db) await this.init();
    
    const tx = this.db!.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    await store.put(item);
  }

  async deleteItem(storeName: string, id: string): Promise<void> {
    if (!this.db) await this.init();
    
    const tx = this.db!.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    await store.delete(id);
  }

  async clearAll(): Promise<void> {
    if (!this.db) await this.init();
    
    for (const store of STORES) {
      const tx = this.db!.transaction(store.name, 'readwrite');
      await tx.objectStore(store.name).clear();
    }
  }
}

export const offlineStorage = new OfflineStorage();
