import jsPDF from "jspdf";
import { supabase } from "@/integrations/supabase/client";
import { loadLogoDataUrl } from "@/lib/pdfLogo";

/**
 * Papel timbrado padrão aplicado em recibos, contratos e relatórios internos.
 * Cada usuário usa o seu logotipo, endereço, contactos e cores (definidas em Configurações).
 *
 * Layout (A4 retrato):
 *  - Topo-direito: barra de destaque (cor primária) + quadrado (cor secundária)
 *  - Topo-esquerdo: logotipo + nome da empresa + NUIT
 *  - Rodapé-esquerdo: "Local:" (endereço) e "Contatos:" (email/telefone)
 *  - Faixa inferior: barra colorida (cor secundária)
 */

export interface LetterheadConfig {
  nome_empresa?: string | null;
  endereco?: string | null;
  email?: string | null;
  telefone?: string | null;
  nuit?: string | null;
  logo_url?: string | null;
  cor_primaria_documentos?: string | null;
  cor_secundaria_documentos?: string | null;
}

export interface LoadedLetterhead {
  config: LetterheadConfig;
  logo: { dataUrl: string; format: string } | null;
}

/** Espaço a reservar (em mm) acima do conteúdo para o cabeçalho */
export const LETTERHEAD_CONTENT_TOP = 42;
/** Espaço a reservar (em mm) abaixo do conteúdo para o rodapé + faixa */
export const LETTERHEAD_CONTENT_BOTTOM = 32;

const DEFAULT_PRIMARY = "#5B4FBF";
const DEFAULT_SECONDARY = "#1E1B4B";

function hexToRgb(hex?: string | null, fallback = DEFAULT_PRIMARY): [number, number, number] {
  let h = (hex || fallback).trim().replace("#", "");
  if (h.length === 3) h = h.split("").map((c) => c + c).join("");
  if (!/^[0-9a-fA-F]{6}$/.test(h)) h = fallback.replace("#", "");
  const n = parseInt(h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export async function loadLetterhead(): Promise<LoadedLetterhead> {
  let config: LetterheadConfig = {};
  try {
    const { data: { session } } = await supabase.auth.getSession();
    const user = session?.user;
    if (user) {
      const { data } = await supabase
        .from("configuracoes_empresa")
        .select("nome_empresa, endereco, email, telefone, nuit, logo_url, cor_primaria_documentos, cor_secundaria_documentos")
        .eq("user_id", user.id)
        .maybeSingle();
      if (data) config = data as any;
    }
  } catch (e) {
    console.warn("Letterhead config falhou:", e);
  }
  const logo = await loadLogoDataUrl(config.logo_url || null);
  return { config, logo };
}

export function drawLetterheadOnCurrentPage(doc: jsPDF, lh: LoadedLetterhead) {
  const { config, logo } = lh;
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const primary = hexToRgb(config.cor_primaria_documentos, DEFAULT_PRIMARY);
  const secondary = hexToRgb(config.cor_secundaria_documentos, DEFAULT_SECONDARY);

  // Guardar estado de cor/fonte
  const prevFontSize = (doc as any).getFontSize?.() ?? 10;

  // --- TOPO DIREITO: barra de destaque + quadrado
  doc.setFillColor(primary[0], primary[1], primary[2]);
  doc.rect(pageW - 70, 0, 56, 5, "F");
  doc.setFillColor(secondary[0], secondary[1], secondary[2]);
  doc.rect(pageW - 14, 0, 9, 8, "F");

  // --- TOPO ESQUERDO: logotipo + nome
  let textX = 14;
  if (logo) {
    try {
      doc.addImage(logo.dataUrl, logo.format, 14, 7, 18, 18);
      textX = 35;
    } catch {}
  }
  if (config.nome_empresa) {
    doc.setTextColor(secondary[0], secondary[1], secondary[2]);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(13);
    doc.text(String(config.nome_empresa).toUpperCase(), textX, 15);
    if (config.nuit) {
      doc.setFont("helvetica", "normal");
      doc.setFontSize(7.5);
      doc.setTextColor(90, 90, 90);
      doc.text(`NUIT: ${config.nuit}`, textX, 21);
    }
  }

  // --- FAIXA INFERIOR (banda colorida)
  doc.setFillColor(secondary[0], secondary[1], secondary[2]);
  doc.rect(0, pageH - 8, pageW, 8, "F");

  // --- RODAPÉ (acima da faixa): Local / Contatos
  const footY = pageH - 20;
  doc.setFontSize(7.5);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(secondary[0], secondary[1], secondary[2]);
  doc.text("Local:", 14, footY);
  doc.text("Contatos:", 80, footY);

  doc.setFont("helvetica", "normal");
  doc.setTextColor(60, 60, 60);
  doc.setFontSize(7);
  const enderecoLines = doc.splitTextToSize(config.endereco || "-", 60);
  doc.text(enderecoLines.slice(0, 2), 14, footY + 3.2);

  const contactos: string[] = [];
  if (config.email) contactos.push(config.email);
  if (config.telefone) contactos.push(config.telefone);
  if (contactos.length === 0) contactos.push("-");
  doc.text(contactos.slice(0, 2), 80, footY + 3.2);

  // Reset estado
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(prevFontSize);
  doc.setFont("helvetica", "normal");
}

/** Desenha o papel timbrado em todas as páginas existentes. Chamar antes de doc.save(). */
export function applyLetterheadAllPages(doc: jsPDF, lh: LoadedLetterhead) {
  const total = doc.getNumberOfPages();
  for (let i = 1; i <= total; i++) {
    doc.setPage(i);
    drawLetterheadOnCurrentPage(doc, lh);
  }
  doc.setPage(total);
}
