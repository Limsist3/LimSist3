/**
 * Error handling utilities for secure error logging and user feedback
 */

/**
 * Logs errors only in development mode
 * In production, errors are not logged to console to prevent information leakage
 */
export function logError(context: string, error: any): void {
  if (import.meta.env.DEV) {
    console.error(`[${context}]`, error);
  }
  // In production, errors should be sent to a proper error tracking service
  // Example: Sentry.captureException(error, { tags: { context } });
}

/**
 * Gets a safe, user-friendly error message without exposing sensitive details
 */
export function getSafeErrorMessage(error: any): string {
  if (!error) return "Erro inesperado";
  
  // Handle Supabase/Postgres errors - check specific codes first
  if (error.code) {
    if (error.code === '42501') {
      return "Sem permissão para esta operação";
    }
    if (error.code === '23505') {
      return "Registro duplicado. Verifique os dados e tente novamente";
    }
    if (error.code === '23503') {
      return "Dados relacionados não encontrados. Verifique o cliente selecionado";
    }
    if (error.code === '23502') {
      return "Campo obrigatório não preenchido. Verifique todos os campos";
    }
    if (error.code === '23514') {
      return "Valor inválido. Verifique os dados inseridos";
    }
    if (error.code?.startsWith('PGRST')) {
      return "Erro ao processar dados. Tente novamente";
    }
    if (error.code?.startsWith('23')) {
      return "Erro nos dados. Verifique os campos e tente novamente";
    }
  }
  
  // Handle specific error messages
  if (error.message) {
    const msg = error.message.toLowerCase();
    if (msg.includes('invalid login')) return "E-mail ou senha incorretos";
    if (msg.includes('email not confirmed')) return "E-mail não confirmado. Verifique sua caixa de entrada";
    if (msg.includes('auth')) return "Erro de autenticação";
    if (msg.includes('fetch') || msg.includes('network') || msg.includes('failed to fetch')) {
      return "Erro de conexão. Verifique sua internet";
    }
    if (msg.includes('not found') || msg.includes('no rows')) {
      return "Dados não encontrados. Verifique e tente novamente";
    }
  }
  
  return "Erro ao processar solicitação. Tente novamente";
}

/**
 * Handles errors with safe logging and user-friendly messages
 */
export function handleError(context: string, error: any, customMessage?: string): string {
  logError(context, error);
  return customMessage || getSafeErrorMessage(error);
}
