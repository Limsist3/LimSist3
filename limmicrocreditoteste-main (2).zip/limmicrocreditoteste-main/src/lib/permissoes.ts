// Permissões granulares por membro da equipa (definidas pelo usuário mãe)

export type MembroRole = "agente" | "secretariado" | "contabilista" | "auditor" | "visualizador";

export interface ModuloPermissao {
  key: string;
  label: string;
  url: string;
}

// Módulos que o usuário mãe pode conceder aos membros
export const MODULOS_PERMISSAO: ModuloPermissao[] = [
  { key: "dashboard", label: "Painel", url: "/dashboard" },
  { key: "simulador", label: "Simulador", url: "/simulador" },
  { key: "clientes", label: "Clientes", url: "/clientes" },
  { key: "emprestimos", label: "Empréstimos", url: "/emprestimos" },
  { key: "pagamentos", label: "Pagamentos", url: "/pagamentos" },
  { key: "poupancas", label: "Poupanças", url: "/poupancas" },
  { key: "despesas", label: "Despesas", url: "/despesas" },
  { key: "relatorios", label: "Relatórios", url: "/relatorios" },
  { key: "arquivos", label: "Arquivos", url: "/arquivos" },
  { key: "central_risco", label: "Central de Risco", url: "/central-risco" },
  { key: "fecho_contas", label: "Fecho de Contas", url: "/fecho-contas" },
  { key: "chat", label: "Mensagens", url: "/chat" },
];

export interface Permissoes {
  // módulos visíveis
  ver: string[];
  // módulos onde pode criar/editar/apagar
  editar: string[];
}

export const PERMISSOES_PADRAO: Record<MembroRole, Permissoes> = {
  agente: {
    ver: ["dashboard", "simulador", "clientes", "emprestimos", "pagamentos"],
    editar: ["clientes"],
  },
  secretariado: {
    ver: [
      "dashboard",
      "simulador",
      "clientes",
      "emprestimos",
      "pagamentos",
      "poupancas",
      "despesas",
      "relatorios",
      "arquivos",
      "central_risco",
      "fecho_contas",
    ],
    editar: ["clientes", "pagamentos", "despesas", "arquivos"],
  },
  contabilista: {
    ver: ["dashboard", "pagamentos", "despesas", "relatorios", "fecho_contas", "arquivos"],
    editar: ["despesas", "fecho_contas"],
  },
  auditor: {
    ver: [
      "dashboard",
      "clientes",
      "emprestimos",
      "pagamentos",
      "despesas",
      "relatorios",
      "central_risco",
      "fecho_contas",
      "arquivos",
    ],
    editar: [],
  },
  visualizador: {
    ver: ["dashboard", "clientes", "emprestimos", "pagamentos"],
    editar: [],
  },
};

export const ROLES_MEMBRO: { value: MembroRole; label: string; limite: number }[] = [
  { value: "agente", label: "Agente", limite: 10 },
  { value: "secretariado", label: "Secretariado", limite: 1 },
  { value: "contabilista", label: "Contabilista", limite: 2 },
  { value: "auditor", label: "Auditor", limite: 2 },
  { value: "visualizador", label: "Visualizador", limite: 5 },
];

export function labelRole(role: string): string {
  return ROLES_MEMBRO.find((r) => r.value === role)?.label || role;
}

export function normalizarPermissoes(role: string, raw: unknown): Permissoes {
  const padrao = PERMISSOES_PADRAO[role as MembroRole] || { ver: [], editar: [] };
  if (!raw || typeof raw !== "object") return { ver: [...padrao.ver], editar: [...padrao.editar] };
  const obj = raw as Partial<Permissoes>;
  return {
    ver: Array.isArray(obj.ver) ? obj.ver : [...padrao.ver],
    editar: Array.isArray(obj.editar) ? obj.editar : [...padrao.editar],
  };
}

export function podeVer(perm: Permissoes | null, key: string): boolean {
  if (!perm) return true; // usuário mãe / superadmin: sem restrições
  return perm.ver.includes(key);
}

export function podeEditar(perm: Permissoes | null, key: string): boolean {
  if (!perm) return true;
  return perm.ver.includes(key) && perm.editar.includes(key);
}
