import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Guard: don't register SW in iframes or preview hosts
const isInIframe = (() => {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
})();

const isPreviewHost =
  window.location.hostname.includes("id-preview--") ||
  window.location.hostname.includes("lovableproject.com");

if ('serviceWorker' in navigator && !isInIframe && !isPreviewHost) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then((registration) => {
        // Verificar atualizações periodicamente (a cada 5 minutos, menos agressivo)
        setInterval(() => registration.update().catch(() => {}), 5 * 60_000);

        // Quando uma nova versão está pronta, ativa em background SEM reload forçado.
        // A nova versão será aplicada naturalmente na próxima navegação/abertura
        // do utilizador, evitando interromper o trabalho em curso.
        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing;
          if (!newWorker) return;
          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
              // Apenas ativa o novo SW em background; NÃO recarrega a página.
              newWorker.postMessage('SKIP_WAITING');
            }
          });
        });
      })
      .catch((error) => {
        console.log('SW registration failed:', error);
      });

    // IMPORTANTE: NÃO recarregar a página automaticamente em controllerchange.
    // O reload forçado interrompia formulários e dava sensação de "fechou sozinho".
    // A nova versão entra em uso na próxima vez que o utilizador navegar/abrir a app.
  });
} else if (isPreviewHost || isInIframe) {
  // Unregister any existing service workers in preview/iframe
  navigator.serviceWorker?.getRegistrations().then((registrations) => {
    registrations.forEach((r) => r.unregister());
  });
}

createRoot(document.getElementById("root")!).render(<App />);
