export const PROVINCIAS_MOCAMBIQUE = [
  "Maputo Cidade",
  "Maputo Província",
  "Gaza",
  "Inhambane",
  "Sofala",
  "Manica",
  "Tete",
  "Zambézia",
  "Nampula",
  "Niassa",
  "Cabo Delgado",
];

export const CATEGORIAS_DESPESAS = [
  "Salário",
  "Transporte",
  "Aluguel",
  "Eletricidade",
  "Água",
  "Internet/Comunicações",
  "Material de Escritório",
  "Marketing",
  "Manutenção",
  "Impostos",
  "Seguros",
  "Outros",
];

export const TIPOS_GARANTIA = [
  "Viatura",
  "Eletrodoméstico",
  "TV",
  "Geleira",
  "Telemóvel",
  "Laptop",
  "Casa",
  "Outros",
];
