import { useEffect, useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { logError } from "@/lib/errorHandling";

export type UserRole = "superadmin" | "admin" | "user" | "agente" | "secretariado" | null;

// Global cache to avoid redundant fetches across components
let cachedRole: UserRole = null;
let cachedUserId: string | null = null;
let fetchPromise: Promise<UserRole> | null = null;

async function fetchRoleForUser(userId: string): Promise<UserRole> {
  try {
    const { data: profileData } = await supabase
      .from("user_profiles")
      .select("role")
      .eq("user_id", userId)
      .maybeSingle();

    if (profileData) return profileData.role as UserRole;

    const { data, error } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .maybeSingle();

    if (error) {
      logError("Fetch user role", error);
      return "user";
    }
    return (data?.role as UserRole) || "user";
  } catch (error) {
    logError("fetchRoleForUser", error);
    return null;
  }
}

export function useUserRole() {
  const [role, setRole] = useState<UserRole>(cachedRole);
  const [loading, setLoading] = useState(cachedRole === null);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;

    async function resolve() {
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;

      if (!user) {
        cachedRole = null;
        cachedUserId = null;
        if (mounted.current) { setRole(null); setLoading(false); }
        return;
      }

      // Return cached if same user
      if (cachedUserId === user.id && cachedRole !== null) {
        if (mounted.current) { setRole(cachedRole); setLoading(false); }
        return;
      }

      // Deduplicate concurrent fetches
      if (!fetchPromise || cachedUserId !== user.id) {
        cachedUserId = user.id;
        fetchPromise = fetchRoleForUser(user.id);
      }

      const result = await fetchPromise;
      fetchPromise = null;
      cachedRole = result;

      if (mounted.current) { setRole(result); setLoading(false); }
    }

    resolve();

    let roleChannel: ReturnType<typeof supabase.channel> | null = null;

    supabase.auth.getSession().then(({ data: { session } }) => {
      const uid = session?.user?.id;
      if (!uid || !mounted.current) return;

      const refreshRole = async () => {
        cachedRole = null;
        fetchPromise = null;
        const nextRole = await fetchRoleForUser(uid);
        cachedUserId = uid;
        cachedRole = nextRole;
        if (mounted.current) {
          setRole(nextRole);
          setLoading(false);
        }
      };

      roleChannel = supabase
        .channel(`user-role-refresh-${uid}`)
        .on("postgres_changes", { event: "UPDATE", schema: "public", table: "user_profiles", filter: `user_id=eq.${uid}` }, refreshRole)
        .on("postgres_changes", { event: "UPDATE", schema: "public", table: "user_roles", filter: `user_id=eq.${uid}` }, refreshRole)
        .subscribe();
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event) => {
      if (_event === "SIGNED_OUT") {
        cachedRole = null;
        cachedUserId = null;
        fetchPromise = null;
        if (mounted.current) { setRole(null); setLoading(false); }
      } else if (_event === "SIGNED_IN") {
        // Reset cache on new sign in
        cachedRole = null;
        fetchPromise = null;
        resolve();
      }
    });

    return () => {
      mounted.current = false;
      if (roleChannel) supabase.removeChannel(roleChannel);
      subscription.unsubscribe();
    };
  }, []);

  return { 
    role, 
    loading,
    isSuperAdmin: role === "superadmin",
    isAdmin: role === "admin" || role === "superadmin",
    isAgente: role === "agente",
    isSecretariado: role === "secretariado",
  };
}
