import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useRealtimeRefresh } from "./useRealtimeRefresh";

export interface CapitalGlobal {
  id: string;
  user_id: string;
  valor: number;
  data_configuracao: string;
  configurado: boolean;
  ultima_edicao: string | null;
}

export interface CapitalMensal {
  id: string;
  user_id: string;
  mes_ano: string;
  capital_inicial_mes: number;
  capital_actual: number;
  total_creditos_concedidos: number;
  total_reembolsos_capital: number;
  total_juros_recebidos: number;
  total_entradas_extras: number;
  total_despesas_perdas: number;
  data_fecho: string | null;
  fechado: boolean;
}

export interface EntradaCapital {
  id: string;
  user_id: string;
  valor: number;
  descricao: string;
  data: string;
  created_at: string;
}

export interface CapitalEvolution {
  month: string;
  capital: number;
  variacao: number;
}

export function useCapitalData() {
  const [capitalGlobal, setCapitalGlobal] = useState<CapitalGlobal | null>(null);
  const [capitalMensal, setCapitalMensal] = useState<CapitalMensal | null>(null);
  const [historicoMensal, setHistoricoMensal] = useState<CapitalMensal[]>([]);
  const [entradasCapital, setEntradasCapital] = useState<EntradaCapital[]>([]);
  const [capitalEvolution, setCapitalEvolution] = useState<CapitalEvolution[]>([]);
  const [loading, setLoading] = useState(true);
  const [capitalConfigurado, setCapitalConfigurado] = useState(false);

  const fetchCapitalData = useCallback(async () => {
    try {
      setLoading(true);
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return;
      const user = session.user;

      // Buscar capital global
      const { data: capitalGlobalData } = await supabase
        .from("capital_global")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (capitalGlobalData) {
        setCapitalGlobal(capitalGlobalData as CapitalGlobal);
        setCapitalConfigurado(true);
      }

      // Buscar ou criar capital mensal atual
      const mesAtual = new Date().toISOString().slice(0, 7);
      let { data: capitalMensalData } = await supabase
        .from("capital_mensal")
        .select("*")
        .eq("user_id", user.id)
        .eq("mes_ano", mesAtual)
        .single();

      // Se não existe, criar via RPC
      if (!capitalMensalData && capitalGlobalData) {
        await supabase.rpc("get_or_create_capital_mensal", {
          p_user_id: user.id
        });
        
        // Buscar novamente
        const { data: newCapitalMensal } = await supabase
          .from("capital_mensal")
          .select("*")
          .eq("user_id", user.id)
          .eq("mes_ano", mesAtual)
          .single();
        
        capitalMensalData = newCapitalMensal;
      }

      if (capitalMensalData) {
        setCapitalMensal(capitalMensalData as CapitalMensal);
      }

      // Buscar histórico mensal (últimos 12 meses)
      const { data: historicoData } = await supabase
        .from("capital_mensal")
        .select("*")
        .eq("user_id", user.id)
        .order("mes_ano", { ascending: false })
        .limit(12);

      if (historicoData) {
        setHistoricoMensal(historicoData as CapitalMensal[]);
        
        // Calcular evolução do capital
        const evolution: CapitalEvolution[] = [];
        const monthNames = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
        
        const sortedData = [...historicoData].reverse(); // Do mais antigo ao mais recente
        
        sortedData.forEach((item, index) => {
          const [year, month] = item.mes_ano.split("-");
          const monthIndex = parseInt(month) - 1;
          const capitalAnterior = index > 0 ? sortedData[index - 1].capital_actual : item.capital_inicial_mes;
          const variacao = capitalAnterior > 0 
            ? ((item.capital_actual - capitalAnterior) / capitalAnterior) * 100 
            : 0;
          
          evolution.push({
            month: `${monthNames[monthIndex]}/${year.slice(2)}`,
            capital: item.capital_actual,
            variacao: Math.round(variacao * 10) / 10
          });
        });
        
        setCapitalEvolution(evolution.slice(-6)); // Últimos 6 meses
      }

      // Buscar entradas de capital do mês atual
      const { data: entradasData } = await supabase
        .from("entradas_capital")
        .select("*")
        .eq("user_id", user.id)
        .order("data", { ascending: false });

      if (entradasData) {
        setEntradasCapital(entradasData as EntradaCapital[]);
      }

    } catch (error) {
      console.error("Error fetching capital data:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCapitalData();
  }, [fetchCapitalData]);

  useRealtimeRefresh(
    ["capital_global", "capital_mensal", "entradas_capital", "emprestimos", "pagamentos", "despesas"],
    fetchCapitalData,
    true,
    900
  );

  const configurarCapitalGlobal = async (valor: number) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        toast.error("Usuário não autenticado");
        return false;
      }
      const user = session.user;

      // Verificar se já existe
      const { data: existing } = await supabase
        .from("capital_global")
        .select("id")
        .eq("user_id", user.id)
        .single();

      if (existing) {
        toast.error("Capital global já foi configurado e não pode ser alterado");
        return false;
      }

      // Inserir capital global
      const { error: insertError } = await supabase
        .from("capital_global")
        .insert({
          user_id: user.id,
          valor: valor,
        });

      if (insertError) throw insertError;

      // Criar primeiro registro mensal
      const mesAtual = new Date().toISOString().slice(0, 7);
      await supabase
        .from("capital_mensal")
        .insert({
          user_id: user.id,
          mes_ano: mesAtual,
          capital_inicial_mes: valor,
          capital_actual: valor,
        });

      toast.success("Capital inicial global configurado com sucesso!");
      await fetchCapitalData();
      return true;
    } catch (error) {
      console.error("Error configuring capital global:", error);
      toast.error("Erro ao configurar capital global");
      return false;
    }
  };

  const adicionarEntradaCapital = async (valor: number, descricao: string, data: string, contaFinanceiraId?: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        toast.error("Usuário não autenticado");
        return false;
      }
      const user = session.user;

      const { error } = await supabase
        .from("entradas_capital")
        .insert({
          user_id: user.id,
          valor: valor,
          descricao: descricao,
          data: data,
        });

      if (error) throw error;

      // Se uma conta financeira foi selecionada, adicionar ao saldo contabilístico
      if (contaFinanceiraId) {
        // Buscar conta atual
        const { data: conta } = await supabase
          .from("contas_financeiras")
          .select("*")
          .eq("id", contaFinanceiraId)
          .single();

        if (conta) {
          const novoSaldoContabilistico = conta.saldo_contabilistico + valor;

          // Registrar movimento
          await supabase.from("movimentos_conta").insert({
            user_id: user.id,
            conta_financeira_id: contaFinanceiraId,
            tipo_movimento: "entrada_capital",
            valor,
            saldo_disponivel_antes: conta.saldo_disponivel,
            saldo_disponivel_depois: conta.saldo_disponivel,
            saldo_contabilistico_antes: conta.saldo_contabilistico,
            saldo_contabilistico_depois: novoSaldoContabilistico,
            descricao: `Entrada de capital: ${descricao} (disponível às 00:00)`,
          });

          // Atualizar saldo contabilístico da conta
          await supabase
            .from("contas_financeiras")
            .update({ saldo_contabilistico: novoSaldoContabilistico })
            .eq("id", contaFinanceiraId);
        }
      }

      toast.success("Entrada de capital registrada com sucesso! O valor ficará disponível às 00:00.");
      await fetchCapitalData();
      return true;
    } catch (error) {
      console.error("Error adding capital entry:", error);
      toast.error("Erro ao registrar entrada de capital");
      return false;
    }
  };

  const removerEntradaCapital = async (id: string) => {
    try {
      const { error } = await supabase
        .from("entradas_capital")
        .delete()
        .eq("id", id);

      if (error) throw error;

      toast.success("Entrada de capital removida com sucesso!");
      await fetchCapitalData();
      return true;
    } catch (error) {
      console.error("Error removing capital entry:", error);
      toast.error("Erro ao remover entrada de capital");
      return false;
    }
  };

  const fecharMes = async (mesAno: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        toast.error("Usuário não autenticado");
        return false;
      }
      const user = session.user;

      await supabase.rpc("fechar_mes_capital", {
        p_user_id: user.id,
        p_mes_ano: mesAno
      });

      toast.success("Mês fechado com sucesso!");
      await fetchCapitalData();
      return true;
    } catch (error) {
      console.error("Error closing month:", error);
      toast.error("Erro ao fechar mês");
      return false;
    }
  };

  // Calcular variação mensal
  const variacaoMensal = capitalMensal && capitalMensal.capital_inicial_mes > 0
    ? ((capitalMensal.capital_actual - capitalMensal.capital_inicial_mes) / capitalMensal.capital_inicial_mes) * 100
    : 0;

  const podeEditarCapitalGlobal = (): boolean => {
    if (!capitalGlobal) return false;
    if (!capitalGlobal.ultima_edicao) return true;
    const ultimaEdicao = new Date(capitalGlobal.ultima_edicao);
    const agora = new Date();
    return ultimaEdicao.getMonth() !== agora.getMonth() || ultimaEdicao.getFullYear() !== agora.getFullYear();
  };

  const editarCapitalGlobal = async (novoValor: number) => {
    try {
      if (!capitalGlobal) {
        toast.error("Capital global não encontrado");
        return false;
      }
      if (!podeEditarCapitalGlobal()) {
        toast.error("O capital global só pode ser editado uma vez por mês");
        return false;
      }
      const { error } = await supabase
        .from("capital_global")
        .update({ valor: novoValor, ultima_edicao: new Date().toISOString() })
        .eq("id", capitalGlobal.id);
      if (error) throw error;
      toast.success("Capital inicial global actualizado com sucesso!");
      await fetchCapitalData();
      return true;
    } catch (error) {
      console.error("Error editing capital global:", error);
      toast.error("Erro ao editar capital global");
      return false;
    }
  };

  return {
    capitalGlobal,
    capitalMensal,
    historicoMensal,
    entradasCapital,
    capitalEvolution,
    loading,
    capitalConfigurado,
    variacaoMensal,
    configurarCapitalGlobal,
    editarCapitalGlobal,
    podeEditarCapitalGlobal,
    adicionarEntradaCapital,
    removerEntradaCapital,
    fecharMes,
    refetch: fetchCapitalData,
  };
}
