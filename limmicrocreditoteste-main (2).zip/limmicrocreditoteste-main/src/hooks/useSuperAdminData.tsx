import { useEffect, useState, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useRealtimeRefresh } from "./useRealtimeRefresh";

export interface SuperAdminStats {
  totalUsuarios: number;
  usuariosAtivos: number;
  usuariosInativos: number;
  usuariosOnline: number;
  totalEmprestadoGlobal: number;
  totalAReceberGlobal: number;
  totalRecebidoGlobal: number;
  emprestimosAtivosGlobal: number;
  emprestimosPagosGlobal: number;
  emprestimosVencidosGlobal: number;
  totalClientesGlobal: number;
  taxaInadimplenciaGlobal: number;
  totalAgentes: number;
  totalSecretariado: number;
}

export interface MonthlyGlobalData {
  month: string;
  emprestimos: number;
  recebimentos: number;
}

export interface UsuarioResumo {
  user_id: string;
  full_name: string;
  email: string | null;
  role: string;
  status: string;
  estado: string | null;
  last_seen: string | null;
  expires_at: string;
  created_at: string | null;
}

export function useSuperAdminData() {
  const [stats, setStats] = useState<SuperAdminStats>({
    totalUsuarios: 0, usuariosAtivos: 0, usuariosInativos: 0, usuariosOnline: 0,
    totalEmprestadoGlobal: 0, totalAReceberGlobal: 0, totalRecebidoGlobal: 0,
    emprestimosAtivosGlobal: 0, emprestimosPagosGlobal: 0, emprestimosVencidosGlobal: 0,
    totalClientesGlobal: 0, taxaInadimplenciaGlobal: 0, totalAgentes: 0, totalSecretariado: 0,
  });
  const [usuarios, setUsuarios] = useState<UsuarioResumo[]>([]);
  const [monthlyData, setMonthlyData] = useState<MonthlyGlobalData[]>([]);
  const [loading, setLoading] = useState(true);
  const mounted = useRef(true);

  const fetchData = useCallback(async () => {
    try {
      const [profilesRes, emprestimosRes, clientesRes, pagamentosRes, incomingRes] = await Promise.all([
        supabase.from("user_profiles").select("user_id, full_name, email, role, status, estado, last_seen, expires_at, created_at"),
        supabase.from("emprestimos").select("id, valor, valor_total, valor_pago, status, data_reembolso, data_desembolso"),
        supabase.from("clientes").select("id"),
        supabase.from("pagamentos").select("id, valor, data_pagamento"),
        supabase.from("incoming_payments").select("id, valor, status").in("status", ["disponivel", "usado"]),
      ]);

      if (!mounted.current) return;

      const profiles = profilesRes.data || [];
      const emprestimos = emprestimosRes.data || [];
      const incomingPayments = incomingRes.data || [];
      const pagamentos = pagamentosRes.data || [];

      const totalUsuarios = profiles.length;
      const usuariosAtivos = profiles.filter(p => p.status === "active").length;
      const usuariosInativos = totalUsuarios - usuariosAtivos;
      const tenMinAgo = new Date(Date.now() - 10 * 60 * 1000);
      const usuariosOnline = profiles.filter(p => p.last_seen && new Date(p.last_seen) >= tenMinAgo).length;
      const totalAgentes = profiles.filter(p => p.role === "agente").length;
      const totalSecretariado = profiles.filter(p => p.role === "secretariado").length;

      const hoje = new Date();
      const emprestimosAtivos = emprestimos.filter(e => e.status === "Ativo");
      const emprestimosPagos = emprestimos.filter(e => e.status === "Pago");
      const emprestimosVencidos = emprestimosAtivos.filter(e =>
        e.data_reembolso && new Date(e.data_reembolso) < hoje && (e.valor_total || 0) > (e.valor_pago || 0)
      );

      const totalEmprestadoGlobal = emprestimos.reduce((s, e) => s + (e.valor || 0), 0);
      const totalAReceberGlobal = emprestimosAtivos.reduce((s, e) => s + ((e.valor_total || 0) - (e.valor_pago || 0)), 0);
      const totalRecebidoLoan = pagamentos.reduce((s, p) => s + (p.valor || 0), 0);
      const totalRecebidoPlataforma = incomingPayments.reduce((s: number, p: any) => s + (p.valor || 0), 0);
      const totalRecebidoGlobal = totalRecebidoLoan + totalRecebidoPlataforma;
      const taxaInadimplenciaGlobal = emprestimosAtivos.length > 0
        ? (emprestimosVencidos.length / emprestimosAtivos.length) * 100 : 0;

      setStats({
        totalUsuarios, usuariosAtivos, usuariosInativos, usuariosOnline,
        totalEmprestadoGlobal, totalAReceberGlobal, totalRecebidoGlobal,
        emprestimosAtivosGlobal: emprestimosAtivos.length,
        emprestimosPagosGlobal: emprestimosPagos.length,
        emprestimosVencidosGlobal: emprestimosVencidos.length,
        totalClientesGlobal: clientesRes.data?.length || 0,
        taxaInadimplenciaGlobal: Math.round(taxaInadimplenciaGlobal * 10) / 10,
        totalAgentes, totalSecretariado,
      });

      // Monthly data (last 6 months)
      const MONTH_NAMES = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
      const now = new Date();
      const monthly: MonthlyGlobalData[] = [];
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const mEnd = new Date(d.getFullYear(), d.getMonth() + 1, 0);
        const totalEmpMes = emprestimos
          .filter(e => { const dt = new Date(e.data_desembolso); return dt >= d && dt <= mEnd; })
          .reduce((s, e) => s + (e.valor || 0), 0);
        const totalRecMes = pagamentos
          .filter(p => { const dt = new Date(p.data_pagamento); return dt >= d && dt <= mEnd; })
          .reduce((s, p) => s + (p.valor || 0), 0);
        monthly.push({ month: MONTH_NAMES[d.getMonth()], emprestimos: totalEmpMes, recebimentos: totalRecMes });
      }
      setMonthlyData(monthly);

      setUsuarios(profiles.map(p => ({
        user_id: p.user_id, full_name: p.full_name, email: p.email,
        role: p.role, status: p.status, estado: p.estado,
        last_seen: p.last_seen, expires_at: p.expires_at, created_at: p.created_at,
      })));
    } catch (error) {
      console.error("Error fetching superadmin data:", error);
    } finally {
      if (mounted.current) setLoading(false);
    }
  }, []);

  useEffect(() => {
    mounted.current = true;
    fetchData();
    const interval = setInterval(fetchData, 60000); // 1 minute

    return () => { mounted.current = false; clearInterval(interval); };
  }, [fetchData]);

  useRealtimeRefresh(
    ["user_profiles", "clientes", "emprestimos", "pagamentos", "incoming_payments", "subscription_requests", "historico_renovacoes"],
    fetchData,
    true,
    1000
  );

  return { stats, usuarios, monthlyData, loading, refetch: fetchData };
}
