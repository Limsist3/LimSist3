import { useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";

type RefreshCallback = () => void | Promise<void>;

export function useRealtimeRefresh(
  tables: string[],
  onRefresh: RefreshCallback,
  enabled = true,
  delayMs = 800
) {
  const callbackRef = useRef(onRefresh);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingWhileHiddenRef = useRef(false);
  const tableKey = tables.join("|");

  useEffect(() => {
    callbackRef.current = onRefresh;
  }, [onRefresh]);

  useEffect(() => {
    if (!enabled || tables.length === 0) return;

    let mounted = true;
    const channel = tables.reduce((currentChannel, table) => {
      return currentChannel.on(
        "postgres_changes",
        { event: "*", schema: "public", table },
        () => {
          if (!mounted) return;

          if (typeof document !== "undefined" && document.hidden) {
            pendingWhileHiddenRef.current = true;
            return;
          }

          if (timeoutRef.current) clearTimeout(timeoutRef.current);
          timeoutRef.current = setTimeout(() => {
            if (!mounted) return;
            callbackRef.current();
          }, delayMs);
        }
      );
    }, supabase.channel(`realtime-refresh-${tableKey}-${Date.now()}`));

    const handleVisibilityChange = () => {
      if (document.hidden || !pendingWhileHiddenRef.current) return;
      pendingWhileHiddenRef.current = false;
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(() => {
        if (mounted) callbackRef.current();
      }, delayMs);
    };

    channel.subscribe();
    document.addEventListener("visibilitychange", handleVisibilityChange);

    return () => {
      mounted = false;
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      supabase.removeChannel(channel);
    };
    // tableKey keeps the subscription stable even when callers pass inline arrays.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, tableKey, delayMs]);
}