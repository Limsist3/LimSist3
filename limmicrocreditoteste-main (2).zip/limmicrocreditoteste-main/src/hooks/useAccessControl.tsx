import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { logError } from "@/lib/errorHandling";

interface AccessStatus {
  isActive: boolean;
  reason?: "expired" | "inactive";
  expiresAt?: string;
  daysRemaining?: number;
  isExpiringSoon?: boolean;
}

export function useAccessControl() {
  const navigate = useNavigate();
  const [accessStatus, setAccessStatus] = useState<AccessStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const checked = useRef(false);

  useEffect(() => {
    if (checked.current) return;
    checked.current = true;
    checkAccess();
  }, []);

  useEffect(() => {
    let channel: ReturnType<typeof supabase.channel> | null = null;
    let mounted = true;

    const setupProfileWatcher = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;
      if (!user || !mounted) return;

      const { data: profile } = await supabase
        .from("user_profiles")
        .select("role, usuario_mae_id")
        .eq("user_id", user.id)
        .maybeSingle();

      if (!mounted) return;
      channel = supabase
        .channel(`access-control-${user.id}`)
        .on("postgres_changes", { event: "UPDATE", schema: "public", table: "user_profiles", filter: `user_id=eq.${user.id}` }, () => checkAccess());

      if ((profile?.role === "agente" || profile?.role === "secretariado") && profile?.usuario_mae_id) {
        channel.on("postgres_changes", { event: "UPDATE", schema: "public", table: "user_profiles", filter: `user_id=eq.${profile.usuario_mae_id}` }, () => checkAccess());
      }

      channel.subscribe();
    };

    setupProfileWatcher();

    return () => {
      mounted = false;
      if (channel) supabase.removeChannel(channel);
    };
  }, []);

  const checkAccess = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;
      
      if (!user) {
        navigate("/auth");
        return;
      }

      const { data: profile, error } = await supabase
        .from("user_profiles")
        .select("status, expires_at, role, usuario_mae_id")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) {
        logError("Fetch profile", error);
        throw error;
      }

      if (!profile) {
        // Trial automático de 24 horas para novos registos
        const trialExpires = new Date(Date.now() + 24 * 60 * 60 * 1000);
        const { error: insertError } = await supabase
          .from("user_profiles")
          .insert({
            user_id: user.id,
            full_name: user.email,
            role: "user",
            status: "active",
            usage_days: 1,
            expires_at: trialExpires.toISOString()
          });

        if (insertError) logError("Create profile", insertError);
        setAccessStatus({
          isActive: true,
          daysRemaining: 1,
          isExpiringSoon: true,
          expiresAt: trialExpires.toISOString(),
        });
        setLoading(false);
        return;
      }


      // Superadmins sempre têm acesso
      if (profile.role === "superadmin") {
        setAccessStatus({ isActive: true });
        setLoading(false);
        return;
      }

      // Agentes e Secretariados - herdam tempo do usuário mãe
      if (profile.role === "agente" || profile.role === "secretariado") {
        if (profile.status !== "active") {
          setAccessStatus({ isActive: false, reason: "inactive" });
          setLoading(false);
          return;
        }

        // Buscar expires_at do usuário mãe
        const { data: maeProfile } = await supabase
          .from("user_profiles")
          .select("expires_at, status")
          .eq("user_id", profile.usuario_mae_id)
          .maybeSingle();

        if (maeProfile) {
          const maeExpires = new Date(maeProfile.expires_at);
          const now = new Date();
          const maeActive = maeProfile.status === "active" && maeExpires > now;

          if (!maeActive) {
            setAccessStatus({ isActive: false, reason: "expired" });
            setLoading(false);
            return;
          }

          // Só atualiza se realmente diferir (evita escrita em todo render/login)
          if (profile.expires_at !== maeProfile.expires_at) {
            supabase
              .from("user_profiles")
              .update({ expires_at: maeProfile.expires_at })
              .eq("user_id", user.id)
              .then();
          }

          const daysRemaining = Math.ceil((maeExpires.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          setAccessStatus({
            isActive: true,
            daysRemaining,
            isExpiringSoon: daysRemaining <= 3 && daysRemaining > 0,
            expiresAt: maeProfile.expires_at,
          });
        } else {
          setAccessStatus({ isActive: true });
        }
        setLoading(false);
        return;
      }

      if (profile.status !== "active") {
        setAccessStatus({ isActive: false, reason: "inactive", expiresAt: profile.expires_at });
        setLoading(false);
        return;
      }

      const expiresAt = new Date(profile.expires_at);
      const now = new Date();

      if (expiresAt < now) {
        await supabase
          .from("user_profiles")
          .update({ status: "inactive" })
          .eq("user_id", user.id);

        setAccessStatus({ isActive: false, reason: "expired", expiresAt: profile.expires_at });
        setLoading(false);
        return;
      }

      const daysRemaining = Math.ceil((expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      setAccessStatus({
        isActive: true,
        daysRemaining,
        isExpiringSoon: daysRemaining <= 3 && daysRemaining > 0,
        expiresAt: profile.expires_at,
      });
    } catch (error) {
      logError("Access control check", error);
      navigate("/auth");
    } finally {
      setLoading(false);
    }
  };

  return { accessStatus, loading };
}
