import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface PendingOperation {
  id: string;
  type: 'INSERT' | 'UPDATE' | 'DELETE';
  table: string;
  data: any;
  timestamp: number;
}

const DB_NAME = 'limsist_offline';
const DB_VERSION = 1;
const STORE_NAME = 'pending_operations';

export const useOfflineSync = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);

  // Inicializar IndexedDB
  const openDB = (): Promise<IDBDatabase> => {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);

      request.onupgradeneeded = (event: any) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        }
      };
    });
  };

  // Adicionar operação pendente
  const addPendingOperation = async (operation: Omit<PendingOperation, 'id' | 'timestamp'>) => {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);

    const pendingOp: PendingOperation = {
      ...operation,
      id: `${Date.now()}_${Math.random()}`,
      timestamp: Date.now(),
    };

    await store.add(pendingOp);
    await updatePendingCount();
    return pendingOp.id;
  };

  // Obter todas as operações pendentes
  const getPendingOperations = async (): Promise<PendingOperation[]> => {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);

    return new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  };

  // Remover operação pendente
  const removePendingOperation = async (id: string) => {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    await store.delete(id);
    await updatePendingCount();
  };

  // Atualizar contador de operações pendentes
  const updatePendingCount = async () => {
    const operations = await getPendingOperations();
    setPendingCount(operations.length);
  };

  // Sincronizar operações pendentes
  const syncPendingOperations = async () => {
    if (!navigator.onLine || isSyncing) return;

    setIsSyncing(true);
    const operations = await getPendingOperations();

    if (operations.length === 0) {
      setIsSyncing(false);
      return;
    }

    toast.info(`Sincronizando ${operations.length} operação(ões)...`);

    let successCount = 0;
    let errorCount = 0;

    for (const op of operations) {
      try {
        const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
        
        if (!user) {
          console.error('Usuário não autenticado para sincronização');
          continue;
        }

        // Adicionar user_id aos dados se não existir
        const dataWithUser = { ...op.data, user_id: user.id };

        switch (op.type) {
          case 'INSERT':
            const { error: insertError } = await supabase
              .from(op.table as any)
              .insert([dataWithUser]);
            if (insertError) throw insertError;
            break;

          case 'UPDATE':
            const { id, ...updateData } = dataWithUser;
            const { error: updateError } = await supabase
              .from(op.table as any)
              .update(updateData)
              .eq('id', id);
            if (updateError) throw updateError;
            break;

          case 'DELETE':
            const { error: deleteError } = await supabase
              .from(op.table as any)
              .delete()
              .eq('id', dataWithUser.id);
            if (deleteError) throw deleteError;
            break;
        }

        await removePendingOperation(op.id);
        successCount++;
      } catch (error) {
        console.error('Erro ao sincronizar operação:', error);
        errorCount++;
      }
    }

    setIsSyncing(false);

    if (successCount > 0) {
      toast.success(`${successCount} operação(ões) sincronizada(s) com sucesso!`);
    }

    if (errorCount > 0) {
      toast.error(`${errorCount} operação(ões) falharam na sincronização.`);
    }
  };

  // Monitorar status de conexão
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      toast.success('Conexão restaurada! Sincronizando dados...');
      syncPendingOperations();
    };

    const handleOffline = () => {
      setIsOnline(false);
      toast.warning('Você está offline. As alterações serão salvas localmente.');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Atualizar contador inicial
    updatePendingCount();

    // Tentar sincronizar ao iniciar se estiver online
    if (navigator.onLine) {
      syncPendingOperations();
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return {
    isOnline,
    isSyncing,
    pendingCount,
    addPendingOperation,
    syncPendingOperations,
  };
};
