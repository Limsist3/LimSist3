import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface ContaFinanceira {
  id: string;
  user_id: string;
  tipo: string;
  nome: string;
  saldo_disponivel: number;
  saldo_contabilistico: number;
  ativo: boolean;
  ultima_recarga: string | null;
  ultimo_ajuste_saldo?: string | null;
  created_at: string;
  updated_at: string;
}

export const DIAS_ENTRE_AJUSTES = 90;

export function diasParaProximoAjuste(conta: ContaFinanceira): number {
  if (!conta.ultimo_ajuste_saldo) return 0;
  const decorridos = Math.floor(
    (Date.now() - new Date(conta.ultimo_ajuste_saldo).getTime()) / 86400000
  );
  return Math.max(0, DIAS_ENTRE_AJUSTES - decorridos);
}


const SYSTEM_ACCOUNT_NAME = "Conta do Sistema";
const SYSTEM_ACCOUNT_TYPE = "sistema";

export function useContasFinanceiras() {
  const [contas, setContas] = useState<ContaFinanceira[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchContas = useCallback(async () => {
    try {
      setLoading(true);
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return;
      const user = session.user;

      const { data: existingContas, error } = await supabase
        .from("contas_financeiras")
        .select("*")
        .eq("user_id", user.id)
        .order("tipo", { ascending: true })
        .order("nome", { ascending: true });

      if (error) throw error;

      if (!existingContas || existingContas.length === 0) {
        await supabase.rpc("inicializar_contas_financeiras", { p_user_id: user.id });
        
        const { data: newContas } = await supabase
          .from("contas_financeiras")
          .select("*")
          .eq("user_id", user.id)
          .order("tipo", { ascending: true })
          .order("nome", { ascending: true });

        setContas((newContas as ContaFinanceira[]) || []);
      } else {
        setContas(existingContas as ContaFinanceira[]);
      }
    } catch (error) {
      console.error("Error fetching contas:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchContas();
  }, [fetchContas]);

  // Get or create the system account for a user
  const getOrCreateSystemAccount = async (userId: string): Promise<ContaFinanceira | null> => {
    try {
      // Check if system account already exists
      let systemAccount = contas.find(c => c.tipo === SYSTEM_ACCOUNT_TYPE && c.nome === SYSTEM_ACCOUNT_NAME);
      
      if (systemAccount) return systemAccount;

      // Check in DB (might not be in local state yet)
      const { data: existing } = await supabase
        .from("contas_financeiras")
        .select("*")
        .eq("user_id", userId)
        .eq("tipo", SYSTEM_ACCOUNT_TYPE)
        .eq("nome", SYSTEM_ACCOUNT_NAME)
        .maybeSingle();

      if (existing) return existing as ContaFinanceira;

      // Create system account
      const { data: newAccount, error } = await supabase
        .from("contas_financeiras")
        .insert({
          user_id: userId,
          tipo: SYSTEM_ACCOUNT_TYPE,
          nome: SYSTEM_ACCOUNT_NAME,
          saldo_disponivel: 0,
          saldo_contabilistico: 0,
          ativo: true,
        })
        .select()
        .single();

      if (error) throw error;
      
      await fetchContas();
      return newAccount as ContaFinanceira;
    } catch (error) {
      console.error("Error creating system account:", error);
      return null;
    }
  };

  const adicionarSaldo = async (contaId: string, valor: number) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;
      if (!user) { toast.error("Não autenticado"); return false; }

      const conta = contas.find(c => c.id === contaId);
      if (!conta) { toast.error("Conta não encontrada"); return false; }

      // Check daily reload limit (not for system account)
      const hoje = new Date().toISOString().split("T")[0];
      if (conta.tipo !== SYSTEM_ACCOUNT_TYPE && conta.ultima_recarga === hoje) {
        toast.error("Já foi adicionado saldo a esta conta hoje. Tente novamente amanhã.");
        return false;
      }

      const novoSaldoDisponivel = conta.saldo_disponivel + valor;
      const novoSaldoContabilistico = conta.saldo_contabilistico + valor;

      await supabase.from("movimentos_conta").insert({
        user_id: user.id,
        conta_financeira_id: contaId,
        tipo_movimento: "recarga",
        valor,
        saldo_disponivel_antes: conta.saldo_disponivel,
        saldo_disponivel_depois: novoSaldoDisponivel,
        saldo_contabilistico_antes: conta.saldo_contabilistico,
        saldo_contabilistico_depois: novoSaldoContabilistico,
        descricao: `Recarga de saldo - ${conta.nome}`,
      });

      const { error } = await supabase
        .from("contas_financeiras")
        .update({
          saldo_disponivel: novoSaldoDisponivel,
          saldo_contabilistico: novoSaldoContabilistico,
          ultima_recarga: hoje,
        })
        .eq("id", contaId);

      if (error) throw error;

      toast.success(`Saldo adicionado com sucesso a ${conta.nome}!`);
      await fetchContas();
      return true;
    } catch (error) {
      console.error("Error adding balance:", error);
      toast.error("Erro ao adicionar saldo");
      return false;
    }
  };

  // Ajuste manual dos saldos (aumentar ou diminuir capital) — 1 vez a cada 90 dias por conta
  const ajustarSaldoConta = async (
    contaId: string,
    novoDisponivel: number,
    novoContabilistico: number,
    motivo?: string
  ) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;
      if (!user) { toast.error("Não autenticado"); return false; }

      const { data: contaData } = await supabase
        .from("contas_financeiras")
        .select("*")
        .eq("id", contaId)
        .maybeSingle();

      const conta = contaData as ContaFinanceira | null;
      if (!conta) { toast.error("Conta não encontrada"); return false; }

      const { data: isSuper } = await supabase.rpc("is_superadmin", { _user_id: user.id });
      if (!isSuper) {
        toast.error("Apenas o superadministrador pode ajustar os saldos.");
        return false;
      }

      const restantes = diasParaProximoAjuste(conta);
      if (restantes > 0) {
        toast.error(`Esta conta só pode ser editada novamente em ${restantes} dia(s).`);
        return false;
      }

      if (!Number.isFinite(novoDisponivel) || !Number.isFinite(novoContabilistico)) {
        toast.error("Valores inválidos");
        return false;
      }

      const diff = novoDisponivel - conta.saldo_disponivel;

      await supabase.from("movimentos_conta").insert({
        user_id: conta.user_id,
        conta_financeira_id: contaId,
        tipo_movimento: "ajuste_manual",
        valor: diff,
        saldo_disponivel_antes: conta.saldo_disponivel,
        saldo_disponivel_depois: novoDisponivel,
        saldo_contabilistico_antes: conta.saldo_contabilistico,
        saldo_contabilistico_depois: novoContabilistico,
        descricao: `Ajuste manual de saldo - ${conta.nome}${motivo ? `: ${motivo}` : ""}`,
      });

      const { error } = await supabase
        .from("contas_financeiras")
        .update({
          saldo_disponivel: novoDisponivel,
          saldo_contabilistico: novoContabilistico,
          ultimo_ajuste_saldo: new Date().toISOString(),
        })
        .eq("id", contaId);

      if (error) throw error;

      toast.success(`Saldos de ${conta.nome} actualizados com sucesso!`);
      await fetchContas();
      return true;
    } catch (error) {
      console.error("Error adjusting balance:", error);
      toast.error("Erro ao ajustar saldos");
      return false;
    }
  };


  const desembolsar = async (contaId: string, valor: number, emprestimoId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return false;
      const user = session.user;

      // Fetch fresh account data from DB
      const { data: contaData } = await supabase
        .from("contas_financeiras")
        .select("*")
        .eq("id", contaId)
        .single();

      const conta = contaData as ContaFinanceira | null;
      if (!conta) { toast.error("Conta não encontrada"); return false; }

      // Only block if NOT system account and insufficient balance
      if (conta.tipo !== SYSTEM_ACCOUNT_TYPE && conta.saldo_disponivel < valor) {
        toast.error(`Saldo insuficiente em ${conta.nome}. Disponível: ${conta.saldo_disponivel.toLocaleString()} MZN`);
        return false;
      }

      const novoSaldoDisponivel = conta.saldo_disponivel - valor;
      const novoSaldoContabilistico = conta.saldo_contabilistico - valor;

      await supabase.from("movimentos_conta").insert({
        user_id: user.id,
        conta_financeira_id: contaId,
        tipo_movimento: "desembolso",
        valor: -valor,
        saldo_disponivel_antes: conta.saldo_disponivel,
        saldo_disponivel_depois: novoSaldoDisponivel,
        saldo_contabilistico_antes: conta.saldo_contabilistico,
        saldo_contabilistico_depois: novoSaldoContabilistico,
        referencia_id: emprestimoId,
        descricao: `Desembolso de empréstimo`,
      });

      await supabase
        .from("contas_financeiras")
        .update({ saldo_disponivel: novoSaldoDisponivel, saldo_contabilistico: novoSaldoContabilistico })
        .eq("id", contaId);

      await fetchContas();
      return true;
    } catch (error) {
      console.error("Error disbursing:", error);
      toast.error("Erro ao desembolsar");
      return false;
    }
  };

  const estornarDesembolso = async (contaId: string, valor: number, emprestimoId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return false;
      const user = session.user;

      const { data: contaData } = await supabase
        .from("contas_financeiras")
        .select("*")
        .eq("id", contaId)
        .single();

      const conta = contaData as ContaFinanceira | null;
      if (!conta) return false;

      const novoSaldoContabilistico = conta.saldo_contabilistico + valor;

      await supabase.from("movimentos_conta").insert({
        user_id: user.id,
        conta_financeira_id: contaId,
        tipo_movimento: "estorno_desembolso",
        valor,
        saldo_disponivel_antes: conta.saldo_disponivel,
        saldo_disponivel_depois: conta.saldo_disponivel,
        saldo_contabilistico_antes: conta.saldo_contabilistico,
        saldo_contabilistico_depois: novoSaldoContabilistico,
        referencia_id: emprestimoId,
        descricao: `Estorno de empréstimo eliminado (disponível à meia-noite)`,
      });

      await supabase
        .from("contas_financeiras")
        .update({ saldo_contabilistico: novoSaldoContabilistico })
        .eq("id", contaId);

      await fetchContas();
      return true;
    } catch (error) {
      console.error("Error reversing:", error);
      return false;
    }
  };

  const registrarReembolso = async (contaId: string, valor: number, pagamentoId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return false;
      const user = session.user;

      const { data: contaData } = await supabase
        .from("contas_financeiras")
        .select("*")
        .eq("id", contaId)
        .single();

      const conta = contaData as ContaFinanceira | null;
      if (!conta) return false;

      const novoSaldoContabilistico = conta.saldo_contabilistico + valor;

      await supabase.from("movimentos_conta").insert({
        user_id: user.id,
        conta_financeira_id: contaId,
        tipo_movimento: "reembolso",
        valor,
        saldo_disponivel_antes: conta.saldo_disponivel,
        saldo_disponivel_depois: conta.saldo_disponivel,
        saldo_contabilistico_antes: conta.saldo_contabilistico,
        saldo_contabilistico_depois: novoSaldoContabilistico,
        referencia_id: pagamentoId,
        descricao: `Reembolso recebido (disponível à meia-noite)`,
      });

      await supabase
        .from("contas_financeiras")
        .update({ saldo_contabilistico: novoSaldoContabilistico })
        .eq("id", contaId);

      await fetchContas();
      return true;
    } catch (error) {
      console.error("Error recording reimbursement:", error);
    return false;
    }
  };

  const estornarReembolso = async (contaId: string, valor: number, pagamentoId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return false;
      const user = session.user;

      const { data: contaData } = await supabase
        .from("contas_financeiras")
        .select("*")
        .eq("id", contaId)
        .single();

      const conta = contaData as ContaFinanceira | null;
      if (!conta) return false;

      const novoSaldoContabilistico = conta.saldo_contabilistico - valor;

      await supabase.from("movimentos_conta").insert({
        user_id: user.id,
        conta_financeira_id: contaId,
        tipo_movimento: "estorno_reembolso",
        valor: -valor,
        saldo_disponivel_antes: conta.saldo_disponivel,
        saldo_disponivel_depois: conta.saldo_disponivel,
        saldo_contabilistico_antes: conta.saldo_contabilistico,
        saldo_contabilistico_depois: novoSaldoContabilistico,
        referencia_id: pagamentoId,
        descricao: `Estorno de reembolso (pagamento editado/excluído)`,
      });

      await supabase
        .from("contas_financeiras")
        .update({ saldo_contabilistico: novoSaldoContabilistico })
        .eq("id", contaId);

      await fetchContas();
      return true;
    } catch (error) {
      console.error("Error reversing reimbursement:", error);
      return false;
    }
  };

  // Filter: hide system account when balance is 0
  const contasVisiveis = contas.filter(c => {
    if (c.tipo === SYSTEM_ACCOUNT_TYPE) {
      return c.saldo_disponivel !== 0 || c.saldo_contabilistico !== 0;
    }
    return true;
  });

  const totalSaldoDisponivel = contasVisiveis.reduce((sum, c) => sum + c.saldo_disponivel, 0);
  const totalSaldoContabilistico = contasVisiveis.reduce((sum, c) => sum + c.saldo_contabilistico, 0);
  const bancos = contasVisiveis.filter(c => c.tipo === "banco");
  const carteiras = contasVisiveis.filter(c => c.tipo === "carteira_movel");
  const contaSistema = contas.find(c => c.tipo === SYSTEM_ACCOUNT_TYPE);

  return {
    contas: contasVisiveis,
    allContas: contas,
    bancos,
    carteiras,
    contaSistema,
    loading,
    totalSaldoDisponivel,
    totalSaldoContabilistico,
    adicionarSaldo,
    ajustarSaldoConta,

    desembolsar,
    estornarDesembolso,
    registrarReembolso,
    estornarReembolso,
    getOrCreateSystemAccount,
    refetch: fetchContas,
  };
}
