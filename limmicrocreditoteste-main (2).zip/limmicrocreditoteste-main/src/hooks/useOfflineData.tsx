import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useOfflineSync } from './useOfflineSync';
import { offlineStorage } from '@/lib/offlineStorage';

interface UseOfflineDataOptions {
  table: string;
  select?: string;
  orderBy?: { column: string; ascending: boolean };
}

export const useOfflineData = <T extends { id: string }>({
  table,
  select = '*',
  orderBy,
}: UseOfflineDataOptions) => {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const { isOnline, addPendingOperation } = useOfflineSync();

  // Carregar dados
  const loadData = async () => {
    setLoading(true);
    try {
      if (isOnline) {
        // Tentar carregar do servidor
        const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
        
        if (!user) {
          throw new Error('Usuário não autenticado');
        }

        let query = supabase.from(table as any).select(select).eq('user_id', user.id);
        
        if (orderBy) {
          query = query.order(orderBy.column, { ascending: orderBy.ascending });
        }

        const { data: serverData, error } = await query;

        if (error) throw error;

        // Salvar no cache local
        await offlineStorage.saveData(table, serverData || []);
        setData((serverData as any) || []);
      } else {
        // Carregar do cache local
        const cachedData = await offlineStorage.getData(table);
        setData(cachedData as any as T[]);
      }
    } catch (error) {
      console.error(`Erro ao carregar ${table}:`, error);
      
      // Se falhar e estiver online, tentar cache
      if (isOnline) {
        const cachedData = await offlineStorage.getData(table);
        setData(cachedData as any as T[]);
      }
    } finally {
      setLoading(false);
    }
  };

  // Criar item
  const createItem = async (item: Omit<T, 'id'>) => {
    const newItem = { ...item, id: `temp_${Date.now()}` } as T;

    if (isOnline) {
      // Tentar inserir diretamente
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      
      if (!user) throw new Error('Usuário não autenticado');

      const { data: insertedData, error } = await supabase
        .from(table as any)
        .insert([{ ...item, user_id: user.id }])
        .select()
        .single();

      if (error) throw error;

      // Atualizar cache e estado
      await offlineStorage.addItem(table, insertedData);
      setData((prev) => [insertedData as any, ...prev]);
      return insertedData as any;
    } else {
      // Salvar localmente e adicionar à fila de sincronização
      await offlineStorage.addItem(table, newItem);
      await addPendingOperation({
        type: 'INSERT',
        table,
        data: item,
      });
      setData((prev) => [newItem, ...prev]);
      return newItem;
    }
  };

  // Atualizar item
  const updateItem = async (id: string, updates: Partial<T>) => {
    if (isOnline) {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      
      if (!user) throw new Error('Usuário não autenticado');

      const { error } = await supabase
        .from(table as any)
        .update(updates)
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;

      // Atualizar cache
      const updatedItem = { ...data.find((d) => d.id === id), ...updates } as T;
      await offlineStorage.updateItem(table, updatedItem);
      setData((prev) => prev.map((item) => (item.id === id ? updatedItem : item)));
    } else {
      // Salvar localmente e adicionar à fila
      const updatedItem = { ...data.find((d) => d.id === id), ...updates } as T;
      await offlineStorage.updateItem(table, updatedItem);
      await addPendingOperation({
        type: 'UPDATE',
        table,
        data: { id, ...updates },
      });
      setData((prev) => prev.map((item) => (item.id === id ? updatedItem : item)));
    }
  };

  // Deletar item
  const deleteItem = async (id: string) => {
    if (isOnline) {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      
      if (!user) throw new Error('Usuário não autenticado');

      const { error } = await supabase
        .from(table as any)
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;

      // Remover do cache
      await offlineStorage.deleteItem(table, id);
      setData((prev) => prev.filter((item) => item.id !== id));
    } else {
      // Remover localmente e adicionar à fila
      await offlineStorage.deleteItem(table, id);
      await addPendingOperation({
        type: 'DELETE',
        table,
        data: { id },
      });
      setData((prev) => prev.filter((item) => item.id !== id));
    }
  };

  useEffect(() => {
    loadData();
  }, [isOnline]);

  return {
    data,
    loading,
    createItem,
    updateItem,
    deleteItem,
    reload: loadData,
  };
};
