import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { normalizarPermissoes, Permissoes, podeEditar, podeVer } from "@/lib/permissoes";

const ROLES_RESTRITOS = ["agente", "secretariado", "contabilista", "auditor", "visualizador"];

// Cache simples por sessão para não repetir a query em cada página
let cache: { userId: string; perm: Permissoes | null } | null = null;

export function usePermissoes() {
  const [permissoes, setPermissoes] = useState<Permissoes | null>(cache?.perm ?? null);
  const [loading, setLoading] = useState(cache === null);

  useEffect(() => {
    let mounted = true;

    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;
      if (!user) {
        if (mounted) { setPermissoes(null); setLoading(false); }
        return;
      }

      if (cache?.userId === user.id) {
        if (mounted) { setPermissoes(cache.perm); setLoading(false); }
        return;
      }

      const { data } = await supabase
        .from("user_profiles")
        .select("role, permissoes")
        .eq("user_id", user.id)
        .maybeSingle();

      const role = (data as any)?.role as string | undefined;
      const perm = role && ROLES_RESTRITOS.includes(role)
        ? normalizarPermissoes(role, (data as any)?.permissoes)
        : null;

      cache = { userId: user.id, perm };
      if (mounted) { setPermissoes(perm); setLoading(false); }
    })();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_OUT" || event === "SIGNED_IN") cache = null;
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  return {
    permissoes,
    loading,
    restrito: permissoes !== null,
    podeVer: (key: string) => podeVer(permissoes, key),
    podeEditar: (key: string) => podeEditar(permissoes, key),
  };
}
