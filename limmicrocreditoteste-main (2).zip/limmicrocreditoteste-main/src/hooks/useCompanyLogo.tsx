import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

let cachedLogo: string | null = null;
let fetched = false;

export function useCompanyLogo() {
  const [logoUrl, setLogoUrl] = useState<string | null>(cachedLogo);

  useEffect(() => {
    if (fetched) return;
    fetched = true;

    const fetchLogo = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return;

      const { data } = await supabase
        .from("configuracoes_empresa")
        .select("logo_url")
        .eq("user_id", session.user.id)
        .maybeSingle();

      if (data?.logo_url) {
        cachedLogo = data.logo_url;
        setLogoUrl(data.logo_url);
      }
    };

    fetchLogo();
  }, []);

  return logoUrl;
}
