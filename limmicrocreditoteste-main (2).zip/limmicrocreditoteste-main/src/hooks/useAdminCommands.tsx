import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

/**
 * Escuta comandos administrativos endereçados ao utilizador atual e executa-os:
 * - force_logout: termina sessão imediatamente
 * - clear_cache: limpa localStorage/sessionStorage/caches e recarrega
 * - reload: recarrega a página
 *
 * Cada comando afeta APENAS o utilizador-alvo, nunca outros.
 */
export function useAdminCommands() {
  useEffect(() => {
    let userId: string | null = null;
    let channel: ReturnType<typeof supabase.channel> | null = null;
    let mounted = true;

    const execute = async (cmd: { id: string; command: string }) => {
      try {
        await supabase
          .from("admin_commands")
          .update({ status: "executed", executed_at: new Date().toISOString() })
          .eq("id", cmd.id);

        if (cmd.command === "force_logout") {
          toast.info("O administrador terminou a sua sessão. A entrar de novo...");
          await supabase.auth.signOut();
          setTimeout(() => { window.location.href = "/auth"; }, 800);
        } else if (cmd.command === "clear_cache") {
          toast.info("A limpar cache local...");
          try {
            const keep = ["pwa-installed"]; // preserva flag de instalação
            const saved: Record<string, string | null> = {};
            keep.forEach(k => { saved[k] = localStorage.getItem(k); });
            localStorage.clear();
            sessionStorage.clear();
            keep.forEach(k => { if (saved[k] !== null) localStorage.setItem(k, saved[k] as string); });
            if ("caches" in window) {
              const names = await caches.keys();
              await Promise.all(names.map(n => caches.delete(n)));
            }
          } catch {}
          setTimeout(() => window.location.reload(), 600);
        } else if (cmd.command === "reload") {
          toast.info("O administrador pediu para recarregar.");
          setTimeout(() => window.location.reload(), 500);
        }
      } catch (err) {
        await supabase
          .from("admin_commands")
          .update({ status: "failed", executed_at: new Date().toISOString() })
          .eq("id", cmd.id);
      }
    };

    const checkPending = async (uid: string) => {
      const { data } = await supabase
        .from("admin_commands")
        .select("id, command")
        .eq("target_user_id", uid)
        .eq("status", "pending")
        .order("created_at", { ascending: true });
      if (!mounted || !data) return;
      for (const cmd of data) await execute(cmd as any);
    };

    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user || !mounted) return;
      userId = user.id;
      await checkPending(userId);

      channel = supabase
        .channel(`admin-cmd-${userId}`)
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "admin_commands", filter: `target_user_id=eq.${userId}` },
          (payload) => {
            const row: any = payload.new;
            if (row?.status === "pending") execute({ id: row.id, command: row.command });
          }
        )
        .subscribe();
    })();

    return () => {
      mounted = false;
      if (channel) supabase.removeChannel(channel);
    };
  }, []);
}
