import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useUserRole } from "./useUserRole";
import { useRealtimeRefresh } from "./useRealtimeRefresh";

export interface DashboardStats {
  totalEmprestado: number;
  totalAReceber: number;
  totalRecebimentos: number;
  clientesAtivos: number;
  taxaInadimplencia: number;
  emprestimosAtivos: number;
}

export interface MonthlyData {
  month: string;
  emprestimos: number;
  recebimentos: number;
}

export interface PortfolioData {
  name: string;
  value: number;
  color: string;
}

export interface InadimplenciaData {
  month: string;
  taxa: number;
}

const MONTH_NAMES = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

export function useDashboardData() {
  const { isAgente, isSuperAdmin, role, loading: roleLoading } = useUserRole();
  const [stats, setStats] = useState<DashboardStats>({
    totalEmprestado: 0,
    totalAReceber: 0,
    totalRecebimentos: 0,
    clientesAtivos: 0,
    taxaInadimplencia: 0,
    emprestimosAtivos: 0,
  });
  const [monthlyData, setMonthlyData] = useState<MonthlyData[]>([]);
  const [portfolioData, setPortfolioData] = useState<PortfolioData[]>([]);
  const [inadimplenciaData, setInadimplenciaData] = useState<InadimplenciaData[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = useCallback(async () => {
    try {
      // Superadmin tem o seu próprio dashboard (SuperAdminDashboard) — não correr nada aqui.
      if (isSuperAdmin) {
        setLoading(false);
        return;
      }

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return;
      const user = session.user;

      // Determinar o "scope" — para agentes usa-se RPC específica, senão usa-se o user_id (que cobre user-mãe e RLS)
      let statsRes: any;
      let monthlyRes: any;

      if (isAgente) {
        [statsRes, monthlyRes] = await Promise.all([
          (supabase as any).rpc("dashboard_stats_agente", { p_agente_id: user.id }),
          (supabase as any).rpc("dashboard_monthly_user", { p_scope_user_id: user.id, p_months: 6 }),
        ]);
      } else {
        // user-mãe / secretariado / admin — usa scope do próprio user_id (RPC já cobre user_id OR usuario_mae_id)
        // Para secretariado/agentes filhos podemos resolver depois; manter user.id como scope é correto p/ user-mãe.
        [statsRes, monthlyRes] = await Promise.all([
          (supabase as any).rpc("dashboard_stats_user", { p_scope_user_id: user.id }),
          (supabase as any).rpc("dashboard_monthly_user", { p_scope_user_id: user.id, p_months: 6 }),
        ]);
      }

      const s = statsRes?.data || {};
      setStats({
        totalEmprestado: Number(s.totalEmprestado || 0),
        totalAReceber: Number(s.totalAReceber || 0),
        totalRecebimentos: Number(s.totalRecebimentos || 0),
        clientesAtivos: Number(s.clientesAtivos || 0),
        taxaInadimplencia: Number(s.taxaInadimplencia || 0),
        emprestimosAtivos: Number(s.emprestimosAtivos || 0),
      });

      const monthlyArr: any[] = monthlyRes?.data || [];
      const monthly: MonthlyData[] = monthlyArr.map((m) => {
        const [yy, mm] = String(m.mes || "").split("-");
        const idx = Math.max(0, Math.min(11, parseInt(mm || "1", 10) - 1));
        return {
          month: MONTH_NAMES[idx] || String(m.mes || ""),
          emprestimos: Number(m.emprestimos || 0),
          recebimentos: Number(m.recebimentos || 0),
        };
      });
      setMonthlyData(monthly);

      // Inadimplência (aprox.): usar a taxa atual em todos os meses (placeholder leve, sem fetchs extra)
      setInadimplenciaData(
        monthly.map((m) => ({ month: m.month, taxa: Number(s.taxaInadimplencia || 0) }))
      );

      // Portfólio com valores reais (MT) vindos da RPC
      const emDia = Number(s.valorEmDia || 0);
      const vencido = Number(s.valorVencido || 0);
      const pago = Number(s.valorPago || 0);
      const portfolio = [
        { name: "Em dia", value: emDia, color: "hsl(142, 76%, 36%)" },
        { name: "Vencido", value: vencido, color: "hsl(0, 84%, 60%)" },
        { name: "Pago", value: pago, color: "hsl(217, 91%, 60%)" },
      ].filter((p) => p.value > 0);

      setPortfolioData(portfolio.length > 0 ? portfolio : [{ name: "Sem dados", value: 1, color: "hsl(0, 0%, 70%)" }]);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoading(false);
    }
  }, [isAgente, isSuperAdmin]);

  useEffect(() => {
    if (roleLoading) return;
    fetchDashboardData();
  }, [fetchDashboardData, roleLoading, role]);

  useRealtimeRefresh(
    ["clientes", "emprestimos", "pagamentos", "despesas", "entradas_capital", "capital_mensal", "capital_global"],
    fetchDashboardData,
    !roleLoading && !isSuperAdmin,
    900
  );

  return { stats, monthlyData, portfolioData, inadimplenciaData, loading };
}
