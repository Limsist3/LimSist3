import { useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";

const HEARTBEAT_INTERVAL = 10 * 60 * 1000; // 10 minutos (reduzir carga no DB)
const MIN_GAP_MS = 5 * 60 * 1000; // não atualiza se já atualizado há <5min nesta sessão
let lastUpdateAt = 0;

export function useHeartbeat() {
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    let cancelled = false;

    const updateLastSeen = async () => {
      // Evitar updates duplicados se vários componentes montarem o hook
      const now = Date.now();
      if (now - lastUpdateAt < MIN_GAP_MS) return;
      // Pausar quando a aba está em background
      if (typeof document !== "undefined" && document.hidden) return;
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session?.user || cancelled) return;

        lastUpdateAt = now;
        // fire-and-forget; não bloquear a UI
        supabase
          .from("user_profiles")
          .update({ last_seen: new Date().toISOString() })
          .eq("user_id", session.user.id)
          .then(() => {}, () => {});
      } catch {
        // silent
      }
    };

    updateLastSeen();
    intervalRef.current = setInterval(updateLastSeen, HEARTBEAT_INTERVAL);

    return () => {
      cancelled = true;
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);
}
