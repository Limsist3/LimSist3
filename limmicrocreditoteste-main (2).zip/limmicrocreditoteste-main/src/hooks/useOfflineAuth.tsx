import { supabase } from '@/integrations/supabase/client';

const DB_NAME = 'limsist_auth';
const DB_VERSION = 1;
const STORE_NAME = 'cached_sessions';

interface CachedSession {
  email: string;
  passwordHash: string;
  userData: any;
  timestamp: number;
}

// Simple hash function for password verification
const hashPassword = async (password: string): Promise<string> => {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
};

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);

    request.onupgradeneeded = (event: any) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'email' });
      }
    };
  });
};

export const useOfflineAuth = () => {
  // Store session after successful online login
  const cacheSession = async (email: string, password: string, userData: any) => {
    try {
      const db = await openDB();
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);

      const passwordHash = await hashPassword(password);
      const cachedSession: CachedSession = {
        email,
        passwordHash,
        userData,
        timestamp: Date.now(),
      };

      await store.put(cachedSession);
    } catch (error) {
      console.error('Erro ao armazenar sessão offline:', error);
    }
  };

  // Attempt offline login
  const offlineLogin = async (email: string, password: string): Promise<{ success: boolean; userData?: any; error?: string }> => {
    try {
      const db = await openDB();
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);

      return new Promise((resolve) => {
        const request = store.get(email);
        
        request.onsuccess = async () => {
          const cachedSession: CachedSession = request.result;
          
          if (!cachedSession) {
            resolve({ success: false, error: 'Nenhuma sessão offline encontrada para este e-mail.' });
            return;
          }

          const passwordHash = await hashPassword(password);
          
          if (passwordHash === cachedSession.passwordHash) {
            resolve({ success: true, userData: cachedSession.userData });
          } else {
            resolve({ success: false, error: 'Senha incorreta.' });
          }
        };

        request.onerror = () => {
          resolve({ success: false, error: 'Erro ao acessar sessão offline.' });
        };
      });
    } catch (error) {
      return { success: false, error: 'Erro ao tentar login offline.' };
    }
  };

  // Clear cached sessions (for logout)
  const clearCachedSession = async (email: string) => {
    try {
      const db = await openDB();
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      await store.delete(email);
    } catch (error) {
      console.error('Erro ao limpar sessão offline:', error);
    }
  };

  return {
    cacheSession,
    offlineLogin,
    clearCachedSession,
  };
};
