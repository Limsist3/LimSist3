import { useEffect, useState, lazy, Suspense, createContext, useContext } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import { OfflineIndicator } from "@/components/OfflineIndicator";
import { PWAInstallGate } from "@/components/PWAInstallGate";
import { useInactivityLogout } from "@/hooks/useInactivityLogout";
import { useAdminCommands } from "@/hooks/useAdminCommands";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { installErrorReporter } from "@/lib/errorReporter";
import { initPWAInstallCapture } from "@/lib/pwaInstall";
import Auth from "./pages/Auth";

installErrorReporter();
initPWAInstallCapture();

// Lazy load all pages for better performance
const Dashboard = lazy(() => import("./pages/Dashboard"));
const Clientes = lazy(() => import("./pages/Clientes"));
const Emprestimos = lazy(() => import("./pages/Emprestimos"));
const Simulador = lazy(() => import("./pages/Simulador"));
const Poupancas = lazy(() => import("./pages/Poupancas"));
const Relatorios = lazy(() => import("./pages/Relatorios"));

const Despesas = lazy(() => import("./pages/Despesas"));
const Configuracoes = lazy(() => import("./pages/Configuracoes"));
const Administracao = lazy(() => import("./pages/Administracao"));
const Pagamentos = lazy(() => import("./pages/Pagamentos"));
const CentralRisco = lazy(() => import("./pages/CentralRisco"));
const FechoContas = lazy(() => import("./pages/FechoContas"));
const GestaoAgentes = lazy(() => import("./pages/GestaoAgentes"));
const ConfiguracaoPagamentos = lazy(() => import("./pages/ConfiguracaoPagamentos"));
const PagamentoRenovacao = lazy(() => import("./pages/PagamentoRenovacao"));
const UsuarioDetalhe = lazy(() => import("./pages/UsuarioDetalhe"));
const Chat = lazy(() => import("./pages/Chat"));
const MeusPagamentos = lazy(() => import("./pages/MeusPagamentos"));
const NotFound = lazy(() => import("./pages/NotFound"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 10, // 10 minutos
      gcTime: 1000 * 60 * 30, // 30 minutos
      refetchOnWindowFocus: false,
      refetchOnReconnect: false,
      refetchOnMount: false,
      retry: 1,
    },
  },
});

type AuthState = { session: Session | null; loading: boolean };
const AuthContext = createContext<AuthState>({ session: null, loading: true });

function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AuthState>({ session: null, loading: true });

  // Hooks globais (uma única instância para toda a aplicação)
  useInactivityLogout();
  useAdminCommands();

  useEffect(() => {
    let mounted = true;

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (mounted) setState({ session, loading: false });
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (mounted) setState({ session, loading: false });
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  return <AuthContext.Provider value={state}>{children}</AuthContext.Provider>;
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { session, loading } = useContext(AuthContext);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!session) {
    return <Navigate to="/auth" replace />;
  }

  return <>{children}</>;
}

/** Pré-carrega as páginas mais usadas quando o browser está inactivo (navegação instantânea) */
function useIdlePrefetch() {
  useEffect(() => {
    const prefetch = () => {
      import("./pages/Dashboard");
      import("./pages/Clientes");
      import("./pages/Emprestimos");
      import("./pages/Pagamentos");
    };
    const w = window as any;
    if (typeof w.requestIdleCallback === "function") {
      const id = w.requestIdleCallback(prefetch, { timeout: 3000 });
      return () => w.cancelIdleCallback?.(id);
    }
    const t = setTimeout(prefetch, 2000);
    return () => clearTimeout(t);
  }, []);
}

const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center">
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
  </div>
);

const AppRoutes = () => {
  useIdlePrefetch();
  return (
        <Suspense fallback={<PageLoader />}>
        <Routes>

          <Route path="/auth" element={<Auth />} />
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <Navigate to="/dashboard" replace />
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/clientes"
            element={
              <ProtectedRoute>
                <Clientes />
              </ProtectedRoute>
            }
          />
          <Route
            path="/emprestimos"
            element={
              <ProtectedRoute>
                <Emprestimos />
              </ProtectedRoute>
            }
          />
          <Route
            path="/simulador"
            element={
              <ProtectedRoute>
                <Simulador />
              </ProtectedRoute>
            }
          />
          <Route
            path="/poupancas"
            element={
              <ProtectedRoute>
                <Poupancas />
              </ProtectedRoute>
            }
          />
          <Route
            path="/relatorios"
            element={
              <ProtectedRoute>
                <Relatorios />
              </ProtectedRoute>
            }
          />
          <Route
            path="/despesas"
            element={
              <ProtectedRoute>
                <Despesas />
              </ProtectedRoute>
            }
          />
          <Route
            path="/pagamentos"
            element={
              <ProtectedRoute>
                <Pagamentos />
              </ProtectedRoute>
            }
          />
          <Route
            path="/configuracoes"
            element={
              <ProtectedRoute>
                <Configuracoes />
              </ProtectedRoute>
            }
          />
          <Route
            path="/administracao"
            element={
              <ProtectedRoute>
                <Administracao />
              </ProtectedRoute>
            }
          />
          <Route
            path="/gestao-agentes"
            element={
              <ProtectedRoute>
                <GestaoAgentes />
              </ProtectedRoute>
            }
          />
          <Route
            path="/configuracao-pagamentos"
            element={
              <ProtectedRoute>
                <ConfiguracaoPagamentos />
              </ProtectedRoute>
            }
          />
          <Route path="/pagamento-renovacao" element={<PagamentoRenovacao />} />
          <Route
            path="/central-risco"
            element={
              <ProtectedRoute>
                <CentralRisco />
              </ProtectedRoute>
            }
          />
          <Route
            path="/fecho-contas"
            element={
              <ProtectedRoute>
                <FechoContas />
              </ProtectedRoute>
            }
          />
          <Route
            path="/usuario/:userId"
            element={
              <ProtectedRoute>
                <UsuarioDetalhe />
              </ProtectedRoute>
            }
          />
          <Route
            path="/chat"
            element={
              <ProtectedRoute>
                <Chat />
              </ProtectedRoute>
            }
          />
          <Route
            path="/meus-pagamentos"
            element={
              <ProtectedRoute>
                <MeusPagamentos />
              </ProtectedRoute>
            }
          />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
        </Suspense>
  );
};

const App = () => (
  <ErrorBoundary>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <OfflineIndicator />
        <BrowserRouter>
          <AuthProvider>
            <AppRoutes />
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </ErrorBoundary>
);


export default App;
