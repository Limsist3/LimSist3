import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Edit, Trash2, FileText, FileSignature, TrendingUp, CalendarDays, DollarSign, Percent, Check } from "lucide-react";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";
import { gerarContratoInvestimento, gerarRelatorioInvestimento, calcularCronogramaInvestimento } from "@/lib/investimentoPdf";

const fmt = (v: number) => new Intl.NumberFormat("pt-MZ", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v || 0);
const fmtDate = (d?: string | null) => d ? new Date(d).toLocaleDateString("pt-PT") : "-";

interface FormState {
  cliente_nome: string;
  cliente_tipo: string;
  nuit: string;
  contacto: string;
  endereco: string;
  valor_capital: string;
  taxa_mensal: string;
  periodo_meses: string;
  data_inicio: string;
  observacoes: string;
}

const emptyForm: FormState = {
  cliente_nome: "", cliente_tipo: "individual", nuit: "", contacto: "", endereco: "",
  valor_capital: "", taxa_mensal: "", periodo_meses: "", data_inicio: new Date().toISOString().slice(0, 10), observacoes: "",
};

export function PoupancasInvestimentoSection() {
  const [items, setItems] = useState<any[]>([]);
  const [selected, setSelected] = useState<any | null>(null);
  const [ganhos, setGanhos] = useState<any[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [toDelete, setToDelete] = useState<string | null>(null);

  const load = async () => {
    const { data } = await supabase.from("poupancas_investimento").select("*").order("created_at", { ascending: false });
    setItems(data || []);
  };
  const loadGanhos = async (id: string) => {
    const { data } = await supabase.from("poupanca_investimento_ganhos").select("*").eq("poupanca_id", id).order("mes_referencia");
    setGanhos(data || []);
  };

  useEffect(() => { load(); }, []);
  useEffect(() => { if (selected?.id) loadGanhos(selected.id); }, [selected]);
  useRealtimeRefresh(["poupancas_investimento", "poupanca_investimento_ganhos"], () => {
    load();
    if (selected?.id) loadGanhos(selected.id);
  }, true, 900);

  const openNew = () => { setEditing(null); setForm(emptyForm); setDialogOpen(true); };
  const openEdit = (it: any) => {
    setEditing(it);
    setForm({
      cliente_nome: it.cliente_nome || "", cliente_tipo: it.cliente_tipo || "individual",
      nuit: it.nuit || "", contacto: it.contacto || "", endereco: it.endereco || "",
      valor_capital: String(it.valor_capital || ""), taxa_mensal: String(it.taxa_mensal || ""),
      periodo_meses: String(it.periodo_meses || ""), data_inicio: it.data_inicio || "",
      observacoes: it.observacoes || "",
    });
    setDialogOpen(true);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const { data: { session } } = await supabase.auth.getSession();
    const user = session?.user;
    if (!user) { toast.error("Sessão expirada"); return; }
    const capital = parseFloat(form.valor_capital.replace(",", ".")) || 0;
    const taxa = parseFloat(form.taxa_mensal.replace(",", ".")) || 0;
    const meses = parseInt(form.periodo_meses) || 0;
    if (!form.cliente_nome || capital <= 0 || meses <= 0) {
      toast.error("Preencha nome, capital e período");
      return;
    }
    const dIni = new Date(form.data_inicio || new Date());
    const dFim = new Date(dIni); dFim.setMonth(dFim.getMonth() + meses);

    const payload = {
      user_id: user.id,
      cliente_nome: form.cliente_nome,
      cliente_tipo: form.cliente_tipo,
      nuit: form.nuit || null,
      contacto: form.contacto || null,
      endereco: form.endereco || null,
      valor_capital: capital,
      taxa_mensal: taxa,
      periodo_meses: meses,
      data_inicio: form.data_inicio,
      data_fim: dFim.toISOString().slice(0, 10),
      observacoes: form.observacoes || null,
    };
    const { error } = editing
      ? await supabase.from("poupancas_investimento").update(payload).eq("id", editing.id)
      : await supabase.from("poupancas_investimento").insert([payload]);
    if (error) { toast.error("Erro ao guardar"); return; }
    toast.success(editing ? "Poupança actualizada" : "Poupança criada");
    setDialogOpen(false);
    load();
  };

  const remove = async () => {
    if (!toDelete) return;
    const { error } = await supabase.from("poupancas_investimento").delete().eq("id", toDelete);
    if (error) toast.error("Erro ao apagar");
    else { toast.success("Apagado"); if (selected?.id === toDelete) setSelected(null); load(); }
    setDeleteOpen(false); setToDelete(null);
  };

  const marcarGanhoPago = async (mesRef: string, valor: number, poupancaId: string) => {
    const { data: { session } } = await supabase.auth.getSession();
    const user = session?.user;
    if (!user) return;
    const existente = ganhos.find(g => g.mes_referencia === mesRef);
    const payload = {
      poupanca_id: poupancaId, user_id: user.id, mes_referencia: mesRef,
      valor_ganho: valor, pago: true, data_pagamento: new Date().toISOString().slice(0, 10)
    };
    if (existente) {
      await supabase.from("poupanca_investimento_ganhos")
        .update({ pago: !existente.pago, data_pagamento: existente.pago ? null : new Date().toISOString().slice(0, 10) })
        .eq("id", existente.id);
    } else {
      await supabase.from("poupanca_investimento_ganhos").insert([payload]);
    }
    toast.success("Ganho actualizado");
    loadGanhos(poupancaId);
  };

  const diasRestantes = (p: any) => {
    if (!p.data_fim) return 0;
    return Math.max(0, Math.ceil((new Date(p.data_fim).getTime() - Date.now()) / (1000 * 60 * 60 * 24)));
  };
  const diasTotais = (p: any) => {
    if (!p.data_inicio || !p.data_fim) return 0;
    return Math.round((new Date(p.data_fim).getTime() - new Date(p.data_inicio).getTime()) / (1000 * 60 * 60 * 24));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold">Poupança Investimento</h2>
          <p className="text-sm text-muted-foreground">Depósito com rendimento mensal fixo e devolução do capital ao final do período</p>
        </div>
        <Button onClick={openNew}><Plus className="mr-2 h-4 w-4" />Nova Poupança</Button>
      </div>

      {items.length === 0 ? (
        <Card><CardContent className="py-10 text-center text-muted-foreground">
          <TrendingUp className="h-12 w-12 mx-auto mb-3 opacity-50" />
          Nenhuma poupança de investimento registada.
        </CardContent></Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {items.map((p) => {
            const c = calcularCronogramaInvestimento(p);
            const dRest = diasRestantes(p);
            const dTot = diasTotais(p);
            const perc = dTot > 0 ? Math.min(100, ((dTot - dRest) / dTot) * 100) : 0;
            return (
              <Card key={p.id} className="hover:shadow-lg transition-all border-l-4 border-l-primary">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <CardTitle className="text-lg leading-tight">{p.cliente_nome}</CardTitle>
                      <div className="flex gap-2 mt-1">
                        <Badge variant="outline">{p.cliente_tipo === "instituicao" ? "Instituição" : "Individual"}</Badge>
                        <Badge variant={p.status === "activo" ? "default" : "secondary"}>{p.status}</Badge>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground flex items-center gap-1"><DollarSign className="h-3 w-3" />Capital</span><span className="font-semibold">{fmt(p.valor_capital)} MZN</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground flex items-center gap-1"><Percent className="h-3 w-3" />Taxa Mensal</span><span>{Number(p.taxa_mensal).toFixed(2)}%</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Ganho/mês</span><span className="text-primary font-semibold">{fmt(p.valor_capital * (p.taxa_mensal/100))} MZN</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Total previsto</span><span className="font-semibold">{fmt(c.totalGanhos)} MZN</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground flex items-center gap-1"><CalendarDays className="h-3 w-3" />Período</span><span>{p.periodo_meses} meses ({dTot}d)</span></div>
                  <div className="flex justify-between text-xs"><span>Início: {fmtDate(p.data_inicio)}</span><span>Fim: {fmtDate(p.data_fim)}</span></div>
                  <div className="pt-1">
                    <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-primary to-primary/60" style={{ width: `${perc}%` }} />
                    </div>
                    <div className="text-xs text-muted-foreground mt-1 text-right">{dRest} dias restantes</div>
                  </div>
                  <div className="flex flex-wrap gap-1 pt-2 border-t">
                    <Button size="sm" variant="outline" onClick={() => setSelected(p)}><FileText className="h-3 w-3 mr-1" />Detalhes</Button>
                    <Button size="sm" variant="outline" onClick={() => gerarContratoInvestimento(p)}><FileSignature className="h-3 w-3 mr-1" />Contrato</Button>
                    <Button size="sm" variant="ghost" onClick={() => openEdit(p)}><Edit className="h-3 w-3" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => { setToDelete(p.id); setDeleteOpen(true); }}><Trash2 className="h-3 w-3 text-destructive" /></Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Detalhes */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl">{selected?.cliente_nome} — Cronograma de Rendimentos</DialogTitle>
            <DialogDescription>Marque os ganhos como pagos à medida que forem sendo entregues.</DialogDescription>
          </DialogHeader>
          {selected && (() => {
            const c = calcularCronogramaInvestimento(selected);
            const totalPago = ganhos.filter(g => g.pago).reduce((s, g) => s + Number(g.valor_ganho || 0), 0);
            return (
              <div className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <Card><CardContent className="p-3"><div className="text-xs text-muted-foreground">Capital</div><div className="text-lg font-bold">{fmt(selected.valor_capital)}</div></CardContent></Card>
                  <Card><CardContent className="p-3"><div className="text-xs text-muted-foreground">Total Previsto</div><div className="text-lg font-bold">{fmt(c.totalGanhos)}</div></CardContent></Card>
                  <Card><CardContent className="p-3"><div className="text-xs text-muted-foreground">Pago</div><div className="text-lg font-bold text-primary">{fmt(totalPago)}</div></CardContent></Card>
                  <Card><CardContent className="p-3"><div className="text-xs text-muted-foreground">Por Pagar</div><div className="text-lg font-bold text-orange-600">{fmt(c.totalGanhos - totalPago)}</div></CardContent></Card>
                </div>
                <Button onClick={() => gerarRelatorioInvestimento(selected, ganhos)}><FileText className="mr-2 h-4 w-4" />Descarregar Relatório</Button>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-muted">
                      <tr>
                        <th className="p-2 text-left">Mês</th>
                        <th className="p-2 text-left">Data Prevista</th>
                        <th className="p-2 text-right">Ganho</th>
                        <th className="p-2 text-center">Estado</th>
                        <th className="p-2 text-center">Acção</th>
                      </tr>
                    </thead>
                    <tbody>
                      {c.rows.map((r) => {
                        const mesRef = r.data.slice(0, 7);
                        const g = ganhos.find(x => x.mes_referencia === mesRef);
                        return (
                          <tr key={r.mes} className="border-t">
                            <td className="p-2">{r.mes}</td>
                            <td className="p-2">{fmtDate(r.data)}</td>
                            <td className="p-2 text-right font-semibold">{fmt(r.ganho)}</td>
                            <td className="p-2 text-center">
                              {g?.pago
                                ? <Badge className="bg-green-600">Pago {g.data_pagamento ? `em ${fmtDate(g.data_pagamento)}` : ""}</Badge>
                                : <Badge variant="outline">Pendente</Badge>}
                            </td>
                            <td className="p-2 text-center">
                              <Button size="sm" variant={g?.pago ? "outline" : "default"} onClick={() => marcarGanhoPago(mesRef, r.ganho, selected.id)}>
                                <Check className="h-3 w-3 mr-1" />{g?.pago ? "Desmarcar" : "Marcar Pago"}
                              </Button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      {/* Formulário */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar Poupança Investimento" : "Nova Poupança Investimento"}</DialogTitle>
            <DialogDescription>Um cliente ou instituição deposita um capital por um período e recebe ganhos mensais.</DialogDescription>
          </DialogHeader>
          <form onSubmit={submit} className="space-y-3">
            <div className="grid md:grid-cols-2 gap-3">
              <div><Label>Nome do Investidor *</Label><Input value={form.cliente_nome} onChange={(e) => setForm(f => ({ ...f, cliente_nome: e.target.value }))} required /></div>
              <div>
                <Label>Tipo</Label>
                <Select value={form.cliente_tipo} onValueChange={(v) => setForm(f => ({ ...f, cliente_tipo: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="individual">Individual</SelectItem>
                    <SelectItem value="instituicao">Instituição</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>NUIT</Label><Input value={form.nuit} onChange={(e) => setForm(f => ({ ...f, nuit: e.target.value }))} /></div>
              <div><Label>Contacto</Label><Input value={form.contacto} onChange={(e) => setForm(f => ({ ...f, contacto: e.target.value }))} /></div>
              <div className="md:col-span-2"><Label>Endereço</Label><Input value={form.endereco} onChange={(e) => setForm(f => ({ ...f, endereco: e.target.value }))} /></div>
              <div><Label>Capital (MZN) *</Label><Input value={form.valor_capital} onChange={(e) => setForm(f => ({ ...f, valor_capital: e.target.value }))} required /></div>
              <div><Label>Taxa Mensal (%) *</Label><Input value={form.taxa_mensal} onChange={(e) => setForm(f => ({ ...f, taxa_mensal: e.target.value }))} required /></div>
              <div><Label>Período (meses) *</Label><Input type="number" value={form.periodo_meses} onChange={(e) => setForm(f => ({ ...f, periodo_meses: e.target.value }))} required /></div>
              <div><Label>Data de Início</Label><Input type="date" value={form.data_inicio} onChange={(e) => setForm(f => ({ ...f, data_inicio: e.target.value }))} /></div>
            </div>
            <div><Label>Observações</Label><Textarea value={form.observacoes} onChange={(e) => setForm(f => ({ ...f, observacoes: e.target.value }))} /></div>
            {form.valor_capital && form.taxa_mensal && form.periodo_meses && (
              <div className="p-3 rounded-lg bg-muted/50 text-sm space-y-1">
                <div className="font-semibold">Pré-visualização:</div>
                <div>Ganho mensal: <strong>{fmt((parseFloat(form.valor_capital) || 0) * ((parseFloat(form.taxa_mensal) || 0) / 100))} MZN</strong></div>
                <div>Total de ganhos: <strong>{fmt((parseFloat(form.valor_capital) || 0) * ((parseFloat(form.taxa_mensal) || 0) / 100) * (parseInt(form.periodo_meses) || 0))} MZN</strong></div>
                <div>Duração: <strong>{parseInt(form.periodo_meses) || 0} meses ({(parseInt(form.periodo_meses) || 0) * 30} dias aprox.)</strong></div>
              </div>
            )}
            <Button type="submit" className="w-full">{editing ? "Actualizar" : "Criar Poupança"}</Button>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog open={deleteOpen} onOpenChange={setDeleteOpen} title="Apagar poupança?" description="Esta acção não pode ser revertida." onConfirm={remove} />
    </div>
  );
}
