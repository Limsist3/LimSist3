import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { FileText, Download, Printer } from "lucide-react";
import { GarantiaItem, jsonToGarantias } from "@/components/GarantiasForm";
import { gerarTabelaAmortizacao, calcularTotaisAmortizacao, type ParcelaAmortizacao, type SistemaAmortizacao } from "@/lib/amortization";
import { loadLetterhead, applyLetterheadAllPages, LETTERHEAD_CONTENT_TOP, LETTERHEAD_CONTENT_BOTTOM } from "@/lib/letterhead";

interface ContratoEmprestimoDialogProps {
  emprestimoId: string;
}

const numeroParaExtenso = (num: number): string => {
  const unidades = ['', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove'];
  const especiais = ['dez', 'onze', 'doze', 'treze', 'catorze', 'quinze', 'dezesseis', 'dezessete', 'dezoito', 'dezenove'];
  const dezenas = ['', '', 'vinte', 'trinta', 'quarenta', 'cinquenta', 'sessenta', 'setenta', 'oitenta', 'noventa'];
  const centenas = ['', 'cento', 'duzentos', 'trezentos', 'quatrocentos', 'quinhentos', 'seiscentos', 'setecentos', 'oitocentos', 'novecentos'];
  
  if (num === 0) return 'zero';
  if (num === 100) return 'cem';
  
  let resultado = '';
  const milhares = Math.floor(num / 1000);
  const resto = num % 1000;
  
  if (milhares > 0) {
    if (milhares === 1) resultado += 'mil';
    else resultado += numeroParaExtenso(milhares) + ' mil';
    if (resto > 0) resultado += ' e ';
  }
  
  const c = Math.floor(resto / 100);
  const d = Math.floor((resto % 100) / 10);
  const u = resto % 10;
  
  if (c > 0) resultado += centenas[c];
  if (d > 0 || u > 0) {
    if (c > 0) resultado += ' e ';
    if (d === 1) resultado += especiais[u];
    else {
      resultado += dezenas[d];
      if (u > 0) resultado += (d > 0 ? ' e ' : '') + unidades[u];
    }
  }
  
  return resultado;
};

export function ContratoEmprestimoDialog({ emprestimoId }: ContratoEmprestimoDialogProps) {
  const [open, setOpen] = useState(false);
  const [contratoTexto, setContratoTexto] = useState("");
  const [loading, setLoading] = useState(false);
  const [garantiasState, setGarantiasState] = useState<GarantiaItem[]>([]);
  const [parcelasState, setParcelasState] = useState<ParcelaAmortizacao[]>([]);
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [nomeEmpresa, setNomeEmpresa] = useState("");

  const gerarContratoTexto = useCallback(async () => {
    setLoading(true);
    try {
      const [empRes, configRes] = await Promise.all([
        supabase.from("emprestimos").select(`*, clientes (*)`).eq("id", emprestimoId).single(),
        supabase.from("configuracoes_empresa").select("*").single(),
      ]);

      if (empRes.error) throw empRes.error;
      const emprestimo = empRes.data;
      const config = configRes.data;

      const hoje = new Date();
      const empresa = config?.nome_empresa || 'EMPRESA DE MICROCRÉDITO';
      const endereco = config?.endereco || 'Maputo';
      const diretorNome = config?.diretor_nome || 'Administrador';
      const diretorPosicao = config?.diretor_posicao || 'DIRECTOR GERAL';
      const nuitEmpresa = (config as any)?.nuit || (config as any)?.nuit_empresa || 'N/A';
      // Foro: cidade onde a microcrédito está sediada (campo provincia/cidade), não o endereço completo
      const cidadeEmpresa = (config as any)?.cidade || (config as any)?.provincia || 'Maputo';
      
      setLogoUrl(config?.logo_url || null);
      setNomeEmpresa(empresa);

      const cliente = emprestimo.clientes;

      const garantias: GarantiaItem[] = jsonToGarantias(emprestimo.detalhes_garantia);
      const garantiasValidas = garantias.filter(g => g.descricao.trim());
      setGarantiasState(garantiasValidas);

      // Generate amortization schedule
      const sistema: SistemaAmortizacao = (emprestimo.sistema_amortizacao === 'sac' ? 'sac' : 'price');
      const parcelas = gerarTabelaAmortizacao(
        emprestimo.valor, emprestimo.taxa_juros, emprestimo.duracao_meses,
        emprestimo.modalidade_reembolso || 'mensal', emprestimo.data_desembolso,
        emprestimo.duracao_meses > 1 && emprestimo.tipo_juros === 'Composto' ? sistema : 'price',
        emprestimo.tipo_juros || 'Simples'
      );
      setParcelasState(parcelas);

      let garantiaTabela = '';
      if (garantiasValidas.length > 0) {
        garantiaTabela = '{{TABELA_GARANTIAS}}';
      }

      const custosAdmin = Number(emprestimo.custos_administrativos || 0);
      const taxaMora = Number(emprestimo.taxa_mora || 2);
      const cidadeUpper = String(cidadeEmpresa).toUpperCase();
      const generoMutuario = cliente.genero === 'Feminino' ? 'Mutuária' : 'Mutuário';
      const estadoCivil = (cliente as any).estado_civil || 'Solteiro(a)';

      const texto = `{{LOGO}}

{{CENTER}}**CONTRATO DE EMPRÉSTIMO**{{/CENTER}}

Entre

**${empresa}**, registada na conservatória do Registo de Entidades Legais sob o número ${nuitEmpresa}, com sede **${endereco}**, na cidade de **${cidadeUpper}**, representado neste acto por **${diretorNome}**, na qualidade de ${diretorPosicao}, doravante designado por **Operador de Microcrédito**.

E

**${cliente.nome_completo}**, ${estadoCivil}, natural de ${cliente.distrito || 'N/A'}, residente em ${cliente.bairro || 'N/A'}${cliente.rua ? ', ' + cliente.rua : ''}, portador(a) do(a) BI (BILHETE DE IDENTIDADE) nº ${(cliente as any).bi || cliente.nuit || 'N/A'}${(cliente as any).bi_data_emissao ? `, emitido no dia ${new Date((cliente as any).bi_data_emissao).toLocaleDateString('pt-MZ')}` : ''}${(cliente as any).bi_local_emissao ? `, pelo arquivo de identificação de ${(cliente as any).bi_local_emissao}` : ''}, doravante designado por **${generoMutuario} (a)**.

Declarando e presente Contrato de empréstimo, que se rege pelo Código de Conduta das Instituições de Crédito e Sociedades Financeiras e de Protecção do Consumidor Financeiro, pela Lei nº 20/2020 de 31 de Dezembro, e pelas Cláusulas e termos seguintes:


{{CENTER}}**PRIMEIRA**{{/CENTER}}
{{CENTER}}(Condições de empréstimo){{/CENTER}}

Fica acordando-se no mutuário (a) o valor de **${emprestimo.valor.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT (${numeroParaExtenso(emprestimo.valor)} meticais)** a ser pago em **${emprestimo.duracao_meses} prestações mês(es)**.

A finalidade do presente crédito é: **${emprestimo.observacoes && String(emprestimo.observacoes).trim() ? String(emprestimo.observacoes).trim() : 'Não especificada'}**.


{{CENTER}}**SEGUNDA**{{/CENTER}}
{{CENTER}}(Taxas de Juros){{/CENTER}}

O empréstimo vence juros à taxa de **${Number(emprestimo.taxa_juros).toFixed(2)}%**, sendo as prestações de juros mensais, sucessivas e contadas em forma de prestações mensais sobre o capital em dívida.


{{CENTER}}**TERCEIRA**{{/CENTER}}
{{CENTER}}(Modo e lugar de reembolso){{/CENTER}}

1. O mutuário aceita expressamente devolver o crédito em **${emprestimo.duracao_meses} mensal(is)**, contados a partir da data de desembolso do crédito, conforme as datas de vencimento e montantes das prestações especificadas no plano de pagamento, que faz parte integrante do presente contrato.

{{TABELA_AMORTIZACAO}}

2. O mutuário (a) compromete-se ainda a efectuar os reembolsos do crédito nas contas em anexo ao plano de pagamento, apresentando o comprovativo do reembolso junto à sede da operadora para que lhe seja passado o recibo que confirma a recepção do valor pela operadora.

3. Os encargos resultantes da alteração do plano financeiro a pedido do mutuário são da sua inteira responsabilidade.


{{CENTER}}**QUARTA**{{/CENTER}}
{{CENTER}}(Custos Administrativos){{/CENTER}}

1. Os custos administrativos no valor de **${custosAdmin.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })}MT (${numeroParaExtenso(Math.floor(custosAdmin))} meticais)**, associados à operação de crédito, são da inteira responsabilidade do mutuário.
2. Os custos de reconhecimento/autenticação de documentos, inscrição de hipoteca, registo de bens móveis e outros associados à operação do crédito correm igualmente por conta do mutuário.


{{CENTER}}**QUINTA**{{/CENTER}}
{{CENTER}}(Vencimento Imediato){{/CENTER}}

1. Pode ser considerado imediatamente vencido o presente contrato exigindo-se de imediato o pagamento de todo o valor de capital e juros, ainda em dívida, bem como todos os outros encargos devidos pelo mutuário à operadora de Microcrédito por força deste empréstimo em qualquer dos casos seguintes:
a) Por falta de pagamento pontual de qualquer das prestações acordadas no plano de pagamento;
b) Por destituição do contrato nos casos de atraso de 07 dias após a recepção do valor, devidamente comprovado ou o não uso do mesmo;
c) Por desrespeito de qualquer das cláusulas estabelecidas no presente contrato;
d) Inclusão de informação bem como a omissão de informação falsa;
e) Mudança de domicílio sem prévia comunicação ao operador de Microcrédito.


{{CENTER}}**SEXTA**{{/CENTER}}
{{CENTER}}(Garantias patrimoniais do mutuário){{/CENTER}}

1. Para assegurar o reembolso de capital, juros e demais encargos inerentes ao empréstimo, o mutuário constitui garantia para o empréstimo a favor da **${empresa}**, os seguintes bens:

{{TABELA_GARANTIAS}}

2. As garantias acima descritas serão constituídas através da celebração de um contrato escrito entre a operadora e o mutuário(a).
3. Os mesmos bens podem ser usados em futuros créditos sendo o seu montante actualizado.


{{CENTER}}**SÉTIMA**{{/CENTER}}
{{CENTER}}(Registo das garantias constituídas){{/CENTER}}

Os bens móveis constituídos como garantia de reembolso do crédito estão sujeitos a registo na Central de Registo das Garantias Mobiliárias.


{{CENTER}}**OITAVA**{{/CENTER}}
{{CENTER}}(Conservação das Garantias){{/CENTER}}

1. Enquanto estiver em vigor o presente contrato, o mutuário (a) obriga-se a manter os bens constituídos como garantia em perfeito estado de conservação e funcionamento.
2. O mutuário (a) obriga-se a participar à operadora, de todo o acontecimento que perturbe ou possa perturbar o normal domínio ou a posse dos bens dados em garantia, bem como fazer com que a operadora, a qualquer diligência judicial que importe a penhora ou apreensão dos bens dados em penhor à operadora.
3. O mutuário (a) fica obrigada a permitir o acesso aos bens dados em garantia para a inspecção e verificação da qualidade, quantidade e o estado de conservação.


{{CENTER}}**NONA**{{/CENTER}}
{{CENTER}}(Sanções de incumprimento){{/CENTER}}

1. Caso se verifique falta de pagamento pontual das prestações de capital e juros, o mutuário aceita e autoriza a operadora a aplicação das seguintes sanções:
a) Pagamento de juros de mora diária correspondente a **${Number(taxaMora).toFixed(0)}%** sobre a prestação em atraso e não paga, onde os juros são calculados enquanto durar o atraso no pagamento;
b) Execução extrajudicial da garantia, sem necessidade de recorrer ao tribunal por quaisquer das formas acordadas pelas partes no contrato de Garantia;
c) Cessão do exercício do direito de uso dos bens garantidos, quando receber a notificação da operadora sobre a sua intenção de executar a garantia;
d) O operador fica autorizado a preencher a livrança em branco, conforme acordo de preenchimento da livrança em anexo e a fazer da mesma o uso que melhor entender para a defesa dos seus interesses;
e) Em caso de cobrança em processo judicial ou extrajudicial o mutuário responderá pelos honorários do advogado, custas judiciais, despesas contraídas, pelas inclusive perdas e danos decorrentes da falta de pagamento pontual das prestações.


{{CENTER}}**DÉCIMA**{{/CENTER}}
{{CENTER}}(Resolução e validade do contrato){{/CENTER}}

1. O presente contrato pode ser executado, logo que verificada a entrega da garantia, caso se verifique incumprimento pontual do mutuário e/ou do avalista.
2. O mutuário obriga-se a assinar todos os documentos necessários para que os bens executados sejam vendidos judicial ou extrajudicialmente, dando o prazo para os executados liquidarem a dívida ou procederem à substituição de bens avaliados em conformidade com os termos acordados pelas partes e/ou procedimentos de registo das garantias móveis junto da central de registo das Garantias Mobiliárias.


{{CENTER}}**DÉCIMA PRIMEIRA**{{/CENTER}}
{{CENTER}}(Foro){{/CENTER}}

1. Quaisquer diferendos relacionados com o presente contrato serão resolvidos amigavelmente pelas partes;
2. Caso as partes não consigam resolver os diferendo nos termos do número anterior, serão exclusivamente competente o Tribunal Judicial de **${cidadeUpper}**, com renúncia expressa a outros tribunais.


{{CENTER}}**DÉCIMA SEGUNDA**{{/CENTER}}
{{CENTER}}(Salvaguarda contratual){{/CENTER}}

A nulidade ou declaração de anulação parcial do contrato de empréstimo não determina a invalidade de todo o contrato, salvo quando se mostre que este não teria sido concluído sem a parte inválida.


{{CENTER}}${cidadeUpper}, aos ________________{{/CENTER}}


{{CENTER}}Assinatura do Operador{{/CENTER}}

{{CENTER}}_______________________{{/CENTER}}


{{CENTER}}Assinatura do Mutuário{{/CENTER}}

{{CENTER}}_______________________{{/CENTER}}


{{CENTER}}Assinatura do Avalista{{/CENTER}}

{{CENTER}}_______________________{{/CENTER}}
${emprestimo.avalista_nome ? `{{CENTER}}(${emprestimo.avalista_nome})${emprestimo.testemunha_bi ? '' : ''}{{/CENTER}}` : ''}`;

      // ===== ANEXO: CONFISSÃO DE DÍVIDA E PROMESSA DE PAGAMENTO =====
      const fmtData = (d: any) => d ? new Date(d).toLocaleDateString('pt-MZ') : '________';
      const dividaTotal = Number(emprestimo.valor_total || emprestimo.valor || 0);
      const dataLimite = emprestimo.data_reembolso ? fmtData(emprestimo.data_reembolso) : '________';
      const telefoneCliente = cliente.telefone || 'N/A';
      const nascimento = (cliente as any).data_nascimento ? fmtData((cliente as any).data_nascimento) : '________';
      const biCliente = (cliente as any).bi || cliente.nuit || 'N/A';
      const residencia = `${cliente.bairro || 'N/A'}${cliente.rua ? ', ' + cliente.rua : ''}${cliente.distrito ? ', ' + cliente.distrito : ''}`;
      const telEmpresa = config?.telefone || 'N/A';

      const confissao = `{{PAGEBREAK}}

{{CENTER}}**CONFISSÃO DE DÍVIDA E PROMESSA DE PAGAMENTO**{{/CENTER}}

Eu, **${cliente.nome_completo}**, nascido(a) aos ${nascimento}, portador(a) do B.I nº ${biCliente}, estado civil ${estadoCivil}, natural de ${cliente.distrito || 'N/A'}, residente em ${residencia}, telefone nº ${telefoneCliente}, NUIT ${cliente.nuit || 'N/A'}, declaro ser devedor(a) do valor de **${dividaTotal.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT (${numeroParaExtenso(Math.floor(dividaTotal))} meticais)**, a **${empresa}**, registada na Conservatória do Registo de Entidades Legais sob o nº ${nuitEmpresa}, com sede em ${endereco}, cidade de ${cidadeUpper}, contacto ${telEmpresa}. O mesmo valor será pago até o dia **${dataLimite}**, nos termos do plano de pagamento anexo ao contrato de empréstimo.

Diante do reconhecimento voluntário da supracitada dívida, assumo integral responsabilidade pelo seu total pagamento, comprometendo-me com o ressarcimento integral de acordo com as condições previstas na presente declaração.

O não pagamento ou pagamento parcial além da data de vencimento provocará automaticamente a constituição do devedor em mora, sujeito ao pagamento do valor integral actualizado, acrescido de juros de mora à taxa de **${Number(taxaMora).toFixed(0)}%**.

Por ser verdade, a presente declaração é assinada por mim e pelo(a) senhor(a) **${diretorNome}**, sendo que o não cumprimento nos termos dispostos na presente declaração é passível de execução, servindo a mesma de título executivo, conforme estabelecido no Código de Processo Civil.

{{CENTER}}${cidadeUpper}, aos ________________{{/CENTER}}


Credor                                                             Devedor

**${empresa}**                                        **${cliente.nome_completo}**

_______________________                    _______________________
`;

      setContratoTexto(texto + "\n" + confissao);
      toast.success("Contrato gerado com sucesso!");
    } catch (err: any) {
      console.error("Erro ao gerar contrato:", err);
      toast.error("Erro ao gerar contrato");
    } finally {
      setLoading(false);
    }
  }, [emprestimoId]);

  const gerarPDF = useCallback(async () => {
    const lh = await loadLetterhead();
    const [{ default: jsPDF }, { default: autoTable }] = await Promise.all([
      import("jspdf"),
      import("jspdf-autotable"),
    ]);
    const doc = new jsPDF({ compress: true });
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 15;
    // Times New Roman 10pt com espaçamento compacto (~1.15) → contrato em menos páginas
    const fontSize = 10;
    const lineHeight = 4.6;
    const contentTop = LETTERHEAD_CONTENT_TOP + 2;
    const contentBottomLimit = pageHeight - LETTERHEAD_CONTENT_BOTTOM;
    let y = contentTop;

    // Helper: watermark logo (mantido)
    const addWatermark = () => {
      if (!logoUrl) return;
      try {
        const logoW = 80;
        const logoH = 80;
        const cx = (pageWidth - logoW) / 2;
        const cy = (pageHeight - logoH) / 2;
        const gState = (doc as any).GState;
        if (typeof (doc as any).setGState === 'function') {
          const gs = new gState({ opacity: 0.06 });
          (doc as any).setGState(gs);
          doc.addImage(logoUrl, 'PNG', cx, cy, logoW, logoH);
          const gsNormal = new gState({ opacity: 1 });
          (doc as any).setGState(gsNormal);
        }
      } catch {}
    };

    addWatermark();

    const lines = contratoTexto.split('\n');

    lines.forEach((line) => {
      if (y > contentBottomLimit) {
        doc.addPage();
        addWatermark();
        y = contentTop;
      }

      // Skip logo placeholder (já tratado pelo papel timbrado)
      if (line.includes('{{LOGO}}')) return;

      // Quebra de página (anexos, ex.: Confissão de Dívida)
      if (line.includes('{{PAGEBREAK}}')) {
        doc.addPage();
        addWatermark();
        y = contentTop;
        return;
      }

      // Render guarantee table
      if (line.includes('{{TABELA_GARANTIAS}}')) {
        if (garantiasState.length > 0) {
          autoTable(doc, {
            startY: y,
            head: [['#', 'Tipo de garantia', 'Descrição', 'Preço estimado']],
            body: garantiasState.map((g, i) => [
              (i + 1).toString(), g.tipo || 'N/A', g.descricao,
              `${(g.preco || 0).toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT`,
            ]),
            foot: [['', '', 'Total', `${garantiasState.reduce((s, g) => s + (g.preco || 0), 0).toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT`]],
            margin: { left: margin, right: margin, top: contentTop, bottom: LETTERHEAD_CONTENT_BOTTOM },
            styles: { fontSize: 7.5, cellPadding: 1 },
            headStyles: { fillColor: [60, 60, 60], fontSize: 7 },
            footStyles: { fillColor: [240, 240, 240], textColor: [0, 0, 0], fontStyle: 'bold' },
            didDrawPage: () => { addWatermark(); },
          });
          y = (doc as any).lastAutoTable.finalY + 3;
        }
        return;
      }

      // Render amortization table
      if (line.includes('{{TABELA_AMORTIZACAO}}')) {
        if (parcelasState.length > 0) {
          const totais = calcularTotaisAmortizacao(parcelasState);
          autoTable(doc, {
            startY: y,
            head: [['Nº', 'Data Vencimento', 'Prestação (MT)', 'Capital (MT)', 'Juros (MT)', 'Saldo Devedor (MT)']],
            body: parcelasState.map((p) => [
              p.numero.toString(),
              new Date(p.dataVencimento).toLocaleDateString('pt-MZ'),
              p.prestacao.toLocaleString('pt-MZ', { minimumFractionDigits: 2 }),
              p.amortizacao.toLocaleString('pt-MZ', { minimumFractionDigits: 2 }),
              p.juros.toLocaleString('pt-MZ', { minimumFractionDigits: 2 }),
              p.saldoDevedor.toLocaleString('pt-MZ', { minimumFractionDigits: 2 }),
            ]),
            foot: [['', 'Total', totais.totalPrestacoes.toLocaleString('pt-MZ', { minimumFractionDigits: 2 }), totais.totalAmortizacao.toLocaleString('pt-MZ', { minimumFractionDigits: 2 }), totais.totalJuros.toLocaleString('pt-MZ', { minimumFractionDigits: 2 }), '']],
            margin: { left: margin, right: margin, top: contentTop, bottom: LETTERHEAD_CONTENT_BOTTOM },
            styles: { fontSize: 7, cellPadding: 0.8 },
            headStyles: { fillColor: [60, 60, 60], fontSize: 6.5 },
            footStyles: { fillColor: [240, 240, 240], textColor: [0, 0, 0], fontStyle: 'bold', fontSize: 7 },
            didDrawPage: () => { addWatermark(); },
          });
          y = (doc as any).lastAutoTable.finalY + 3;
        }
        return;
      }

      // Check for centered text
      const isCentered = line.includes('{{CENTER}}');
      let cleanLine = line.replace(/\{\{CENTER\}\}/g, '').replace(/\{\{\/CENTER\}\}/g, '');
      const isBold = cleanLine.includes('**');
      cleanLine = cleanLine.replace(/\*\*/g, '');

      if (!cleanLine.trim()) { y += lineHeight * 0.35; return; }

      doc.setFont("times", isBold ? "bold" : "normal");
      doc.setFontSize(fontSize);

      const maxWidth = pageWidth - 2 * margin;
      const wrappedLines = doc.splitTextToSize(cleanLine, maxWidth);
      const lastIdx = wrappedLines.length - 1;
      wrappedLines.forEach((wl: string, idx: number) => {
        if (y > contentBottomLimit) {
          doc.addPage();
          addWatermark();
          y = contentTop;
        }
        if (isCentered) {
          doc.text(wl, pageWidth / 2, y, { align: 'center' });
        } else {
          const words = wl.trim().split(/\s+/);
          const isLast = idx === lastIdx;
          if (!isLast && words.length > 1) {
            const naturalWidth = doc.getTextWidth(words.join(' '));
            const totalSpace = maxWidth - doc.getTextWidth(words.join(''));
            const gap = totalSpace / (words.length - 1);
            const naturalGap = (naturalWidth - doc.getTextWidth(words.join(''))) / (words.length - 1);
            if (gap > naturalGap * 4) {
              doc.text(wl, margin, y);
            } else {
              let x = margin;
              for (let i = 0; i < words.length; i++) {
                doc.text(words[i], x, y);
                x += doc.getTextWidth(words[i]) + gap;
              }
            }
          } else {
            doc.text(wl, margin, y);
          }
        }
        y += lineHeight;
      });
    });

    applyLetterheadAllPages(doc, lh);
    doc.save(`Contrato_${emprestimoId}.pdf`);
    toast.success("Contrato gerado!");
  }, [contratoTexto, garantiasState, parcelasState, logoUrl, emprestimoId]);

  const imprimir = useCallback(() => {
    const printWindow = window.open('', '', 'height=600,width=800');
    if (!printWindow) return;

    printWindow.document.write('<html><head><title>Contrato</title>');
    printWindow.document.write(`<style>
      @page { margin: 12mm; size: A4; }
      html, body { background: #fff; }
      body {
        font-family: 'Times New Roman', Times, serif;
        padding: 0;
        line-height: 1.2;
        font-size: 10pt;
        position: relative;
        text-align: justify;
        -webkit-hyphens: auto;
        hyphens: auto;
        word-spacing: 0.05em;
      }
      p {
        margin: 0 0 3pt 0;
        text-align: justify;
        text-justify: inter-word;
        orphans: 2;
        widows: 2;
      }
      p.center, div.center { text-align: center; }
      strong { font-weight: bold; }
      table { page-break-inside: avoid; }
      .logo { max-height: 60px; max-width: 120px; margin: 0 auto 10px; display: block; }
      .watermark {
        position: fixed;
        top: 50%; left: 50%;
        transform: translate(-50%, -50%);
        opacity: 0.05;
        pointer-events: none;
        z-index: -1;
        width: 300px;
        height: auto;
      }
      @media print {
        body { padding: 0; }
        .watermark { position: fixed; opacity: 0.05; width: 300px; }
        p { text-align: justify !important; text-justify: inter-word !important; }
      }
    </style>`);
    printWindow.document.write('</head><body>');
    
    // Add watermark background
    if (logoUrl) {
      printWindow.document.write(`<img src="${logoUrl}" class="watermark" />`);
    }

    const htmlContent = contratoTexto
      .split('\n')
      .map(line => {
        if (line.includes('{{PAGEBREAK}}')) {
          return '<div style="page-break-before: always;"></div>';
        }
        if (line.includes('{{LOGO}}')) {
          return logoUrl ? `<div class="center"><img src="${logoUrl}" class="logo" /></div>` : '';
        }
        if (line.includes('{{TABELA_GARANTIAS}}')) {
          if (garantiasState.length === 0) return '';
          const total = garantiasState.reduce((s, g) => s + (g.preco || 0), 0);
          let table = '<table border="1" cellpadding="2" cellspacing="0" style="width:100%;border-collapse:collapse;margin:4px 0;font-size:8pt;">';
          table += '<tr style="background:#f0f0f0;font-weight:bold;"><td>#</td><td>Tipo de garantia</td><td>Descrição</td><td>Preço estimado</td></tr>';
          garantiasState.forEach((g, i) => {
            table += `<tr><td>${i + 1}</td><td>${g.tipo || 'N/A'}</td><td>${g.descricao}</td><td>${(g.preco || 0).toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT</td></tr>`;
          });
          table += `<tr><td colspan="3" style="text-align:right;font-weight:bold;">Total</td><td style="font-weight:bold;">${total.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT</td></tr>`;
          table += '</table>';
          return table;
        }
        if (line.includes('{{TABELA_AMORTIZACAO}}')) {
          if (parcelasState.length === 0) return '';
          const totais = calcularTotaisAmortizacao(parcelasState);
          let tbl = '<table border="1" cellpadding="2" cellspacing="0" style="width:100%;border-collapse:collapse;margin:4px 0;font-size:7.5pt;">';
          tbl += '<tr style="background:#f0f0f0;font-weight:bold;"><td>Nº</td><td>Vencimento</td><td style="text-align:right">Prestação</td><td style="text-align:right">Capital</td><td style="text-align:right">Juros</td><td style="text-align:right">Saldo Devedor</td></tr>';
          parcelasState.forEach((p) => {
            tbl += `<tr><td>${p.numero}</td><td>${new Date(p.dataVencimento).toLocaleDateString('pt-MZ')}</td><td style="text-align:right">${p.prestacao.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT</td><td style="text-align:right">${p.amortizacao.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT</td><td style="text-align:right">${p.juros.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT</td><td style="text-align:right">${p.saldoDevedor.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT</td></tr>`;
          });
          tbl += `<tr style="font-weight:bold;background:#f0f0f0;"><td></td><td>Total</td><td style="text-align:right">${totais.totalPrestacoes.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT</td><td style="text-align:right">${totais.totalAmortizacao.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT</td><td style="text-align:right">${totais.totalJuros.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT</td><td></td></tr>`;
          tbl += '</table>';
          return tbl;
        }

        const isCentered = line.includes('{{CENTER}}');
        let cleanLine = line.replace(/\{\{CENTER\}\}/g, '').replace(/\{\{\/CENTER\}\}/g, '');
        cleanLine = cleanLine.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

        if (!cleanLine.trim()) return '<div style="height:3pt"></div>';
        if (isCentered) return `<p class="center">${cleanLine}</p>`;
        return `<p>${cleanLine}</p>`;
      })
      .join('');

    printWindow.document.write(htmlContent);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    // Aguarda o layout/imagens estabilizarem antes de imprimir,
    // garantindo que a justificação seja aplicada corretamente.
    const doPrint = () => {
      try { printWindow.focus(); printWindow.print(); } catch {}
    };
    if (printWindow.document.readyState === 'complete') {
      setTimeout(doPrint, 150);
    } else {
      printWindow.addEventListener('load', () => setTimeout(doPrint, 150));
    }
  }, [contratoTexto, garantiasState, parcelasState, logoUrl]);

  const handleOpen = () => {
    setOpen(true);
    if (!contratoTexto) gerarContratoTexto();
  };

  return (
    <>
      <Button variant="ghost" size="sm" onClick={handleOpen} title="Gerar Contrato">
        <FileText className="h-4 w-4" />
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>Contrato de Empréstimo</DialogTitle>
          </DialogHeader>
          
          <div className="flex-1 overflow-hidden flex flex-col space-y-4">
            {loading ? (
              <div className="flex-1 flex items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : (
              <>
                <Textarea 
                  value={contratoTexto} 
                  onChange={(e) => setContratoTexto(e.target.value)} 
                  className="flex-1 font-mono text-sm min-h-[400px] resize-none"
                />
                <div className="flex gap-2 pt-4 border-t">
                  <Button onClick={gerarPDF} className="flex-1">
                    <Download className="mr-2 h-4 w-4" />
                    Descarregar PDF
                  </Button>
                  <Button onClick={imprimir} variant="outline" className="flex-1">
                    <Printer className="mr-2 h-4 w-4" />
                    Imprimir
                  </Button>
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
