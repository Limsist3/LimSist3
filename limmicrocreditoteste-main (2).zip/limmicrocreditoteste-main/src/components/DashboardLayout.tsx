import { ReactNode, useState, useEffect } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { useAccessControl } from "@/hooks/useAccessControl";
import { AccountBlocked } from "./AccountBlocked";
import { Menu, AlertTriangle } from "lucide-react";
import { NotificationBell } from "./NotificationBell";
import { PWAInstallButton } from "./PWAInstallButton";
import { PWAInstallForcer } from "./PWAInstallForcer";
import { CountdownTimer } from "./CountdownTimer";
import { Badge } from "@/components/ui/badge";
import { useUserRole } from "@/hooks/useUserRole";
import { useCompanyLogo } from "@/hooks/useCompanyLogo";
import { useHeartbeat } from "@/hooks/useHeartbeat";
import { SuperAdminAlertBar } from "./SuperAdminAlertBar";
import { supabase } from "@/integrations/supabase/client";

interface DashboardLayoutProps {
  children: ReactNode;
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const { accessStatus, loading } = useAccessControl();
  const { role, isSuperAdmin, isAgente, isSecretariado } = useUserRole();
  const companyLogo = useCompanyLogo();
  useHeartbeat();

  const getRoleLabel = () => {
    if (isSuperAdmin) return "Superadministrador";
    if (isAgente) return "Agente";
    if (isSecretariado) return "Secretariado";
    return "Usuário Mãe";
  };

  const getRoleBadgeVariant = () => {
    if (isSuperAdmin) return "default";
    if (isAgente) return "secondary";
    if (isSecretariado) return "secondary";
    return "outline";
  };

  const [hasRecentPayment, setHasRecentPayment] = useState(false);

  useEffect(() => {
    if (isSuperAdmin) return;
    const checkRecentPayment = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return;
      const { data } = await supabase
        .from("subscription_requests")
        .select("id")
        .eq("user_id", session.user.id)
        .in("status", ["aprovado", "temporario", "pendente"])
        .limit(1);
      if (data && data.length > 0) setHasRecentPayment(true);
    };
    checkRecentPayment();
  }, [isSuperAdmin]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (accessStatus && !accessStatus.isActive) {
    return (
      <AccountBlocked
        reason={accessStatus.reason!}
        expiresAt={accessStatus.expiresAt}
      />
    );
  }

  return (
    <PWAInstallForcer>
      <SidebarProvider>
        <div className="min-h-screen flex w-full bg-background overflow-x-hidden">
          <AppSidebar />
          <div className="flex-1 flex flex-col min-w-0">
            <SuperAdminAlertBar />
            {/* Banner de aviso de expiração - ocultar se tem pagamento recente */}
            {accessStatus?.isExpiringSoon && !hasRecentPayment && (
              <div className="bg-amber-500 text-white px-4 py-3 text-center text-sm font-medium flex flex-col sm:flex-row items-center justify-center gap-2">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 shrink-0" />
                  <span>
                    ⚠️ A sua conta expira em {accessStatus.daysRemaining} {accessStatus.daysRemaining === 1 ? 'dia' : 'dias'}!
                  </span>
                </div>
                <a
                  href="/pagamento-renovacao"
                  className="inline-flex items-center gap-1 bg-white text-amber-700 hover:bg-amber-50 font-bold px-4 py-1.5 rounded-md text-sm shadow transition-colors"
                >
                  💳 Renovar Pagamento
                </a>
              </div>
            )}
            {/* Header com botão de menu e notificações */}
            <header className="sticky top-0 z-10 flex h-14 items-center justify-between gap-2 sm:gap-4 border-b bg-background px-3 sm:px-4">
              <div className="flex items-center gap-4 lg:hidden">
                <SidebarTrigger className="text-foreground">
                  <Menu className="h-6 w-6" />
                </SidebarTrigger>
                <div className="flex items-center gap-2">
                  {companyLogo && <img src={companyLogo} alt="Logo" className="h-6 w-6 object-contain rounded" />}
                  <h1 className="text-lg font-semibold">LimSist 2.0</h1>
                </div>
              </div>
              <div className="hidden lg:flex items-center gap-3">
                {companyLogo && <img src={companyLogo} alt="Logo" className="h-6 w-6 object-contain rounded" />}
                <h1 className="text-lg font-semibold">LimSist 2.0</h1>
                {role && (
                  <Badge variant={getRoleBadgeVariant() as any}>
                    {getRoleLabel()}
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
                {accessStatus?.expiresAt && !isSuperAdmin && (
                  <CountdownTimer expiresAt={accessStatus.expiresAt} />
                )}
                <PWAInstallButton />
                <NotificationBell />
              </div>
            </header>
            <main className="flex-1 overflow-y-auto overflow-x-hidden">
              {children}
            </main>
          </div>
        </div>
      </SidebarProvider>
    </PWAInstallForcer>
  );
}
