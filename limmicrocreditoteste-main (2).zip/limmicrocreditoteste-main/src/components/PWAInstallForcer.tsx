import { useState, useEffect, useRef, useCallback } from "react";
import { Download, Smartphone, X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

const PROMPT_DELAY_MS = 30 * 1000; // 30s após abrir
const DISMISS_KEY = "pwa-prompt-dismissed-at";
const INSTALLED_KEY = "pwa-installed";
const REPROMPT_HOURS = 72; // volta a perguntar após 3 dias

export function PWAInstallForcer({ children }: { children: React.ReactNode }) {
  const [showPrompt, setShowPrompt] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [installing, setInstalling] = useState(false);
  const [showManualInstructions, setShowManualInstructions] = useState(false);
  const [browserType, setBrowserType] = useState<string>("other");
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const detectBrowser = useCallback(() => {
    const ua = navigator.userAgent.toLowerCase();
    if (ua.includes("samsungbrowser")) return "samsung";
    if (ua.includes("edg/")) return "edge";
    if (ua.includes("opr/") || ua.includes("opera")) return "opera";
    if (ua.includes("firefox")) return "firefox";
    if (/iPad|iPhone|iPod/.test(navigator.userAgent)) return "safari";
    if (ua.includes("chrome")) return "chrome";
    if (ua.includes("safari")) return "safari";
    return "other";
  }, []);

  const isStandalone = useCallback(() => {
    return (
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as any).standalone === true ||
      document.referrer.includes("android-app://") ||
      localStorage.getItem(INSTALLED_KEY) === "true"
    );
  }, []);

  const isInIframe = useCallback(() => {
    try { return window.self !== window.top; } catch { return true; }
  }, []);

  const wasRecentlyDismissed = () => {
    const last = parseInt(localStorage.getItem(DISMISS_KEY) || "0", 10);
    if (!last) return false;
    return Date.now() - last < REPROMPT_HOURS * 60 * 60 * 1000;
  };

  useEffect(() => {
    if (isInIframe()) return;
    if (isStandalone()) {
      localStorage.setItem(INSTALLED_KEY, "true");
      return;
    }
    setBrowserType(detectBrowser());

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", handler);

    const installedHandler = () => {
      setShowPrompt(false);
      localStorage.setItem(INSTALLED_KEY, "true");
    };
    window.addEventListener("appinstalled", installedHandler);

    if (!wasRecentlyDismissed()) {
      timerRef.current = setTimeout(() => {
        if (!isStandalone()) setShowPrompt(true);
      }, PROMPT_DELAY_MS);
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", handler);
      window.removeEventListener("appinstalled", installedHandler);
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [isStandalone, isInIframe, detectBrowser]);

  const handleDismiss = () => {
    localStorage.setItem(DISMISS_KEY, String(Date.now()));
    setShowPrompt(false);
    setShowManualInstructions(false);
  };

  const handleInstall = async () => {
    if (!deferredPrompt) {
      setShowManualInstructions(true);
      return;
    }
    setInstalling(true);
    try {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        localStorage.setItem(INSTALLED_KEY, "true");
        setShowPrompt(false);
      } else {
        handleDismiss();
      }
    } catch (err) {
      console.error("Install error:", err);
      setShowManualInstructions(true);
    } finally {
      setInstalling(false);
      setDeferredPrompt(null);
    }
  };

  const getManualInstructions = () => {
    const isAndroid = /android/i.test(navigator.userAgent);
    const isMobile = isAndroid || /iPad|iPhone|iPod/.test(navigator.userAgent);
    switch (browserType) {
      case "chrome":
        return isMobile
          ? ["Toque no menu ⋮ no canto superior direito", 'Escolha "Instalar app" ou "Adicionar ao ecrã principal"', 'Confirme tocando em "Instalar"']
          : ["Clique no ícone ⊕ na barra de endereço", 'Ou menu ⋮ → "Instalar LimSist..."'];
      case "edge":
        return ["Menu ⋯ → Apps → Instalar este site como aplicação"];
      case "samsung":
        return ["Menu ☰ → Adicionar página a → Ecrã inicial"];
      case "safari":
        return ["Toque em Partilhar (↑) → Adicionar ao ecrã principal → Adicionar"];
      default:
        return ["Abra o menu do navegador", 'Procure "Instalar app" ou "Adicionar ao ecrã principal"'];
    }
  };

  return (
    <>
      {children}
      {showPrompt && (
        <div className="fixed inset-0 z-[9999] bg-black/50 flex items-end sm:items-center justify-center p-4" onClick={handleDismiss}>
          <div
            className="bg-background rounded-2xl shadow-2xl max-w-md w-full p-6 relative animate-in slide-in-from-bottom-4"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={handleDismiss}
              className="absolute top-3 right-3 text-muted-foreground hover:text-foreground"
              aria-label="Fechar"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Download className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h2 className="text-lg font-bold">Instalar LimSist?</h2>
                <p className="text-xs text-muted-foreground">Acesso mais rápido pelo ecrã principal</p>
              </div>
            </div>

            <p className="text-sm text-muted-foreground mb-5">
              Instalar a aplicação é opcional, mas torna o sistema mais rápido e prático de usar.
            </p>

            {showManualInstructions ? (
              <div className="bg-muted p-3 rounded-lg mb-4 space-y-2">
                <p className="font-semibold text-sm flex items-center gap-2">
                  <Smartphone className="h-4 w-4" /> Como instalar:
                </p>
                <ol className="text-sm space-y-1 text-muted-foreground list-decimal list-inside">
                  {getManualInstructions().map((s, i) => <li key={i}>{s}</li>)}
                </ol>
              </div>
            ) : null}

            <div className="flex flex-col sm:flex-row gap-2">
              <Button
                onClick={handleInstall}
                disabled={installing}
                className="flex-1"
                size="lg"
              >
                <Download className="h-4 w-4 mr-2" />
                {installing ? "A instalar..." : (deferredPrompt ? "Instalar agora" : "Ver como instalar")}
              </Button>
              <Button
                onClick={handleDismiss}
                variant="outline"
                size="lg"
                className="flex-1"
              >
                Agora não
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
