import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, MessageCircle, CreditCard } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface AccountBlockedProps {
  reason: "expired" | "inactive";
  expiresAt?: string;
}

export function AccountBlocked({ reason, expiresAt }: AccountBlockedProps) {
  const navigate = useNavigate();

  const handleWhatsApp = () => {
    const message = encodeURIComponent(
      `Olá! Minha conta está ${reason === "expired" ? "expirada" : "inativa"}. Gostaria de renovar meu acesso à plataforma.`
    );
    window.open(`https://wa.me/258875611599?text=${message}`, "_blank");
  };

  const handleLogin = () => {
    navigate("/auth");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-primary p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-full bg-destructive/10 flex items-center justify-center">
              <AlertTriangle className="h-8 w-8 text-destructive" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold">Conta Não Ativa</CardTitle>
          <CardDescription className="text-base mt-2">
            {reason === "expired" ? (
              <>
                Sua conta expirou em{" "}
                <span className="font-semibold">
                  {expiresAt ? new Date(expiresAt).toLocaleDateString("pt-PT") : "N/A"}
                </span>
              </>
            ) : (
              "Sua conta está inativa no momento"
            )}
          </CardDescription>
          <p className="text-sm text-muted-foreground mt-2">
            Após o pagamento, a sua conta será ativada pelo superadministrador.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-muted p-4 rounded-lg">
            <p className="text-sm text-muted-foreground text-center">
              Para reativar sua conta e continuar usando a plataforma, entre em contato
              conosco ou realize o pagamento de renovação.
            </p>
          </div>

          <div className="space-y-3">
            <Button
              onClick={() => navigate("/pagamento-renovacao")}
              className="w-full"
              size="lg"
              variant="default"
            >
              <CreditCard className="mr-2 h-5 w-5" />
              💳 Pagar Renovação
            </Button>

            <Button
              onClick={handleWhatsApp}
              className="w-full"
              size="lg"
              variant="outline"
            >
              <MessageCircle className="mr-2 h-5 w-5" />
              Contactar via WhatsApp
            </Button>

            <Button
              onClick={handleLogin}
              variant="outline"
              className="w-full"
              size="lg"
            >
              Voltar ao Login
            </Button>
          </div>

          <div className="text-center pt-4 border-t">
            <p className="text-xs text-muted-foreground">
              WhatsApp: +258 87 561 1599
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
