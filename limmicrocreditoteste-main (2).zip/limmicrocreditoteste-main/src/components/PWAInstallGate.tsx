import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, Smartphone, CheckCircle2 } from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export function PWAInstallGate({ children }: { children: React.ReactNode }) {
  const [isInstalled, setIsInstalled] = useState(true); // default true to avoid flash
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [installing, setInstalling] = useState(false);
  const [showIOSInstructions, setShowIOSInstructions] = useState(false);

  useEffect(() => {
    // Check if already installed (standalone mode)
    const isStandalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as any).standalone === true ||
      document.referrer.includes("android-app://");

    // Also check localStorage as fallback
    const wasInstalled = localStorage.getItem("pwa-installed") === "true";

    if (isStandalone || wasInstalled) {
      setIsInstalled(true);
      localStorage.setItem("pwa-installed", "true");
      return;
    }

    setIsInstalled(false);

    // Detect iOS
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    if (isIOS) {
      setShowIOSInstructions(true);
    }

    // Listen for the install prompt
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener("beforeinstallprompt", handler);

    // Listen for successful install
    const installedHandler = () => {
      setIsInstalled(true);
      localStorage.setItem("pwa-installed", "true");
    };
    window.addEventListener("appinstalled", installedHandler);

    // Also listen for display mode changes
    const mediaQuery = window.matchMedia("(display-mode: standalone)");
    const mediaHandler = (e: MediaQueryListEvent) => {
      if (e.matches) {
        setIsInstalled(true);
        localStorage.setItem("pwa-installed", "true");
      }
    };
    mediaQuery.addEventListener("change", mediaHandler);

    return () => {
      window.removeEventListener("beforeinstallprompt", handler);
      window.removeEventListener("appinstalled", installedHandler);
      mediaQuery.removeEventListener("change", mediaHandler);
    };
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    setInstalling(true);
    try {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        setIsInstalled(true);
        localStorage.setItem("pwa-installed", "true");
      }
    } catch (err) {
      console.error("Install error:", err);
    } finally {
      setInstalling(false);
      setDeferredPrompt(null);
    }
  };

  if (isInstalled) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-3">
          <div className="mx-auto bg-primary/10 p-4 rounded-full w-fit">
            <Download className="h-10 w-10 text-primary" />
          </div>
          <CardTitle className="text-xl">Instalar LimSist</CardTitle>
          <p className="text-sm text-muted-foreground">
            Para utilizar o sistema, é necessário instalar a aplicação no seu dispositivo.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Benefits */}
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
              <span>Funciona mesmo sem internet</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
              <span>Acesso rápido pelo ecrã principal</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
              <span>Experiência optimizada para o seu dispositivo</span>
            </div>
          </div>

          {/* Install button - always visible */}
          <Button
            onClick={handleInstall}
            disabled={installing || !deferredPrompt}
            className="w-full h-14 text-base font-semibold"
            size="lg"
          >
            {installing ? (
              "Instalando..."
            ) : !deferredPrompt ? (
              <>
                <Download className="mr-2 h-5 w-5" />
                📲 A preparar instalação...
              </>
            ) : (
              <>
                <Download className="mr-2 h-5 w-5" />
                📲 Instalar Agora
              </>
            )}
          </Button>

          {/* iOS instructions only */}
          {showIOSInstructions && (
            <div className="bg-muted p-4 rounded-lg space-y-3">
              <p className="font-semibold text-sm flex items-center gap-2">
                <Smartphone className="h-4 w-4" />
                Como instalar no iPhone/iPad:
              </p>
              <ol className="text-sm space-y-2 text-muted-foreground list-decimal list-inside">
                <li>Toque no botão <strong>Partilhar</strong> (ícone ↑) na barra do Safari</li>
                <li>Escolha <strong>"Adicionar ao ecrã principal"</strong></li>
                <li>Toque em <strong>"Adicionar"</strong></li>
                <li>Abra o LimSist a partir do ecrã principal</li>
              </ol>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
