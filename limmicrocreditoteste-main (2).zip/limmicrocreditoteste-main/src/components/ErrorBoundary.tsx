import React from "react";
import { reportError } from "@/lib/errorReporter";
import { Button } from "@/components/ui/button";

interface State { hasError: boolean; message?: string; }

const RELOAD_FLAG = "__chunk_reload_attempt__";

function isStaleChunkError(message?: string): boolean {
  if (!message) return false;
  const m = message.toLowerCase();
  return (
    m.includes("failed to fetch dynamically imported module") ||
    m.includes("failed to fetch dynamically imported") ||
    m.includes("importing a module script failed") ||
    m.includes("error loading dynamically imported module") ||
    (m.includes("loading chunk") && m.includes("failed"))
  );
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // Auto-recuperação para erros de chunk obsoleto após nova publicação
    if (isStaleChunkError(error.message)) {
      try {
        const attempted = sessionStorage.getItem(RELOAD_FLAG);
        if (!attempted) {
          sessionStorage.setItem(RELOAD_FLAG, "1");
          // Limpa caches do Service Worker se existirem, depois recarrega forçado
          if (typeof caches !== "undefined") {
            caches.keys().then((keys: string[]) => Promise.all(keys.map((k: string) => caches.delete(k))))
              .finally(() => window.location.reload());
          } else {
            window.location.reload();
          }
          return;
        }
      } catch {
        window.location.reload();
        return;
      }
    }
    reportError(error.message, error.stack, { componentStack: info.componentStack });
  }

  handleReset = () => {
    try { sessionStorage.removeItem(RELOAD_FLAG); } catch {}
    this.setState({ hasError: false, message: undefined });
  };

  render() {
    if (!this.state.hasError) return this.props.children;
    const stale = isStaleChunkError(this.state.message);
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-background">
        <div className="max-w-md w-full text-center space-y-4">
          <h1 className="text-2xl font-bold">
            {stale ? "Nova versão disponível" : "Ocorreu um erro"}
          </h1>
          <p className="text-sm text-muted-foreground">
            {stale
              ? "Foi publicada uma actualização. Clique em Recarregar para obter a versão mais recente."
              : "O sistema reportou o problema ao administrador. Pode tentar novamente."}
          </p>
          {!stale && this.state.message && (
            <p className="text-xs text-muted-foreground font-mono break-all">{this.state.message}</p>
          )}
          <div className="flex gap-2 justify-center">
            {!stale && (
              <Button onClick={this.handleReset} variant="outline">Tentar novamente</Button>
            )}
            <Button onClick={() => { try { sessionStorage.removeItem(RELOAD_FLAG); } catch {}; window.location.reload(); }}>
              Recarregar
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Suporte: <a href="https://wa.me/258875611599" className="underline">875611599</a>
          </p>
        </div>
      </div>
    );
  }
}
