import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { FileText, Download, Printer } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { format } from "date-fns";
import { type ParcelaAmortizacao } from "@/lib/amortization";
import { loadLetterhead, applyLetterheadAllPages, LETTERHEAD_CONTENT_TOP, LETTERHEAD_CONTENT_BOTTOM } from "@/lib/letterhead";

interface ConfigEmpresa {
  nome_empresa: string;
  endereco: string;
  telefone: string;
  nuit: string;
  logo_url?: string | null;
}

interface ReciboSimuladorProps {
  nomeCliente: string;
  valor: number;
  periodo: number;
  taxaJuros: number;
  tipoJuros: string;
  tabelaParcelas?: ParcelaAmortizacao[];
  sistemaAmortizacao?: string;
  modalidadeReembolso?: string;
  taxaPreparoPercent?: number;
}

export function ReciboSimulador({
  nomeCliente,
  valor,
  periodo,
  taxaJuros,
  tipoJuros,
  tabelaParcelas = [],
  sistemaAmortizacao = "price",
  modalidadeReembolso = "mensal",
  taxaPreparoPercent = 0,
}: ReciboSimuladorProps) {
  const [open, setOpen] = useState(false);
  const [config, setConfig] = useState<ConfigEmpresa | null>(null);

  useEffect(() => {
    if (open) carregarConfig();
  }, [open]);

  const carregarConfig = async () => {
    const { data: { session: __s } } = await supabase.auth.getSession();
    const user = __s?.user;
    if (!user) return;
    const { data } = await supabase
      .from("configuracoes_empresa")
      .select("nome_empresa, endereco, telefone, nuit, logo_url")
      .eq("user_id", user.id)
      .maybeSingle();
    if (data) setConfig(data);
  };

  const formatCurrency = (value: number) => value.toFixed(2) + " MZN";

  const calcularTotais = () => {
    const totalJuros = tabelaParcelas.reduce((s, p) => s + p.juros, 0);
    const totalPrestacoes = tabelaParcelas.reduce((s, p) => s + p.prestacao, 0);
    const taxaPreparo = valor * (taxaPreparoPercent / 100);
    return {
      montante: valor,
      juros: totalJuros,
      valorTotal: totalPrestacoes,
      taxaDesembolso: 0,
      taxaPreparo,
      impostoSelo: 0,
      desembolso: valor - taxaPreparo,
    };
  };

  const modalidadeLabel = () => {
    const map: Record<string, string> = { diaria: "Diária", semanal: "Semanal", quinzenal: "Quinzenal", mensal: "Mensal" };
    return map[modalidadeReembolso] || "Mensal";
  };

  const sistemaLabel = () => {
    if (periodo <= 1 || tipoJuros !== "Composto") return tipoJuros === "Simples" ? "Juros Simples" : "Juros Compostos";
    return sistemaAmortizacao === "price" ? "Sistema Price (Parcelas Fixas)" : "SAC (Parcelas Variáveis)";
  };

  const gerarPDF = async () => {
    const doc = new jsPDF({ compress: true });
    const totais = calcularTotais();
    const lh = await loadLetterhead();

    let y = LETTERHEAD_CONTENT_TOP;

    doc.setFontSize(15);
    doc.setFont("helvetica", "bold");
    doc.text("SIMULAÇÃO DE EMPRÉSTIMO", 105, y, { align: "center" });
    y += 8;

    // Client info box
    doc.setFillColor(240, 240, 240);
    doc.rect(10, y, 190, 16, "F");
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(9);
    doc.setFont("helvetica", "bold");
    doc.text("DADOS DO CLIENTE", 14, y + 5);
    doc.setFont("helvetica", "normal");
    doc.text(`Nome: ${nomeCliente || "NÃO INFORMADO"}`, 14, y + 11);
    doc.text(`Modalidade: ${modalidadeLabel()} | ${sistemaLabel()}`, 110, y + 11);
    y += 20;

    autoTable(doc, {
      startY: y,
      head: [["MONTANTE", "JUROS TOTAL", "VALOR TOTAL", "TAXA PREPARO", "DESEMBOLSO"]],
      body: [[
        formatCurrency(totais.montante),
        formatCurrency(totais.juros),
        formatCurrency(totais.valorTotal),
        formatCurrency(totais.taxaPreparo),
        formatCurrency(totais.desembolso),
      ]],
      theme: "grid",
      headStyles: { fillColor: [91, 79, 191], fontSize: 8, halign: "center" },
      bodyStyles: { fontSize: 9, halign: "center" },
      margin: { top: LETTERHEAD_CONTENT_TOP, bottom: LETTERHEAD_CONTENT_BOTTOM },
    });

    const finalY = (doc as any).lastAutoTable.finalY || 110;
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("TABELA DE AMORTIZAÇÃO", 14, finalY + 8);

    autoTable(doc, {
      startY: finalY + 12,
      head: [["Nº", "VENCIMENTO", "PRESTAÇÃO", "CAPITAL", "JUROS", "SALDO DEVEDOR"]],
      body: tabelaParcelas.map(p => [
        p.numero.toString(),
        new Date(p.dataVencimento).toLocaleDateString("pt-MZ"),
        formatCurrency(p.prestacao),
        formatCurrency(p.amortizacao),
        formatCurrency(p.juros),
        formatCurrency(p.saldoDevedor),
      ]),
      theme: "grid",
      headStyles: { fillColor: [91, 79, 191], fontSize: 7, halign: "center" },
      bodyStyles: { fontSize: 7, halign: "center" },
      columnStyles: { 0: { cellWidth: 15 }, 1: { cellWidth: 30 } },
      margin: { top: LETTERHEAD_CONTENT_TOP, bottom: LETTERHEAD_CONTENT_BOTTOM },
    });

    const finalY2 = (doc as any).lastAutoTable.finalY || 200;
    doc.setFontSize(8);
    doc.setFont("helvetica", "bold");
    doc.text(`Total Prestações: ${formatCurrency(totais.valorTotal)}  |  Total Juros: ${formatCurrency(totais.juros)}`, 14, finalY2 + 5);

    doc.setFont("helvetica", "normal");
    const notes = [
      "• Esta simulação é apenas uma estimativa e não constitui uma oferta de crédito.",
      "• A aprovação do empréstimo está sujeita à análise de crédito.",
      `• Taxa de preparo: ${taxaPreparoPercent}% do valor solicitado`,
      `• Simulação gerada em: ${format(new Date(), "dd/MM/yyyy 'às' HH:mm")}`,
    ];
    let yPos = finalY2 + 11;
    notes.forEach(n => { doc.text(n, 14, yPos); yPos += 4.5; });

    applyLetterheadAllPages(doc, lh);
    doc.save(`Simulacao_${nomeCliente || "Cliente"}_${format(new Date(), "ddMMyyyy")}.pdf`);
  };

  const imprimir = () => {
    const totais = calcularTotais();
    const html = `<html><head><title>Simulação</title><style>
      body{font-family:Arial,sans-serif;margin:0;padding:20px}
      .header{background:#2172E5;color:white;padding:30px;text-align:center}
      .header h1{margin:10px 0;font-size:24px}.header p{margin:5px 0;font-size:12px}
      .section-title{background:#f0f0f0;padding:10px;font-weight:bold;margin-top:20px}
      table{width:100%;border-collapse:collapse;margin-top:10px}
      th,td{border:1px solid #ddd;padding:6px;text-align:center;font-size:10px}
      th{background:#333;color:white}
      .info{padding:10px;font-size:11px}
      .totals{background:#f0f0f0;padding:8px;font-weight:bold;font-size:11px;margin-top:5px}
    </style></head><body>
      <div class="header">
        ${config?.logo_url ? `<img src="${config.logo_url}" style="max-height:60px;margin-bottom:10px" />` : ""}
        <h1>${config?.nome_empresa || "NOME DA EMPRESA"}</h1>
        <p>${config?.endereco || ""}</p>
        <p>Tel: ${config?.telefone || ""} | NUIT: ${config?.nuit || ""}</p>
        <h2 style="margin-top:20px">SIMULAÇÃO DE EMPRÉSTIMO</h2>
      </div>
      <div class="section-title">DADOS DO CLIENTE</div>
      <div class="info">
        <strong>Nome:</strong> ${nomeCliente || "NÃO INFORMADO"} &nbsp;|&nbsp;
        <strong>Modalidade:</strong> ${modalidadeLabel()} &nbsp;|&nbsp;
        <strong>Sistema:</strong> ${sistemaLabel()}
      </div>
      <table><thead><tr>
        <th>MONTANTE</th><th>JUROS TOTAL</th><th>VALOR TOTAL</th><th>TAXA PREPARO</th><th>DESEMBOLSO</th>
      </tr></thead><tbody><tr>
        <td>${formatCurrency(totais.montante)}</td>
        <td>${formatCurrency(totais.juros)}</td>
        <td>${formatCurrency(totais.valorTotal)}</td>
        <td>${formatCurrency(totais.taxaPreparo)}</td>
        <td>${formatCurrency(totais.desembolso)}</td>
      </tr></tbody></table>
      <div class="section-title">TABELA DE AMORTIZAÇÃO</div>
      <table><thead><tr>
        <th>Nº</th><th>VENCIMENTO</th><th>PRESTAÇÃO</th><th>CAPITAL</th><th>JUROS</th><th>SALDO DEVEDOR</th>
      </tr></thead><tbody>
        ${tabelaParcelas.map(p => `<tr>
          <td>${p.numero}</td>
          <td>${new Date(p.dataVencimento).toLocaleDateString("pt-MZ")}</td>
          <td>${formatCurrency(p.prestacao)}</td>
          <td>${formatCurrency(p.amortizacao)}</td>
          <td>${formatCurrency(p.juros)}</td>
          <td>${formatCurrency(p.saldoDevedor)}</td>
        </tr>`).join("")}
      </tbody></table>
      <div class="totals">Total: ${formatCurrency(totais.valorTotal)} | Juros: ${formatCurrency(totais.juros)}</div>
      <div class="section-title">Observações</div>
      <div style="padding:10px;font-size:10px;line-height:1.6">
        <p>• Esta simulação é apenas uma estimativa.</p>
        <p>• Taxa de preparo: ${taxaPreparoPercent}% do valor solicitado</p>
        <p>• Gerado em: ${format(new Date(), "dd/MM/yyyy 'às' HH:mm")}</p>
        <p>• LimSist 2.0</p>
      </div>
    </body></html>`;
    const w = window.open("", "_blank");
    if (w) { w.document.write(html); w.document.close(); w.focus(); setTimeout(() => w.print(), 250); }
  };

  if (tabelaParcelas.length === 0) return null;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <FileText className="mr-2 h-4 w-4" />
          Ver Recibo
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <span>Recibo de Simulação</span>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={gerarPDF}>
                <Download className="h-4 w-4 sm:mr-2" />
                <span className="hidden sm:inline">Descarregar PDF</span>
              </Button>
              <Button variant="outline" size="sm" onClick={imprimir}>
                <Printer className="h-4 w-4 sm:mr-2" />
                <span className="hidden sm:inline">Imprimir</span>
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Header */}
          <div className="bg-primary text-primary-foreground p-6 rounded-lg text-center">
            {config?.logo_url && (
              <img src={config.logo_url} alt="Logo" className="h-14 w-14 object-contain mx-auto mb-2 bg-white rounded p-1" />
            )}
            <h2 className="text-2xl font-bold mb-2">{config?.nome_empresa || "NOME DA EMPRESA"}</h2>
            <p className="text-sm opacity-90">{config?.endereco || ""}</p>
            <p className="text-sm opacity-90">Tel: {config?.telefone || ""} | NUIT: {config?.nuit || ""}</p>
            <h3 className="text-xl font-bold mt-4">SIMULAÇÃO DE EMPRÉSTIMO</h3>
          </div>

          {/* Client */}
          <div className="border rounded-lg">
            <div className="bg-muted p-3 font-bold">DADOS DO CLIENTE</div>
            <div className="p-4 flex flex-wrap gap-4 text-sm">
              <div><span className="font-semibold">Nome:</span> {nomeCliente || "NÃO INFORMADO"}</div>
              <div><span className="font-semibold">Modalidade:</span> {modalidadeLabel()}</div>
              <div><span className="font-semibold">Sistema:</span> {sistemaLabel()}</div>
            </div>
          </div>

          {/* Financial Summary */}
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border text-xs sm:text-sm">
              <thead>
                <tr className="bg-primary text-primary-foreground">
                  <th className="border p-1 sm:p-2 text-[10px] sm:text-xs">MONTANTE</th>
                  <th className="border p-1 sm:p-2 text-[10px] sm:text-xs">JUROS TOTAL</th>
                  <th className="border p-1 sm:p-2 text-[10px] sm:text-xs">VALOR TOTAL</th>
                  <th className="border p-1 sm:p-2 text-[10px] sm:text-xs">TAXA PREP.</th>
                  <th className="border p-1 sm:p-2 text-[10px] sm:text-xs">DESEMBOLSO</th>
                </tr>
              </thead>
              <tbody>
                <tr className="text-center">
                  <td className="border p-1 sm:p-2">{formatCurrency(calcularTotais().montante)}</td>
                  <td className="border p-1 sm:p-2">{formatCurrency(calcularTotais().juros)}</td>
                  <td className="border p-1 sm:p-2">{formatCurrency(calcularTotais().valorTotal)}</td>
                  <td className="border p-1 sm:p-2">{formatCurrency(calcularTotais().taxaPreparo)}</td>
                  <td className="border p-1 sm:p-2">{formatCurrency(calcularTotais().desembolso)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Amortization Table */}
          <div>
            <div className="bg-muted p-3 font-bold">TABELA DE AMORTIZAÇÃO</div>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border text-xs sm:text-sm">
                <thead>
                  <tr className="bg-primary text-primary-foreground">
                    <th className="border p-1 sm:p-2 text-[10px] sm:text-xs">Nº</th>
                    <th className="border p-1 sm:p-2 text-[10px] sm:text-xs">VENCIMENTO</th>
                    <th className="border p-1 sm:p-2 text-[10px] sm:text-xs">PRESTAÇÃO</th>
                    <th className="border p-1 sm:p-2 text-[10px] sm:text-xs">CAPITAL</th>
                    <th className="border p-1 sm:p-2 text-[10px] sm:text-xs">JUROS</th>
                    <th className="border p-1 sm:p-2 text-[10px] sm:text-xs">SALDO DEVEDOR</th>
                  </tr>
                </thead>
                <tbody>
                  {tabelaParcelas.map((p) => (
                    <tr key={p.numero} className="text-center">
                      <td className="border p-1 sm:p-2">{p.numero}</td>
                      <td className="border p-1 sm:p-2">{new Date(p.dataVencimento).toLocaleDateString("pt-MZ")}</td>
                      <td className="border p-1 sm:p-2">{formatCurrency(p.prestacao)}</td>
                      <td className="border p-1 sm:p-2">{formatCurrency(p.amortizacao)}</td>
                      <td className="border p-1 sm:p-2">{formatCurrency(p.juros)}</td>
                      <td className="border p-1 sm:p-2">{formatCurrency(p.saldoDevedor)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-2 p-2 bg-muted rounded text-xs flex justify-between font-semibold">
              <span>Total: {formatCurrency(calcularTotais().valorTotal)}</span>
              <span>Juros: {formatCurrency(calcularTotais().juros)}</span>
            </div>
          </div>

          {/* Notes */}
          <div className="border rounded-lg">
            <div className="bg-muted p-3 font-bold">Observações</div>
            <div className="p-4 space-y-1 text-xs sm:text-sm">
              <p>• Esta simulação é apenas uma estimativa e não constitui uma oferta de crédito.</p>
              <p>• Taxa de preparo: {taxaPreparoPercent}% do valor solicitado</p>
              <p>• Simulação gerada em: {format(new Date(), "dd/MM/yyyy 'às' HH:mm")}</p>
              <p>• Gerado por Sistema de Gestão para Microcrédito - LimSist 2.0</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
