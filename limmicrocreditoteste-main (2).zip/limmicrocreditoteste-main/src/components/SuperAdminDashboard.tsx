import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Users,
  UserCheck,
  UserX,
  Wifi,
  DollarSign,
  CreditCard,
  AlertTriangle,
  TrendingUp,
  Shield,
  Briefcase,
} from "lucide-react";
import { useSuperAdminData } from "@/hooks/useSuperAdminData";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from "recharts";

export function SuperAdminDashboard() {
  const { stats, monthlyData, loading } = useSuperAdminData();

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("pt-MZ", {
      style: "currency",
      currency: "MZN",
      minimumFractionDigits: 0,
    }).format(value);

  const cardStats = [
    { title: "Total Utilizadores", value: stats.totalUsuarios, icon: Users, color: "text-primary" },
    { title: "Utilizadores Ativos", value: stats.usuariosAtivos, icon: UserCheck, color: "text-green-600" },
    { title: "Utilizadores Inativos", value: stats.usuariosInativos, icon: UserX, color: "text-destructive" },
    { title: "Online Agora", value: stats.usuariosOnline, icon: Wifi, color: "text-emerald-500" },
    { title: "Total Agentes", value: stats.totalAgentes, icon: Shield, color: "text-blue-600" },
    { title: "Total Secretariado", value: stats.totalSecretariado, icon: Briefcase, color: "text-violet-600" },
  ];

  const financeStats = [
    { title: "Total Emprestado (Global)", value: formatCurrency(stats.totalEmprestadoGlobal), icon: DollarSign },
    { title: "Total A Receber (Global)", value: formatCurrency(stats.totalAReceberGlobal), icon: TrendingUp },
    { title: "Total Recebido (Global)", value: formatCurrency(stats.totalRecebidoGlobal), icon: CreditCard },
    { title: "Empréstimos Ativos", value: stats.emprestimosAtivosGlobal.toString(), icon: CreditCard },
    { title: "Empréstimos Pagos", value: stats.emprestimosPagosGlobal.toString(), icon: UserCheck },
    { title: "Empréstimos Vencidos", value: stats.emprestimosVencidosGlobal.toString(), icon: AlertTriangle },
    { title: "Total Clientes (Global)", value: stats.totalClientesGlobal.toString(), icon: Users },
    { title: "Taxa Inadimplência (Global)", value: `${stats.taxaInadimplenciaGlobal}%`, icon: AlertTriangle },
  ];

  const tooltipFormatter = (value: number) => formatCurrency(value);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-foreground mb-3">Utilizadores da Plataforma</h2>
        <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
          {cardStats.map((s) => {
            const Icon = s.icon;
            return (
              <Card key={s.title} className="hover:shadow-md transition-shadow">
                <CardContent className="pt-4 pb-3 px-4">
                  {loading ? (
                    <Skeleton className="h-10 w-full" />
                  ) : (
                    <div className="flex items-center gap-3">
                      <Icon className={`h-8 w-8 ${s.color} flex-shrink-0`} />
                      <div>
                        <p className="text-2xl font-bold text-foreground">{s.value}</p>
                        <p className="text-xs text-muted-foreground leading-tight">{s.title}</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      <div>
        <h2 className="text-lg font-semibold text-foreground mb-3">Visão Financeira Global</h2>
        <div className="grid gap-4 grid-cols-2 md:grid-cols-4">
          {financeStats.map((s) => {
            const Icon = s.icon;
            return (
              <Card key={s.title} className="hover:shadow-md transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
                  <CardTitle className="text-xs font-medium text-muted-foreground">{s.title}</CardTitle>
                  <Icon className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent className="px-4 pb-4">
                  {loading ? (
                    <Skeleton className="h-7 w-24" />
                  ) : (
                    <div className="text-xl font-bold text-foreground">{s.value}</div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      <div>
        <h2 className="text-lg font-semibold text-foreground mb-3">Volume Mensal de Empréstimos e Recebimentos</h2>
        <Card>
          <CardContent className="pt-6 pb-4">
            {loading ? (
              <Skeleton className="h-[300px] w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={monthlyData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                  <YAxis tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                  <Tooltip formatter={tooltipFormatter} labelStyle={{ color: 'hsl(var(--foreground))' }} contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }} />
                  <Legend />
                  <Bar dataKey="emprestimos" name="Empréstimos" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="recebimentos" name="Recebimentos" fill="hsl(142, 76%, 36%)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}