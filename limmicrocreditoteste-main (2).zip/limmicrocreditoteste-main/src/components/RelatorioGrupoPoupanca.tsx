import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Download, FileSpreadsheet } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import { formatDatePT } from "@/lib/excelExport";
import { loadLetterhead, applyLetterheadAllPages, LETTERHEAD_CONTENT_TOP, LETTERHEAD_CONTENT_BOTTOM } from "@/lib/letterhead";

interface RelatorioGrupoPoupancaProps {
  grupo: any;
  membros: any[];
}

export function RelatorioGrupoPoupanca({ grupo, membros }: RelatorioGrupoPoupancaProps) {
  const calcularTotalGeral = (membro: any) => {
    const divida = membro.divida || 0;
    const producao = divida === 0 ? (membro.producao || 0) : 0;
    
    return (membro.valor_poupado || 0) + 
           (membro.valor_pago || 0) - 
           divida + 
           producao +
           (membro.bonus || 0) + 
           (membro.outros1 || 0) + 
           (membro.outros2 || 0);
  };

  const formatNumber = (value: number) => {
    return value.toLocaleString("pt-PT", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const getMembrosData = () => {
    return membros.map(m => {
      const divida = m.divida || 0;
      const producao = divida === 0 ? (m.producao || 0) : 0;
      
      return {
        nome: m.nome,
        poupado: m.valor_poupado || 0,
        emprestimo: m.valor_emprestimo || 0,
        pago: m.valor_pago || 0,
        divida,
        producao,
        bonus: m.bonus || 0,
        outros1: m.outros1 || 0,
        outros2: m.outros2 || 0,
        totalGeral: calcularTotalGeral(m)
      };
    });
  };

  const getTotais = () => {
    const totalPoupado = membros.reduce((sum, m) => sum + (m.valor_poupado || 0), 0);
    const totalEmprestado = membros.reduce((sum, m) => sum + (m.valor_emprestimo || 0), 0);
    const totalPago = membros.reduce((sum, m) => sum + (m.valor_pago || 0), 0);
    const totalDivida = membros.reduce((sum, m) => sum + (m.divida || 0), 0);
    const totalProducao = membros.reduce((sum, m) => {
      const divida = m.divida || 0;
      return sum + (divida === 0 ? (m.producao || 0) : 0);
    }, 0);
    const totalBonus = membros.reduce((sum, m) => sum + (m.bonus || 0), 0);
    const totalOutros1 = membros.reduce((sum, m) => sum + (m.outros1 || 0), 0);
    const totalOutros2 = membros.reduce((sum, m) => sum + (m.outros2 || 0), 0);
    const totalGeral = membros.reduce((sum, m) => sum + calcularTotalGeral(m), 0);

    return {
      totalPoupado,
      totalEmprestado,
      totalPago,
      totalDivida,
      totalProducao,
      totalBonus,
      totalOutros1,
      totalOutros2,
      totalGeral
    };
  };

  const gerarPDF = async () => {
    try {
      const lh = await loadLetterhead();

      const doc = new jsPDF({ compress: true });
      const pageWidth = doc.internal.pageSize.getWidth();
      let y = LETTERHEAD_CONTENT_TOP;

      doc.setFontSize(15);
      doc.setFont("helvetica", "bold");
      doc.text("RELATÓRIO DE GRUPO DE POUPANÇA", pageWidth / 2, y, { align: "center" });
      y += 7;
      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      doc.text(`Data: ${formatDatePT(new Date())}`, pageWidth / 2, y, { align: "center" });
      y += 8;

      doc.setFontSize(11);
      doc.setFont("helvetica", "bold");
      doc.text("INFORMAÇÕES DO GRUPO", 14, y);
      y += 5;

      autoTable(doc, {
        startY: y,
        body: [
          ["Nome do Grupo:", grupo.nome],
          ["Local:", grupo.local || "N/A"],
          ["Presidente:", grupo.presidente || "N/A"],
          ["Secretário:", grupo.secretario || "N/A"],
        ],
        theme: "grid",
        styles: { fontSize: 9, cellPadding: 2 },
        columnStyles: { 0: { fontStyle: "bold", cellWidth: 40 }, 1: { cellWidth: 120 } },
        margin: { top: LETTERHEAD_CONTENT_TOP, bottom: LETTERHEAD_CONTENT_BOTTOM },
      });

      y = (doc as any).lastAutoTable.finalY + 8;
      doc.setFontSize(11);
      doc.setFont("helvetica", "bold");
      doc.text("DETALHES DOS MEMBROS", 14, y);
      y += 5;

      const membrosData = getMembrosData().map(m => [
        m.nome, formatNumber(m.poupado), formatNumber(m.emprestimo), formatNumber(m.pago),
        formatNumber(m.divida), formatNumber(m.producao), formatNumber(m.bonus),
        formatNumber(m.outros1), formatNumber(m.outros2), formatNumber(m.totalGeral)
      ]);

      autoTable(doc, {
        startY: y,
        head: [["Nome", "Poupado", "Empréstimo", "Pago", "Dívida", "Prod.(50%)", "Bônus", "Outros 1", "Outros 2", "Total Geral"]],
        body: membrosData,
        theme: "grid",
        styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [91, 79, 191], fontStyle: "bold" },
        columnStyles: {
          0: { cellWidth: 30 },
          1: { halign: "right", cellWidth: 16 }, 2: { halign: "right", cellWidth: 16 },
          3: { halign: "right", cellWidth: 16 }, 4: { halign: "right", cellWidth: 16 },
          5: { halign: "right", cellWidth: 16 }, 6: { halign: "right", cellWidth: 16 },
          7: { halign: "right", cellWidth: 16 }, 8: { halign: "right", cellWidth: 16 },
          9: { halign: "right", cellWidth: 18 }
        },
        margin: { top: LETTERHEAD_CONTENT_TOP, bottom: LETTERHEAD_CONTENT_BOTTOM },
      });

      y = (doc as any).lastAutoTable.finalY + 4;
      const totais = getTotais();
      autoTable(doc, {
        startY: y,
        body: [[
          "TOTAIS",
          formatNumber(totais.totalPoupado), formatNumber(totais.totalEmprestado),
          formatNumber(totais.totalPago), formatNumber(totais.totalDivida),
          formatNumber(totais.totalProducao), formatNumber(totais.totalBonus),
          formatNumber(totais.totalOutros1), formatNumber(totais.totalOutros2),
          formatNumber(totais.totalGeral)
        ]],
        theme: "grid",
        styles: { fontSize: 8, cellPadding: 2, fontStyle: "bold" },
        bodyStyles: { fillColor: [220, 220, 220] },
        columnStyles: {
          0: { cellWidth: 30 },
          1: { halign: "right", cellWidth: 16 }, 2: { halign: "right", cellWidth: 16 },
          3: { halign: "right", cellWidth: 16 }, 4: { halign: "right", cellWidth: 16 },
          5: { halign: "right", cellWidth: 16 }, 6: { halign: "right", cellWidth: 16 },
          7: { halign: "right", cellWidth: 16 }, 8: { halign: "right", cellWidth: 16 },
          9: { halign: "right", cellWidth: 18 }
        },
        margin: { top: LETTERHEAD_CONTENT_TOP, bottom: LETTERHEAD_CONTENT_BOTTOM },
      });

      applyLetterheadAllPages(doc, lh);
      doc.save(`Relatorio_Grupo_${grupo.nome}_${new Date().toISOString().split('T')[0]}.pdf`);
      toast.success("Relatório gerado com sucesso!");
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
      toast.error("Erro ao gerar relatório");
    }
  };

  const gerarExcel = async () => {
    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) return;

      const { data: config } = await supabase
        .from("configuracoes_empresa")
        .select("*")
        .eq("user_id", user.id)
        .single();

      const wb = XLSX.utils.book_new();
      const allData: (string | number)[][] = [];
      const merges: XLSX.Range[] = [];
      let currentRow = 0;

      // Cabeçalho da empresa
      if (config?.nome_empresa) {
        allData.push([config.nome_empresa]);
        merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: 9 } });
        currentRow++;
      }
      if (config?.endereco) {
        allData.push([config.endereco]);
        merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: 9 } });
        currentRow++;
      }
      if (config?.telefone || config?.email) {
        allData.push([`Tel: ${config?.telefone || ''} | Email: ${config?.email || ''}`]);
        merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: 9 } });
        currentRow++;
      }
      
      allData.push([]);
      currentRow++;

      // Título
      allData.push(["RELATÓRIO DE GRUPO DE POUPANÇA"]);
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: 9 } });
      currentRow++;

      allData.push([`Data: ${formatDatePT(new Date())}`]);
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: 9 } });
      currentRow++;

      allData.push([]);
      currentRow++;

      // Informações do Grupo
      allData.push(["INFORMAÇÕES DO GRUPO"]);
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: 9 } });
      currentRow++;

      allData.push([]);
      currentRow++;

      allData.push(["Nome do Grupo:", grupo.nome]);
      currentRow++;
      allData.push(["Local:", grupo.local || "N/A"]);
      currentRow++;
      allData.push(["Presidente:", grupo.presidente || "N/A"]);
      currentRow++;
      allData.push(["Secretário:", grupo.secretario || "N/A"]);
      currentRow++;

      allData.push([]);
      currentRow++;

      // Título da tabela de membros
      allData.push(["DETALHES DOS MEMBROS"]);
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: 9 } });
      currentRow++;

      allData.push([]);
      currentRow++;

      // Cabeçalho da tabela
      allData.push([
        "Nome",
        "Poupado",
        "Empréstimo",
        "Pago",
        "Dívida",
        "Prod.(50%)",
        "Bônus",
        "Outros 1",
        "Outros 2",
        "Total Geral"
      ]);
      currentRow++;

      // Dados dos membros
      const membrosData = getMembrosData();
      membrosData.forEach(m => {
        allData.push([
          m.nome,
          formatNumber(m.poupado),
          formatNumber(m.emprestimo),
          formatNumber(m.pago),
          formatNumber(m.divida),
          formatNumber(m.producao),
          formatNumber(m.bonus),
          formatNumber(m.outros1),
          formatNumber(m.outros2),
          formatNumber(m.totalGeral)
        ]);
        currentRow++;
      });

      // Totais
      const totais = getTotais();
      allData.push([
        "TOTAIS",
        formatNumber(totais.totalPoupado),
        formatNumber(totais.totalEmprestado),
        formatNumber(totais.totalPago),
        formatNumber(totais.totalDivida),
        formatNumber(totais.totalProducao),
        formatNumber(totais.totalBonus),
        formatNumber(totais.totalOutros1),
        formatNumber(totais.totalOutros2),
        formatNumber(totais.totalGeral)
      ]);
      currentRow++;

      allData.push([]);
      currentRow++;

      // Rodapé
      allData.push([`Relatório gerado em: ${new Date().toLocaleString('pt-PT')}`]);
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: 9 } });
      currentRow++;

      allData.push(["Sistema: Sistema de Gestão de Microcrédito - LimSist 2.0"]);
      merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: 9 } });

      const ws = XLSX.utils.aoa_to_sheet(allData);
      ws['!merges'] = merges;
      ws['!cols'] = [
        { wch: 25 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 12 },
        { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 14 }
      ];

      XLSX.utils.book_append_sheet(wb, ws, grupo.nome.substring(0, 31));
      XLSX.writeFile(wb, `Relatorio_Grupo_${grupo.nome}_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success("Excel gerado com sucesso!");
    } catch (error) {
      console.error("Erro ao gerar Excel:", error);
      toast.error("Erro ao gerar Excel");
    }
  };

  return (
    <div className="flex gap-2">
      <Button onClick={gerarExcel} variant="outline">
        <FileSpreadsheet className="mr-2 h-4 w-4" />
        Excel
      </Button>
      <Button onClick={gerarPDF} variant="outline">
        <Download className="mr-2 h-4 w-4" />
        PDF
      </Button>
    </div>
  );
}
