import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { AlertTriangle, RefreshCw, ChevronLeft, ChevronRight } from "lucide-react";
import { toast } from "sonner";

interface ItemMora {
  emprestimo_id: string;
  cliente_id: string;
  nome_completo: string;
  telefone: string;
  prestacoes_vencidas: number;
  juros_acumulados: number;
  saldo_devedor: number;
  total_atualizado: number;
}

const PAGE_SIZE = 20;

export function RelatorioMora() {
  const [loading, setLoading] = useState(false);
  const [itens, setItens] = useState<ItemMora[]>([]);
  const [totals, setTotals] = useState({ clientes: 0, juros: 0, prestacoes: 0 });
  const [busca, setBusca] = useState("");
  const [page, setPage] = useState(1);

  const carregar = async () => {
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return;
      const { data, error } = await (supabase as any).rpc("relatorio_mora_user", {
        p_scope_user_id: session.user.id,
      });
      if (error) throw error;
      setItens((data?.itens as ItemMora[]) || []);
      setTotals({
        clientes: data?.total_clientes_em_mora || 0,
        juros: data?.total_juros_acumulados || 0,
        prestacoes: data?.total_prestacoes_vencidas || 0,
      });
      setPage(1);
    } catch (e: any) {
      toast.error("Erro ao carregar relatório de mora: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { carregar(); }, []);

  const fmt = (n: number) => Number(n || 0).toLocaleString("pt-MZ", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  const filtrados = useMemo(() => {
    const q = busca.trim().toLowerCase();
    if (!q) return itens;
    return itens.filter(i =>
      i.nome_completo?.toLowerCase().includes(q) ||
      i.telefone?.toLowerCase().includes(q)
    );
  }, [itens, busca]);

  const totalPages = Math.max(1, Math.ceil(filtrados.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const visiveis = useMemo(
    () => filtrados.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE),
    [filtrados, currentPage]
  );

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-destructive" />
          Relatório de Mora
        </CardTitle>
        <Button size="sm" variant="outline" onClick={carregar} disabled={loading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
          Atualizar
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <div className="border rounded-lg p-3">
            <p className="text-xs text-muted-foreground">Clientes em mora</p>
            <p className="text-2xl font-bold">{totals.clientes}</p>
          </div>
          <div className="border rounded-lg p-3">
            <p className="text-xs text-muted-foreground">Prestações vencidas</p>
            <p className="text-2xl font-bold">{totals.prestacoes}</p>
          </div>
          <div className="border rounded-lg p-3">
            <p className="text-xs text-muted-foreground">Juros acumulados (MT)</p>
            <p className="text-2xl font-bold">{fmt(totals.juros)}</p>
          </div>
        </div>

        <Input
          placeholder="Pesquisar por nome ou telefone..."
          value={busca}
          onChange={(e) => { setBusca(e.target.value); setPage(1); }}
          className="max-w-md"
        />

        {filtrados.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">
            {itens.length === 0 ? "Nenhum cliente em mora. 🎉" : "Sem resultados para a pesquisa."}
          </p>
        ) : (
          <>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Telefone</TableHead>
                    <TableHead className="text-right">Prest. vencidas</TableHead>
                    <TableHead className="text-right">Saldo (MT)</TableHead>
                    <TableHead className="text-right">Juros (MT)</TableHead>
                    <TableHead className="text-right">Total (MT)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {visiveis.map((i) => (
                    <TableRow key={i.emprestimo_id}>
                      <TableCell className="font-medium">{i.nome_completo}</TableCell>
                      <TableCell>{i.telefone}</TableCell>
                      <TableCell className="text-right">{i.prestacoes_vencidas}</TableCell>
                      <TableCell className="text-right">{fmt(i.saldo_devedor)}</TableCell>
                      <TableCell className="text-right text-destructive">{fmt(i.juros_acumulados)}</TableCell>
                      <TableCell className="text-right font-bold">{fmt(i.total_atualizado)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">
                A mostrar {(currentPage - 1) * PAGE_SIZE + 1}–
                {Math.min(currentPage * PAGE_SIZE, filtrados.length)} de {filtrados.length}
              </span>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage <= 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span>Página {currentPage} / {totalPages}</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage >= totalPages}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
