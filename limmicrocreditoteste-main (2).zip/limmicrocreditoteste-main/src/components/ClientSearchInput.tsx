import { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

interface Cliente {
  id: string;
  nome_completo: string;
}

interface ClientSearchInputProps {
  clientes: Cliente[];
  value: string;
  onSelect: (clienteId: string) => void;
  placeholder?: string;
  disabled?: boolean;
}

export function ClientSearchInput({ clientes, value, onSelect, placeholder = "Digite 3 letras para procurar cliente...", disabled }: ClientSearchInputProps) {
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const selectedCliente = clientes.find(c => c.id === value);

  useEffect(() => {
    if (selectedCliente && !search) {
      setSearch(selectedCliente.nome_completo);
    }
  }, [value, selectedCliente]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const filtered = search.length >= 3
    ? clientes.filter(c => c.nome_completo.toLowerCase().includes(search.toLowerCase())).slice(0, 10)
    : [];

  return (
    <div ref={ref} className="relative">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setOpen(true);
            if (e.target.value.length < 3 && value) {
              onSelect("");
            }
          }}
          onFocus={() => search.length >= 3 && setOpen(true)}
          placeholder={placeholder}
          className="pl-10"
          disabled={disabled}
        />
      </div>
      {open && filtered.length > 0 && (
        <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-lg max-h-48 overflow-y-auto">
          {filtered.map(c => (
            <button
              key={c.id}
              type="button"
              className="w-full text-left px-3 py-2 hover:bg-accent text-sm transition-colors"
              onClick={() => {
                onSelect(c.id);
                setSearch(c.nome_completo);
                setOpen(false);
              }}
            >
              {c.nome_completo}
            </button>
          ))}
        </div>
      )}
      {open && search.length >= 3 && filtered.length === 0 && (
        <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-lg p-3 text-sm text-muted-foreground">
          Nenhum cliente encontrado
        </div>
      )}
    </div>
  );
}
