import { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { BookOpen, Download, TrendingUp, TrendingDown } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { loadLetterhead, applyLetterheadAllPages, LETTERHEAD_CONTENT_TOP, LETTERHEAD_CONTENT_BOTTOM } from "@/lib/letterhead";

const fmt = (v: number) => new Intl.NumberFormat("pt-MZ", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v || 0);
const fmtDate = (d?: string | null) => d ? new Date(d).toLocaleDateString("pt-PT") : "-";

interface Movimento {
  data: string;
  conta: string;
  descricao: string;
  debito: number;
  credito: number;
}

export function RelatorioContabilidade() {
  const hoje = new Date();
  const primeiroDia = new Date(hoje.getFullYear(), hoje.getMonth(), 1).toISOString().slice(0, 10);
  const ultimoDia = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0).toISOString().slice(0, 10);
  const [dataInicio, setDataInicio] = useState(primeiroDia);
  const [dataFim, setDataFim] = useState(ultimoDia);
  const [loading, setLoading] = useState(false);
  const [movimentos, setMovimentos] = useState<Movimento[]>([]);

  const carregar = async () => {
    setLoading(true);
    try {
      const [pag, desp, emp, inv, ganhos] = await Promise.all([
        supabase.from("pagamentos").select("data_pagamento, valor, tipo, cliente_nome, emprestimo_id").gte("data_pagamento", dataInicio).lte("data_pagamento", dataFim),
        supabase.from("despesas").select("data, valor, descricao, categoria").gte("data", dataInicio).lte("data", dataFim),
        supabase.from("emprestimos").select("data_emprestimo, valor, valor_total, cliente_nome, status").gte("data_emprestimo", dataInicio).lte("data_emprestimo", dataFim),
        supabase.from("poupancas_investimento").select("data_inicio, valor_capital, cliente_nome").gte("data_inicio", dataInicio).lte("data_inicio", dataFim),
        supabase.from("poupanca_investimento_ganhos").select("data_pagamento, valor_ganho, pago, poupancas_investimento(cliente_nome)").eq("pago", true).gte("data_pagamento", dataInicio).lte("data_pagamento", dataFim),
      ]);

      const mv: Movimento[] = [];

      (pag.data || []).forEach((p: any) => {
        const t = (p.tipo || "").toLowerCase();
        if (t.includes("juros")) {
          mv.push({ data: p.data_pagamento, conta: "Receitas - Juros de Empréstimos", descricao: `Juros ${p.cliente_nome || ""}`, debito: 0, credito: Number(p.valor) || 0 });
          mv.push({ data: p.data_pagamento, conta: "Caixa / Bancos", descricao: `Recebimento juros ${p.cliente_nome || ""}`, debito: Number(p.valor) || 0, credito: 0 });
        } else {
          // Parcela: capital de volta
          mv.push({ data: p.data_pagamento, conta: "Empréstimos a Receber", descricao: `Amortização ${p.cliente_nome || ""}`, debito: 0, credito: Number(p.valor) || 0 });
          mv.push({ data: p.data_pagamento, conta: "Caixa / Bancos", descricao: `Recebimento parcela ${p.cliente_nome || ""}`, debito: Number(p.valor) || 0, credito: 0 });
        }
      });

      (desp.data || []).forEach((d: any) => {
        mv.push({ data: d.data, conta: `Despesas - ${d.categoria || "Geral"}`, descricao: d.descricao || "-", debito: Number(d.valor) || 0, credito: 0 });
        mv.push({ data: d.data, conta: "Caixa / Bancos", descricao: `Pagamento despesa`, debito: 0, credito: Number(d.valor) || 0 });
      });

      (emp.data || []).forEach((e: any) => {
        mv.push({ data: e.data_emprestimo, conta: "Empréstimos a Receber", descricao: `Concessão ${e.cliente_nome || ""}`, debito: Number(e.valor) || 0, credito: 0 });
        mv.push({ data: e.data_emprestimo, conta: "Caixa / Bancos", descricao: `Desembolso ${e.cliente_nome || ""}`, debito: 0, credito: Number(e.valor) || 0 });
      });

      (inv.data || []).forEach((i: any) => {
        mv.push({ data: i.data_inicio, conta: "Caixa / Bancos", descricao: `Depósito investidor ${i.cliente_nome}`, debito: Number(i.valor_capital) || 0, credito: 0 });
        mv.push({ data: i.data_inicio, conta: "Poupanças Investimento (Passivo)", descricao: `Capital de ${i.cliente_nome}`, debito: 0, credito: Number(i.valor_capital) || 0 });
      });

      (ganhos.data || []).forEach((g: any) => {
        mv.push({ data: g.data_pagamento, conta: "Custos - Rendimentos Investidores", descricao: `Ganho pago ${g.poupancas_investimento?.cliente_nome || ""}`, debito: Number(g.valor_ganho) || 0, credito: 0 });
        mv.push({ data: g.data_pagamento, conta: "Caixa / Bancos", descricao: `Pagamento ganho investidor`, debito: 0, credito: Number(g.valor_ganho) || 0 });
      });

      mv.sort((a, b) => (a.data || "").localeCompare(b.data || ""));
      setMovimentos(mv);
    } catch (e: any) {
      toast.error("Erro ao carregar dados contábeis");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { carregar(); }, []);

  const contas = useMemo(() => {
    const map: Record<string, { debito: number; credito: number; movs: Movimento[] }> = {};
    movimentos.forEach(m => {
      if (!map[m.conta]) map[m.conta] = { debito: 0, credito: 0, movs: [] };
      map[m.conta].debito += m.debito;
      map[m.conta].credito += m.credito;
      map[m.conta].movs.push(m);
    });
    return map;
  }, [movimentos]);

  const balancete = useMemo(() => {
    return Object.entries(contas).map(([conta, v]) => ({
      conta, debito: v.debito, credito: v.credito, saldo: v.debito - v.credito
    })).sort((a, b) => a.conta.localeCompare(b.conta));
  }, [contas]);

  const dr = useMemo(() => {
    let receitas = 0, custos = 0;
    const detalheR: { nome: string; valor: number }[] = [];
    const detalheC: { nome: string; valor: number }[] = [];
    Object.entries(contas).forEach(([nome, v]) => {
      if (nome.startsWith("Receitas")) {
        const val = v.credito - v.debito;
        receitas += val; detalheR.push({ nome, valor: val });
      } else if (nome.startsWith("Custos") || nome.startsWith("Despesas")) {
        const val = v.debito - v.credito;
        custos += val; detalheC.push({ nome, valor: val });
      }
    });
    return { receitas, custos, resultado: receitas - custos, detalheR, detalheC };
  }, [contas]);

  const exportarPDF = async () => {
    const lh = await loadLetterhead();
    const doc = new jsPDF({ compress: true });
    const pageW = doc.internal.pageSize.getWidth();
    let y = LETTERHEAD_CONTENT_TOP;

    doc.setFont("helvetica", "bold"); doc.setFontSize(15);
    doc.text("RELATÓRIO CONTABILÍSTICO", pageW / 2, y, { align: "center" });
    y += 6;
    doc.setFont("helvetica", "normal"); doc.setFontSize(10);
    doc.text(`Período: ${fmtDate(dataInicio)} a ${fmtDate(dataFim)}`, pageW / 2, y, { align: "center" });
    y += 8;

    // Balancete
    doc.setFont("helvetica", "bold"); doc.setFontSize(12);
    doc.text("BALANCETE", 14, y); y += 4;
    autoTable(doc, {
      startY: y,
      head: [["Conta", "Débito", "Crédito", "Saldo"]],
      body: balancete.map(b => [b.conta, fmt(b.debito), fmt(b.credito), fmt(b.saldo)]),
      foot: [["TOTAIS", fmt(balancete.reduce((s, b) => s + b.debito, 0)), fmt(balancete.reduce((s, b) => s + b.credito, 0)), ""]],
      styles: { fontSize: 9 },
      headStyles: { fillColor: [91, 79, 191] },
      footStyles: { fillColor: [230, 230, 240], textColor: 0, fontStyle: "bold" },
      margin: { bottom: LETTERHEAD_CONTENT_BOTTOM },
    });

    // DR
    doc.addPage(); y = LETTERHEAD_CONTENT_TOP;
    doc.setFont("helvetica", "bold"); doc.setFontSize(12);
    doc.text("DEMONSTRAÇÃO DE RESULTADOS", 14, y); y += 4;
    autoTable(doc, {
      startY: y,
      body: [
        [{ content: "RECEITAS", styles: { fontStyle: "bold", fillColor: [230, 245, 230] } }, ""],
        ...dr.detalheR.map(d => [d.nome, fmt(d.valor)]),
        [{ content: "Total Receitas", styles: { fontStyle: "bold" } }, { content: fmt(dr.receitas), styles: { fontStyle: "bold" } }],
        [{ content: "CUSTOS E DESPESAS", styles: { fontStyle: "bold", fillColor: [250, 230, 230] } }, ""],
        ...dr.detalheC.map(d => [d.nome, fmt(d.valor)]),
        [{ content: "Total Custos", styles: { fontStyle: "bold" } }, { content: fmt(dr.custos), styles: { fontStyle: "bold" } }],
        [{ content: "RESULTADO LÍQUIDO", styles: { fontStyle: "bold", fillColor: [220, 230, 250] } }, { content: fmt(dr.resultado), styles: { fontStyle: "bold" } }],
      ],
      styles: { fontSize: 10 },
      margin: { bottom: LETTERHEAD_CONTENT_BOTTOM },
    });

    // Razões
    for (const [conta, v] of Object.entries(contas)) {
      doc.addPage(); y = LETTERHEAD_CONTENT_TOP;
      doc.setFont("helvetica", "bold"); doc.setFontSize(11);
      doc.text(`RAZÃO: ${conta}`, 14, y); y += 4;
      autoTable(doc, {
        startY: y,
        head: [["Data", "Descrição", "Débito", "Crédito"]],
        body: v.movs.map(m => [fmtDate(m.data), m.descricao, fmt(m.debito), fmt(m.credito)]),
        foot: [["", "TOTAIS", fmt(v.debito), fmt(v.credito)]],
        styles: { fontSize: 8 },
        headStyles: { fillColor: [91, 79, 191] },
        footStyles: { fontStyle: "bold" },
        margin: { bottom: LETTERHEAD_CONTENT_BOTTOM },
      });
    }

    applyLetterheadAllPages(doc, lh);
    doc.save(`contabilidade-${dataInicio}-a-${dataFim}.pdf`);
  };

  const totalDeb = balancete.reduce((s, b) => s + b.debito, 0);
  const totalCred = balancete.reduce((s, b) => s + b.credito, 0);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><BookOpen className="h-5 w-5 text-primary" />Contabilidade — Balancete, Demonstração de Resultados e Razões</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid md:grid-cols-3 gap-3">
          <div><Label>Data Início</Label><Input type="date" value={dataInicio} onChange={(e) => setDataInicio(e.target.value)} /></div>
          <div><Label>Data Fim</Label><Input type="date" value={dataFim} onChange={(e) => setDataFim(e.target.value)} /></div>
          <div className="flex items-end gap-2">
            <Button onClick={carregar} disabled={loading}>{loading ? "A carregar..." : "Actualizar"}</Button>
            <Button variant="outline" onClick={exportarPDF}><Download className="h-4 w-4 mr-1" />PDF</Button>
          </div>
        </div>

        <Tabs defaultValue="balancete">
          <TabsList>
            <TabsTrigger value="balancete">Balancete</TabsTrigger>
            <TabsTrigger value="dr">Demonstração de Resultados</TabsTrigger>
            <TabsTrigger value="razoes">Razões</TabsTrigger>
          </TabsList>

          <TabsContent value="balancete" className="mt-3">
            <div className="border rounded-lg overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted"><tr><th className="p-2 text-left">Conta</th><th className="p-2 text-right">Débito</th><th className="p-2 text-right">Crédito</th><th className="p-2 text-right">Saldo</th></tr></thead>
                <tbody>
                  {balancete.map(b => (
                    <tr key={b.conta} className="border-t"><td className="p-2">{b.conta}</td><td className="p-2 text-right">{fmt(b.debito)}</td><td className="p-2 text-right">{fmt(b.credito)}</td><td className="p-2 text-right font-semibold">{fmt(b.saldo)}</td></tr>
                  ))}
                </tbody>
                <tfoot className="bg-muted font-bold"><tr><td className="p-2">TOTAIS</td><td className="p-2 text-right">{fmt(totalDeb)}</td><td className="p-2 text-right">{fmt(totalCred)}</td><td></td></tr></tfoot>
              </table>
            </div>
          </TabsContent>

          <TabsContent value="dr" className="mt-3 space-y-3">
            <div className="grid md:grid-cols-3 gap-3">
              <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground flex items-center gap-1"><TrendingUp className="h-3 w-3 text-green-600" />Receitas</div><div className="text-xl font-bold text-green-600">{fmt(dr.receitas)}</div></CardContent></Card>
              <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground flex items-center gap-1"><TrendingDown className="h-3 w-3 text-red-600" />Custos</div><div className="text-xl font-bold text-red-600">{fmt(dr.custos)}</div></CardContent></Card>
              <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Resultado Líquido</div><div className={`text-xl font-bold ${dr.resultado >= 0 ? "text-primary" : "text-red-600"}`}>{fmt(dr.resultado)}</div></CardContent></Card>
            </div>
            <div className="border rounded-lg overflow-hidden">
              <table className="w-full text-sm">
                <tbody>
                  <tr className="bg-green-50"><td className="p-2 font-bold" colSpan={2}>RECEITAS</td></tr>
                  {dr.detalheR.map(d => <tr key={d.nome} className="border-t"><td className="p-2">{d.nome}</td><td className="p-2 text-right">{fmt(d.valor)}</td></tr>)}
                  <tr className="border-t bg-muted"><td className="p-2 font-semibold">Total Receitas</td><td className="p-2 text-right font-semibold">{fmt(dr.receitas)}</td></tr>
                  <tr className="bg-red-50"><td className="p-2 font-bold" colSpan={2}>CUSTOS E DESPESAS</td></tr>
                  {dr.detalheC.map(d => <tr key={d.nome} className="border-t"><td className="p-2">{d.nome}</td><td className="p-2 text-right">{fmt(d.valor)}</td></tr>)}
                  <tr className="border-t bg-muted"><td className="p-2 font-semibold">Total Custos</td><td className="p-2 text-right font-semibold">{fmt(dr.custos)}</td></tr>
                  <tr className="border-t bg-primary/10"><td className="p-2 font-bold">RESULTADO LÍQUIDO</td><td className="p-2 text-right font-bold">{fmt(dr.resultado)}</td></tr>
                </tbody>
              </table>
            </div>
          </TabsContent>

          <TabsContent value="razoes" className="mt-3 space-y-4">
            {Object.entries(contas).map(([conta, v]) => (
              <div key={conta} className="border rounded-lg overflow-hidden">
                <div className="bg-muted p-2 font-semibold">{conta}</div>
                <table className="w-full text-sm">
                  <thead className="bg-muted/50"><tr><th className="p-2 text-left">Data</th><th className="p-2 text-left">Descrição</th><th className="p-2 text-right">Débito</th><th className="p-2 text-right">Crédito</th></tr></thead>
                  <tbody>
                    {v.movs.map((m, i) => <tr key={i} className="border-t"><td className="p-2">{fmtDate(m.data)}</td><td className="p-2">{m.descricao}</td><td className="p-2 text-right">{fmt(m.debito)}</td><td className="p-2 text-right">{fmt(m.credito)}</td></tr>)}
                    <tr className="border-t bg-muted font-semibold"><td className="p-2" colSpan={2}>TOTAIS</td><td className="p-2 text-right">{fmt(v.debito)}</td><td className="p-2 text-right">{fmt(v.credito)}</td></tr>
                  </tbody>
                </table>
              </div>
            ))}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
