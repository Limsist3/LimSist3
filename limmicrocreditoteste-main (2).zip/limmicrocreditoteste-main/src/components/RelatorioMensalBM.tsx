import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Download, FileText, FileSpreadsheet, FileType, Edit } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import ExcelJS from "exceljs";
import { Document, Packer, Paragraph, Table, TableRow, TableCell, TextRun, WidthType, AlignmentType, BorderStyle } from "docx";
import { saveAs } from "file-saver";

const BM_LOGO_URL = "/images/banco-mocambique-logo.png";

export function RelatorioMensalBM() {
  const [dataInicio, setDataInicio] = useState("");
  const [dataFim, setDataFim] = useState("");
  const [config, setConfig] = useState<any>(null);
  const [emprestimos, setEmprestimos] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Estado para edição
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [exportType, setExportType] = useState<"pdf" | "excel" | "word">("pdf");
  const [editableData, setEditableData] = useState({
    titulo: "BANCO DE MOÇAMBIQUE",
    departamento: "DEPARTAMENTO DE SUPERVISÃO BANCÁRIA",
    subtitulo1: "REPORTE PERIÓDICO DE INFORMAÇÕES DE MICROFINANÇAS",
    subtitulo2: "INSTITUIÇÕES SUJEITAS A MONITORIZAÇÃO",
    subtitulo3: "(Operadores de Microcrédito)",
    observacoes: ""
  });

  useEffect(() => {
    carregarConfig();
  }, []);

  const carregarConfig = async () => {
    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) return;

      const { data, error } = await supabase
        .from("configuracoes_empresa")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) {
        console.error("Erro ao carregar configurações:", error);
        toast.error("Erro ao carregar configurações da empresa");
        return;
      }

      setConfig(data);
    } catch (err) {
      console.error("Erro ao carregar configurações:", err);
      toast.error("Erro ao carregar configurações");
    }
  };

  const carregarDados = async () => {
    if (!dataInicio || !dataFim) {
      toast.error("Selecione o período do relatório");
      return;
    }

    setLoading(true);
    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) {
        toast.error("Usuário não autenticado");
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from("emprestimos")
        .select(`
          *,
          clientes (nome_completo, telefone)
        `)
        .eq("user_id", user.id)
        .gte("data_desembolso", dataInicio)
        .lte("data_desembolso", dataFim)
        .order("data_desembolso", { ascending: true });

      if (error) {
        console.error("Erro ao carregar empréstimos:", error);
        toast.error("Erro ao carregar dados dos empréstimos");
        setLoading(false);
        return;
      }

      // Pré-calcular dias em atraso (uma vez só, para tornar exportação instantânea)
      const hoje = new Date();
      hoje.setHours(0, 0, 0, 0);
      const enriched = (data || []).map((emp: any) => {
        let diasAtraso = 0;
        if (emp.data_reembolso && emp.status !== "Pago") {
          const dr = new Date(emp.data_reembolso);
          dr.setHours(0, 0, 0, 0);
          const diff = Math.floor((hoje.getTime() - dr.getTime()) / 86400000);
          if (diff > 0) {
            // Se houver mora paga, reduzir proporcionalmente
            const taxaMora = Number(emp.taxa_mora) || 0;
            const saldo = (Number(emp.valor_total) || 0) - (Number(emp.valor_pago) || 0);
            const moraPaga = Number(emp.mora_paga) || 0;
            if (taxaMora > 0 && saldo > 0 && moraPaga > 0) {
              const moraDiaria = (taxaMora / 30 / 100) * saldo;
              if (moraDiaria > 0) {
                const diasPagos = Math.floor(moraPaga / moraDiaria);
                diasAtraso = Math.max(0, diff - diasPagos);
              } else diasAtraso = diff;
            } else diasAtraso = diff;
          }
        }
        // Regra BM: mais de 30 dias em atraso => o crédito deixa de ser "em dia"
        // e passa automaticamente para "em atraso" (saldo em dívida).
        const saldoDivida = (Number(emp.valor_total) || 0) - (Number(emp.valor_pago) || 0);
        const vencidoBM = diasAtraso > 30 && emp.status !== "Pago";
        let emDia: number | string = "-";
        let emAtraso: number | string = "-";
        if (vencidoBM) {
          emAtraso = Number(Math.max(0, saldoDivida).toFixed(2));
        } else if (emp.status === "Ativo") {
          emDia = Number((Number(emp.valor) || 0).toFixed(2));
        } else if (emp.status !== "Pago") {
          emAtraso = Number(Math.max(0, saldoDivida).toFixed(2));
        }
        return { ...emp, _diasAtraso: diasAtraso, _emDia: emDia, _emAtraso: emAtraso };
      });
      setEmprestimos(enriched);

      if (!data || data.length === 0) {
        toast.info("Nenhum empréstimo encontrado no período selecionado");
      } else {
        toast.success(`${data.length} empréstimo(s) carregado(s)`);
      }
    } catch (err) {
      console.error("Erro ao carregar dados:", err);
      toast.error("Erro ao carregar dados");
    } finally {
      setLoading(false);
    }
  };

  const abrirDialogExportacao = (tipo: "pdf" | "excel" | "word") => {
    if (!config) {
      toast.error("Configure primeiro as informações da empresa em Configurações");
      return;
    }
    if (emprestimos.length === 0) {
      toast.error("Carregue os dados antes de exportar");
      return;
    }
    setExportType(tipo);
    setShowEditDialog(true);
  };

  const confirmarExportacao = () => {
    setShowEditDialog(false);
    if (exportType === "pdf") {
      gerarPDF();
    } else if (exportType === "excel") {
      gerarExcel();
    } else {
      gerarWord();
    }
  };

  const loadLogoAsBase64 = async (): Promise<string | null> => {
    try {
      const response = await fetch(BM_LOGO_URL);
      const blob = await response.blob();
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = () => resolve(null);
        reader.readAsDataURL(blob);
      });
    } catch {
      return null;
    }
  };

  const gerarPDF = async () => {
    try {
      const doc = new jsPDF({ orientation: "landscape", compress: true });
      const pageWidth = doc.internal.pageSize.getWidth();
      let y = 15;

      // Logo do Banco de Moçambique
      const logoBase64 = await loadLogoAsBase64();
      if (logoBase64) {
        doc.addImage(logoBase64, "PNG", 14, y - 5, 25, 25);
      }

      // Logotipo da empresa (lado direito)
      try {
        const { loadLogoDataUrl } = await import("@/lib/pdfLogo");
        const empLogo = await loadLogoDataUrl(config?.logo_url);
        if (empLogo) {
          doc.addImage(empLogo.dataUrl, empLogo.format, pageWidth - 39, y - 5, 25, 25);
        }
      } catch {}

      // Cabeçalho centrado
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text(editableData.titulo, pageWidth / 2, y, { align: "center" });
      y += 7;

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text(editableData.departamento, pageWidth / 2, y, { align: "center" });
      y += 5;
      doc.text(editableData.subtitulo1, pageWidth / 2, y, { align: "center" });
      y += 5;
      doc.text(editableData.subtitulo2, pageWidth / 2, y, { align: "center" });
      y += 5;
      doc.text(editableData.subtitulo3, pageWidth / 2, y, { align: "center" });
      y += 10;

      doc.setFont("helvetica", "bold");
      doc.text(`PERÍODO DE REPORTE:          ${new Date(dataInicio).toLocaleDateString('pt-PT')} á ${new Date(dataFim).toLocaleDateString('pt-PT')}`, 14, y);
      y += 10;

      // 1. IDENTIFICAÇÃO DA INSTITUIÇÃO
      doc.setFontSize(11);
      doc.text("1. IDENTIFICAÇÃO DA INSTITUIÇÃO", 14, y);
      y += 7;

      const infoTable = [
        ["Nome ou designação:", config.nome_empresa || "N/A"],
        ["Endereço ou Localização:", config.endereco || "N/A"],
        ["Telefone:", config.telefone || "N/A"],
        ["Telefax:", config.telefax || "N/A"],
        ["E-mail:", config.email || "N/A"],
        ["No de Trabalhadores", config.num_trabalhadores?.toString() || "0"],
        ["Ano de início das actividades:", config.ano_inicio_atividades?.toString() || "N/A"],
        ["Nome:", config.diretor_nome || "N/A"],
        ["Posição:", config.diretor_posicao || "DIRECTOR GERAL"]
      ];

      autoTable(doc, {
        startY: y,
        head: [],
        body: infoTable,
        theme: "grid",
        styles: { fontSize: 9, cellPadding: 2 },
        columnStyles: {
          0: { cellWidth: 60, fontStyle: "bold" },
          1: { cellWidth: 160 }
        },
        margin: { left: 14 }
      });

      y = (doc as any).lastAutoTable.finalY + 10;

      // Tabela de empréstimos
      const tableData = emprestimos.map((emp, index) => [
        (index + 1).toString(),
        emp.clientes?.nome_completo || "N/A",
        new Date(emp.data_desembolso).toLocaleDateString('pt-PT'),
        emp.valor.toFixed(2),
        emp.observacoes || "consumo",
        emp.parcela_mensal?.toFixed(2) || "0.00",
        "Mensal",
        new Date(emp.data_reembolso).toLocaleDateString('pt-PT'),
        `${emp.taxa_juros}%`,
        typeof emp._emDia === "number" ? emp._emDia.toFixed(2) : "-",
        typeof emp._emAtraso === "number" ? emp._emAtraso.toFixed(2) : "-",
        emp._diasAtraso > 0 ? String(emp._diasAtraso) : "-",
        "-"
      ]);

      autoTable(doc, {
        startY: y,
        head: [[
          "No da OP",
          "Nome do cliente",
          "data de desembolso",
          "Montante desembolso",
          "Finalidade do crédito",
          "Valor da prestação",
          "Periodicidade dos pagamentos",
          "Prazo de reembolso",
          "Taxa de juro",
          "Crédito em dia",
          "Crédito em atraso",
          "Dias em atraso",
          "PDEs"
        ]],
        body: tableData,
        theme: "grid",
        styles: { fontSize: 7, cellPadding: 1 },
        headStyles: { fillColor: [200, 220, 240], textColor: 0, fontStyle: "bold" },
        columnStyles: {
          0: { cellWidth: 15 },
          1: { cellWidth: 35 },
          2: { cellWidth: 22 },
          3: { cellWidth: 22 },
          4: { cellWidth: 20 },
          5: { cellWidth: 20 },
          6: { cellWidth: 25 },
          7: { cellWidth: 22 },
          8: { cellWidth: 18 },
          9: { cellWidth: 20 },
          10: { cellWidth: 20 },
          11: { cellWidth: 18 },
          12: { cellWidth: 15 }
        },
        margin: { left: 14, right: 14 }
      });

      // Observações adicionais
      let finalY = (doc as any).lastAutoTable.finalY + 10;
      if (editableData.observacoes) {
        doc.setFontSize(9);
        doc.setFont("helvetica", "normal");
        doc.text("Observações:", 14, finalY);
        doc.text(editableData.observacoes, 14, finalY + 5);
        finalY += 15;
      }

      // Espaço para assinatura
      finalY += 15;
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.line(pageWidth / 2 - 40, finalY, pageWidth / 2 + 40, finalY);
      finalY += 5;
      doc.setFont("helvetica", "italic");
      doc.text(`${config?.diretor_nome || "Representante Legal"} - ${config?.diretor_posicao || "Director Geral"}`, pageWidth / 2, finalY, { align: "center" });

      doc.save(`Relatorio_Mensal_BM_${dataInicio}_${dataFim}.pdf`);
      toast.success("Relatório PDF gerado com sucesso!");
    } catch (err) {
      console.error("Erro ao gerar PDF:", err);
      toast.error("Erro ao gerar PDF do relatório");
    }
  };

  const gerarExcel = async () => {
    try {
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet("Relatório Mensal BM", {
        pageSetup: { orientation: "landscape", paperSize: 9, fitToPage: true }
      });

      const totalCols = 13;
      const thinBorder: Partial<ExcelJS.Borders> = {
        top: { style: "thin" }, bottom: { style: "thin" },
        left: { style: "thin" }, right: { style: "thin" }
      };
      const headerFill: ExcelJS.FillPattern = { type: "pattern", pattern: "solid", fgColor: { argb: "FFC8DCF0" } };
      const sectionFill: ExcelJS.FillPattern = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE8E8E8" } };

      // Add logo
      try {
        const logoResponse = await fetch(BM_LOGO_URL);
        const logoBlob = await logoResponse.blob();
        const logoBuffer = await logoBlob.arrayBuffer();
        const logoId = wb.addImage({ buffer: logoBuffer, extension: "png" });
        ws.addImage(logoId, { tl: { col: 0, row: 0 }, ext: { width: 80, height: 80 } });
      } catch (e) { /* logo optional */ }

      // Column widths
      ws.columns = [
        { width: 12 }, { width: 30 }, { width: 18 }, { width: 20 },
        { width: 20 }, { width: 18 }, { width: 24 }, { width: 18 },
        { width: 14 }, { width: 18 }, { width: 18 }, { width: 16 }, { width: 12 }
      ];

      let rowNum = 1;

      // === CABEÇALHO CENTRALIZADO ===
      const headerLines = [
        { text: editableData.titulo, bold: true, size: 16 },
        { text: editableData.departamento, bold: false, size: 12 },
        { text: editableData.subtitulo1, bold: false, size: 11 },
        { text: editableData.subtitulo2, bold: false, size: 11 },
        { text: editableData.subtitulo3, bold: false, size: 11 }
      ];

      headerLines.forEach(h => {
        const row = ws.addRow([h.text]);
        ws.mergeCells(rowNum, 1, rowNum, totalCols);
        row.getCell(1).alignment = { horizontal: "center", vertical: "middle" };
        row.getCell(1).font = { bold: h.bold, size: h.size };
        row.height = h.bold ? 22 : 18;
        rowNum++;
      });

      // Linha vazia
      ws.addRow([]); rowNum++;

      // Período
      const periodoRow = ws.addRow([`PERÍODO DE REPORTE:          ${new Date(dataInicio).toLocaleDateString('pt-PT')} á ${new Date(dataFim).toLocaleDateString('pt-PT')}`]);
      ws.mergeCells(rowNum, 1, rowNum, totalCols);
      periodoRow.getCell(1).font = { bold: true, size: 11 };
      rowNum++;

      ws.addRow([]); rowNum++;

      // === 1. IDENTIFICAÇÃO DA INSTITUIÇÃO ===
      const secRow = ws.addRow(["1. IDENTIFICAÇÃO DA INSTITUIÇÃO"]);
      ws.mergeCells(rowNum, 1, rowNum, totalCols);
      secRow.getCell(1).font = { bold: true, size: 12 };
      secRow.getCell(1).fill = sectionFill;
      secRow.getCell(1).border = thinBorder;
      secRow.getCell(1).alignment = { horizontal: "left", vertical: "middle" };
      secRow.height = 24;
      rowNum++;

      ws.addRow([]); rowNum++;

      // Tabela de identificação com bordas - usar 4 colunas para melhor layout
      const infoRows = [
        ["Nome ou designação:", config?.nome_empresa || "N/A"],
        ["Endereço ou Localização:", config?.endereco || "N/A"],
        ["Telefone:", config?.telefone || "N/A"],
        ["Telefax:", config?.telefax || "N/A"],
        ["E-mail:", config?.email || "N/A"],
        ["Nº de Trabalhadores:", config?.num_trabalhadores?.toString() || "0"],
        ["Ano de início das actividades:", config?.ano_inicio_atividades?.toString() || "N/A"],
        ["Director/Representante Legal"],
        ["Nome:", config?.diretor_nome || "N/A"],
        ["Cargo:", config?.diretor_posicao || "DIRECTOR GERAL"]
      ];
      infoRows.forEach(r => {
        if (r.length === 1) {
          // Sub-header row
          const row = ws.addRow([r[0]]);
          ws.mergeCells(rowNum, 1, rowNum, totalCols);
          row.getCell(1).font = { bold: true, size: 10, italic: true };
          row.getCell(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFF0F0F0" } };
          row.getCell(1).border = thinBorder;
          row.getCell(1).alignment = { horizontal: "left", vertical: "middle" };
          row.height = 20;
        } else {
          const row = ws.addRow([r[0], r[1]]);
          ws.mergeCells(rowNum, 2, rowNum, totalCols);
          row.getCell(1).font = { bold: true, size: 10 };
          row.getCell(1).border = thinBorder;
          row.getCell(2).border = thinBorder;
          row.getCell(1).alignment = { vertical: "middle", horizontal: "left" };
          row.getCell(2).alignment = { vertical: "middle", horizontal: "left" };
          row.height = 20;
        }
        rowNum++;
      });

      ws.addRow([]); rowNum++;

      // === 2. DETALHES DOS EMPRÉSTIMOS ===
      const secRow2 = ws.addRow(["2. DETALHES DOS EMPRÉSTIMOS"]);
      ws.mergeCells(rowNum, 1, rowNum, totalCols);
      secRow2.getCell(1).font = { bold: true, size: 12 };
      secRow2.getCell(1).fill = sectionFill;
      rowNum++;

      ws.addRow([]); rowNum++;

      // Cabeçalho da tabela com bordas e fundo
      const headers = [
        "No da OP", "Nome do cliente", "Data de desembolso", "Montante desembolso",
        "Finalidade do crédito", "Valor da prestação", "Periodicidade dos pagamentos",
        "Prazo de reembolso", "Taxa de juro", "Crédito em dia", "Crédito em atraso",
        "Dias em atraso", "PDEs"
      ];
      const headerRow = ws.addRow(headers);
      headerRow.height = 30;
      for (let c = 1; c <= totalCols; c++) {
        const cell = headerRow.getCell(c);
        cell.font = { bold: true, size: 9 };
        cell.fill = headerFill;
        cell.border = thinBorder;
        cell.alignment = { horizontal: "center", vertical: "middle", wrapText: true };
      }
      rowNum++;

      // Dados com bordas
      emprestimos.forEach((emp, index) => {
        const dataRow = ws.addRow([
          index + 1,
          emp.clientes?.nome_completo || "N/A",
          new Date(emp.data_desembolso).toLocaleDateString('pt-PT'),
          Number(emp.valor.toFixed(2)),
          emp.observacoes || "consumo",
          Number(emp.parcela_mensal?.toFixed(2) || 0),
          "Mensal",
          new Date(emp.data_reembolso).toLocaleDateString('pt-PT'),
          `${emp.taxa_juros}%`,
          emp._emDia,
          emp._emAtraso,
          emp._diasAtraso > 0 ? emp._diasAtraso : "-",
          "-"
        ]);
        for (let c = 1; c <= totalCols; c++) {
          const cell = dataRow.getCell(c);
          cell.border = thinBorder;
          cell.alignment = { horizontal: "center", vertical: "middle" };
          cell.font = { size: 9 };
          // Format numbers as currency
          if (c === 4 || c === 6 || c === 10 || c === 11) {
            if (typeof cell.value === "number") {
              cell.numFmt = '#,##0.00';
            }
          }
        }
        // Left align name
        dataRow.getCell(2).alignment = { horizontal: "left", vertical: "middle" };
        rowNum++;
      });

      ws.addRow([]); rowNum++;

      // Resumo
      const totalEmp = ws.addRow(["Total de empréstimos no período:", emprestimos.length]);
      ws.mergeCells(rowNum, 2, rowNum, totalCols);
      totalEmp.getCell(1).font = { bold: true, size: 10 };
      totalEmp.getCell(1).border = thinBorder;
      totalEmp.getCell(2).border = thinBorder;
      rowNum++;

      const totalVal = ws.addRow(["Valor total desembolsado:", emprestimos.reduce((acc, emp) => acc + emp.valor, 0).toFixed(2) + " MZN"]);
      ws.mergeCells(rowNum, 2, rowNum, totalCols);
      totalVal.getCell(1).font = { bold: true, size: 10 };
      totalVal.getCell(1).border = thinBorder;
      totalVal.getCell(2).border = thinBorder;
      rowNum++;

      // Observações
      if (editableData.observacoes) {
        ws.addRow([]); rowNum++;
        const obsRow = ws.addRow(["Observações:", editableData.observacoes]);
        ws.mergeCells(rowNum, 2, rowNum, totalCols);
        obsRow.getCell(1).font = { bold: true, size: 10 };
        rowNum++;
      }

      // Espaço para assinatura
      ws.addRow([]); rowNum++;
      ws.addRow([]); rowNum++;
      const sigLine = ws.addRow(["_______________________________________"]);
      ws.mergeCells(rowNum, 1, rowNum, 4);
      sigLine.getCell(1).alignment = { horizontal: "center", vertical: "middle" };
      sigLine.getCell(1).font = { size: 10 };
      rowNum++;
      const sigLabel = ws.addRow([`${config?.diretor_nome || "Representante Legal"} - ${config?.diretor_posicao || "Director Geral"}`]);
      ws.mergeCells(rowNum, 1, rowNum, 4);
      sigLabel.getCell(1).alignment = { horizontal: "center", vertical: "middle" };
      sigLabel.getCell(1).font = { size: 10, italic: true };
      rowNum++;

      // Download
      const buffer = await wb.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      saveAs(blob, `Relatorio_Mensal_BM_${dataInicio}_${dataFim}.xlsx`);
      toast.success("Excel gerado com sucesso!");
    } catch (err) {
      console.error("Erro ao gerar Excel:", err);
      toast.error("Erro ao gerar Excel do relatório");
    }
  };

  const gerarWord = async () => {
    try {
      const cellBorders = {
        top: { style: BorderStyle.SINGLE, size: 1 },
        bottom: { style: BorderStyle.SINGLE, size: 1 },
        left: { style: BorderStyle.SINGLE, size: 1 },
        right: { style: BorderStyle.SINGLE, size: 1 },
      };

      // Criar tabela de identificação
      const infoRows = [
        ["Nome ou designação:", config.nome_empresa || "N/A"],
        ["Endereço ou Localização:", config.endereco || "N/A"],
        ["Telefone:", config.telefone || "N/A"],
        ["Telefax:", config.telefax || "N/A"],
        ["E-mail:", config.email || "N/A"],
        ["No de Trabalhadores", config.num_trabalhadores?.toString() || "0"],
        ["Ano de início das actividades:", config.ano_inicio_atividades?.toString() || "N/A"],
        ["Nome:", config.diretor_nome || "N/A"],
        ["Posição:", config.diretor_posicao || "DIRECTOR GERAL"]
      ].map(row => new TableRow({
        children: [
          new TableCell({
            children: [new Paragraph({ children: [new TextRun({ text: row[0], bold: true, size: 20 })] })],
            width: { size: 3000, type: WidthType.DXA },
            borders: cellBorders
          }),
          new TableCell({
            children: [new Paragraph({ children: [new TextRun({ text: row[1], size: 20 })] })],
            width: { size: 6000, type: WidthType.DXA },
            borders: cellBorders
          })
        ]
      }));

      // Criar tabela de empréstimos
      const headerRow = new TableRow({
        children: [
          "No da OP", "Nome do cliente", "Data desembolso", "Montante", "Finalidade",
          "Prestação", "Periodicidade", "Prazo reembolso", "Taxa juro", "Em dia", "Em atraso", "Dias atraso", "PDEs"
        ].map(text => new TableCell({
          children: [new Paragraph({ children: [new TextRun({ text, bold: true, size: 16 })] })],
          borders: cellBorders
        }))
      });

      const dataRows = emprestimos.map((emp, index) => new TableRow({
        children: [
          (index + 1).toString(),
          emp.clientes?.nome_completo || "N/A",
          new Date(emp.data_desembolso).toLocaleDateString('pt-PT'),
          emp.valor.toFixed(2),
          emp.observacoes || "consumo",
          emp.parcela_mensal?.toFixed(2) || "0.00",
          "Mensal",
          new Date(emp.data_reembolso).toLocaleDateString('pt-PT'),
          `${emp.taxa_juros}%`,
          typeof emp._emDia === "number" ? emp._emDia.toFixed(2) : "-",
          typeof emp._emAtraso === "number" ? emp._emAtraso.toFixed(2) : "-",
          emp._diasAtraso > 0 ? String(emp._diasAtraso) : "-",
          "-"
        ].map(text => new TableCell({
          children: [new Paragraph({ children: [new TextRun({ text: String(text), size: 16 })] })],
          borders: cellBorders
        }))
      }));

      const doc = new Document({
        sections: [{
          properties: {
            page: {
              size: { orientation: "landscape" }
            }
          },
          children: [
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: editableData.titulo, bold: true, size: 28 })] }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: editableData.departamento, size: 22 })] }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: editableData.subtitulo1, size: 20 })] }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: editableData.subtitulo2, size: 20 })] }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: editableData.subtitulo3, size: 20 })] }),
            new Paragraph({ text: "" }),
            new Paragraph({ children: [new TextRun({ text: `PERÍODO DE REPORTE: ${new Date(dataInicio).toLocaleDateString('pt-PT')} á ${new Date(dataFim).toLocaleDateString('pt-PT')}`, bold: true, size: 22 })] }),
            new Paragraph({ text: "" }),
            new Paragraph({ children: [new TextRun({ text: "1. IDENTIFICAÇÃO DA INSTITUIÇÃO", bold: true, size: 24 })] }),
            new Paragraph({ text: "" }),
            new Table({ rows: infoRows, width: { size: 100, type: WidthType.PERCENTAGE } }),
            new Paragraph({ text: "" }),
            new Paragraph({ children: [new TextRun({ text: "2. DETALHES DOS EMPRÉSTIMOS", bold: true, size: 24 })] }),
            new Paragraph({ text: "" }),
            new Table({ rows: [headerRow, ...dataRows], width: { size: 100, type: WidthType.PERCENTAGE } }),
            ...(editableData.observacoes ? [
              new Paragraph({ text: "" }),
              new Paragraph({ children: [new TextRun({ text: "Observações:", bold: true, size: 20 })] }),
              new Paragraph({ children: [new TextRun({ text: editableData.observacoes, size: 20 })] })
            ] : []),
            new Paragraph({ text: "" }),
            new Paragraph({ text: "" }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "_______________________________________", size: 20 })] }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: `${config?.diretor_nome || "Representante Legal"} - ${config?.diretor_posicao || "Director Geral"}`, italics: true, size: 18 })] })
          ]
        }]
      });

      const blob = await Packer.toBlob(doc);
      saveAs(blob, `Relatorio_Mensal_BM_${dataInicio}_${dataFim}.docx`);
      toast.success("Relatório Word gerado com sucesso!");
    } catch (err) {
      console.error("Erro ao gerar Word:", err);
      toast.error("Erro ao gerar Word do relatório");
    }
  };

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <FileText className="h-6 w-6 text-primary" />
        <h2 className="text-2xl font-bold">Relatório Mensal BM</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <Label htmlFor="data-inicio">Data Início</Label>
          <Input
            id="data-inicio"
            type="date"
            value={dataInicio}
            onChange={(e) => setDataInicio(e.target.value)}
          />
        </div>
        <div>
          <Label htmlFor="data-fim">Data Fim</Label>
          <Input
            id="data-fim"
            type="date"
            value={dataFim}
            onChange={(e) => setDataFim(e.target.value)}
          />
        </div>
        <div className="flex items-end gap-2">
          <Button onClick={carregarDados} disabled={loading} className="flex-1">
            {loading ? "Carregando..." : "Carregar Dados"}
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        <Button
          onClick={() => abrirDialogExportacao("excel")}
          disabled={emprestimos.length === 0}
          variant="outline"
        >
          <FileSpreadsheet className="h-4 w-4 mr-2" />
          Excel
        </Button>
        <Button
          onClick={() => abrirDialogExportacao("pdf")}
          disabled={emprestimos.length === 0}
          variant="outline"
        >
          <Download className="h-4 w-4 mr-2" />
          PDF
        </Button>
        <Button
          onClick={() => abrirDialogExportacao("word")}
          disabled={emprestimos.length === 0}
          variant="outline"
        >
          <FileType className="h-4 w-4 mr-2" />
          Word
        </Button>
      </div>

      {emprestimos.length > 0 && (
        <div className="border rounded-lg p-4 bg-muted">
          <p className="text-sm font-medium">
            Total de empréstimos no período: {emprestimos.length}
          </p>
          <p className="text-sm text-muted-foreground">
            Valor total desembolsado:{" "}
            {emprestimos.reduce((acc, emp) => acc + emp.valor, 0).toFixed(2)} MZN
          </p>
        </div>
      )}

      {/* Dialog de Edição */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="h-5 w-5" />
              Editar antes de exportar ({exportType.toUpperCase()})
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label>Título Principal</Label>
              <Input
                value={editableData.titulo}
                onChange={(e) => setEditableData({...editableData, titulo: e.target.value})}
              />
            </div>
            <div>
              <Label>Departamento</Label>
              <Input
                value={editableData.departamento}
                onChange={(e) => setEditableData({...editableData, departamento: e.target.value})}
              />
            </div>
            <div>
              <Label>Subtítulo 1</Label>
              <Input
                value={editableData.subtitulo1}
                onChange={(e) => setEditableData({...editableData, subtitulo1: e.target.value})}
              />
            </div>
            <div>
              <Label>Subtítulo 2</Label>
              <Input
                value={editableData.subtitulo2}
                onChange={(e) => setEditableData({...editableData, subtitulo2: e.target.value})}
              />
            </div>
            <div>
              <Label>Subtítulo 3</Label>
              <Input
                value={editableData.subtitulo3}
                onChange={(e) => setEditableData({...editableData, subtitulo3: e.target.value})}
              />
            </div>
            <div>
              <Label>Observações Adicionais</Label>
              <Textarea
                value={editableData.observacoes}
                onChange={(e) => setEditableData({...editableData, observacoes: e.target.value})}
                placeholder="Adicione observações que serão incluídas no relatório..."
                rows={4}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={confirmarExportacao}>
              <Download className="h-4 w-4 mr-2" />
              Exportar {exportType.toUpperCase()}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
