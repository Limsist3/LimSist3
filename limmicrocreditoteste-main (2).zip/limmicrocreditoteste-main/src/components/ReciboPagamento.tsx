import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Printer, Share2, Download } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import jsPDF from "jspdf";
import { loadLetterhead, applyLetterheadAllPages, LETTERHEAD_CONTENT_TOP, LETTERHEAD_CONTENT_BOTTOM } from "@/lib/letterhead";

interface ReciboPagamentoProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  pagamento: {
    id: string;
    valor: number;
    data_pagamento: string;
    observacoes: string;
    emprestimo_id: string;
    cliente_id: string;
    emprestimo: {
      id: string;
      valor: number;
      taxa_juros: number;
      valor_total: number;
      valor_pago: number;
      cliente: {
        nome_completo: string;
        telefone: string;
      };
    };
  };
}

interface HistoricoPagamento {
  id: string;
  valor: number;
  data_pagamento: string;
  observacoes: string;
  tipo?: string;
}

export function ReciboPagamento({ open, onOpenChange, pagamento }: ReciboPagamentoProps) {
  const [config, setConfig] = useState<any>(null);
  const [historicoPagamentos, setHistoricoPagamentos] = useState<HistoricoPagamento[]>([]);

  useEffect(() => {
    if (open && pagamento.emprestimo_id) {
      carregarConfig();
      carregarHistoricoPagamentos();
    }
  }, [open, pagamento.emprestimo_id]);

  const carregarConfig = async () => {
    const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
    if (!user) return;

    const { data } = await supabase
      .from("configuracoes_empresa")
      .select("*")
      .eq("user_id", user.id)
      .single();

    setConfig(data);
  };

  // Só carrega pagamentos REAIS (registados na BD) do MESMO empréstimo.
  // Não mostra parcelas previstas nem pagamentos de outros empréstimos do cliente.
  const carregarHistoricoPagamentos = async () => {
    try {
      const { data } = await supabase
        .from("pagamentos")
        .select("id, valor, data_pagamento, observacoes, tipo")
        .eq("emprestimo_id", pagamento.emprestimo_id)
        .order("data_pagamento", { ascending: true });

      setHistoricoPagamentos(data || []);
    } catch (err) {
      console.error("Erro ao carregar histórico:", err);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-MZ', {
      style: 'currency',
      currency: 'MZN',
    }).format(value);
  };

  const extrairMetodo = (observacoes: string) => {
    const match = observacoes?.match(/Método:\s*([^|]+)/);
    return match ? match[1].trim() : '-';
  };

  const valorDivida = pagamento.emprestimo.valor_total - pagamento.emprestimo.valor_pago;
  const capital = pagamento.emprestimo.valor;
  const juros = pagamento.emprestimo.valor_total - pagamento.emprestimo.valor;

  // Gera um recibo numa página (com espaço reservado ao papel timbrado)
  const desenharRecibo = (doc: jsPDF, tipo: "CLIENTE" | "EMPRESA") => {
    const pageWidth = doc.internal.pageSize.getWidth();
    const marginLeft = 14;
    const marginRight = pageWidth - 14;
    const contentWidth = marginRight - marginLeft;
    let y = LETTERHEAD_CONTENT_TOP;

    // Título
    doc.setFontSize(14);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(0, 0, 0);
    doc.text("RECIBO DE PAGAMENTO", pageWidth / 2, y, { align: "center" });
    y += 5;

    doc.setFontSize(8);
    doc.setFont("helvetica", "italic");
    doc.text(`(Via ${tipo === "CLIENTE" ? "Cliente" : "Empresa"})`, pageWidth / 2, y, { align: "center" });
    y += 6;

    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.text(`Recibo Nº: ${pagamento.id.substring(0, 8).toUpperCase()}`, marginLeft, y);
    doc.text(`Data: ${new Date(pagamento.data_pagamento).toLocaleDateString('pt-PT')}`, pageWidth / 2, y, { align: "center" });
    doc.text(`Hora: ${new Date().toLocaleTimeString('pt-PT')}`, marginRight, y, { align: "right" });
    y += 7;

    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.text("DADOS DO CLIENTE", marginLeft, y);
    y += 4;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.text(`Nome: ${pagamento.emprestimo.cliente.nome_completo}`, marginLeft, y);
    doc.text(`Telefone: ${pagamento.emprestimo.cliente.telefone}`, marginLeft + contentWidth / 2, y);
    y += 7;

    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.text("DADOS DO EMPRÉSTIMO", marginLeft, y);
    y += 4;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    const col1 = marginLeft;
    const col2 = marginLeft + contentWidth / 3;
    const col3 = marginLeft + (contentWidth * 2) / 3;

    doc.text(`Nº: EMP-${pagamento.emprestimo.id.substring(0, 8).toUpperCase()}`, col1, y);
    doc.text(`Capital: ${formatCurrency(capital)}`, col2, y);
    doc.text(`Juros: ${formatCurrency(juros)}`, col3, y);
    y += 4;
    doc.text(`Valor Total: ${formatCurrency(pagamento.emprestimo.valor_total)}`, col1, y);
    doc.text(`Já Pago: ${formatCurrency(pagamento.emprestimo.valor_pago)}`, col2, y);
    doc.text(`Dívida: ${formatCurrency(valorDivida)}`, col3, y);
    y += 7;

    // Payment info
    doc.setFillColor(240, 240, 240);
    doc.rect(marginLeft, y - 1, contentWidth, 14, 'F');
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.text("PAGAMENTO", marginLeft + 3, y + 4);
    doc.setFontSize(14);
    doc.text(formatCurrency(pagamento.valor), marginLeft + contentWidth / 2, y + 9, { align: "center" });
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.text(`Método: ${extrairMetodo(pagamento.observacoes)}`, marginRight - 3, y + 4, { align: "right" });
    y += 18;

    // Histórico
    if (historicoPagamentos.length > 0) {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.text("HISTÓRICO DE PAGAMENTOS", marginLeft, y);
      y += 4;

      doc.setFillColor(220, 220, 220);
      doc.rect(marginLeft, y - 1, contentWidth, 4.5, 'F');
      doc.setFontSize(7);
      doc.text("Data", marginLeft + 2, y + 2);
      doc.text("Valor", marginLeft + contentWidth * 0.28, y + 2);
      doc.text("Saldo Após", marginLeft + contentWidth * 0.52, y + 2);
      doc.text("Método", marginRight - 2, y + 2, { align: "right" });
      y += 6;

      doc.setFont("helvetica", "normal");
      const maxRows = Math.min(historicoPagamentos.length, 12);

      let saldoCorrente = pagamento.emprestimo.valor_total;
      const pagamentosComSaldo = historicoPagamentos.map(pag => {
        if (pag.tipo !== 'Juros Mora') saldoCorrente -= pag.valor;
        return { ...pag, saldoApos: Math.max(0, saldoCorrente) };
      });

      for (let i = 0; i < maxRows; i++) {
        const pag = pagamentosComSaldo[i];
        doc.text(new Date(pag.data_pagamento).toLocaleDateString('pt-PT'), marginLeft + 2, y);
        doc.text(formatCurrency(pag.valor), marginLeft + contentWidth * 0.28, y);
        doc.text(formatCurrency(pag.saldoApos), marginLeft + contentWidth * 0.52, y);
        doc.text(extrairMetodo(pag.observacoes), marginRight - 2, y, { align: "right" });
        y += 3.5;
      }

      if (historicoPagamentos.length > maxRows) {
        doc.setFont("helvetica", "italic");
        doc.text(`... e mais ${historicoPagamentos.length - maxRows} pagamento(s)`, marginLeft + 2, y);
        y += 4;
      }

      doc.setLineWidth(0.2);
      doc.line(marginLeft, y, marginRight, y);
      y += 4;
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.text("Total Pago:", marginLeft + 2, y);
      doc.text(formatCurrency(historicoPagamentos.reduce((sum, p) => sum + p.valor, 0)), marginLeft + contentWidth * 0.28, y);
      const saldoFinal = pagamentosComSaldo.length > 0 ? pagamentosComSaldo[pagamentosComSaldo.length - 1].saldoApos : pagamento.emprestimo.valor_total;
      doc.text(`Saldo: ${formatCurrency(saldoFinal)}`, marginLeft + contentWidth * 0.52, y);
      y += 8;
    }

    // Assinaturas
    const pageH = doc.internal.pageSize.getHeight();
    const sigY = Math.max(y + 10, pageH - LETTERHEAD_CONTENT_BOTTOM - 18);
    const sigWidth = contentWidth / 3;
    doc.setLineWidth(0.2);
    doc.line(marginLeft + 10, sigY, marginLeft + 10 + sigWidth, sigY);
    doc.line(marginRight - 10 - sigWidth, sigY, marginRight - 10, sigY);
    doc.setFontSize(7);
    doc.setFont("helvetica", "normal");
    doc.text("Assinatura do Cliente", marginLeft + 10 + sigWidth / 2, sigY + 3.5, { align: "center" });
    doc.text("Assinatura da Empresa", marginRight - 10 - sigWidth / 2, sigY + 3.5, { align: "center" });
  };

  const gerarPDF = async () => {
    try {
      const lh = await loadLetterhead();
      const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4', compress: true });

      // Via Cliente — página 1
      desenharRecibo(doc, "CLIENTE");
      // Via Empresa — página 2
      doc.addPage();
      desenharRecibo(doc, "EMPRESA");

      applyLetterheadAllPages(doc, lh);
      doc.save(`Recibo_${pagamento.id.substring(0, 8).toUpperCase()}.pdf`);
      toast.success("Recibo PDF gerado com sucesso!");
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
      toast.error("Erro ao gerar recibo PDF");
    }
  };

  const imprimir = () => {
    gerarPDF();
  };

  const enviarWhatsApp = () => {
    const mensagem = `*RECIBO DE PAGAMENTO*\n\n` +
      `*Recibo Nº:* ${pagamento.id.substring(0, 8).toUpperCase()}\n` +
      `*Data:* ${new Date(pagamento.data_pagamento).toLocaleDateString('pt-PT')}\n\n` +
      `*DADOS DO CLIENTE*\n` +
      `Nome: ${pagamento.emprestimo.cliente.nome_completo}\n` +
      `Telefone: ${pagamento.emprestimo.cliente.telefone}\n\n` +
      `*DADOS DO EMPRÉSTIMO*\n` +
      `Capital: ${formatCurrency(capital)}\n` +
      `Juros: ${formatCurrency(juros)}\n` +
      `Valor Total: ${formatCurrency(pagamento.emprestimo.valor_total)}\n` +
      `Já Pago: ${formatCurrency(pagamento.emprestimo.valor_pago)}\n` +
      `Dívida: ${formatCurrency(valorDivida)}\n\n` +
      `*PAGAMENTO*\n` +
      `Valor Pago: ${formatCurrency(pagamento.valor)}\n` +
      `Método: ${extrairMetodo(pagamento.observacoes)}\n\n` +
      `Obrigado pela sua confiança!\nwww.limsist.com`;

    const url = `https://wa.me/${pagamento.emprestimo.cliente.telefone}?text=${encodeURIComponent(mensagem)}`;
    window.open(url, '_blank');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Recibo de Pagamento</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Preview */}
          {config && (
            <div className="text-center border-b pb-4">
              {config.logo_url && (
                <img src={config.logo_url} alt="Logo" className="h-16 w-16 object-contain mx-auto mb-2" />
              )}
              <h3 className="font-bold text-lg">{config.nome_empresa}</h3>
              <p className="text-sm text-muted-foreground">{config.endereco}</p>
              <p className="text-sm text-muted-foreground">
                NUIT: {config.nuit} | Tel: {config.telefone}
              </p>
            </div>
          )}

          <div className="text-center border-b pb-4">
            <div className="inline-block px-4 py-2 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100 rounded-full text-sm font-bold mb-2">
              PAGO
            </div>
            <h2 className="text-2xl font-bold mb-4">Recibo de Pagamento</h2>
            <div className="grid grid-cols-2 gap-4 text-sm max-w-md mx-auto">
              <div className="text-left">
                <p className="text-muted-foreground">Recibo Nº:</p>
                <p className="font-bold">{pagamento.id.substring(0, 8).toUpperCase()}</p>
              </div>
              <div className="text-left">
                <p className="text-muted-foreground">Data:</p>
                <p className="font-bold">{new Date(pagamento.data_pagamento).toLocaleDateString('pt-PT')}</p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-2">Dados do Cliente</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <p className="text-muted-foreground">Nome:</p>
                <p className="font-medium">{pagamento.emprestimo.cliente.nome_completo}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Telefone:</p>
                <p className="font-medium">{pagamento.emprestimo.cliente.telefone}</p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-2">Dados do Empréstimo</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <p className="text-muted-foreground">Nº Empréstimo:</p>
                <p className="font-medium">EMP-{pagamento.emprestimo.id.substring(0, 8).toUpperCase()}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Capital:</p>
                <p className="font-medium">{formatCurrency(capital)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Juros:</p>
                <p className="font-medium">{formatCurrency(juros)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Valor Total:</p>
                <p className="font-medium">{formatCurrency(pagamento.emprestimo.valor_total)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Já Pago:</p>
                <p className="font-medium text-green-600">{formatCurrency(pagamento.emprestimo.valor_pago)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Valor em Dívida:</p>
                <p className="font-medium text-orange-500">{formatCurrency(valorDivida)}</p>
              </div>
            </div>
          </div>

          <div className="bg-muted p-4 rounded-lg">
            <h3 className="font-bold text-lg mb-2">Pagamento</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <p className="text-muted-foreground">Valor Pago:</p>
                <p className="font-bold text-xl text-green-600">{formatCurrency(pagamento.valor)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Método:</p>
                <p className="font-medium">{extrairMetodo(pagamento.observacoes)}</p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            <Button onClick={gerarPDF} className="flex-1">
              <Download className="mr-2 h-4 w-4" />
              Descarregar PDF (2 vias)
            </Button>
            <Button onClick={enviarWhatsApp} variant="outline" className="flex-1">
              <Share2 className="mr-2 h-4 w-4" />
              Enviar via WhatsApp
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
