import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { MessageSquare, Send, CreditCard, History, Clock, AlertTriangle, Copy } from "lucide-react";
import { format } from "date-fns";

interface SmsSaldo {
  id: string; saldo: number; total_enviadas: number; expira_em: string | null;
}
interface SmsConfigData {
  id: string; ativo: boolean; nome_remetente: string; hora_envio: number;
  aviso_3_dias_antes: boolean; aviso_no_dia: boolean; aviso_2_dias_depois: boolean;
  template_antes: string; template_dia: string; template_depois: string;
}
interface SmsPacote {
  id: string; nome: string; quantidade_sms: number; preco: number; numero_mpesa: string; numero_emola: string; nome_titular: string;
}
interface SmsEnvio {
  id: string; telefone: string; mensagem: string; tipo: string; status: string; erro: string | null; created_at: string;
}
interface SmsRecarga {
  id: string; pacote_id: string; quantidade_sms: number; valor: number; metodo_pagamento: string; status: string; created_at: string;
}
interface ConfigPagamento {
  numero_mpesa: string | null; numero_emola: string | null; nome_titular: string | null;
  nome_titular_mpesa: string | null; nome_titular_emola: string | null;
}


export function SmsConfigSection() {
  const [userId, setUserId] = useState<string>("");
  const [saldo, setSaldo] = useState<SmsSaldo | null>(null);
  const [config, setConfig] = useState<SmsConfigData | null>(null);
  const [pacotes, setPacotes] = useState<SmsPacote[]>([]);
  const [envios, setEnvios] = useState<SmsEnvio[]>([]);
  const [recargas, setRecargas] = useState<SmsRecarga[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [sending, setSending] = useState(false);
  const [rechargeOpen, setRechargeOpen] = useState(false);
  const [rechargeStep, setRechargeStep] = useState<1 | 2 | 3>(1);
  const [selectedPacote, setSelectedPacote] = useState<string>("");
  const [metodo, setMetodo] = useState<"mpesa" | "emola">("mpesa");
  const [configPag, setConfigPag] = useState<ConfigPagamento | null>(null);
  const [submittingRecharge, setSubmittingRecharge] = useState(false);


  const [manualPhone, setManualPhone] = useState("");
  const [manualMessage, setManualMessage] = useState("");

  useEffect(() => { void load(); }, []);

  async function load() {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) return;
    setUserId(session.user.id);

    const [saldoRes, configRes, pacotesRes, enviosRes, recargasRes, configPagRes] = await Promise.all([
      supabase.from("sms_saldos").select("*").eq("user_id", session.user.id).maybeSingle(),
      supabase.from("sms_config").select("*").eq("user_id", session.user.id).maybeSingle(),
      supabase.from("sms_pacotes").select("*").eq("ativo", true).order("preco"),
      supabase.from("sms_envios").select("*").eq("user_id", session.user.id).order("created_at", { ascending: false }).limit(10),
      supabase.from("sms_recargas").select("*").eq("user_id", session.user.id).order("created_at", { ascending: false }).limit(10),
      supabase.from("configuracao_pagamento").select("numero_mpesa,numero_emola,nome_titular,nome_titular_mpesa,nome_titular_emola").maybeSingle(),
    ]);

    setSaldo(saldoRes.data || null);
    setConfig(configRes.data || ({
      ativo: false, nome_remetente: "", hora_envio: 8,
      aviso_3_dias_antes: true, aviso_no_dia: true, aviso_2_dias_depois: true,
      template_antes: "Prezado(a) {nome}, a sua prestacao de {valor} MT vence em {dias} dias ({data}). {instituicao}",
      template_dia: "Prezado(a) {nome}, a sua prestacao de {valor} MT vence hoje ({data}). {instituicao}",
      template_depois: "Prezado(a) {nome}, a sua prestacao de {valor} MT venceu em {data} e encontra-se em atraso. {instituicao}",
    } as SmsConfigData));
    setPacotes((pacotesRes.data as SmsPacote[]) || []);
    setEnvios((enviosRes.data as SmsEnvio[]) || []);
    setRecargas((recargasRes.data as SmsRecarga[]) || []);
    setConfigPag((configPagRes.data as ConfigPagamento) || null);
    setLoading(false);
  }


  async function handleSaveConfig() {
    if (!userId || !config) return;
    setSaving(true);
    const payload = {
      user_id: userId,
      ativo: config.ativo,
      nome_remetente: config.nome_remetente,
      hora_envio: config.hora_envio,
      aviso_3_dias_antes: config.aviso_3_dias_antes,
      aviso_no_dia: config.aviso_no_dia,
      aviso_2_dias_depois: config.aviso_2_dias_depois,
      template_antes: config.template_antes,
      template_dia: config.template_dia,
      template_depois: config.template_depois,
    };
    const { error } = await supabase.from("sms_config").upsert(payload, { onConflict: "user_id" });
    if (error) toast.error("Erro ao guardar configuração: " + error.message);
    else toast.success("Configuração de SMS guardada");
    setSaving(false);
  }

  async function handleSendManual() {
    if (!userId || !manualPhone || !manualMessage) return;
    setSending(true);
    const { data, error } = await supabase.functions.invoke("enviar-sms", {
      body: { telefone: manualPhone, mensagem: manualMessage, tipo: "manual" },
    });
    if (error) {
      toast.error("Erro ao enviar SMS");
    } else if (data?.success) {
      toast.success("SMS enviado com sucesso");
      setManualPhone("");
      setManualMessage("");
      void load();
    } else {
      toast.error(data?.error || "Falha ao enviar SMS");
    }
    setSending(false);
  }

  function resetRecharge() {
    setRechargeStep(1);
    setSelectedPacote("");
  }

  async function handleRechargeSubmit() {
    if (!userId || !selectedPacote) return;
    const pacote = pacotes.find(p => p.id === selectedPacote);
    if (!pacote) return;
    setSubmittingRecharge(true);

    const { error } = await supabase.from("sms_recargas").insert({
      user_id: userId,
      pacote_id: pacote.id,
      quantidade_sms: pacote.quantidade_sms,
      valor: pacote.preco,
      metodo_pagamento: metodo,
      status: "pendente",
    });

    if (error) {
      toast.error("Erro ao submeter recarga: " + error.message);
    } else {
      void supabase.functions.invoke("notificar-pedido-superadmin", {
        body: { tipo: "sms_recarga", pacote: pacote.nome, valor: pacote.preco, metodo },
      });
      toast.success("Pedido de recarga enviado. Aguarde a confirmação do superadministrador.");
      setRechargeOpen(false);
      resetRecharge();
      void load();
    }
    setSubmittingRecharge(false);
  }

  if (loading) return <p className="text-muted-foreground">A carregar configuração SMS...</p>;

  const pacoteSelecionado = pacotes.find(p => p.id === selectedPacote) || null;
  const numeroDestino = {
    numero: (metodo === "mpesa" ? configPag?.numero_mpesa : configPag?.numero_emola) || "",
    titular: (metodo === "mpesa"
      ? (configPag?.nome_titular_mpesa || configPag?.nome_titular)
      : (configPag?.nome_titular_emola || configPag?.nome_titular)) || "",
  };
  const copiar = (t: string) => { if (t) { navigator.clipboard.writeText(t); toast.success("Copiado"); } };

  const saldoExpirado = saldo?.expira_em && new Date(saldo.expira_em) < new Date();
  const saldoAtivo = saldo && saldo.saldo > 0 && !saldoExpirado;


  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" /> SMS de Cobrança
          </CardTitle>
          <CardDescription>
            Envie SMS automáticos para os mutuários antes, no dia e depois do vencimento.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Saldo */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="border rounded-lg p-4">
              <div className="text-sm text-muted-foreground">Saldo de SMS</div>
              <div className="text-2xl font-bold">{saldo?.saldo || 0}</div>
              <Badge variant={saldoAtivo ? "default" : "destructive"} className="mt-2">
                {saldoAtivo ? "Activo" : "Sem saldo"}
              </Badge>
            </div>
            <div className="border rounded-lg p-4">
              <div className="text-sm text-muted-foreground">Total Enviadas</div>
              <div className="text-2xl font-bold">{saldo?.total_enviadas || 0}</div>
            </div>
            <div className="border rounded-lg p-4">
              <div className="text-sm text-muted-foreground">Validade</div>
              <div className="text-lg font-semibold">
                {saldo?.expira_em ? format(new Date(saldo.expira_em), "dd/MM/yyyy") : "—"}
              </div>
              {saldoExpirado && <div className="text-xs text-destructive mt-1">Saldo expirado</div>}
            </div>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button variant="outline" onClick={() => setRechargeOpen(true)}>
              <CreditCard className="h-4 w-4 mr-2" /> Recarregar SMS
            </Button>
          </div>

          {/* Configuração automática */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold flex items-center gap-2"><Clock className="h-4 w-4" /> Envio Automático</h3>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Activar envios automáticos</div>
                <div className="text-sm text-muted-foreground">Enviar SMS conforme regras configuradas</div>
              </div>
              <Switch checked={config?.ativo || false} onCheckedChange={(v) => setConfig(c => c ? { ...c, ativo: v } : c)} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Nome do Remetente / Instituição</Label>
                <Input value={config?.nome_remetente || ""} onChange={(e) => setConfig(c => c ? { ...c, nome_remetente: e.target.value } : c)} placeholder="Ex: XYZ Microcrédito" />
              </div>
              <div>
                <Label>Hora de envio (0-23)</Label>
                <Input type="number" min={0} max={23} value={config?.hora_envio || 8} onChange={(e) => setConfig(c => c ? { ...c, hora_envio: Math.min(23, Math.max(0, parseInt(e.target.value) || 0)) } : c)} />
              </div>
            </div>
            <div className="flex flex-wrap gap-6">
              <div className="flex items-center gap-2">
                <Switch checked={config?.aviso_3_dias_antes || false} onCheckedChange={(v) => setConfig(c => c ? { ...c, aviso_3_dias_antes: v } : c)} />
                <Label>3 dias antes</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={config?.aviso_no_dia || false} onCheckedChange={(v) => setConfig(c => c ? { ...c, aviso_no_dia: v } : c)} />
                <Label>No dia do vencimento</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={config?.aviso_2_dias_depois || false} onCheckedChange={(v) => setConfig(c => c ? { ...c, aviso_2_dias_depois: v } : c)} />
                <Label>2 dias depois</Label>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label>Template 3 dias antes</Label>
                <Textarea value={config?.template_antes || ""} onChange={(e) => setConfig(c => c ? { ...c, template_antes: e.target.value } : c)} rows={2} />
              </div>
              <div>
                <Label>Template no dia do vencimento</Label>
                <Textarea value={config?.template_dia || ""} onChange={(e) => setConfig(c => c ? { ...c, template_dia: e.target.value } : c)} rows={2} />
              </div>
              <div>
                <Label>Template 2 dias depois</Label>
                <Textarea value={config?.template_depois || ""} onChange={(e) => setConfig(c => c ? { ...c, template_depois: e.target.value } : c)} rows={2} />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Variáveis disponíveis: {"{nome}"}, {"{valor}"}, {"{data}"}, {"{dias}"}, {"{instituicao}"}
            </p>
            <Button onClick={handleSaveConfig} disabled={saving} className="w-full">
              {saving ? "A guardar..." : "Guardar Configuração"}
            </Button>
          </div>

          {/* Envio manual */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold flex items-center gap-2"><Send className="h-4 w-4" /> Envio Manual</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Telefone</Label>
                <Input value={manualPhone} onChange={(e) => setManualPhone(e.target.value)} placeholder="+258 84 XXX XXXX" />
              </div>
              <div className="md:col-span-2">
                <Label>Mensagem</Label>
                <Textarea value={manualMessage} onChange={(e) => setManualMessage(e.target.value)} rows={3} placeholder="Mensagem a enviar..." />
              </div>
            </div>
            <Button onClick={handleSendManual} disabled={sending || !manualPhone || !manualMessage || !saldoAtivo} className="w-full">
              <Send className="h-4 w-4 mr-2" /> {sending ? "A enviar..." : "Enviar SMS"}
            </Button>
            {!saldoAtivo && (
              <div className="flex items-center gap-2 text-sm text-destructive">
                <AlertTriangle className="h-4 w-4" /> Sem saldo válido para enviar SMS. Recarregue primeiro.
              </div>
            )}
          </div>

          {/* Histórico */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold flex items-center gap-2"><History className="h-4 w-4" /> Últimos Envios</h3>
            {envios.length === 0 ? (
              <p className="text-sm text-muted-foreground">Ainda não enviou nenhum SMS.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Data</TableHead><TableHead>Telefone</TableHead><TableHead>Tipo</TableHead><TableHead>Estado</TableHead></TableRow>
                </TableHeader>
                <TableBody>
                  {envios.map((e) => (
                    <TableRow key={e.id}>
                      <TableCell>{format(new Date(e.created_at), "dd/MM/yyyy HH:mm")}</TableCell>
                      <TableCell>{e.telefone}</TableCell>
                      <TableCell>{e.tipo}</TableCell>
                      <TableCell>
                        <Badge variant={e.status === "enviado" ? "default" : "destructive"}>{e.status}</Badge>
                        {e.erro && <div className="text-xs text-destructive mt-1">{e.erro}</div>}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>

          {/* Recargas */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold flex items-center gap-2"><CreditCard className="h-4 w-4" /> Pedidos de Recarga</h3>
            {recargas.length === 0 ? (
              <p className="text-sm text-muted-foreground">Sem pedidos de recarga.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Data</TableHead><TableHead>Pacote</TableHead><TableHead>Valor</TableHead><TableHead>Estado</TableHead></TableRow>
                </TableHeader>
                <TableBody>
                  {recargas.map((r) => (
                    <TableRow key={r.id}>
                      <TableCell>{format(new Date(r.created_at), "dd/MM/yyyy HH:mm")}</TableCell>
                      <TableCell>{r.quantidade_sms} SMS</TableCell>
                      <TableCell>{r.valor.toLocaleString("pt-PT")} MZN</TableCell>
                      <TableCell><Badge variant={r.status === "aprovado" ? "default" : r.status === "rejeitado" ? "destructive" : "secondary"}>{r.status}</Badge></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Dialog recarga — fluxo igual à renovação de subscrição */}
      <Dialog open={rechargeOpen} onOpenChange={(o) => { setRechargeOpen(o); if (!o) resetRecharge(); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Recarregar SMS</DialogTitle>
            <DialogDescription>
              {rechargeStep === 1 && "Escolha o pacote de SMS."}
              {rechargeStep === 2 && "Escolha o método de pagamento."}
              {rechargeStep === 3 && "Efectue o pagamento com os dados abaixo."}
            </DialogDescription>
          </DialogHeader>

          {/* PASSO 1 — pacote */}
          {rechargeStep === 1 && (
            <div className="space-y-3">
              {pacotes.length === 0 && (
                <p className="text-sm text-muted-foreground">Sem pacotes disponíveis.</p>
              )}
              {pacotes.map(p => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => { setSelectedPacote(p.id); setRechargeStep(2); }}
                  className="w-full rounded-lg border-2 p-4 text-left transition hover:border-primary"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold">{p.nome}</div>
                      <div className="text-xs text-muted-foreground">{p.quantidade_sms} SMS</div>
                    </div>
                    <div className="text-lg font-bold">{p.preco.toLocaleString("pt-PT")} MZN</div>
                  </div>
                </button>
              ))}
            </div>
          )}

          {/* PASSO 2 — método */}
          {rechargeStep === 2 && pacoteSelecionado && (
            <div className="space-y-4">
              <div className="text-center border-b pb-3">
                <div className="font-semibold">{pacoteSelecionado.nome}</div>
                <div className="text-2xl font-bold text-primary">{pacoteSelecionado.preco.toLocaleString("pt-PT")} MZN</div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  disabled={!configPag?.numero_mpesa}
                  onClick={() => { setMetodo("mpesa"); setRechargeStep(3); }}
                  className="rounded-xl border-2 p-4 text-center transition hover:border-primary disabled:opacity-50"
                >
                  <div className="text-2xl mb-1">📱</div>
                  <div className="font-bold">m-pesa</div>
                </button>
                <button
                  type="button"
                  disabled={!configPag?.numero_emola}
                  onClick={() => { setMetodo("emola"); setRechargeStep(3); }}
                  className="rounded-xl border-2 p-4 text-center transition hover:border-primary disabled:opacity-50"
                >
                  <div className="text-2xl mb-1">📱</div>
                  <div className="font-bold">e-Mola</div>
                </button>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setRechargeStep(1)}>Voltar</Button>
            </div>
          )}

          {/* PASSO 3 — detalhes de pagamento */}
          {rechargeStep === 3 && pacoteSelecionado && (
            <div className="space-y-4">
              <div className="rounded-xl border-2 p-4 space-y-3">
                <div className="text-sm font-bold">
                  PAGUE {pacoteSelecionado.preco.toLocaleString("pt-PT")} MZN PARA
                </div>
                <div>
                  <div className="text-[10px] uppercase text-muted-foreground tracking-wider">Titular</div>
                  <div className="font-semibold">{numeroDestino.titular || "—"}</div>
                </div>
                <div className="flex items-center justify-between bg-muted rounded-lg p-3">
                  <div>
                    <div className="text-[10px] uppercase text-muted-foreground tracking-wider">
                      Número {metodo === "mpesa" ? "M-Pesa" : "e-Mola"}
                    </div>
                    <div className="font-mono font-bold text-xl">{numeroDestino.numero || "—"}</div>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => copiar(numeroDestino.numero)}>
                    <Copy className="h-3 w-3 mr-1" /> Copiar
                  </Button>
                </div>
                <div className="bg-muted rounded-lg p-3">
                  <div className="text-[10px] uppercase text-muted-foreground tracking-wider">Valor exacto</div>
                  <div className="font-bold text-xl">{pacoteSelecionado.preco.toLocaleString("pt-PT")} MZN</div>
                </div>
              </div>
              <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 text-sm">
                Após efectuar o pagamento, clique no botão <strong>Submeter pedido</strong>.
                O superadministrador será notificado e a sua recarga será creditada após confirmação.
              </div>
              <Button variant="ghost" size="sm" onClick={() => setRechargeStep(2)}>Voltar</Button>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setRechargeOpen(false)}>Cancelar</Button>
            {rechargeStep === 3 && (
              <Button onClick={handleRechargeSubmit} disabled={submittingRecharge}>
                {submittingRecharge ? "A submeter..." : "Submeter pedido"}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
}
