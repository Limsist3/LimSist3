import { ContratoEmprestimoDialog } from "./ContratoEmprestimoDialog";

interface ContratoEmprestimoProps {
  emprestimoId: string;
}

export function ContratoEmprestimo({ emprestimoId }: ContratoEmprestimoProps) {
  return <ContratoEmprestimoDialog emprestimoId={emprestimoId} />;
}
  /*  const numeroParaExtenso = (num: number): string => {
    const unidades = ['', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove'];
    const especiais = ['dez', 'onze', 'doze', 'treze', 'catorze', 'quinze', 'dezesseis', 'dezessete', 'dezoito', 'dezenove'];
    const dezenas = ['', '', 'vinte', 'trinta', 'quarenta', 'cinquenta', 'sessenta', 'setenta', 'oitenta', 'noventa'];
    const centenas = ['', 'cento', 'duzentos', 'trezentos', 'quatrocentos', 'quinhentos', 'seiscentos', 'setecentos', 'oitocentos', 'novecentos'];
    
    if (num === 0) return 'zero';
    if (num === 100) return 'cem';
    
    let resultado = '';
    const milhares = Math.floor(num / 1000);
    const resto = num % 1000;
    
    if (milhares > 0) {
      if (milhares === 1) resultado += 'mil';
      else resultado += numeroParaExtenso(milhares) + ' mil';
      if (resto > 0) resultado += ' e ';
    }
    
    const c = Math.floor(resto / 100);
    const d = Math.floor((resto % 100) / 10);
    const u = resto % 10;
    
    if (c > 0) resultado += centenas[c];
    if (d > 0 || u > 0) {
      if (c > 0) resultado += ' e ';
      if (d === 1) resultado += especiais[u];
      else {
        resultado += dezenas[d];
        if (u > 0) resultado += (d > 0 ? ' e ' : '') + unidades[u];
      }
    }
    
    return resultado;
  }; */

/*  const gerarContrato = async () => {
    try {
      const { data: emprestimo, error: empError } = await supabase
        .from("emprestimos")
        .select(`
          *,
          clientes (
            nome_completo,
            telefone,
            email,
            nuit,
            provincia,
            distrito,
            bairro,
            rua
          )
        `)
        .eq("id", emprestimoId)
        .single();

      if (empError) throw empError;

      const { data: config, error: configError } = await supabase
        .from("configuracoes_empresa")
        .select("*")
        .single();

      if (configError) throw configError;

      const doc = new jsPDF({ compress: true });
      let y = 20;
      // Times New Roman 12pt com espaçamento 1.5 → ~7.2mm
      const lineHeight = 7.2;
      const margin = 20;
      const pageWidth = doc.internal.pageSize.width;

      // Função para adicionar texto com quebra de linha (justificado por padrão)
      const addText = (text: string, fontSize: number = 12, isBold: boolean = false, align: 'left' | 'center' = 'left') => {
        doc.setFontSize(fontSize);
        doc.setFont('times', isBold ? 'bold' : 'normal');

        if (align === 'center') {
          doc.text(text, pageWidth / 2, y, { align: 'center' });
        } else {
          const maxWidth = pageWidth - 2 * margin;
          const lines = doc.splitTextToSize(text, maxWidth);
          lines.forEach((wl: string, idx: number) => {
            const isLast = idx === lines.length - 1;
            if (!isLast && wl.trim().split(/\s+/).length > 1) {
              doc.text(wl, margin, y, { align: 'justify', maxWidth });
            } else {
              doc.text(wl, margin, y);
            }
            if (idx < lines.length - 1) y += lineHeight;
          });
        }
        y += lineHeight;
      };

      const checkPageBreak = () => {
        if (y > 270) {
          doc.addPage();
          y = 20;
        }
      };

      // Título
      addText("CONTRATO DE CONCESSÃO DE CRÉDITO", 16, true, 'center');
      y += 5;

      // Entre
      addText("Entre:", 12, true);
      addText(`${config.nome_empresa || 'Empresa de Microcrédito'}, Empresa de Microcrédito, com sede em Moçambique, ${config.endereco || 'Maputo'}, inscrita na Conservatória do Registo Comercial, com NUIT n.º ${config.nuit || 'N/A'}, doravante designada por "Credor".`);
      y += 3;

      addText("E:", 12, true);
      addText(`Sr.(a) ${emprestimo.clientes.nome_completo}, portador(a) do Bilhete de Identidade, residente em ${emprestimo.clientes.rua || 'N/A'}, ${emprestimo.clientes.bairro || 'N/A'}, ${emprestimo.clientes.distrito || 'N/A'}, ${emprestimo.clientes.provincia || 'N/A'}, com NUIT n.º ${emprestimo.clientes.nuit || 'N/A'}, doravante designado por "Cliente".`);
      y += 5;

      addText("As partes acima identificadas celebram o presente Contrato de Concessão de Crédito, que se rege pelas cláusulas seguintes:");
      y += 5;

      checkPageBreak();

      // CLÁUSULAS
      addText("CLÁUSULA PRIMEIRA — (Montante do Crédito)", 11, true);
      addText(`O Credor concede ao Cliente um crédito no valor de ${numeroParaExtenso(emprestimo.valor)} Meticais (MZN ${emprestimo.valor.toLocaleString('pt-MZ')}).`);
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA SEGUNDA — (Finalidade e Prazo)", 11, true);
      addText(`O crédito destina-se a: ${emprestimo.observacoes || 'Capital de giro'}.`);
      addText(`O prazo de reembolso é de ${emprestimo.duracao_meses} ${emprestimo.duracao_meses === 1 ? 'mês' : 'meses'}, com início em ${new Date(emprestimo.data_desembolso).toLocaleDateString('pt-MZ')} e término em ${new Date(emprestimo.data_reembolso).toLocaleDateString('pt-MZ')}.`);
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA TERCEIRA — (Taxa de Juro)", 11, true);
      addText(`O crédito vencerá juros à taxa de ${emprestimo.taxa_juros}% ao mês.`);
      addText("Os juros serão calculados mensalmente e pagos juntamente com cada prestação.");
      addText("A primeira prestação vence 30 dias após o desembolso.");
      addText("A taxa poderá ser alterada pelo Credor, mediante aviso prévio de 15 dias.");
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA QUARTA — (Forma de Desembolso)", 11, true);
      addText("O montante do crédito será desembolsado em uma única tranche.");
      addText(`O desembolso será efetuado via ${emprestimo.modalidade_desembolso || 'transferência bancária'}, para o meio indicado pelo Cliente.`);
      addText("O Credor reserva-se o direito de suspender o desembolso em caso de falsidade documental ou incumprimento contratual.");
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA QUINTA — (Reembolso do Crédito)", 11, true);
      addText(`O Cliente compromete-se a reembolsar o montante concedido, acrescido de juros, em ${emprestimo.duracao_meses} prestações mensais iguais de MZN ${emprestimo.parcela_mensal.toLocaleString('pt-MZ')}.`);
      addText("O plano de pagamento segue em anexo a este contrato.");
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA SEXTA — (Mora e Penalizações)", 11, true);
      addText("Em caso de mora, o Cliente:");
      addText(`- Pagará juros moratórios à Taxa de Mora de ${emprestimo.taxa_mora || 0}% / dia, calculados pela fórmula: Saldo Devedor × Taxa × Dias de Atraso;`);
      addText("- Sujeitar-se-á a multa adicional sobre o valor em atraso conforme política da instituição;");
      addText("- Se o atraso ultrapassar 60 dias, poderá ser iniciada cobrança coerciva, incluindo penhora de bens ou inscrição no Registo de Incumpridores;");
      addText("- O Credor poderá capitalizar os juros em dívida.");
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA SÉTIMA — (Garantias e Penhor)", 11, true);
      addText(`Como garantia, o Cliente oferece: ${emprestimo.tipo_garantia || 'Sem garantia específica'}, ${emprestimo.detalhes_garantia ? 'com detalhes: ' + emprestimo.detalhes_garantia : 'no valor estimado de MZN ' + emprestimo.valor.toLocaleString('pt-MZ')}.`);
      addText("O bem permanecerá na posse do Cliente, salvo indicação em contrário, não podendo ser vendido ou transferido durante a vigência do contrato.");
      addText("Em caso de incumprimento, o Credor poderá proceder à execução do penhor nos termos legais.");
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA OITAVA — (Avalistas e Coobrigados)", 11, true);
      addText("Se aplicável, o crédito será garantido adicionalmente por avalista a ser designado.");
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA NONA — (Comunicações e Notificações)", 11, true);
      addText("Toda comunicação entre as partes poderá ser feita por carta, email, SMS ou WhatsApp.");
      addText("Qualquer alteração de contactos deve ser comunicada com antecedência mínima de 5 dias úteis.");
      addText("Caso não seja comunicado, será considerada válida a última informação fornecida.");
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA DÉCIMA — (Resolução Antecipada)", 11, true);
      addText("O Cliente poderá liquidar antecipadamente o crédito, sem penalização, mediante aviso prévio de 7 dias úteis.");
      addText("Nesse caso, os juros serão recalculados proporcionalmente ao tempo decorrido.");
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA DÉCIMA PRIMEIRA — (Incumprimento e Consequências)", 11, true);
      addText("O não cumprimento de qualquer obrigação contratual implicará:");
      addText("- Vencimento imediato de todas as prestações vincendas;");
      addText("- Abertura de processo de execução judicial ou extrajudicial;");
      addText("- Inclusão do nome do Cliente em registos de risco de crédito;");
      addText("- Perda de eventuais condições promocionais, descontos ou renegociações.");
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA DÉCIMA SEGUNDA — (Confidencialidade e Dados Pessoais)", 11, true);
      addText("O Cliente autoriza o tratamento dos seus dados pessoais para efeitos de gestão do contrato, cobrança e reporting estatístico, conforme a Lei de Proteção de Dados em vigor em Moçambique.");
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA DÉCIMA TERCEIRA — (Disposições Gerais)", 11, true);
      addText("Este contrato vincula as partes e seus sucessores.");
      addText("A tolerância de qualquer das partes quanto ao cumprimento das obrigações da outra não implica renúncia nem modificação contratual.");
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA DÉCIMA QUARTA — (Foro Competente)", 11, true);
      addText("Para dirimir quaisquer conflitos resultantes deste contrato, é competente o Foro da Comarca da cidade de Maputo, com exclusão de qualquer outro.");
      y += 3;

      checkPageBreak();

      addText("CLÁUSULA DÉCIMA QUINTA — (Entrada em Vigor)", 11, true);
      addText("Este contrato entra em vigor na data da sua assinatura, desde que acompanhada da entrega de toda a documentação exigida.");
      y += 5;

      checkPageBreak();

      addText("FECHO", 12, true, 'center');
      const hoje = new Date();
      addText(`Feito em duplicado, em Maputo, aos ${hoje.getDate()} dias do mês de ${hoje.toLocaleDateString('pt-MZ', { month: 'long' })} de ${hoje.getFullYear()}.`, 10, false, 'center');
      y += 10;

      checkPageBreak();

      addText("O CREDOR", 11, true);
      addText(config.nome_empresa || 'EMPRESA DE MICROCRÉDITO');
      addText("Assinatura: __________________________");
      y += 10;

      checkPageBreak();

      addText("O CLIENTE", 11, true);
      addText(emprestimo.clientes.nome_completo);
      addText("Assinatura: __________________________");

      doc.save(`Contrato_${emprestimo.clientes.nome_completo}_${new Date().getTime()}.pdf`);
      toast.success("Contrato gerado com sucesso!");
    } catch (error: any) {
      console.error("Erro ao gerar contrato:", error);
      toast.error("Erro ao gerar contrato");
    }
  }; */
