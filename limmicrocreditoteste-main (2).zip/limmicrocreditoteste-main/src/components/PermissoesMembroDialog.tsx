import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { MODULOS_PERMISSAO, PERMISSOES_PADRAO, MembroRole, Permissoes, normalizarPermissoes, labelRole } from "@/lib/permissoes";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  membro: { id: string; full_name: string; role: string } | null;
  onSaved?: () => void;
}

export function PermissoesMembroDialog({ open, onOpenChange, membro, onSaved }: Props) {
  const [perm, setPerm] = useState<Permissoes>({ ver: [], editar: [] });
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || !membro) return;
    (async () => {
      setLoading(true);
      const { data } = await supabase
        .from("user_profiles")
        .select("permissoes")
        .eq("user_id", membro.id)
        .maybeSingle();
      setPerm(normalizarPermissoes(membro.role, (data as any)?.permissoes));
      setLoading(false);
    })();
  }, [open, membro]);

  const toggleVer = (key: string, on: boolean) => {
    setPerm((p) => ({
      ver: on ? [...new Set([...p.ver, key])] : p.ver.filter((k) => k !== key),
      editar: on ? p.editar : p.editar.filter((k) => k !== key),
    }));
  };

  const toggleEditar = (key: string, on: boolean) => {
    setPerm((p) => ({
      ver: on ? [...new Set([...p.ver, key])] : p.ver,
      editar: on ? [...new Set([...p.editar, key])] : p.editar.filter((k) => k !== key),
    }));
  };

  const restaurarPadrao = () => {
    if (!membro) return;
    const padrao = PERMISSOES_PADRAO[membro.role as MembroRole];
    if (padrao) setPerm({ ver: [...padrao.ver], editar: [...padrao.editar] });
  };

  const salvar = async () => {
    if (!membro) return;
    try {
      setSaving(true);
      const { error } = await supabase
        .from("user_profiles")
        .update({ permissoes: perm } as any)
        .eq("user_id", membro.id);
      if (error) throw error;
      toast.success("Permissões actualizadas!");
      onSaved?.();
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e.message || "Erro ao guardar permissões");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Permissões — {membro?.full_name}</DialogTitle>
          <DialogDescription>
            {membro ? labelRole(membro.role) : ""}: escolha o que este membro pode ver e onde pode criar, editar ou apagar.
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="max-h-[55vh] pr-3">
          <div className="space-y-3">
            <div className="grid grid-cols-[1fr_auto_auto] gap-3 text-xs font-medium text-muted-foreground px-1">
              <span>Secção</span>
              <span className="w-12 text-center">Ver</span>
              <span className="w-12 text-center">Editar</span>
            </div>
            {MODULOS_PERMISSAO.map((m) => (
              <div key={m.key} className="grid grid-cols-[1fr_auto_auto] items-center gap-3 rounded-md border p-3">
                <Label className="text-sm">{m.label}</Label>
                <div className="w-12 flex justify-center">
                  <Switch
                    checked={perm.ver.includes(m.key)}
                    onCheckedChange={(v) => toggleVer(m.key, v)}
                    disabled={loading}
                  />
                </div>
                <div className="w-12 flex justify-center">
                  <Switch
                    checked={perm.editar.includes(m.key)}
                    onCheckedChange={(v) => toggleEditar(m.key, v)}
                    disabled={loading}
                  />
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={restaurarPadrao} disabled={saving}>Restaurar padrão</Button>
          <Button onClick={salvar} disabled={saving || loading}>{saving ? "A guardar..." : "Guardar permissões"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
