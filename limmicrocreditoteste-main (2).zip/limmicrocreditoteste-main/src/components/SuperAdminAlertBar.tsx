import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useUserRole } from "@/hooks/useUserRole";
import { AlertTriangle, Bell, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";

/**
 * Barra vermelha a piscar (com som) no topo do superadmin
 * sempre que existem pagamentos por confirmar ou notificações não lidas.
 */
export function SuperAdminAlertBar() {
  const { isSuperAdmin } = useUserRole();
  const navigate = useNavigate();
  const [pendentes, setPendentes] = useState(0);
  const [unread, setUnread] = useState(0);
  const [muted, setMuted] = useState<boolean>(() => localStorage.getItem("sa_alert_muted") === "1");
  const audioCtxRef = useRef<AudioContext | null>(null);
  const lastBeepRef = useRef<number>(0);

  const total = pendentes + unread;

  useEffect(() => {
    if (!isSuperAdmin) return;

    const refresh = async () => {
      const [{ count: pCount }, { count: nCount }] = await Promise.all([
        supabase.from("subscription_requests").select("id", { count: "exact", head: true })
          .in("status", ["temporario", "pendente"]),
        supabase.from("notificacoes").select("id", { count: "exact", head: true })
          .eq("user_id", (await supabase.auth.getUser()).data.user?.id || "")
          .eq("lida", false),
      ]);
      setPendentes(pCount || 0);
      setUnread(nCount || 0);
    };

    refresh();

    const ch = supabase.channel("sa-alert-bar")
      .on("postgres_changes", { event: "*", schema: "public", table: "subscription_requests" }, refresh)
      .on("postgres_changes", { event: "*", schema: "public", table: "notificacoes" }, refresh)
      .subscribe();

    const interval = setInterval(refresh, 30000);
    return () => { supabase.removeChannel(ch); clearInterval(interval); };
  }, [isSuperAdmin]);

  // Som intermitente quando há alerta
  useEffect(() => {
    if (!isSuperAdmin || total === 0 || muted) return;

    const playBeep = () => {
      const now = Date.now();
      if (now - lastBeepRef.current < 4000) return;
      lastBeepRef.current = now;
      try {
        if (!audioCtxRef.current) audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        const ctx = audioCtxRef.current;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.type = "square";
        osc.frequency.value = 880;
        gain.gain.setValueAtTime(0.0001, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.15, ctx.currentTime + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.45);
        osc.start();
        osc.stop(ctx.currentTime + 0.5);
      } catch { /* ignore */ }
    };

    playBeep();
    const id = setInterval(playBeep, 5000);
    return () => clearInterval(id);
  }, [isSuperAdmin, total, muted]);

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    localStorage.setItem("sa_alert_muted", next ? "1" : "0");
  };

  if (!isSuperAdmin || total === 0) return null;

  return (
    <div
      className="bg-red-600 text-white px-4 py-2.5 flex items-center justify-center gap-3 cursor-pointer text-sm font-semibold shadow-lg"
      style={{ animation: "saBlink 1s steps(2) infinite" }}
      onClick={() => {
        if (pendentes > 0) navigate("/configuracao-pagamentos");
        else navigate("/dashboard");
      }}
    >
      <style>{`@keyframes saBlink { 50% { background-color: hsl(0 70% 35%); } }`}</style>
      <AlertTriangle className="h-5 w-5 shrink-0" />
      <span>
        {pendentes > 0 && <>🔔 {pendentes} pagamento{pendentes !== 1 ? "s" : ""} por confirmar</>}
        {pendentes > 0 && unread > 0 && " • "}
        {unread > 0 && <><Bell className="inline h-4 w-4 mr-1" />{unread} notificaç{unread !== 1 ? "ões" : "ão"}</>}
      </span>
      <Button
        size="sm"
        variant="ghost"
        className="h-7 px-2 text-white hover:bg-white/20 hover:text-white ml-2"
        onClick={(e) => { e.stopPropagation(); toggleMute(); }}
        title={muted ? "Activar som" : "Silenciar som"}
      >
        {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
      </Button>
    </div>
  );
}
