import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, Pencil, RotateCcw } from "lucide-react";
import { gerarTabelaAmortizacao, type ParcelaAmortizacao, type SistemaAmortizacao } from "@/lib/amortization";

export interface PlanoAmortizacaoProps {
  valor: number;
  taxaJuros: number;
  duracaoMeses: number;
  modalidadeReembolso?: string;
  dataDesembolso: string;
  sistema?: SistemaAmortizacao;
  tipoJuros?: string;
  taxaMora?: number;
  /** Total já pago que abate ao saldo (capital + juros da prestação) */
  totalPago: number;
  defaultOpen?: boolean;
}

type EstadoParcela = "paga" | "parcial" | "vencida" | "pendente";

export interface ParcelaComEstado extends ParcelaAmortizacao {
  pago: number;
  divida: number;
  estado: EstadoParcela;
  diasAtraso: number;
  mora: number;
}

const fmt = (n: number) =>
  `${(Number(n) || 0).toLocaleString("pt-MZ", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} MT`;

const ESTADO_LABEL: Record<EstadoParcela, string> = {
  paga: "Paga",
  parcial: "Parcial",
  vencida: "Em dívida",
  pendente: "Pendente",
};

/**
 * Distribui o total pago pelas prestações (FIFO) e classifica cada parcela.
 * Calcula juros de mora por parcela vencida não paga: dívida × taxa/dia × dias de atraso.
 */
export function calcularPlanoComEstado(
  parcelas: ParcelaAmortizacao[],
  totalPago: number,
  taxaMoraDiaria: number
): ParcelaComEstado[] {
  let restante = Math.max(0, Number(totalPago) || 0);
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);

  return parcelas.map((p) => {
    const pago = Math.min(p.prestacao, restante);
    restante = Math.max(0, restante - pago);
    const divida = Math.max(0, p.prestacao - pago);
    const venc = new Date(p.dataVencimento);
    venc.setHours(0, 0, 0, 0);
    const atrasada = divida > 0.005 && venc < hoje;
    const diasAtraso = atrasada ? Math.floor((hoje.getTime() - venc.getTime()) / 86400000) : 0;
    const mora = atrasada && taxaMoraDiaria > 0 ? divida * (taxaMoraDiaria / 100) * diasAtraso : 0;
    const estado: EstadoParcela = divida <= 0.005 ? "paga" : atrasada ? "vencida" : pago > 0.005 ? "parcial" : "pendente";
    return { ...p, pago, divida, estado, diasAtraso, mora };
  });
}

export function PlanoAmortizacaoDetalhado({
  valor,
  taxaJuros,
  duracaoMeses,
  modalidadeReembolso = "mensal",
  dataDesembolso,
  sistema = "price",
  tipoJuros = "Composto",
  taxaMora = 0,
  totalPago,
  defaultOpen = false,
}: PlanoAmortizacaoProps) {
  const [editando, setEditando] = useState(false);
  const [custom, setCustom] = useState<Record<number, { prestacao?: number; dataVencimento?: string }>>({});

  const base = useMemo(
    () =>
      gerarTabelaAmortizacao(
        valor,
        taxaJuros,
        duracaoMeses,
        modalidadeReembolso,
        dataDesembolso,
        sistema,
        tipoJuros
      ),
    [valor, taxaJuros, duracaoMeses, modalidadeReembolso, dataDesembolso, sistema, tipoJuros]
  );

  const totalOriginal = useMemo(
    () => Math.round(base.reduce((s, p) => s + p.prestacao, 0) * 100) / 100,
    [base]
  );

  // Aplica personalizações mantendo o total a pagar inalterado:
  // o que é acrescentado/reduzido numa prestação é redistribuído pelas seguintes.
  const parcelas = useMemo(() => {
    let saldo = valor;
    let restanteTotal = totalOriginal;

    return base.map((p, idx) => {
      const c = custom[p.numero];
      const seguintesNaoEditadas = base.slice(idx + 1).filter((q) => custom[q.numero]?.prestacao === undefined).length;
      const seguintesEditadas = base
        .slice(idx + 1)
        .reduce((s, q) => s + (custom[q.numero]?.prestacao !== undefined ? custom[q.numero]!.prestacao! : 0), 0);

      let prestacao: number;
      if (c?.prestacao !== undefined) {
        // não pode exceder o que falta pagar do total
        prestacao = Math.max(0, Math.min(c.prestacao, restanteTotal));
      } else if (seguintesNaoEditadas > 0) {
        // distribui o restante (descontando prestações fixas seguintes) pelas restantes livres
        const disponivel = Math.max(0, restanteTotal - seguintesEditadas);
        prestacao = Math.round((disponivel / (seguintesNaoEditadas + 1)) * 100) / 100;
      } else {
        prestacao = Math.max(0, Math.round((restanteTotal - seguintesEditadas) * 100) / 100);
      }

      restanteTotal = Math.round((restanteTotal - prestacao) * 100) / 100;

      const juros = Math.min(p.juros, prestacao);
      const amortizacao = Math.max(0, prestacao - juros);
      saldo = Math.max(0, saldo - amortizacao);
      return {
        ...p,
        dataVencimento: c?.dataVencimento || p.dataVencimento,
        prestacao,
        juros,
        amortizacao,
        saldoDevedor: saldo,
      };
    });
  }, [base, custom, valor, totalOriginal]);


  const plano = useMemo(
    () => calcularPlanoComEstado(parcelas, totalPago, Number(taxaMora) || 0),
    [parcelas, totalPago, taxaMora]
  );

  const vencidas = plano.filter((p) => p.estado === "vencida");
  const totalDividaVencida = vencidas.reduce((s, p) => s + p.divida, 0);
  const totalMora = vencidas.reduce((s, p) => s + p.mora, 0);
  const totalEmAberto = plano.reduce((s, p) => s + p.divida, 0);
  const proxima = plano.find((p) => p.estado !== "paga");
  const personalizado = Object.keys(custom).length > 0;

  return (
    <Collapsible defaultOpen={defaultOpen}>
      <CollapsibleTrigger asChild>
        <Button variant="ghost" className="w-full justify-between p-2 h-auto">
          <span className="text-xs font-semibold">
            Plano de Amortização ({plano.length} prestações)
            {vencidas.length > 0 && (
              <Badge variant="destructive" className="ml-2 text-[10px] px-1 py-0">
                {vencidas.length} em dívida
              </Badge>
            )}
          </span>
          <ChevronDown className="h-4 w-4" />
        </Button>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-2">
          <div className="border rounded-md p-2">
            <p className="text-[11px] text-muted-foreground">Prestações em dívida</p>
            <p className="text-sm font-bold text-destructive">{vencidas.length}</p>
          </div>
          <div className="border rounded-md p-2">
            <p className="text-[11px] text-muted-foreground">Valor em dívida (vencido)</p>
            <p className="text-sm font-bold text-destructive">{fmt(totalDividaVencida)}</p>
          </div>
          <div className="border rounded-md p-2">
            <p className="text-[11px] text-muted-foreground">Juros de mora (vencidos)</p>
            <p className="text-sm font-bold text-destructive">{fmt(totalMora)}</p>
          </div>
          <div className="border rounded-md p-2">
            <p className="text-[11px] text-muted-foreground">Total em aberto</p>
            <p className="text-sm font-bold">{fmt(totalEmAberto + totalMora)}</p>
          </div>
        </div>

        {proxima && (
          <p className="text-[11px] text-muted-foreground mb-2">
            Próxima prestação: nº {proxima.numero} — {fmt(proxima.divida)} em{" "}
            {new Date(proxima.dataVencimento).toLocaleDateString("pt-MZ")}
            {vencidas.length > 0 && ` | Mora acumulada: ${fmt(totalMora)}`}
          </p>
        )}

        <div className="flex gap-2 mb-2">
          <Button size="sm" variant={editando ? "default" : "outline"} onClick={() => setEditando((v) => !v)}>
            <Pencil className="h-3 w-3 mr-1" />
            {editando ? "Concluir personalização" : "Personalizar amortização"}
          </Button>
          {personalizado && (
            <Button size="sm" variant="ghost" onClick={() => setCustom({})}>
              <RotateCcw className="h-3 w-3 mr-1" />
              Restaurar plano original
            </Button>
          )}
        </div>

        <div className="overflow-x-auto max-h-72">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-xs p-1">Nº</TableHead>
                <TableHead className="text-xs p-1">Vencimento</TableHead>
                <TableHead className="text-xs p-1 text-right">Prestação</TableHead>
                <TableHead className="text-xs p-1 text-right">Capital</TableHead>
                <TableHead className="text-xs p-1 text-right">Juros</TableHead>
                <TableHead className="text-xs p-1 text-right">Pago</TableHead>
                <TableHead className="text-xs p-1 text-right">Em dívida</TableHead>
                <TableHead className="text-xs p-1 text-right">Mora</TableHead>
                <TableHead className="text-xs p-1">Estado</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {plano.map((p) => (
                <TableRow
                  key={p.numero}
                  className={
                    p.estado === "vencida"
                      ? "bg-destructive/10"
                      : p.estado === "paga"
                      ? "opacity-60"
                      : p.numero === proxima?.numero
                      ? "bg-primary/10 font-medium"
                      : ""
                  }
                >
                  <TableCell className="text-xs p-1">{p.numero}</TableCell>
                  <TableCell className="text-xs p-1">
                    {editando ? (
                      <Input
                        type="date"
                        className="h-7 text-xs w-32"
                        value={p.dataVencimento}
                        onChange={(e) =>
                          setCustom((c) => ({
                            ...c,
                            [p.numero]: { ...c[p.numero], dataVencimento: e.target.value },
                          }))
                        }
                      />
                    ) : (
                      new Date(p.dataVencimento).toLocaleDateString("pt-MZ")
                    )}
                  </TableCell>
                  <TableCell className="text-xs p-1 text-right">
                    {editando ? (
                      <Input
                        type="number"
                        step="0.01"
                        className="h-7 text-xs w-24 text-right"
                        value={p.prestacao}
                        onChange={(e) =>
                          setCustom((c) => ({
                            ...c,
                            [p.numero]: { ...c[p.numero], prestacao: parseFloat(e.target.value) || 0 },
                          }))
                        }
                      />
                    ) : (
                      fmt(p.prestacao)
                    )}
                  </TableCell>
                  <TableCell className="text-xs p-1 text-right">{fmt(p.amortizacao)}</TableCell>
                  <TableCell className="text-xs p-1 text-right">{fmt(p.juros)}</TableCell>
                  <TableCell className="text-xs p-1 text-right text-success">{fmt(p.pago)}</TableCell>
                  <TableCell className="text-xs p-1 text-right">{p.divida > 0.005 ? fmt(p.divida) : "-"}</TableCell>
                  <TableCell className="text-xs p-1 text-right text-destructive">
                    {p.mora > 0.005 ? fmt(p.mora) : "-"}
                  </TableCell>
                  <TableCell className="text-xs p-1">
                    {p.estado === "vencida" ? (
                      <Badge variant="destructive" className="text-[10px] px-1 py-0">
                        {ESTADO_LABEL.vencida} ({p.diasAtraso}d)
                      </Badge>
                    ) : p.estado === "paga" ? (
                      <span className="text-success">✓ {ESTADO_LABEL.paga}</span>
                    ) : (
                      <span className="text-muted-foreground">{ESTADO_LABEL[p.estado]}</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        {personalizado && (
          <p className="text-[11px] text-muted-foreground mt-1">
            Plano personalizado (visualização) — total a pagar mantém-se em {fmt(totalOriginal)}; as prestações
            seguintes são recalculadas automaticamente. Não altera os valores registados do empréstimo.
          </p>
        )}
      </CollapsibleContent>
    </Collapsible>
  );
}
