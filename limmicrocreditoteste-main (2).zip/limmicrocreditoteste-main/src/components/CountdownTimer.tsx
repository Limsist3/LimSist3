import { useState, useEffect, memo } from "react";
import { Clock } from "lucide-react";

interface Props {
  expiresAt: string;
}

function CountdownTimerInner({ expiresAt }: Props) {
  const [timeLeft, setTimeLeft] = useState("");
  const [daysLeft, setDaysLeft] = useState<number | null>(null);

  useEffect(() => {
    const update = () => {
      const now = Date.now();
      const exp = new Date(expiresAt).getTime();
      const diff = exp - now;
      if (diff <= 0) { setTimeLeft("Expirado"); setDaysLeft(0); return; }
      const d = Math.floor(diff / 86400000);
      const h = Math.floor((diff % 86400000) / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setDaysLeft(d);
      setTimeLeft(`${d}d ${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`);
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [expiresAt]);

  if (daysLeft !== null && daysLeft > 3650) {
    return (
      <div className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border bg-emerald-500/15 text-emerald-600 border-emerald-500/30">
        <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          <path d="m9 12 2 2 4-4"/>
        </svg>
        <span>Plano Vitalício ✓</span>
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${
      daysLeft !== null && daysLeft <= 2
        ? 'bg-destructive/10 text-destructive border-destructive/30 animate-pulse'
        : daysLeft !== null && daysLeft <= 5
          ? 'bg-amber-500/10 text-amber-600 border-amber-500/30'
          : 'bg-primary/10 text-primary border-primary/30'
    }`}>
      <Clock className="h-3.5 w-3.5" />
      <span className="hidden sm:inline">Tempo:</span>
      <span className="font-mono tabular-nums">{timeLeft}</span>
    </div>
  );
}

export const CountdownTimer = memo(CountdownTimerInner);
