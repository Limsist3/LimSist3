import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Download, FileSpreadsheet, FileText } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { createFormattedExcel, formatMZN, formatDatePT } from "@/lib/excelExport";
import { loadLetterhead, applyLetterheadAllPages, LETTERHEAD_CONTENT_TOP, LETTERHEAD_CONTENT_BOTTOM } from "@/lib/letterhead";

export function RelatorioResumoGeral() {
  const [resumo, setResumo] = useState<any>(null);
  const [config, setConfig] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const carregarResumo = async () => {
    setLoading(true);
    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;

      const { data: configData } = await supabase
        .from("configuracoes_empresa")
        .select("*")
        .eq("user_id", user?.id)
        .single();

      setConfig(configData);

      const { count: totalClientes } = await supabase
        .from("clientes")
        .select("*", { count: "exact", head: true })
        .eq("user_id", user?.id);

      const { data: emprestimos } = await supabase
        .from("emprestimos")
        .select("valor, valor_total, valor_pago, status")
        .eq("user_id", user?.id);

      const totalEmprestado = emprestimos?.reduce((acc, e) => acc + (e.valor || 0), 0) || 0;
      const totalRecebido = emprestimos?.reduce((acc, e) => acc + (e.valor_pago || 0), 0) || 0;
      const clientesAtivos = emprestimos?.filter(e => e.status === "Ativo").length || 0;

      setResumo({
        totalClientes: totalClientes || 0,
        totalEmprestado,
        totalRecebido,
        clientesAtivos,
      });
    } catch (err) {
      console.error("Erro ao carregar resumo:", err);
      toast.error("Erro ao carregar dados");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregarResumo();
  }, []);

  const exportarExcel = () => {
    if (!resumo) return;

    createFormattedExcel(
      [
        {
          title: "RESUMO GERAL DA PLATAFORMA",
          headers: ["Indicador", "Valor"],
          data: [
            ["Total de Clientes", resumo.totalClientes.toString()],
            ["Clientes Ativos", resumo.clientesAtivos.toString()],
            ["Total Emprestado", formatMZN(resumo.totalEmprestado)],
            ["Total Recebido", formatMZN(resumo.totalRecebido)],
          ]
        }
      ],
      "ResumoGeral.xlsx",
      "Resumo Geral",
      {
        nomeEmpresa: config?.nome_empresa,
        endereco: config?.endereco,
        telefone: config?.telefone,
        email: config?.email,
        titulo: "RESUMO GERAL DA PLATAFORMA",
        data: formatDatePT(new Date())
      }
    );
    
    toast.success("Excel exportado com sucesso!");
  };

  const exportarPDF = async () => {
    if (!resumo) return;

    const lh = await loadLetterhead();
    const doc = new jsPDF({ compress: true });
    const pageWidth = doc.internal.pageSize.getWidth();
    let y = LETTERHEAD_CONTENT_TOP;

    doc.setFontSize(15);
    doc.setFont("helvetica", "bold");
    doc.text("RESUMO GERAL DA PLATAFORMA", pageWidth / 2, y, { align: "center" });
    y += 7;
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.text(`Data: ${formatDatePT(new Date())}`, pageWidth / 2, y, { align: "center" });
    y += 8;

    autoTable(doc, {
      startY: y,
      head: [["Indicador", "Valor"]],
      body: [
        ["Total de Clientes", resumo.totalClientes.toString()],
        ["Clientes Ativos", resumo.clientesAtivos.toString()],
        ["Total Emprestado", formatMZN(resumo.totalEmprestado)],
        ["Total Recebido", formatMZN(resumo.totalRecebido)],
      ],
      theme: "grid",
      styles: { fontSize: 10 },
      headStyles: { fillColor: [91, 79, 191] },
      margin: { top: LETTERHEAD_CONTENT_TOP, bottom: LETTERHEAD_CONTENT_BOTTOM },
    });

    applyLetterheadAllPages(doc, lh);
    doc.save("ResumoGeral.pdf");
    toast.success("PDF gerado com sucesso!");
  };

  return (
    <Card className="p-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Resumo Geral
        </CardTitle>
      </CardHeader>

      {loading ? (
        <CardContent><p>Carregando dados...</p></CardContent>
      ) : resumo ? (
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Total de Clientes</p>
              <p className="text-2xl font-bold">{resumo.totalClientes}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Clientes Ativos</p>
              <p className="text-2xl font-bold">{resumo.clientesAtivos}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Emprestado</p>
              <p className="text-2xl font-bold text-primary">{resumo.totalEmprestado.toLocaleString("pt-MZ")} MZN</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Recebido</p>
              <p className="text-2xl font-bold text-success">{resumo.totalRecebido.toLocaleString("pt-MZ")} MZN</p>
            </div>
          </div>

          <div className="flex gap-2 mt-4">
            <Button onClick={exportarExcel} variant="outline" className="flex-1">
              <FileSpreadsheet className="mr-2 h-4 w-4" />
              Exportar Excel
            </Button>
            <Button onClick={exportarPDF} variant="outline" className="flex-1">
              <Download className="mr-2 h-4 w-4" />
              Exportar PDF
            </Button>
          </div>
        </CardContent>
      ) : (
        <CardContent><p>Nenhum dado encontrado.</p></CardContent>
      )}
    </Card>
  );
}
