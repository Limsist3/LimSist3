import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Download, Upload, Database, Loader2 } from "lucide-react";
import { ConfirmDialog } from "@/components/ConfirmDialog";

const BACKUP_TABLES = [
  "clientes",
  "emprestimos",
  "pagamentos",
  "despesas",
  "contas_financeiras",
  "movimentos_conta",
  "capital_global",
  "capital_mensal",
  "entradas_capital",
  "grupos_poupanca",
  "configuracoes_empresa",
  "arquivos",
  "central_risco",
  "poupancas_investimento",
  "poupanca_investimento_ganhos",
  "pg_grupos",
  "pg_membros",
  "pg_emprestimos",
  "pg_depositos",
  "pg_pagamentos",
  "pg_movimentos",
  "declaracoes_ispc",
  "notificacoes",
] as const;


export function BackupSection() {
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [confirmImport, setConfirmImport] = useState(false);
  const [pendingFile, setPendingFile] = useState<File | null>(null);

  const formatCoreError = (missingTables: string[]) => {
    const labels = missingTables.map(getTableLabel);
    return `O backup precisa conter obrigatoriamente: ${labels.join(", ")}.`;
  };

  const getTableLabel = (table: string) => {
    const labels: Record<string, string> = {
      clientes: "Clientes",
      emprestimos: "Empréstimos",
      pagamentos: "Pagamentos",
      despesas: "Despesas",
      contas_financeiras: "Contas Financeiras",
      movimentos_conta: "Movimentos de Conta",
      capital_global: "Capital Global",
      capital_mensal: "Capital Mensal",
      entradas_capital: "Entradas de Capital",
      grupos_poupanca: "Grupos de Poupança",
      membros_poupanca: "Membros de Poupança",
      configuracoes_empresa: "Configurações",
      arquivos: "Arquivos",
      central_risco: "Central de Risco",
      agente_atividades: "Gestão de Agentes",
      poupancas_investimento: "Poupança Investimento",
      poupanca_investimento_ganhos: "Ganhos de Investimento",
      pg_grupos: "Poupança em Grupo",
      pg_membros: "Membros (Poupança em Grupo)",
      pg_emprestimos: "Empréstimos (Poupança em Grupo)",
      pg_depositos: "Depósitos (Poupança em Grupo)",
      pg_pagamentos: "Pagamentos (Poupança em Grupo)",
      pg_movimentos: "Movimentos (Poupança em Grupo)",
      declaracoes_ispc: "Declarações ISPC",
      notificacoes: "Notificações",
    };

    return labels[table] || table;
  };

  const handleExport = async () => {
    setExporting(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) { toast.error("Não autenticado"); return; }
      const userId = session.user.id;

      const backup: Record<string, any[]> = {};

      for (const table of BACKUP_TABLES) {
        const { data, error } = await (supabase
          .from(table as any)
          .select("*") as any)
          .eq("user_id", userId);

        if (error) {
          console.warn(`Erro ao exportar ${table}:`, error.message);
          backup[table] = [];
        } else {
          backup[table] = data || [];
        }
      }

      // membros_poupanca (sem user_id) via grupo_ids
      if (backup.grupos_poupanca?.length > 0) {
        const grupoIds = backup.grupos_poupanca.map((g: any) => g.id);
        const { data: membros } = await supabase
          .from("membros_poupanca")
          .select("*")
          .in("grupo_id", grupoIds);
        backup.membros_poupanca = membros || [];
      }

      // agente_atividades (sem user_id) via agentes deste usuário mãe
      const { data: agentes } = await supabase
        .from("user_profiles")
        .select("user_id")
        .eq("usuario_mae_id", userId);
      const agenteIds = (agentes || []).map((a: any) => a.user_id);
      if (agenteIds.length > 0) {
        const { data: atividades } = await supabase
          .from("agente_atividades")
          .select("*")
          .in("agente_id", agenteIds);
        backup.agente_atividades = atividades || [];
      }


      const backupData = {
        version: "1.0",
        exportDate: new Date().toISOString(),
        userId,
        tables: backup,
      };

      // Comprimir com gzip nativo (CompressionStream) — reduz ~85%
      const jsonString = JSON.stringify(backupData);
      const dateStr = new Date().toISOString().split("T")[0];
      let blob: Blob;
      let filename: string;

      if (typeof (window as any).CompressionStream !== "undefined") {
        try {
          const stream = new Blob([jsonString], { type: "application/json" })
            .stream()
            .pipeThrough(new (window as any).CompressionStream("gzip"));
          blob = await new Response(stream).blob();
          filename = `backup_limsist_${dateStr}.json.gz`;
        } catch {
          blob = new Blob([jsonString], { type: "application/json" });
          filename = `backup_limsist_${dateStr}.json`;
        }
      } else {
        blob = new Blob([jsonString], { type: "application/json" });
        filename = `backup_limsist_${dateStr}.json`;
      }

      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);

      toast.success(`Backup exportado com sucesso! (${BACKUP_TABLES.length} tabelas)`);
    } catch (err) {
      console.error("Erro ao exportar backup:", err);
      toast.error("Erro ao exportar backup");
    } finally {
      setExporting(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.name.endsWith(".json") && !file.name.endsWith(".json.gz") && !file.name.endsWith(".gz")) {
      toast.error("Selecione um ficheiro .json ou .json.gz de backup");
      return;
    }
    setPendingFile(file);
    setConfirmImport(true);
    e.target.value = "";
  };

  const handleImport = async () => {
    if (!pendingFile) return;
    setImporting(true);
    setConfirmImport(false);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) { toast.error("Não autenticado"); return; }
      const userId = session.user.id;

      // Detectar e descomprimir gzip se aplicável
      let text: string;
      const isGz = pendingFile.name.endsWith(".gz");
      if (isGz && typeof (window as any).DecompressionStream !== "undefined") {
        const stream = pendingFile.stream().pipeThrough(new (window as any).DecompressionStream("gzip"));
        text = await new Response(stream).text();
      } else {
        text = await pendingFile.text();
      }
      const backupData = JSON.parse(text);

      if (!backupData || typeof backupData !== "object" || Array.isArray(backupData)) {
        toast.error("Ficheiro de backup inválido");
        return;
      }

      const { data, error } = await supabase.functions.invoke("import-backup", {
        body: { backupData },
      });

      if (error) throw error;

      const importedTables = Number(data?.importedTables || 0);
      const skippedRows = Number(data?.totalSkippedRows || 0);
      const importedRows = Number(data?.totalImportedRows || 0);
      const repairedRows = Number(data?.totalRepairedRows || 0);
      const summary = Array.isArray(data?.summary) ? data.summary : [];

      if (skippedRows > 0) {
        const failedModules = summary
          .filter((item: any) => item.skipped > 0)
          .map((item: any) => getTableLabel(item.table))
          .slice(0, 5)
          .join(", ");

        toast.warning(`Importação concluída: ${importedRows} registos importados${repairedRows ? ` (${repairedRows} convertidos automaticamente)` : ""}. ${skippedRows} registos não puderam ser recuperados${failedModules ? ` em ${failedModules}` : ""}.`);
      } else if (repairedRows > 0) {
        toast.success(`Importação concluída! ${importedRows} registos em ${importedTables} módulos — ${repairedRows} foram convertidos automaticamente para serem compatíveis.`);
      } else {
        toast.success(`Importação concluída com sucesso! ${importedRows} registos actualizados em ${importedTables} módulos.`);
      }


      // Reload page to reflect changes
      setTimeout(() => window.location.reload(), 1500);
    } catch (err) {
      console.error("Erro ao importar backup:", err);

      const message = err && typeof err === "object" && "message" in err ? String(err.message) : "";
      const missingMatch = message.match(/clientes|emprestimos|pagamentos/gi);

      if (missingMatch?.length) {
        toast.error(formatCoreError(Array.from(new Set(missingMatch.map((item) => item.toLowerCase())))));
      } else {
        toast.error("Erro ao importar backup. Verifique se o ficheiro é válido e se contém Clientes, Empréstimos e Pagamentos.");
      }
    } finally {
      setImporting(false);
      setPendingFile(null);
    }
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" /> Backup de Dados
          </CardTitle>
          <CardDescription>
            Exporte todos os seus dados para um ficheiro JSON ou importe um backup anterior.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border rounded-lg p-4 space-y-3">
              <h4 className="font-semibold flex items-center gap-2">
                <Download className="h-4 w-4" /> Exportar Backup
              </h4>
              <p className="text-sm text-muted-foreground">
                Descarregue todos os seus dados (clientes, empréstimos, pagamentos, despesas, contas, etc.) num ficheiro JSON.
              </p>
              <Button onClick={handleExport} disabled={exporting} className="w-full">
                {exporting ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> A exportar...</> : <><Download className="h-4 w-4 mr-2" /> Exportar Dados</>}
              </Button>
            </div>

            <div className="border rounded-lg p-4 space-y-3">
              <h4 className="font-semibold flex items-center gap-2">
                <Upload className="h-4 w-4" /> Importar Backup
              </h4>
              <p className="text-sm text-muted-foreground">
                Restaure dados a partir de um ficheiro de backup. A importação substitui totalmente os dados actuais pelos do backup — nada é duplicado.
              </p>
              <label>
                <input
                  type="file"
                  accept=".json,.gz,application/gzip,application/json"
                  onChange={handleFileSelect}
                  className="hidden"
                  disabled={importing}
                />
                <Button asChild className="w-full" variant="outline" disabled={importing}>
                  <span>
                    {importing ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> A importar...</> : <><Upload className="h-4 w-4 mr-2" /> Selecionar Ficheiro</>}
                  </span>
                </Button>
              </label>
            </div>
          </div>
        </CardContent>
      </Card>

      <ConfirmDialog
        open={confirmImport}
        onOpenChange={setConfirmImport}
        description={`Importar o backup "${pendingFile?.name}"? ATENÇÃO: todos os dados actuais (clientes, empréstimos, pagamentos, despesas, capital, contas, poupanças, etc.) serão APAGADOS e substituídos exactamente pelos dados do backup. Esta acção não pode ser desfeita.`}
        onConfirm={handleImport}
        confirmLabel="Importar"
        variant="default"
      />
    </>
  );
}
