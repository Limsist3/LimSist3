import { useState } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Download } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { formatMZN, formatDatePT } from "@/lib/excelExport";
import { loadLetterhead, applyLetterheadAllPages, LETTERHEAD_CONTENT_TOP, LETTERHEAD_CONTENT_BOTTOM } from "@/lib/letterhead";

export function RelatorioFinanceiro() {
  const [loading, setLoading] = useState(false);

  const carregarDados = async () => {
    const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
    if (!user) return null;

    const { data: emprestimos } = await supabase
      .from("emprestimos")
      .select("valor, valor_total, valor_pago, status, data_desembolso")
      .eq("user_id", user.id);

    const totalEmprestado = emprestimos?.reduce((sum, e) => sum + (e.valor || 0), 0) || 0;
    const totalReceber = emprestimos?.reduce((sum, e) => sum + ((e.valor_total || 0) - (e.valor_pago || 0)), 0) || 0;
    const totalRecebido = emprestimos?.reduce((sum, e) => sum + (e.valor_pago || 0), 0) || 0;
    const ativos = emprestimos?.filter(e => e.status === "Ativo").length || 0;
    const pagos = emprestimos?.filter(e => e.status === "Pago").length || 0;
    const emAtraso = emprestimos?.filter(e => e.status === "Em Atraso" || e.status === "em_atraso").length || 0;

    return { emprestimos, totalEmprestado, totalReceber, totalRecebido, ativos, pagos, emAtraso };
  };

  const gerarPDF = async () => {
    setLoading(true);
    try {
      const dados = await carregarDados();
      if (!dados) return;

      const lh = await loadLetterhead();
      const { emprestimos, totalEmprestado, totalReceber, totalRecebido, ativos, pagos, emAtraso } = dados;

      const doc = new jsPDF({ compress: true });
      const pageWidth = doc.internal.pageSize.getWidth();
      let y = LETTERHEAD_CONTENT_TOP;

      doc.setFontSize(15);
      doc.setFont("helvetica", "bold");
      doc.text("RELATÓRIO FINANCEIRO", pageWidth / 2, y, { align: "center" });
      y += 7;
      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      doc.text(`Data: ${formatDatePT(new Date())}`, pageWidth / 2, y, { align: "center" });
      y += 8;

      autoTable(doc, {
        startY: y,
        head: [["Indicador", "Valor"]],
        body: [
          ["Total Emprestado", formatMZN(totalEmprestado)],
          ["Total A Receber", formatMZN(totalReceber)],
          ["Total Recebido", formatMZN(totalRecebido)],
          ["Total de Empréstimos", (emprestimos?.length || 0).toString()],
        ],
        theme: "grid",
        styles: { fontSize: 10 },
        headStyles: { fillColor: [91, 79, 191] },
        margin: { top: LETTERHEAD_CONTENT_TOP, bottom: LETTERHEAD_CONTENT_BOTTOM },
      });

      y = (doc as any).lastAutoTable.finalY + 8;
      doc.setFontSize(11);
      doc.setFont("helvetica", "bold");
      doc.text("DISTRIBUIÇÃO POR STATUS", 14, y);
      y += 5;

      autoTable(doc, {
        startY: y,
        head: [["Status", "Quantidade"]],
        body: [
          ["Ativos", ativos.toString()],
          ["Pagos", pagos.toString()],
          ["Em Atraso", emAtraso.toString()],
        ],
        theme: "grid",
        styles: { fontSize: 10 },
        headStyles: { fillColor: [91, 79, 191] },
        margin: { top: LETTERHEAD_CONTENT_TOP, bottom: LETTERHEAD_CONTENT_BOTTOM },
      });

      applyLetterheadAllPages(doc, lh);
      doc.save(`Relatorio_Financeiro_${new Date().toISOString().split('T')[0]}.pdf`);
      toast.success("Relatório gerado com sucesso!");
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
      toast.error("Erro ao gerar relatório");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex gap-2">
      <Button onClick={gerarPDF} disabled={loading} variant="outline" className="flex-1">
        <Download className="mr-2 h-4 w-4" />
        {loading ? "Gerando..." : "PDF"}
      </Button>
    </div>
  );
}
