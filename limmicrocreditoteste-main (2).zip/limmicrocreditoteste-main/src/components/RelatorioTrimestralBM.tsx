import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Download, FileText, FileSpreadsheet, FileType, Edit } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import ExcelJS from "exceljs";
import { Document, Packer, Paragraph, Table, TableRow, TableCell, TextRun, WidthType, AlignmentType, BorderStyle } from "docx";
import { saveAs } from "file-saver";

const BM_LOGO_URL = "/images/banco-mocambique-logo.png";

export function RelatorioTrimestralBM() {
  const [dataInicio, setDataInicio] = useState("");
  const [dataFim, setDataFim] = useState("");
  const [config, setConfig] = useState<any>(null);
  const [dados, setDados] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const [showEditDialog, setShowEditDialog] = useState(false);
  const [exportType, setExportType] = useState<"pdf" | "excel" | "word">("pdf");
  const [editableData, setEditableData] = useState({
    titulo: "BANCO DE MOÇAMBIQUE",
    departamento: "DEPARTAMENTO DE SUPERVISÃO PRUDENCIAL",
    subtitulo1: "REPORTE PERIÓDICO DE INFORMAÇÕES DE MICROFINANÇAS",
    subtitulo2: "INSTITUIÇÕES SUJEITAS À MONITORIZAÇÃO",
    observacoes: ""
  });

  useEffect(() => {
    carregarConfig();
  }, []);

  const carregarConfig = async () => {
    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) return;

      const { data: configData } = await supabase
        .from("configuracoes_empresa")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      const { data: capitalGlobal } = await supabase
        .from("capital_global")
        .select("valor")
        .eq("user_id", user.id)
        .maybeSingle();

      const mesAtual = new Date().toISOString().slice(0, 7);
      const { data: capitalMensal } = await supabase
        .from("capital_mensal")
        .select("capital_actual")
        .eq("user_id", user.id)
        .eq("mes_ano", mesAtual)
        .maybeSingle();

      // Buscar saldos das contas financeiras
      const { data: contasData } = await supabase
        .from("contas_financeiras")
        .select("*")
        .eq("user_id", user.id);

      setConfig({
        ...configData,
        capitalInicial: capitalGlobal?.valor || 0,
        capitalAtual: capitalMensal?.capital_actual || 0,
        contas: contasData || []
      });
    } catch (err) {
      console.error("Erro ao carregar configurações:", err);
      toast.error("Erro ao carregar configurações");
    }
  };

  const carregarDados = async () => {
    if (!dataInicio || !dataFim) {
      toast.error("Selecione o período do relatório");
      return;
    }

    setLoading(true);
    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) { setLoading(false); return; }

      // Empréstimos do período
      const { data: emprestimos } = await supabase
        .from("emprestimos")
        .select(`*, clientes (nome_completo, genero)`)
        .eq("user_id", user.id)
        .gte("data_desembolso", dataInicio)
        .lte("data_desembolso", dataFim);

      // Pagamentos do período
      const { data: pagamentos } = await supabase
        .from("pagamentos")
        .select("*")
        .gte("data_pagamento", dataInicio)
        .lte("data_pagamento", dataFim);

      // Empréstimos ativos (carteira vigente)
      const { data: emprestimosAtivos } = await supabase
        .from("emprestimos")
        .select(`*, clientes (genero)`)
        .eq("user_id", user.id)
        .eq("status", "Ativo");

      // Todos os pagamentos para calcular juros
      const allPagamentos = pagamentos || [];
      
      const totalConcedido = emprestimos?.reduce((acc, emp) => acc + Number(emp.valor), 0) || 0;
      
      // Reembolsos de capital
      const reembolsosCapital = allPagamentos.filter(p => p.tipo === 'Parcela' || p.tipo === 'Amortização' || p.tipo === 'Total');
      const totalReembolsadoCapital = reembolsosCapital.reduce((acc, pag) => acc + Number(pag.valor), 0);
      
      // Juros recebidos
      const jurosRecebidos = allPagamentos.filter(p => p.tipo === 'Juros');
      const totalJuros = jurosRecebidos.reduce((acc, pag) => acc + Number(pag.valor), 0);
      
      const totalReembolsado = totalReembolsadoCapital;
      const totalReembolsadoTotal = totalReembolsadoCapital + totalJuros;

      const carteiraAtiva = emprestimosAtivos?.reduce((acc, emp) => 
        acc + (Number(emp.valor_total || 0) - Number(emp.valor_pago || 0)), 0) || 0;

      const hoje = new Date();
      const carteiraRisco = emprestimosAtivos?.filter(emp => {
        const dataReembolso = new Date(emp.data_reembolso);
        return dataReembolso < hoje;
      }).reduce((acc, emp) => acc + (Number(emp.valor_total || 0) - Number(emp.valor_pago || 0)), 0) || 0;

      const numConcedidos = emprestimos?.length || 0;
      const empReembolsadosIds = new Set(
        allPagamentos.filter(p => p.tipo === "Total").map(p => p.emprestimo_id)
      );
      const numReembolsados = empReembolsadosIds.size;

      // Clientes por género
      const clientesAtivos = emprestimosAtivos || [];
      const homens = clientesAtivos.filter(e => e.clientes?.genero === "Masculino").length;
      const mulheres = clientesAtivos.filter(e => e.clientes?.genero === "Feminino").length;
      const outrosGenero = clientesAtivos.length - homens - mulheres;
      const totalClientesAtivos = clientesAtivos.length;

      // Taxas min/max
      const taxas = emprestimos?.map(e => Number(e.taxa_juros)) || [];
      const taxaMin = taxas.length > 0 ? Math.min(...taxas) : 0;
      const taxaMax = taxas.length > 0 ? Math.max(...taxas) : 0;

      // Prazos min/max (em meses)
      const prazos = emprestimos?.map(e => Number(e.duracao_meses)) || [];
      const prazoMin = prazos.length > 0 ? Math.min(...prazos) : 0;
      const prazoMax = prazos.length > 0 ? Math.max(...prazos) : 0;

      // Classes de risco
      const calcularDiasAtraso = (emp: any) => {
        const dataReembolso = new Date(emp.data_reembolso);
        return Math.max(0, Math.floor((hoje.getTime() - dataReembolso.getTime()) / (1000 * 60 * 60 * 24)));
      };

      const calcularRiscoClasse = (empList: any[], minDias: number, maxDias: number) => {
        const filtered = empList?.filter(e => {
          const dias = calcularDiasAtraso(e);
          return dias >= minDias && (maxDias === Infinity ? true : dias <= maxDias);
        }) || [];
        let capital = 0, juros = 0;
        filtered.forEach(e => {
          const valorPrincipal = Number(e.valor || 0);
          const valorTotal = Number(e.valor_total || 0);
          const valorPago = Number(e.valor_pago || 0);
          const jurosTotal = Math.max(0, valorTotal - valorPrincipal);
          const restante = Math.max(0, valorTotal - valorPago);
          // proporção do que falta receber
          const ratio = valorTotal > 0 ? restante / valorTotal : 0;
          const capRest = valorPrincipal * ratio;
          const jurRest = jurosTotal * ratio;
          capital += capRest;
          juros += jurRest;
        });
        return { capital, juros, total: capital + juros };
      };

      const classe1 = calcularRiscoClasse(emprestimosAtivos || [], 1, 30);
      const classe2 = calcularRiscoClasse(emprestimosAtivos || [], 31, 90);
      const classe3 = calcularRiscoClasse(emprestimosAtivos || [], 91, 365);
      const classe4 = calcularRiscoClasse(emprestimosAtivos || [], 366, Infinity);
      const classeTotal = {
        capital: classe1.capital + classe2.capital + classe3.capital + classe4.capital,
        juros: classe1.juros + classe2.juros + classe3.juros + classe4.juros,
        total: classe1.total + classe2.total + classe3.total + classe4.total,
      };

      // Montante por finalidade
      const montantePorFinalidade: Record<string, number> = {
        'Comércio': 0, 'Agricultura': 0, 'Negócio': 0, 'Indústria': 0,
        'Serviços': 0, 'Consumo': 0, 'Outros': 0
      };

      emprestimos?.forEach(emp => {
        const finalidade = emp.observacoes || 'Consumo';
        const key = Object.keys(montantePorFinalidade).find(
          k => k.toLowerCase() === finalidade.toLowerCase()
        ) || 'Outros';
        montantePorFinalidade[key] += Number(emp.valor);
      });

      const totalFinalidade = Object.values(montantePorFinalidade).reduce((a, b) => a + b, 0);

      // Situação financeira por mês do trimestre - exactamente 3 meses
      const startDate = new Date(dataInicio);
      const monthNames = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", 
                          "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
      
      // Garantir exactamente 3 meses do trimestre
      const mesesTrimestre: string[] = [];
      const mesesNomes: string[] = [];
      for (let i = 0; i < 3; i++) {
        const d = new Date(startDate.getFullYear(), startDate.getMonth() + i, 1);
        mesesTrimestre.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
        mesesNomes.push(monthNames[d.getMonth()]);
      }

      // Buscar contas financeiras directamente (não depender do state config)
      const { data: contasFrescas } = await supabase
        .from("contas_financeiras")
        .select("*")
        .eq("user_id", user.id);

      const contas = contasFrescas || [];
      const contasCarteira = contas.filter((c: any) => c.tipo === 'carteira_movel');
      const contasBanco = contas.filter((c: any) => c.tipo === 'banco');
      
      const agora = new Date();
      const mesAtualStr = `${agora.getFullYear()}-${String(agora.getMonth() + 1).padStart(2, "0")}`;

      const situacaoFinanceira = await Promise.all(mesesTrimestre.map(async (mes, idx) => {
        const mesYear = parseInt(mes.split("-")[0]);
        const mesMonth = parseInt(mes.split("-")[1]);
        // Último dia real do mês (dia 28/29/30/31 conforme o mês)
        const ultimoDiaMes = new Date(mesYear, mesMonth, 0);
        // Fim do último dia (23:59:59.999)
        const fimMes = new Date(mesYear, mesMonth, 0, 23, 59, 59, 999).toISOString();
        
        let caixa = 0;
        let bancos = 0;
        
        if (mes === mesAtualStr) {
          // Mês actual: usar saldo_disponivel actual
          caixa = contasCarteira.reduce((acc: number, c: any) => acc + Number(c.saldo_disponivel || 0), 0);
          bancos = contasBanco.reduce((acc: number, c: any) => acc + Number(c.saldo_disponivel || 0), 0);
        } else if (mes > mesAtualStr) {
          // Mês futuro: sem dados
          caixa = 0;
          bancos = 0;
        } else {
          // Mês passado: buscar último movimento até ao último dia do mês
          for (const conta of contasCarteira) {
            const { data: lastMov } = await supabase
              .from("movimentos_conta")
              .select("saldo_disponivel_depois")
              .eq("conta_financeira_id", conta.id)
              .lte("created_at", fimMes)
              .order("created_at", { ascending: false })
              .limit(1)
              .maybeSingle();
            caixa += lastMov ? Number(lastMov.saldo_disponivel_depois) : 0;
          }
          
          for (const conta of contasBanco) {
            const { data: lastMov } = await supabase
              .from("movimentos_conta")
              .select("saldo_disponivel_depois")
              .eq("conta_financeira_id", conta.id)
              .lte("created_at", fimMes)
              .order("created_at", { ascending: false })
              .limit(1)
              .maybeSingle();
            bancos += lastMov ? Number(lastMov.saldo_disponivel_depois) : 0;
          }
        }
        
        return {
          mes: mesesNomes[idx],
          ultimoDia: ultimoDiaMes.getDate(),
          caixa,
          bancos,
          outrosActivos: Number(config?.outros_activos || 0),
        };
      }));

      // Capital Actual = soma dos saldos disponíveis em bancos + carteiras móveis (automático)
      const saldoBancosCarteiras = [...contasBanco, ...contasCarteira]
        .reduce((acc: number, c: any) => acc + Number(c.saldo_disponivel || 0), 0);
      const saldoActualCalculado = saldoBancosCarteiras;

      setDados({
        totalConcedido, totalReembolsado, totalJuros, totalReembolsadoTotal,
        carteiraAtiva, carteiraRisco,
        numConcedidos, numReembolsados,
        homens, mulheres, outrosGenero, totalClientesAtivos,
        taxaMin, taxaMax, prazoMin, prazoMax,
        classe1, classe2, classe3, classe4, classeTotal,
        montantePorFinalidade, totalFinalidade,
        capitalInicial: Number(config?.capitalInicial || 0),
        capitalAtual: saldoActualCalculado,
        situacaoFinanceira, mesesNomes,
      });

      toast.success("Dados carregados com sucesso!");
    } catch (err) {
      console.error("Erro ao carregar dados:", err);
      toast.error("Erro ao carregar dados");
    } finally {
      setLoading(false);
    }
  };

  const abrirDialogExportacao = (tipo: "pdf" | "excel" | "word") => {
    if (!config) { toast.error("Configure primeiro as informações da empresa em Configurações"); return; }
    if (!dados) { toast.error("Carregue os dados antes de exportar"); return; }
    setExportType(tipo);
    setShowEditDialog(true);
  };

  const confirmarExportacao = () => {
    setShowEditDialog(false);
    if (exportType === "pdf") gerarPDF();
    else if (exportType === "excel") gerarExcel();
    else gerarWord();
  };

  const loadLogoAsBase64 = async (): Promise<string | null> => {
    try {
      const response = await fetch(BM_LOGO_URL);
      const blob = await response.blob();
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = () => resolve(null);
        reader.readAsDataURL(blob);
      });
    } catch { return null; }
  };

  const fmt = (v: number) => v.toLocaleString('pt-PT', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  const gerarPDF = async () => {
    try {
      const doc = new jsPDF({ compress: true });
      const pw = doc.internal.pageSize.getWidth();
      let y = 15;

      const logoBase64 = await loadLogoAsBase64();
      if (logoBase64) doc.addImage(logoBase64, "PNG", 14, y - 5, 22, 22);

      // Logotipo da empresa (lado direito)
      try {
        const { loadLogoDataUrl } = await import("@/lib/pdfLogo");
        const empLogo = await loadLogoDataUrl(config?.logo_url);
        if (empLogo) {
          doc.addImage(empLogo.dataUrl, empLogo.format, pw - 36, y - 5, 22, 22);
        }
      } catch {}

      doc.setFontSize(13); doc.setFont("helvetica", "bold");
      doc.text(editableData.titulo, pw / 2, y, { align: "center" }); y += 6;
      doc.setFontSize(9); doc.setFont("helvetica", "normal");
      doc.text(editableData.departamento, pw / 2, y, { align: "center" }); y += 5;
      doc.text(editableData.subtitulo1, pw / 2, y, { align: "center" }); y += 5;
      doc.text(editableData.subtitulo2, pw / 2, y, { align: "center" }); y += 8;

      doc.setFont("helvetica", "bold"); doc.setFontSize(9);
      doc.text("PERÍODO DE REPORTE:", 14, y); y += 5;
      doc.text(`DATA: ${new Date(dataInicio).toLocaleDateString('pt-PT')} à ${new Date(dataFim).toLocaleDateString('pt-PT')}`, 14, y); y += 8;

      // Capital próprio à direita
      doc.text(`${fmt(dados.capitalInicial)}`, pw - 14, y - 13, { align: "right" });

      // OPERADORES DE MICROCRÉDITO
      doc.setFontSize(10); doc.setFont("helvetica", "bold");
      doc.text("OPERADORES DE MICROCRÉDITO", 14, y); y += 6;

      const infoTable = [
        ["Denominação:", config?.nome_empresa || "N/A"],
        ["Endereço:", config?.endereco || "N/A"],
        ["Província:", config?.provincia || "N/A"],
        ["Telefone:", config?.telefone || "N/A"],
        [`Fax: ${config?.telefax || '___________'}`, `E-mail: ${config?.email || 'N/A'}`],
        ["Nº de Trabalhadores:", config?.num_trabalhadores?.toString() || "0"],
        ["Data de Início das Actividades:", config?.ano_inicio_atividades?.toString() || "N/A"],
        ["Nome do Operador:", config?.diretor_nome || "N/A"],
      ];

      autoTable(doc, {
        startY: y, body: infoTable, theme: "grid",
        styles: { fontSize: 8, cellPadding: 2 },
        columnStyles: { 0: { cellWidth: 55, fontStyle: "bold" }, 1: { cellWidth: 125 } },
        margin: { left: 14 }
      });
      y = (doc as any).lastAutoTable.finalY + 6;

      // 2. INFORMAÇÕES SOBRE A ACTIVIDADE
      doc.setFontSize(10); doc.setFont("helvetica", "bold");
      doc.text("2. INFORMAÇÕES SOBRE A ACTIVIDADE", 14, y); y += 5;
      doc.text("2.1 CARTEIRA DE CRÉDITO", 14, y); y += 6;

      // 2.1.1 Volume de créditos
      doc.setFontSize(9);
      doc.text("2.1.1 Volume de créditos - MZN", 14, y); y += 5;

      autoTable(doc, {
        startY: y,
        head: [["", "", "Capital", "Juro", "TOTAL"]],
        body: [
          ["Montante de créditos concedidos no período", "", fmt(dados.totalConcedido), "", ""],
          ["Montante de créditos reembolsados no período", "", fmt(dados.totalReembolsado), fmt(dados.totalJuros), fmt(dados.totalReembolsadoTotal)],
          ["Montante de créditos abatidos no período", "", "0.00", "", ""],
          ["Montante da carteira de crédito activa/vigente:", "", fmt(dados.carteiraAtiva), "", ""],
          ["Montante da carteira em risco", "", fmt(dados.carteiraRisco), "", ""],
        ],
        theme: "grid", styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [200, 220, 240], textColor: 0, fontStyle: "bold", fontSize: 8 },
        columnStyles: { 0: { cellWidth: 75 }, 1: { cellWidth: 15 }, 2: { cellWidth: 30 }, 3: { cellWidth: 30 }, 4: { cellWidth: 30 } },
        margin: { left: 14 }
      });
      y = (doc as any).lastAutoTable.finalY + 6;

      // 2.1.2 Número de créditos
      doc.text("2.1.2 Número de créditos", 14, y); y += 5;
      autoTable(doc, {
        startY: y,
        body: [
          ["Número de créditos concedidos no período", "", "", "", dados.numConcedidos.toString()],
          ["Número de créditos reembolsados no período", "", "", "", dados.numReembolsados.toString()],
        ],
        theme: "grid", styles: { fontSize: 8, cellPadding: 2 },
        margin: { left: 14 }
      });
      y = (doc as any).lastAutoTable.finalY + 6;

      // 2.1.3 Créditos por actividade
      doc.text("2.1.3 Créditos concedidos por sector de actividade/finalidade", 14, y); y += 5;
      const finalidadeRows = Object.entries(dados.montantePorFinalidade).map(([k, v]) => [k, "", "", "", fmt(v as number)]);
      finalidadeRows.push(["TOTAL", "", "", "", fmt(dados.totalFinalidade)]);
      
      autoTable(doc, {
        startY: y,
        head: [["Actividade/finalidade", "", "", "", "Montante de créditos concedidos no período"]],
        body: finalidadeRows,
        theme: "grid", styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [200, 220, 240], textColor: 0, fontStyle: "bold", fontSize: 7 },
        margin: { left: 14 }
      });
      y = (doc as any).lastAutoTable.finalY + 6;

      if (y > 240) { doc.addPage(); y = 15; }

      // 2.1.4 Carteira de clientes
      doc.text("2.1.4 Carteira de Clientes", 14, y); y += 5;
      autoTable(doc, {
        startY: y,
        head: [["Descrição", "", "", "", "Nº de clientes activos"]],
        body: [
          ["Homens", "", "", "", dados.homens.toString()],
          ["Mulheres", "", "", "", dados.mulheres.toString()],
          ["Outros", "", "", "", dados.outrosGenero.toString()],
          ["Total", "", "", "", dados.totalClientesAtivos.toString()],
        ],
        theme: "grid", styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [200, 220, 240], textColor: 0, fontStyle: "bold", fontSize: 8 },
        margin: { left: 14 }
      });
      y = (doc as any).lastAutoTable.finalY + 6;

      // 2.1.5 Estrutura da Carteira em Risco
      doc.text("2.1.5 Estrutura da Carteira em Risco", 14, y); y += 5;
      autoTable(doc, {
        startY: y,
        head: [["Classe de Risco", "", "Capital", "Juro", "TOTAL"]],
        body: [
          ["Classe I (de 1 até 30 dias)", "", fmt(dados.classe1.capital), fmt(dados.classe1.juros), fmt(dados.classe1.total)],
          ["Classe II (de 31 até 90 dias)", "", fmt(dados.classe2.capital), fmt(dados.classe2.juros), fmt(dados.classe2.total)],
          ["Classe III (de 91 a 365 dias)", "", fmt(dados.classe3.capital), fmt(dados.classe3.juros), fmt(dados.classe3.total)],
          ["Classe IV (mais de 365 dias)", "", fmt(dados.classe4.capital), fmt(dados.classe4.juros), fmt(dados.classe4.total)],
          ["Total", "", fmt(dados.classeTotal.capital), fmt(dados.classeTotal.juros), fmt(dados.classeTotal.total)],
        ],
        theme: "grid", styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [200, 220, 240], textColor: 0, fontStyle: "bold", fontSize: 8 },
        margin: { left: 14 }
      });
      y = (doc as any).lastAutoTable.finalY + 6;

      if (y > 240) { doc.addPage(); y = 15; }

      // 2.2 Taxas de juro e prazos
      doc.text("2.2 TAXAS DE JURO E PRAZOS DE VENCIMENTO", 14, y); y += 5;
      autoTable(doc, {
        startY: y,
        head: [["Descrição", "", "", "Mínimo", "Máximo"]],
        body: [
          ["Taxa de juro mensal", "", "", `${dados.taxaMin}%`, `${dados.taxaMax}%`],
          ["Prazo (Meses)", "", "", dados.prazoMin.toString(), dados.prazoMax.toString()],
        ],
        theme: "grid", styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [200, 220, 240], textColor: 0, fontStyle: "bold", fontSize: 8 },
        margin: { left: 14 }
      });
      y = (doc as any).lastAutoTable.finalY + 6;

      // 2.3 Fontes de Financiamento
      doc.text("2.3 FONTES DE FINANCIAMENTO DA INSTITUIÇÃO", 14, y); y += 5;
      autoTable(doc, {
        startY: y,
        body: [
          ["Capitais Próprios", "", fmt(dados.capitalInicial), "", ""],
          ["Capitais Alheios", "", "", "", ""],
          ["  Nacionais", "", fmt(Number(config?.capitais_alheios_nacionais || 0)), "", ""],
          ["  Estrangeiros", "", fmt(Number(config?.capitais_alheios_estrangeiros || 0)), "", ""],
          ["Total", "", fmt(dados.capitalInicial + Number(config?.capitais_alheios_nacionais || 0) + Number(config?.capitais_alheios_estrangeiros || 0)), "", ""],
        ],
        theme: "grid", styles: { fontSize: 8, cellPadding: 2 },
        margin: { left: 14 }
      });
      y = (doc as any).lastAutoTable.finalY + 6;

      // 2.4 Financiamentos do período
      doc.text("2.4 FINANCIAMENTOS DO PERÍODO", 14, y); y += 5;
      autoTable(doc, {
        startY: y,
        body: [
          ["Empréstimos obtidos no período", "", fmt(Number(config?.emprestimos_obtidos || 0)), "", ""],
          ["Donativos obtidos no período", "", fmt(Number(config?.donativos_obtidos || 0)), "", ""],
          ["Aumento do capital com recursos próprios", "", fmt(Number(config?.aumento_capital_proprio || 0)), "", ""],
          ["Total", "", fmt(Number(config?.emprestimos_obtidos || 0) + Number(config?.donativos_obtidos || 0) + Number(config?.aumento_capital_proprio || 0)), "", ""],
        ],
        theme: "grid", styles: { fontSize: 8, cellPadding: 2 },
        margin: { left: 14 }
      });
      y = (doc as any).lastAutoTable.finalY + 6;

      if (y > 240) { doc.addPage(); y = 15; }

      // 2.5 Capital
      doc.text("2.5 CAPITAL", 14, y); y += 5;
      autoTable(doc, {
        startY: y,
        body: [
          ["Inicial", "", fmt(dados.capitalInicial), "", ""],
          ["Actual", "", fmt(dados.capitalAtual), "", ""],
        ],
        theme: "grid", styles: { fontSize: 8, cellPadding: 2 },
        margin: { left: 14 }
      });
      y = (doc as any).lastAutoTable.finalY + 6;

      // 3. Situação Financeira
      doc.setFontSize(10); doc.setFont("helvetica", "bold");
      doc.text("3. SITUAÇÃO FINANCEIRA DO OPERADOR", 14, y); y += 5;
      doc.setFontSize(9);

      const sfHeaders = ["", "", ...dados.situacaoFinanceira.map((s: any) => `${s.mes} (Dia ${s.ultimoDia})`)];
      while (sfHeaders.length < 5) sfHeaders.push("");
      const sfBody = [
        ["Caixa", "", ...dados.situacaoFinanceira.map((s: any) => fmt(s.caixa))],
        ["Bancos", "", ...dados.situacaoFinanceira.map((s: any) => fmt(s.bancos))],
        ["Outros Activos", "", ...dados.situacaoFinanceira.map((s: any) => fmt(s.outrosActivos))],
        ["Total", "", ...dados.situacaoFinanceira.map((s: any) => fmt(s.caixa + s.bancos + s.outrosActivos))],
      ];
      // Pad rows to 5 columns
      sfBody.forEach(row => { while (row.length < 5) row.push(""); });

      autoTable(doc, {
        startY: y,
        head: [sfHeaders],
        body: sfBody,
        theme: "grid", styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [200, 220, 240], textColor: 0, fontStyle: "bold", fontSize: 8 },
        margin: { left: 14 }
      });
      y = (doc as any).lastAutoTable.finalY + 10;

      if (editableData.observacoes) {
        doc.setFontSize(9); doc.setFont("helvetica", "bold");
        doc.text("Observações:", 14, y);
        doc.setFont("helvetica", "normal");
        doc.text(editableData.observacoes, 14, y + 5); y += 15;
      }

      y += 10;
      doc.line(pw / 2 - 40, y, pw / 2 + 40, y); y += 5;
      doc.setFont("helvetica", "italic"); doc.setFontSize(9);
      doc.text(`${config?.diretor_nome || "Representante Legal"} - ${config?.diretor_posicao || "Director Geral"}`, pw / 2, y, { align: "center" });

      doc.save(`Relatorio_Trimestral_BM_${dataInicio}_${dataFim}.pdf`);
      toast.success("Relatório PDF gerado com sucesso!");
    } catch (err) {
      console.error("Erro ao gerar PDF:", err);
      toast.error("Erro ao gerar PDF do relatório");
    }
  };

  const gerarExcel = async () => {
    try {
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet("Relatório Trimestral BM", { pageSetup: { paperSize: 9, fitToPage: true } });

      const totalCols = 5;
      const thin: Partial<ExcelJS.Borders> = { top: { style: "thin" }, bottom: { style: "thin" }, left: { style: "thin" }, right: { style: "thin" } };
      const hFill: ExcelJS.FillPattern = { type: "pattern", pattern: "solid", fgColor: { argb: "FFC8DCF0" } };
      const sFill: ExcelJS.FillPattern = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE8E8E8" } };

      try {
        const logoResponse = await fetch(BM_LOGO_URL);
        const logoBlob = await logoResponse.blob();
        const logoBuffer = await logoBlob.arrayBuffer();
        const logoId = wb.addImage({ buffer: logoBuffer, extension: "png" });
        ws.addImage(logoId, { tl: { col: 0, row: 0 }, ext: { width: 70, height: 70 } });
      } catch {}

      ws.columns = [{ width: 50 }, { width: 20 }, { width: 22 }, { width: 22 }, { width: 22 }];
      let r = 1;

      const addMergedRow = (text: string, opts?: { bold?: boolean; size?: number; fill?: ExcelJS.FillPattern }) => {
        const row = ws.addRow([text]);
        ws.mergeCells(r, 1, r, totalCols);
        row.getCell(1).alignment = { horizontal: "center", vertical: "middle" };
        row.getCell(1).font = { bold: opts?.bold || false, size: opts?.size || 10 };
        if (opts?.fill) row.getCell(1).fill = opts.fill;
        r++;
        return row;
      };

      const addDataRow = (cells: (string | number)[], opts?: { bold?: boolean; header?: boolean; mergeFrom?: number }) => {
        const row = ws.addRow(cells);
        for (let c = 1; c <= totalCols; c++) {
          const cell = row.getCell(c);
          cell.border = thin;
          cell.font = { size: 9, bold: opts?.bold || false };
          cell.alignment = { vertical: "middle", wrapText: true };
          if (opts?.header) {
            cell.fill = hFill;
            cell.font = { size: 9, bold: true };
            cell.alignment = { horizontal: "center", vertical: "middle", wrapText: true };
          }
        }
        if (opts?.mergeFrom) {
          ws.mergeCells(r, opts.mergeFrom, r, totalCols);
        }
        r++;
        return row;
      };

      // Header
      addMergedRow(editableData.titulo, { bold: true, size: 16 });
      addMergedRow(editableData.departamento, { size: 11 });
      addMergedRow(editableData.subtitulo1, { size: 10 });
      addMergedRow(editableData.subtitulo2, { size: 10 });
      ws.addRow([]); r++;
      addMergedRow("PERÍODO DE REPORTE:", { bold: true, size: 10 });
      addMergedRow(`DATA: ${new Date(dataInicio).toLocaleDateString('pt-PT')} à ${new Date(dataFim).toLocaleDateString('pt-PT')}`, { bold: true, size: 10 });
      ws.addRow([]); r++;

      // Capital próprio
      const cpRow = ws.addRow(["", "", "", fmt(dados.capitalInicial), ""]);
      cpRow.getCell(4).font = { bold: true, size: 10 };
      cpRow.getCell(4).border = thin;
      r++;

      addMergedRow("OPERADORES DE MICROCRÉDITO", { bold: true, size: 11, fill: sFill });
      
      const infoRows = [
        ["Denominação:", config?.nome_empresa || "N/A"],
        ["Endereço:", config?.endereco || "N/A"],
        ["Província:", config?.provincia || "N/A"],
        ["Telefone:", config?.telefone || "N/A"],
        [`Fax: ${config?.telefax || ''}`, `E-mail: ${config?.email || 'N/A'}`],
        ["Nº de Trabalhadores:", config?.num_trabalhadores?.toString() || "0"],
        ["Data de Início das Actividades:", config?.ano_inicio_atividades?.toString() || "N/A"],
        ["Nome do Operador:", config?.diretor_nome || "N/A"],
      ];
      infoRows.forEach(row => {
        const r2 = ws.addRow([row[0], row[1]]);
        ws.mergeCells(r, 2, r, totalCols);
        r2.getCell(1).font = { bold: true, size: 9 };
        r2.getCell(1).border = thin;
        r2.getCell(2).border = thin;
        r++;
      });
      ws.addRow([]); r++;

      // 2. INFORMAÇÕES
      addMergedRow("2. INFORMAÇÕES SOBRE A ACTIVIDADE", { bold: true, size: 11, fill: sFill });
      addMergedRow("2.1 CARTEIRA DE CRÉDITO", { bold: true, size: 10 });
      ws.addRow([]); r++;

      // 2.1.1
      addMergedRow("2.1.1 Volume de créditos - MZN", { bold: true, size: 10 });
      addDataRow(["", "", "Capital", "Juro", "TOTAL"], { header: true });
      addDataRow(["Montante de créditos concedidos no período", "", fmt(dados.totalConcedido), "", ""]);
      addDataRow(["Montante de créditos reembolsados no período", "", fmt(dados.totalReembolsado), fmt(dados.totalJuros), fmt(dados.totalReembolsadoTotal)]);
      addDataRow(["Montante de créditos abatidos no período", "", "0.00", "", ""]);
      addDataRow(["Montante da carteira de crédito activa/vigente:", "", fmt(dados.carteiraAtiva), "", ""]);
      addDataRow(["Montante da carteira em risco", "", fmt(dados.carteiraRisco), "", ""]);
      ws.addRow([]); r++;

      // 2.1.2
      addMergedRow("2.1.2 Número de créditos", { bold: true, size: 10 });
      addDataRow(["Número de créditos concedidos no período", "", "", "", dados.numConcedidos.toString()]);
      addDataRow(["Número de créditos reembolsados no período", "", "", "", dados.numReembolsados.toString()]);
      ws.addRow([]); r++;

      // 2.1.3
      addMergedRow("2.1.3 Créditos concedidos por sector de actividade/finalidade", { bold: true, size: 10 });
      addDataRow(["Actividade/finalidade", "", "", "", "Montante de créditos concedidos no período"], { header: true });
      Object.entries(dados.montantePorFinalidade).forEach(([k, v]) => {
        addDataRow([k, "", "", "", fmt(v as number)]);
      });
      addDataRow(["TOTAL", "", "", "", fmt(dados.totalFinalidade)], { bold: true });
      ws.addRow([]); r++;

      // 2.1.4
      addMergedRow("2.1.4 Carteira de Clientes", { bold: true, size: 10 });
      addDataRow(["Descrição", "", "", "", "Nº de clientes activos"], { header: true });
      addDataRow(["Homens", "", "", "", dados.homens.toString()]);
      addDataRow(["Mulheres", "", "", "", dados.mulheres.toString()]);
      addDataRow(["Outros", "", "", "", dados.outrosGenero.toString()]);
      addDataRow(["Total", "", "", "", dados.totalClientesAtivos.toString()], { bold: true });
      ws.addRow([]); r++;

      // 2.1.5
      addMergedRow("2.1.5 Estrutura da Carteira em Risco", { bold: true, size: 10 });
      addDataRow(["Classe de Risco", "", "Capital", "Juro", "TOTAL"], { header: true });
      addDataRow(["Classe I (de 1 até 30 dias)", "", fmt(dados.classe1.capital), fmt(dados.classe1.juros), fmt(dados.classe1.total)]);
      addDataRow(["Classe II (de 31 até 90 dias)", "", fmt(dados.classe2.capital), fmt(dados.classe2.juros), fmt(dados.classe2.total)]);
      addDataRow(["Classe III (de 91 a 365 dias)", "", fmt(dados.classe3.capital), fmt(dados.classe3.juros), fmt(dados.classe3.total)]);
      addDataRow(["Classe IV (mais de 365 dias)", "", fmt(dados.classe4.capital), fmt(dados.classe4.juros), fmt(dados.classe4.total)]);
      addDataRow(["Total", "", fmt(dados.classeTotal.capital), fmt(dados.classeTotal.juros), fmt(dados.classeTotal.total)], { bold: true });
      ws.addRow([]); r++;

      // 2.2
      addMergedRow("2.2 TAXAS DE JURO E PRAZOS DE VENCIMENTO", { bold: true, size: 10, fill: sFill });
      addDataRow(["Descrição", "", "", "Mínimo", "Máximo"], { header: true });
      addDataRow(["Taxa de juro mensal", "", "", `${dados.taxaMin}%`, `${dados.taxaMax}%`]);
      addDataRow(["Prazo (Meses)", "", "", dados.prazoMin.toString(), dados.prazoMax.toString()]);
      ws.addRow([]); r++;

      // 2.3
      addMergedRow("2.3 FONTES DE FINANCIAMENTO DA INSTITUIÇÃO", { bold: true, size: 10, fill: sFill });
      addDataRow(["Capitais Próprios", "", fmt(dados.capitalInicial), "", ""]);
      addDataRow(["Capitais Alheios", "", "", "", ""]);
      addDataRow(["  Nacionais", "", fmt(Number(config?.capitais_alheios_nacionais || 0)), "", ""]);
      addDataRow(["  Estrangeiros", "", fmt(Number(config?.capitais_alheios_estrangeiros || 0)), "", ""]);
      addDataRow(["Total", "", fmt(dados.capitalInicial + Number(config?.capitais_alheios_nacionais || 0) + Number(config?.capitais_alheios_estrangeiros || 0)), "", ""], { bold: true });
      ws.addRow([]); r++;

      // 2.4
      addMergedRow("2.4 FINANCIAMENTOS DO PERÍODO", { bold: true, size: 10, fill: sFill });
      addDataRow(["Empréstimos obtidos no período", "", fmt(Number(config?.emprestimos_obtidos || 0)), "", ""]);
      addDataRow(["Donativos obtidos no período", "", fmt(Number(config?.donativos_obtidos || 0)), "", ""]);
      addDataRow(["Aumento do capital com recursos próprios", "", fmt(Number(config?.aumento_capital_proprio || 0)), "", ""]);
      addDataRow(["Total", "", fmt(Number(config?.emprestimos_obtidos || 0) + Number(config?.donativos_obtidos || 0) + Number(config?.aumento_capital_proprio || 0)), "", ""], { bold: true });
      ws.addRow([]); r++;

      // 2.5
      addMergedRow("2.5 CAPITAL", { bold: true, size: 10, fill: sFill });
      addDataRow(["Inicial", "", fmt(dados.capitalInicial), "", ""]);
      addDataRow(["Actual", "", fmt(dados.capitalAtual), "", ""]);
      ws.addRow([]); r++;

      // 3. Situação Financeira
      addMergedRow("3. SITUAÇÃO FINANCEIRA DO OPERADOR", { bold: true, size: 11, fill: sFill });
      const sfHead = ["", "", ...dados.situacaoFinanceira.map((s: any) => `${s.mes} (Dia ${s.ultimoDia})`)];
      while (sfHead.length < 5) sfHead.push("");
      addDataRow(sfHead, { header: true });

      const sfRows = [
        ["Caixa", "", ...dados.situacaoFinanceira.map((s: any) => fmt(s.caixa))],
        ["Bancos", "", ...dados.situacaoFinanceira.map((s: any) => fmt(s.bancos))],
        ["Outros Activos", "", ...dados.situacaoFinanceira.map((s: any) => fmt(s.outrosActivos))],
        ["Total", "", ...dados.situacaoFinanceira.map((s: any) => fmt(s.caixa + s.bancos + s.outrosActivos))],
      ];
      sfRows.forEach(row => { while (row.length < 5) row.push(""); addDataRow(row); });

      // Signature
      ws.addRow([]); r++; ws.addRow([]); r++;
      const sigLine = ws.addRow(["_______________________________________"]);
      ws.mergeCells(r, 1, r, totalCols);
      sigLine.getCell(1).alignment = { horizontal: "center" };
      r++;
      const sigLabel = ws.addRow([`${config?.diretor_nome || "Representante Legal"} - ${config?.diretor_posicao || "Director Geral"}`]);
      ws.mergeCells(r, 1, r, totalCols);
      sigLabel.getCell(1).alignment = { horizontal: "center" };
      sigLabel.getCell(1).font = { italic: true, size: 10 };

      const buffer = await wb.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      saveAs(blob, `Relatorio_Trimestral_BM_${dataInicio}_${dataFim}.xlsx`);
      toast.success("Excel gerado com sucesso!");
    } catch (err) {
      console.error("Erro ao gerar Excel:", err);
      toast.error("Erro ao gerar Excel do relatório");
    }
  };

  const gerarWord = async () => {
    try {
      const cellBorders = {
        top: { style: BorderStyle.SINGLE, size: 1 },
        bottom: { style: BorderStyle.SINGLE, size: 1 },
        left: { style: BorderStyle.SINGLE, size: 1 },
        right: { style: BorderStyle.SINGLE, size: 1 },
      };

      const makeRow = (cells: string[], bold?: boolean) => new TableRow({
        children: cells.map((text, i) => new TableCell({
          children: [new Paragraph({ children: [new TextRun({ text, bold: bold || i === 0, size: 18 })] })],
          borders: cellBorders,
        }))
      });

      const makeSection = (title: string) => new Paragraph({ 
        spacing: { before: 200, after: 100 },
        children: [new TextRun({ text: title, bold: true, size: 22 })] 
      });

      const doc = new Document({
        sections: [{
          children: [
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: editableData.titulo, bold: true, size: 28 })] }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: editableData.departamento, size: 20 })] }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: editableData.subtitulo1, size: 18 })] }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: editableData.subtitulo2, size: 18 })] }),
            new Paragraph({ text: "" }),
            new Paragraph({ children: [new TextRun({ text: `PERÍODO DE REPORTE: ${new Date(dataInicio).toLocaleDateString('pt-PT')} à ${new Date(dataFim).toLocaleDateString('pt-PT')}`, bold: true, size: 20 })] }),
            new Paragraph({ text: "" }),
            makeSection("OPERADORES DE MICROCRÉDITO"),
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              rows: [
                makeRow(["Denominação:", config?.nome_empresa || "N/A"]),
                makeRow(["Endereço:", config?.endereco || "N/A"]),
                makeRow(["Província:", config?.provincia || "N/A"]),
                makeRow(["Telefone:", config?.telefone || "N/A"]),
                makeRow(["E-mail:", config?.email || "N/A"]),
                makeRow(["Nº de Trabalhadores:", config?.num_trabalhadores?.toString() || "0"]),
                makeRow(["Data de Início das Actividades:", config?.ano_inicio_atividades?.toString() || "N/A"]),
                makeRow(["Nome do Operador:", config?.diretor_nome || "N/A"]),
              ]
            }),
            new Paragraph({ text: "" }),
            makeSection("2. INFORMAÇÕES SOBRE A ACTIVIDADE"),
            makeSection("2.1.1 Volume de créditos - MZN"),
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              rows: [
                makeRow(["", "Capital", "Juro", "TOTAL"], true),
                makeRow(["Montante de créditos concedidos", fmt(dados.totalConcedido), "", ""]),
                makeRow(["Montante de créditos reembolsados", fmt(dados.totalReembolsado), fmt(dados.totalJuros), fmt(dados.totalReembolsadoTotal)]),
                makeRow(["Montante de créditos abatidos", "0.00", "", ""]),
                makeRow(["Carteira de crédito activa/vigente", fmt(dados.carteiraAtiva), "", ""]),
                makeRow(["Carteira em risco", fmt(dados.carteiraRisco), "", ""]),
              ]
            }),
            new Paragraph({ text: "" }),
            makeSection("2.1.2 Número de créditos"),
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              rows: [
                makeRow(["Créditos concedidos no período", dados.numConcedidos.toString()]),
                makeRow(["Créditos reembolsados no período", dados.numReembolsados.toString()]),
              ]
            }),
            new Paragraph({ text: "" }),
            makeSection("2.1.4 Carteira de Clientes"),
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              rows: [
                makeRow(["Descrição", "Nº de clientes activos"], true),
                makeRow(["Homens", dados.homens.toString()]),
                makeRow(["Mulheres", dados.mulheres.toString()]),
                makeRow(["Outros", dados.outrosGenero.toString()]),
                makeRow(["Total", dados.totalClientesAtivos.toString()]),
              ]
            }),
            new Paragraph({ text: "" }),
            makeSection("2.1.5 Estrutura da Carteira em Risco"),
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              rows: [
                makeRow(["Classe de Risco", "Capital", "Juro", "TOTAL"], true),
                makeRow(["Classe I (1 a 30 dias)", fmt(dados.classe1.capital), fmt(dados.classe1.juros), fmt(dados.classe1.total)]),
                makeRow(["Classe II (31 a 90 dias)", fmt(dados.classe2.capital), fmt(dados.classe2.juros), fmt(dados.classe2.total)]),
                makeRow(["Classe III (91 a 365 dias)", fmt(dados.classe3.capital), fmt(dados.classe3.juros), fmt(dados.classe3.total)]),
                makeRow(["Classe IV (mais de 365 dias)", fmt(dados.classe4.capital), fmt(dados.classe4.juros), fmt(dados.classe4.total)]),
                makeRow(["Total", fmt(dados.classeTotal.capital), fmt(dados.classeTotal.juros), fmt(dados.classeTotal.total)]),
              ]
            }),
            new Paragraph({ text: "" }),
            makeSection("2.2 TAXAS DE JURO E PRAZOS"),
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              rows: [
                makeRow(["Descrição", "Mínimo", "Máximo"], true),
                makeRow(["Taxa de juro mensal", `${dados.taxaMin}%`, `${dados.taxaMax}%`]),
                makeRow(["Prazo (Meses)", dados.prazoMin.toString(), dados.prazoMax.toString()]),
              ]
            }),
            new Paragraph({ text: "" }),
            makeSection("2.5 CAPITAL"),
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              rows: [
                makeRow(["Inicial", fmt(dados.capitalInicial)]),
                makeRow(["Actual", fmt(dados.capitalAtual)]),
              ]
            }),
            new Paragraph({ text: "" }),
            makeSection("3. SITUAÇÃO FINANCEIRA DO OPERADOR"),
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              rows: [
                makeRow(["", ...dados.situacaoFinanceira.map((s: any) => `${s.mes} (Dia ${s.ultimoDia})`)], true),
                makeRow(["Caixa", ...dados.situacaoFinanceira.map((s: any) => fmt(s.caixa))]),
                makeRow(["Bancos", ...dados.situacaoFinanceira.map((s: any) => fmt(s.bancos))]),
                makeRow(["Outros Activos", ...dados.situacaoFinanceira.map((s: any) => fmt(s.outrosActivos))]),
                makeRow(["Total", ...dados.situacaoFinanceira.map((s: any) => fmt(s.caixa + s.bancos + s.outrosActivos))]),
              ]
            }),
            new Paragraph({ text: "" }), new Paragraph({ text: "" }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "_______________________________________", size: 20 })] }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: `${config?.diretor_nome || "Representante Legal"} - ${config?.diretor_posicao || "Director Geral"}`, italics: true, size: 18 })] }),
          ]
        }]
      });

      const blob = await Packer.toBlob(doc);
      saveAs(blob, `Relatorio_Trimestral_BM_${dataInicio}_${dataFim}.docx`);
      toast.success("Relatório Word gerado com sucesso!");
    } catch (err) {
      console.error("Erro ao gerar Word:", err);
      toast.error("Erro ao gerar Word do relatório");
    }
  };

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <FileText className="h-6 w-6 text-primary" />
        <h2 className="text-2xl font-bold">Relatório Trimestral BM</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <Label htmlFor="data-inicio-trim">Data Início</Label>
          <Input id="data-inicio-trim" type="date" value={dataInicio} onChange={(e) => setDataInicio(e.target.value)} />
        </div>
        <div>
          <Label htmlFor="data-fim-trim">Data Fim</Label>
          <Input id="data-fim-trim" type="date" value={dataFim} onChange={(e) => setDataFim(e.target.value)} />
        </div>
        <div className="flex items-end gap-2">
          <Button onClick={carregarDados} disabled={loading} className="flex-1">
            {loading ? "Carregando..." : "Carregar Dados"}
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        <Button onClick={() => abrirDialogExportacao("excel")} disabled={!dados} variant="outline">
          <FileSpreadsheet className="h-4 w-4 mr-2" />Excel
        </Button>
        <Button onClick={() => abrirDialogExportacao("pdf")} disabled={!dados} variant="outline">
          <Download className="h-4 w-4 mr-2" />PDF
        </Button>
        <Button onClick={() => abrirDialogExportacao("word")} disabled={!dados} variant="outline">
          <FileType className="h-4 w-4 mr-2" />Word
        </Button>
      </div>

      {dados && (
        <div className="border rounded-lg p-4 bg-muted space-y-2">
          <p className="text-sm font-medium">Resumo do Período:</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div><p className="text-muted-foreground">Créditos Concedidos:</p><p className="font-semibold">{dados.numConcedidos}</p></div>
            <div><p className="text-muted-foreground">Total Concedido:</p><p className="font-semibold">{fmt(dados.totalConcedido)} MZN</p></div>
            <div><p className="text-muted-foreground">Total Reembolsado:</p><p className="font-semibold">{fmt(dados.totalReembolsado)} MZN</p></div>
            <div><p className="text-muted-foreground">Carteira Ativa:</p><p className="font-semibold">{fmt(dados.carteiraAtiva)} MZN</p></div>
          </div>
        </div>
      )}

      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="h-5 w-5" />Editar antes de exportar ({exportType.toUpperCase()})
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div><Label>Título Principal</Label><Input value={editableData.titulo} onChange={(e) => setEditableData({...editableData, titulo: e.target.value})} /></div>
            <div><Label>Departamento</Label><Input value={editableData.departamento} onChange={(e) => setEditableData({...editableData, departamento: e.target.value})} /></div>
            <div><Label>Subtítulo 1</Label><Input value={editableData.subtitulo1} onChange={(e) => setEditableData({...editableData, subtitulo1: e.target.value})} /></div>
            <div><Label>Subtítulo 2</Label><Input value={editableData.subtitulo2} onChange={(e) => setEditableData({...editableData, subtitulo2: e.target.value})} /></div>
            <div><Label>Observações</Label><Textarea value={editableData.observacoes} onChange={(e) => setEditableData({...editableData, observacoes: e.target.value})} placeholder="Observações..." rows={4} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>Cancelar</Button>
            <Button onClick={confirmarExportacao}><Download className="h-4 w-4 mr-2" />Exportar {exportType.toUpperCase()}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
