import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Download, Share2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import jsPDF from "jspdf";
import { gerarTabelaAmortizacao, type ParcelaAmortizacao } from "@/lib/amortization";

interface ReciboVencidoProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  emprestimo: {
    id: string;
    cliente_id: string;
    valor: number;
    taxa_juros: number;
    taxa_mora: number;
    duracao_meses: number;
    tipo_juros: string;
    modalidade_reembolso: string;
    sistema_amortizacao: string;
    data_desembolso: string;
    data_reembolso: string;
    valor_total: number;
    valor_pago: number;
    clientes: { nome_completo: string };
  };
}

interface Pagamento {
  id: string;
  valor: number;
  data_pagamento: string;
  observacoes: string;
  tipo?: string;
}

export function ReciboVencido({ open, onOpenChange, emprestimo }: ReciboVencidoProps) {
  const [config, setConfig] = useState<any>(null);
  const [cliente, setCliente] = useState<any>(null);
  const [pagamentos, setPagamentos] = useState<Pagamento[]>([]);
  const [tipoJurosMora, setTipoJurosMora] = useState<"simples" | "sobreSaldo">("sobreSaldo");

  useEffect(() => {
    if (open) {
      carregarDados();
    }
  }, [open, emprestimo.id]);

  const carregarDados = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) return;

    const [configRes, clienteRes, pagRes] = await Promise.all([
      supabase.from("configuracoes_empresa").select("*").eq("user_id", session.user.id).single(),
      supabase.from("clientes").select("*").eq("id", emprestimo.cliente_id).single(),
      supabase.from("pagamentos").select("*").eq("emprestimo_id", emprestimo.id).order("data_pagamento", { ascending: true }),
    ]);

    setConfig(configRes.data);
    setCliente(clienteRes.data);
    setPagamentos(pagRes.data || []);
  };

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("pt-MZ", { style: "currency", currency: "MZN" }).format(value);

  const getDiasVencidos = () => {
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    const dataReemb = new Date(emprestimo.data_reembolso);
    dataReemb.setHours(0, 0, 0, 0);
    return Math.max(0, Math.floor((hoje.getTime() - dataReemb.getTime()) / (1000 * 60 * 60 * 24)));
  };

  // Tabela de amortização — ÚNICA fonte de verdade para total/saldo (evita divergir do mapa)
  const gerarParcelas = (): ParcelaAmortizacao[] => {
    try {
      return gerarTabelaAmortizacao(
        emprestimo.valor,
        emprestimo.taxa_juros,
        emprestimo.duracao_meses,
        emprestimo.modalidade_reembolso || "mensal",
        emprestimo.data_desembolso,
        (emprestimo.sistema_amortizacao as "price" | "sac") || "price",
        emprestimo.tipo_juros || "Simples"
      );
    } catch {
      return [];
    }
  };

  // Total recalculado a partir da soma das parcelas (coerente com o Mapa exibido).
  // Fallback para valor_total se a geração falhar.
  const getTotalCalculado = () => {
    const soma = gerarParcelas().reduce((s, p) => s + Number(p.prestacao || 0), 0);
    return soma > 0 ? soma : Number(emprestimo.valor_total || 0);
  };

  const getSaldoDevedor = () => {
    const pagamentosCapital = pagamentos
      .filter((p) => p.tipo !== "Juros Mora")
      .reduce((s, p) => s + Number(p.valor || 0), 0);
    return Math.max(0, getTotalCalculado() - pagamentosCapital);
  };

  const getJurosMoraDiario = () => {
    const taxaDiaria = (emprestimo.taxa_mora || 0) / 100;
    const base = tipoJurosMora === "simples" ? emprestimo.valor : getSaldoDevedor();
    return base * taxaDiaria;
  };

  const calcularJurosMora = () => {
    const dias = getDiasVencidos();
    return getJurosMoraDiario() * dias;
  };

  const classificarParcelas = () => {
    const parcelas = gerarParcelas();
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);

    let valorAcumuladoPago = emprestimo.valor_pago;
    const resultado = parcelas.map((p) => {
      const dataVenc = new Date(p.dataVencimento);
      dataVenc.setHours(0, 0, 0, 0);

      let status: "paga" | "em_divida" | "por_pagar";
      if (valorAcumuladoPago >= p.prestacao) {
        status = "paga";
        valorAcumuladoPago -= p.prestacao;
      } else if (dataVenc <= hoje) {
        status = "em_divida";
        valorAcumuladoPago = Math.max(0, valorAcumuladoPago - p.prestacao);
      } else {
        status = "por_pagar";
      }

      return { ...p, status };
    });

    return resultado;
  };

  const gerarPDF = async () => {
    try {
      const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4", compress: true });
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const marginLeft = 12;
      const marginRight = pageWidth - 12;
      const contentWidth = marginRight - marginLeft;

      let y = 10;

      // Logo
      if (config?.logo_url) {
        try {
          const res = await fetch(config.logo_url);
          const blob = await res.blob();
          const dataUrl: string = await new Promise((resolve) => {
            const r = new FileReader();
            r.onloadend = () => resolve(r.result as string);
            r.readAsDataURL(blob);
          });
          const fmt = (dataUrl.match(/data:image\/(\w+);/)?.[1] || "png").toUpperCase();
          doc.addImage(dataUrl, fmt, pageWidth / 2 - 10, y, 20, 20);
          y += 22;
        } catch (e) {
          console.warn("Logo não carregado:", e);
        }
      }

      // Header
      if (config) {
        doc.setFontSize(12);
        doc.setFont("helvetica", "bold");
        doc.text(config.nome_empresa || "Empresa", pageWidth / 2, y, { align: "center" });
        y += 5;
        doc.setFontSize(7);
        doc.setFont("helvetica", "normal");
        if (config.endereco) { doc.text(config.endereco, pageWidth / 2, y, { align: "center" }); y += 3; }
        const info = [config.nuit ? `NUIT: ${config.nuit}` : "", config.telefone ? `Tel: ${config.telefone}` : ""].filter(Boolean).join(" | ");
        if (info) { doc.text(info, pageWidth / 2, y, { align: "center" }); y += 3; }
      }

      y += 2;
      doc.setLineWidth(0.3);
      doc.line(marginLeft, y, marginRight, y);
      y += 5;

      // Title
      doc.setFontSize(11);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(200, 0, 0);
      doc.text("RECIBO DE DÍVIDA - EMPRÉSTIMO VENCIDO", pageWidth / 2, y, { align: "center" });
      doc.setTextColor(0, 0, 0);
      y += 6;

      // Date & Ref
      doc.setFontSize(7);
      doc.setFont("helvetica", "normal");
      doc.text(`Ref: EMP-${emprestimo.id.substring(0, 8).toUpperCase()}`, marginLeft, y);
      doc.text(`Data Emissão: ${new Date().toLocaleDateString("pt-PT")}`, marginRight, y, { align: "right" });
      y += 5;

      // Client
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.text("DADOS DO CLIENTE", marginLeft, y);
      y += 4;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(7);
      doc.text(`Nome: ${cliente?.nome_completo || emprestimo.clientes?.nome_completo}`, marginLeft, y);
      doc.text(`Telefone: ${cliente?.telefone || "-"}`, marginLeft + contentWidth / 2, y);
      y += 5;

      // Loan summary
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.text("RESUMO DO EMPRÉSTIMO", marginLeft, y);
      y += 4;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(7);
      const col2 = marginLeft + contentWidth / 3;
      const col3 = marginLeft + (contentWidth * 2) / 3;
      doc.text(`Capital: ${formatCurrency(emprestimo.valor)}`, marginLeft, y);
      doc.text(`Taxa Juros: ${emprestimo.taxa_juros}%`, col2, y);
      doc.text(`Duração: ${emprestimo.duracao_meses} meses`, col3, y);
      y += 3.5;
      doc.text(`Data Desembolso: ${new Date(emprestimo.data_desembolso).toLocaleDateString("pt-PT")}`, marginLeft, y);
      doc.text(`Data Reembolso: ${new Date(emprestimo.data_reembolso).toLocaleDateString("pt-PT")}`, col2, y);
      doc.text(`Total: ${formatCurrency(getTotalCalculado())}`, col3, y);
      y += 5;

      // Overdue info box - cálculo detalhado de juros de mora
      const diasVencidos = getDiasVencidos();
      const jurosMoraDiario = getJurosMoraDiario();
      const jurosMora = calcularJurosMora();
      const saldoDevedor = getSaldoDevedor();
      const totalComMora = saldoDevedor + jurosMora;
      const baseLabel = tipoJurosMora === "simples" ? "capital inicial" : "saldo devedor";

      doc.setFillColor(255, 235, 235);
      doc.rect(marginLeft, y, contentWidth, 36, "F");
      doc.setDrawColor(200, 0, 0);
      doc.rect(marginLeft, y, contentWidth, 36);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.setTextColor(200, 0, 0);
      doc.text("[!] SITUACAO DE ATRASO E CALCULO DE JUROS DE MORA", marginLeft + 3, y + 4);
      doc.setTextColor(0, 0, 0);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(7);

      // Período da mora
      const dataInicioMora = new Date(emprestimo.data_reembolso);
      dataInicioMora.setDate(dataInicioMora.getDate() + 1);
      const dataFimMora = new Date();
      const fmtData = (d: Date) => d.toLocaleDateString("pt-MZ");
      doc.text(`Início Mora: ${fmtData(dataInicioMora)}`, marginLeft + 3, y + 9);
      doc.text(`Fim Mora (hoje): ${fmtData(dataFimMora)}`, col2, y + 9);
      doc.text(`Dias Vencidos: ${diasVencidos}`, col3, y + 9);

      doc.text(`Capital Pago: ${formatCurrency(emprestimo.valor_total - saldoDevedor)}`, marginLeft + 3, y + 13);
      doc.text(`Saldo Devedor: ${formatCurrency(saldoDevedor)}`, col2, y + 13);
      doc.text(`Base de Cálculo: ${baseLabel}`, col3, y + 13);

      doc.text(`Taxa Mora: ${emprestimo.taxa_mora || 0}% / dia`, marginLeft + 3, y + 17);
      doc.text(`Formula: Saldo x Taxa x Dias`, col2, y + 17);

      doc.setFont("helvetica", "bold");
      doc.text(`Juros Mora DIÁRIO: ${formatCurrency(jurosMoraDiario)}`, marginLeft + 3, y + 22);
      doc.text(`Juros Mora TOTAL (${diasVencidos} dias): ${formatCurrency(jurosMora)}`, col2, y + 22);

      doc.setFontSize(9);
      doc.setTextColor(200, 0, 0);
      doc.text(`TOTAL A PAGAR (Saldo + Mora): ${formatCurrency(totalComMora)}`, marginLeft + 3, y + 30);
      doc.setTextColor(0, 0, 0);
      y += 40;

      // Payment history
      if (pagamentos.length > 0) {
        doc.setFont("helvetica", "bold");
        doc.setFontSize(8);
        doc.text("HISTÓRICO DE PAGAMENTOS EFECTUADOS", marginLeft, y);
        y += 4;

        doc.setFillColor(220, 220, 220);
        doc.rect(marginLeft, y - 1, contentWidth, 4, "F");
        doc.setFontSize(6);
        doc.text("Nº", marginLeft + 2, y + 2);
        doc.text("Data Pagamento", marginLeft + 12, y + 2);
        doc.text("Valor", marginLeft + contentWidth * 0.45, y + 2);
        doc.text("Tipo", marginLeft + contentWidth * 0.65, y + 2);
        doc.text("Saldo Após", marginRight - 2, y + 2, { align: "right" });
        y += 5;

        doc.setFont("helvetica", "normal");
        let saldoCorrente = emprestimo.valor_total;
        for (let i = 0; i < pagamentos.length; i++) {
          const pag = pagamentos[i];
          if (pag.tipo !== "Juros Mora") saldoCorrente -= pag.valor;
          if (y > pageHeight - 30) {
            doc.addPage();
            y = 15;
          }
          doc.text(`${i + 1}`, marginLeft + 2, y);
          doc.text(new Date(pag.data_pagamento).toLocaleDateString("pt-PT"), marginLeft + 12, y);
          doc.text(formatCurrency(pag.valor), marginLeft + contentWidth * 0.45, y);
          doc.text(pag.tipo || "Parcela", marginLeft + contentWidth * 0.65, y);
          doc.text(formatCurrency(Math.max(0, saldoCorrente)), marginRight - 2, y, { align: "right" });
          y += 3.5;
        }
        y += 2;
      }

      // Amortization table - installment status
      const parcelasClassificadas = classificarParcelas();
      if (parcelasClassificadas.length > 0) {
        if (y > pageHeight - 40) { doc.addPage(); y = 15; }

        doc.setFont("helvetica", "bold");
        doc.setFontSize(8);
        doc.text("MAPA DE PRESTAÇÕES", marginLeft, y);
        y += 4;

        doc.setFillColor(220, 220, 220);
        doc.rect(marginLeft, y - 1, contentWidth, 4, "F");
        doc.setFontSize(6);
        doc.text("Nº", marginLeft + 2, y + 2);
        doc.text("Data Vencimento", marginLeft + 12, y + 2);
        doc.text("Prestação", marginLeft + contentWidth * 0.35, y + 2);
        doc.text("Capital", marginLeft + contentWidth * 0.5, y + 2);
        doc.text("Juros", marginLeft + contentWidth * 0.65, y + 2);
        doc.text("Status", marginRight - 2, y + 2, { align: "right" });
        y += 5;

        doc.setFont("helvetica", "normal");
        for (const p of parcelasClassificadas) {
          if (y > pageHeight - 20) { doc.addPage(); y = 15; }

          // Color by status
          if (p.status === "paga") doc.setTextColor(0, 128, 0);
          else if (p.status === "em_divida") doc.setTextColor(200, 0, 0);
          else doc.setTextColor(100, 100, 100);

          doc.text(`${p.numero}`, marginLeft + 2, y);
          doc.text(new Date(p.dataVencimento).toLocaleDateString("pt-PT"), marginLeft + 12, y);
          doc.text(formatCurrency(p.prestacao), marginLeft + contentWidth * 0.35, y);
          doc.text(formatCurrency(p.amortizacao), marginLeft + contentWidth * 0.5, y);
          doc.text(formatCurrency(p.juros), marginLeft + contentWidth * 0.65, y);
          const statusLabel = p.status === "paga" ? "Paga" : p.status === "em_divida" ? "Em Divida" : "Por Pagar";
          doc.text(statusLabel, marginRight - 2, y, { align: "right" });
          y += 3.5;
        }

        doc.setTextColor(0, 0, 0);
        y += 2;

        // Legend
        doc.setFontSize(6);
        doc.setFont("helvetica", "italic");
        doc.setTextColor(0, 128, 0);
        doc.text("Paga", marginLeft, y);
        doc.setTextColor(200, 0, 0);
        doc.text("Em Divida", marginLeft + 25, y);
        doc.setTextColor(100, 100, 100);
        doc.text("Por Pagar", marginLeft + 55, y);
        doc.setTextColor(0, 0, 0);
        y += 5;

        // Summary
        const pagas = parcelasClassificadas.filter((p) => p.status === "paga");
        const emDivida = parcelasClassificadas.filter((p) => p.status === "em_divida");
        const porPagar = parcelasClassificadas.filter((p) => p.status === "por_pagar");

        doc.setFont("helvetica", "bold");
        doc.setFontSize(7);
        doc.text(`Prestações Pagas: ${pagas.length}`, marginLeft, y);
        doc.text(`Em Dívida: ${emDivida.length}`, col2, y);
        doc.text(`Por Pagar: ${porPagar.length}`, col3, y);
        y += 5;
      }

      // Footer
      if (y > pageHeight - 25) { doc.addPage(); y = 15; }
      doc.setLineWidth(0.2);
      doc.line(marginLeft, y, marginRight, y);
      y += 4;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(6);
      doc.text("Este documento serve como comprovativo da situação de dívida do empréstimo acima referido.", pageWidth / 2, y, { align: "center" });
      y += 8;

      // Signatures
      const sigWidth = contentWidth / 3;
      doc.setLineWidth(0.2);
      doc.line(marginLeft + 10, y, marginLeft + 10 + sigWidth, y);
      doc.line(marginRight - 10 - sigWidth, y, marginRight - 10, y);
      y += 3;
      doc.setFontSize(6);
      doc.text("Assinatura do Cliente", marginLeft + 10 + sigWidth / 2, y, { align: "center" });
      doc.text("Assinatura da Empresa", marginRight - 10 - sigWidth / 2, y, { align: "center" });

      doc.save(`Recibo_Divida_${emprestimo.id.substring(0, 8).toUpperCase()}.pdf`);
      toast.success("Recibo de dívida gerado com sucesso!");
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
      toast.error("Erro ao gerar recibo PDF");
    }
  };

  const diasVencidos = getDiasVencidos();
  const jurosMoraDiario = getJurosMoraDiario();
  const jurosMora = calcularJurosMora();
  const saldoDevedor = getSaldoDevedor();
  const capitalPago = emprestimo.valor_total - saldoDevedor;
  const parcelasClassificadas = classificarParcelas();
  const pagas = parcelasClassificadas.filter((p) => p.status === "paga");
  const emDivida = parcelasClassificadas.filter((p) => p.status === "em_divida");
  const porPagar = parcelasClassificadas.filter((p) => p.status === "por_pagar");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-destructive">Recibo de Dívida - Empréstimo Vencido</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Tipo de juros de mora */}
          <div className="bg-muted p-4 rounded-lg">
            <Label className="font-bold text-sm mb-3 block">Tipo de Juros de Mora</Label>
            <RadioGroup value={tipoJurosMora} onValueChange={(v) => setTipoJurosMora(v as "simples" | "sobreSaldo")} className="flex flex-col sm:flex-row gap-4">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="simples" id="mora-simples" />
                <Label htmlFor="mora-simples" className="text-sm cursor-pointer">
                  Juros Simples (sobre capital inicial)
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="sobreSaldo" id="mora-saldo" />
                <Label htmlFor="mora-saldo" className="text-sm cursor-pointer">
                  Juros sobre Saldo Devedor
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Resumo */}
          <div className="bg-destructive/10 border border-destructive/20 p-4 rounded-lg space-y-3">
            <p className="font-bold text-destructive">⚠ Vencido há {diasVencidos} {diasVencidos === 1 ? "dia" : "dias"}</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
              <div>
                <p className="text-muted-foreground">Capital Inicial</p>
                <p className="font-bold">{formatCurrency(emprestimo.valor)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Capital Pago</p>
                <p className="font-bold text-green-600">{formatCurrency(capitalPago)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Saldo Devedor</p>
                <p className="font-bold">{formatCurrency(saldoDevedor)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Taxa Mora</p>
                <p className="font-bold">{emprestimo.taxa_mora || 0}% / dia</p>
              </div>
            </div>

            {/* Cálculo detalhado de juros de mora */}
            <div className="bg-background/50 border border-destructive/30 rounded-lg p-3 space-y-2">
              <p className="text-xs font-semibold text-destructive uppercase">Cálculo dos Juros de Mora (diário)</p>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <p className="text-muted-foreground">Início Mora</p>
                  <p className="font-medium">{(() => { const d = new Date(emprestimo.data_reembolso); d.setDate(d.getDate()+1); return d.toLocaleDateString("pt-MZ"); })()}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Fim Mora (hoje)</p>
                  <p className="font-medium">{new Date().toLocaleDateString("pt-MZ")}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Dias</p>
                  <p className="font-medium">{diasVencidos}</p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Fórmula: Saldo Devedor × Taxa Mora (%/dia) × Dias
              </p>
              <p className="text-xs text-muted-foreground font-mono">
                {formatCurrency(tipoJurosMora === "simples" ? emprestimo.valor : saldoDevedor)} × {(emprestimo.taxa_mora || 0)}% × {diasVencidos} dia(s)
              </p>
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <p className="text-xs text-muted-foreground">Juros Mora DIÁRIO</p>
                  <p className="font-bold text-destructive">{formatCurrency(jurosMoraDiario)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Juros Mora TOTAL ({diasVencidos} dias)</p>
                  <p className="font-bold text-destructive">{formatCurrency(jurosMora)}</p>
                </div>
              </div>
            </div>

            <div className="border-t pt-2 mt-2">
              <p className="text-sm text-muted-foreground">Total a Pagar (Saldo Devedor + Juros de Mora)</p>
              <p className="font-bold text-xl text-destructive">{formatCurrency(saldoDevedor + jurosMora)}</p>
            </div>
          </div>

          {/* Mapa de Prestações */}
          {parcelasClassificadas.length > 0 && (
            <div>
              <h3 className="font-bold text-sm mb-2">Mapa de Prestações</h3>
              <div className="overflow-x-auto max-h-60 overflow-y-auto border rounded-lg">
                <table className="w-full text-xs">
                  <thead className="bg-muted sticky top-0">
                    <tr>
                      <th className="p-2 text-left">Nº</th>
                      <th className="p-2 text-left">Data Vencimento</th>
                      <th className="p-2 text-right">Prestação</th>
                      <th className="p-2 text-right">Capital</th>
                      <th className="p-2 text-right">Juros</th>
                      <th className="p-2 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {parcelasClassificadas.map((p) => (
                      <tr key={p.numero} className={
                        p.status === "paga" ? "bg-green-50 text-green-700" :
                        p.status === "em_divida" ? "bg-red-50 text-red-700" :
                        "text-muted-foreground"
                      }>
                        <td className="p-2">{p.numero}</td>
                        <td className="p-2">{new Date(p.dataVencimento).toLocaleDateString("pt-PT")}</td>
                        <td className="p-2 text-right">{formatCurrency(p.prestacao)}</td>
                        <td className="p-2 text-right">{formatCurrency(p.amortizacao)}</td>
                        <td className="p-2 text-right">{formatCurrency(p.juros)}</td>
                        <td className="p-2 text-center">
                          {p.status === "paga" && <span className="px-2 py-0.5 rounded-full bg-green-100 text-green-700 text-xs font-medium">Paga</span>}
                          {p.status === "em_divida" && <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-medium">Em Dívida</span>}
                          {p.status === "por_pagar" && <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-500 text-xs font-medium">Por Pagar</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="flex gap-4 mt-2 text-xs">
                <span className="text-green-600 font-medium">✓ Pagas: {pagas.length}</span>
                <span className="text-red-600 font-medium">✗ Em Dívida: {emDivida.length}</span>
                <span className="text-muted-foreground font-medium">◯ Por Pagar: {porPagar.length}</span>
              </div>
            </div>
          )}

          {/* Histórico de pagamentos */}
          {pagamentos.length > 0 && (
            <div>
              <h3 className="font-bold text-sm mb-2">Histórico de Pagamentos</h3>
              <div className="overflow-x-auto max-h-40 overflow-y-auto border rounded-lg">
                <table className="w-full text-xs">
                  <thead className="bg-muted sticky top-0">
                    <tr>
                      <th className="p-2 text-left">Data</th>
                      <th className="p-2 text-right">Valor</th>
                      <th className="p-2 text-left">Tipo</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pagamentos.map((pag) => (
                      <tr key={pag.id} className="border-t">
                        <td className="p-2">{new Date(pag.data_pagamento).toLocaleDateString("pt-PT")}</td>
                        <td className="p-2 text-right font-medium">{formatCurrency(pag.valor)}</td>
                        <td className="p-2">{pag.tipo || "Parcela"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            <Button onClick={gerarPDF} className="flex-1">
              <Download className="mr-2 h-4 w-4" />
              Descarregar PDF Detalhado
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
