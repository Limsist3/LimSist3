import { NavLink, useNavigate, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import {
  LayoutDashboard,
  Calculator,
  Users,
  CreditCard,
  PiggyBank,
  FileText,
  FolderOpen,
  Receipt,
  Settings,
  ShieldCheck,
  Menu,
  X,
  LogOut,
  AlertTriangle,
  UsersRound,
  MessageCircle,
  BookOpenCheck,
} from "lucide-react";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";
import { useUserRole } from "@/hooks/useUserRole";
import { useCompanyLogo } from "@/hooks/useCompanyLogo";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { usePermissoes } from "@/hooks/usePermissoes";
import { MODULOS_PERMISSAO } from "@/lib/permissoes";

const ICONES_MODULO: Record<string, typeof LayoutDashboard> = {
  dashboard: LayoutDashboard,
  simulador: Calculator,
  clientes: Users,
  emprestimos: CreditCard,
  pagamentos: Receipt,
  poupancas: PiggyBank,
  despesas: Receipt,
  relatorios: FileText,
  arquivos: FolderOpen,
  central_risco: AlertTriangle,
  fecho_contas: BookOpenCheck,
  chat: MessageCircle,
};

const menuItems = [
  // Menu para SUPERADMIN
  { title: "Dashboard Geral", url: "/dashboard", icon: LayoutDashboard, roles: ["superadmin"] },
  { title: "Administração", url: "/administracao", icon: ShieldCheck, roles: ["superadmin"] },
  { title: "Config. Pagamentos", url: "/configuracao-pagamentos", icon: CreditCard, roles: ["superadmin"] },
  { title: "Mensagens", url: "/chat", icon: MessageCircle, roles: ["superadmin"] },
  
  // Menu para USUÁRIO MÃE (admin, user)
  { title: "Painel", url: "/dashboard", icon: LayoutDashboard, roles: ["admin", "user"] },
  { title: "Simulador", url: "/simulador", icon: Calculator, roles: ["admin", "user"] },
  { title: "Clientes", url: "/clientes", icon: Users, roles: ["admin", "user"] },
  { title: "Empréstimos", url: "/emprestimos", icon: CreditCard, roles: ["admin", "user"] },
  { title: "Pagamentos", url: "/pagamentos", icon: Receipt, roles: ["admin", "user"] },
  { title: "Gestão de Agentes", url: "/gestao-agentes", icon: UsersRound, roles: ["admin", "user"] },
  { title: "Poupanças", url: "/poupancas", icon: PiggyBank, roles: ["admin", "user"] },
  { title: "Relatórios", url: "/relatorios", icon: FileText, roles: ["admin", "user"] },
  
  { title: "Despesas", url: "/despesas", icon: Receipt, roles: ["admin", "user"] },
  { title: "Central de Risco", url: "/central-risco", icon: AlertTriangle, roles: ["admin", "user"] },
  { title: "Fecho de Contas", url: "/fecho-contas", icon: BookOpenCheck, roles: ["admin", "user"] },
  { title: "Configurações", url: "/configuracoes", icon: Settings, roles: ["admin", "user"] },
  { title: "Chat", url: "/chat", icon: MessageCircle, roles: ["admin", "user"] },
  
  // Menu para AGENTE
  { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard, roles: ["agente"] },
  { title: "Simulador", url: "/simulador", icon: Calculator, roles: ["agente"] },
  { title: "Meus Clientes", url: "/clientes", icon: Users, roles: ["agente"] },
  { title: "Empréstimos", url: "/emprestimos", icon: CreditCard, roles: ["agente"] },
  { title: "Pagamentos", url: "/pagamentos", icon: Receipt, roles: ["agente"] },
  { title: "Os Meus Pagamentos", url: "/meus-pagamentos", icon: FileText, roles: ["agente"] },
  

  // Menu para SECRETARIADO
  { title: "Painel", url: "/dashboard", icon: LayoutDashboard, roles: ["secretariado"] },
  { title: "Simulador", url: "/simulador", icon: Calculator, roles: ["secretariado"] },
  { title: "Clientes", url: "/clientes", icon: Users, roles: ["secretariado"] },
  { title: "Empréstimos", url: "/emprestimos", icon: CreditCard, roles: ["secretariado"] },
  { title: "Pagamentos", url: "/pagamentos", icon: Receipt, roles: ["secretariado"] },
  { title: "Poupanças", url: "/poupancas", icon: PiggyBank, roles: ["secretariado"] },
  { title: "Relatórios", url: "/relatorios", icon: FileText, roles: ["secretariado"] },
  { title: "Arquivos", url: "/arquivos", icon: FolderOpen, roles: ["secretariado"] },
  { title: "Despesas", url: "/despesas", icon: Receipt, roles: ["secretariado"] },
  { title: "Central de Risco", url: "/central-risco", icon: AlertTriangle, roles: ["secretariado"] },
  { title: "Fecho de Contas", url: "/fecho-contas", icon: BookOpenCheck, roles: ["secretariado"] },
];

export function AppSidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const { role, isSuperAdmin, isAgente, loading: roleLoading } = useUserRole();
  const { restrito, podeVer } = usePermissoes();
  const companyLogo = useCompanyLogo();
  
  // Auto-expand menu when on dashboard for superadmin
  const [isMenuOpen, setIsMenuOpen] = useState(true);
  
  useEffect(() => {
    // Always keep menu expanded for superadmin on dashboard
    if (isSuperAdmin && location.pathname === "/dashboard") {
      setIsMenuOpen(true);
    }
  }, [isSuperAdmin, location.pathname]);

  // Membros da equipa (agente, secretariado, contabilista, auditor, visualizador):
  // o menu é construído a partir das permissões definidas pelo usuário mãe.
  const filteredMenuItems = restrito
    ? MODULOS_PERMISSAO.filter((m) => podeVer(m.key)).map((m) => ({
        title: m.label,
        url: m.url,
        icon: ICONES_MODULO[m.key] || FileText,
      }))
    : menuItems.filter((item) => {
        if (item.roles.includes("all")) return true;
        if (role && item.roles.includes(role)) return true;
        return false;
      });

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut({ scope: 'local' });
    } catch {
      // Session may already be expired — proceed with local cleanup
    }
    toast.success("Logout realizado com sucesso!");
    navigate("/auth");
  };

  return (
    <Sidebar
      collapsible="icon"
      className="border-r border-sidebar-border bg-sidebar"
    >
      <div className="flex h-16 items-center justify-between px-4 border-b border-sidebar-border">
        {!isCollapsed && (
          <div className="flex items-center gap-2">
            {companyLogo && (
              <img src={companyLogo} alt="Logo" className="h-7 w-7 object-contain rounded" />
            )}
            <h1 className="text-xl font-bold text-sidebar-foreground">
              LimSist 2.0
            </h1>
          </div>
        )}
        {isCollapsed && companyLogo && (
          <img src={companyLogo} alt="Logo" className="h-7 w-7 object-contain rounded mx-auto" />
        )}
        <SidebarTrigger className="text-sidebar-foreground hover:text-sidebar-primary-foreground" />
      </div>

      <SidebarContent>
        <Collapsible open={isMenuOpen} onOpenChange={setIsMenuOpen}>
          <SidebarGroup>
            {!isCollapsed && (
              <CollapsibleTrigger asChild>
                <SidebarGroupLabel className="text-sidebar-foreground/70 cursor-pointer hover:bg-sidebar-accent/50 rounded px-2 py-1">
                  Menu Principal
                </SidebarGroupLabel>
              </CollapsibleTrigger>
            )}
            <CollapsibleContent>
              <SidebarGroupContent>
                <SidebarMenu>
                  {filteredMenuItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton asChild>
                        <NavLink
                          to={item.url}
                          className={({ isActive }) =>
                            cn(
                              "flex items-center gap-3 px-3 py-2 rounded-lg transition-all",
                              "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                              isActive &&
                                "bg-sidebar-primary text-sidebar-primary-foreground font-medium"
                            )
                          }
                        >
                          <item.icon className="h-5 w-5 flex-shrink-0" />
                          {!isCollapsed && <span>{item.title}</span>}
                        </NavLink>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </CollapsibleContent>
          </SidebarGroup>
        </Collapsible>

        {/* Logout Button */}
        <div className="mt-auto p-4 border-t border-sidebar-border">
          <Button
            variant="ghost"
            className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5 flex-shrink-0" />
            {!isCollapsed && <span className="ml-3">Sair</span>}
          </Button>
        </div>
      </SidebarContent>
    </Sidebar>
  );
}
