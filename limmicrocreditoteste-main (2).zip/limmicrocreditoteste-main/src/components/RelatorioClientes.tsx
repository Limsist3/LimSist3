import { useState } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Download } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { formatDatePT } from "@/lib/excelExport";
import { loadLetterhead, applyLetterheadAllPages, LETTERHEAD_CONTENT_TOP, LETTERHEAD_CONTENT_BOTTOM } from "@/lib/letterhead";

export function RelatorioClientes() {
  const [loading, setLoading] = useState(false);

  const carregarDados = async () => {
    const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
    if (!user) return null;

    const { data: clientes } = await supabase
      .from("clientes")
      .select("nome_completo, telefone, email, bloqueado, created_at")
      .eq("user_id", user.id);

    const totalClientes = clientes?.length || 0;
    const clientesAtivos = clientes?.filter(c => !c.bloqueado).length || 0;
    const clientesBloqueados = clientes?.filter(c => c.bloqueado).length || 0;

    return { clientes, totalClientes, clientesAtivos, clientesBloqueados };
  };

  const gerarPDF = async () => {
    setLoading(true);
    try {
      const dados = await carregarDados();
      if (!dados) return;

      const lh = await loadLetterhead();
      const { clientes, totalClientes, clientesAtivos, clientesBloqueados } = dados;

      const doc = new jsPDF({ compress: true });
      const pageWidth = doc.internal.pageSize.getWidth();
      let y = LETTERHEAD_CONTENT_TOP;

      doc.setFontSize(15);
      doc.setFont("helvetica", "bold");
      doc.text("ANÁLISE DE CLIENTES", pageWidth / 2, y, { align: "center" });
      y += 7;
      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      doc.text(`Data: ${formatDatePT(new Date())}`, pageWidth / 2, y, { align: "center" });
      y += 8;

      autoTable(doc, {
        startY: y,
        head: [["Indicador", "Quantidade"]],
        body: [
          ["Total de Clientes", totalClientes.toString()],
          ["Clientes Ativos", clientesAtivos.toString()],
          ["Clientes Bloqueados", clientesBloqueados.toString()],
        ],
        theme: "grid",
        styles: { fontSize: 10 },
        headStyles: { fillColor: [91, 79, 191] },
        margin: { top: LETTERHEAD_CONTENT_TOP, bottom: LETTERHEAD_CONTENT_BOTTOM },
      });

      y = (doc as any).lastAutoTable.finalY + 8;
      doc.setFontSize(11);
      doc.setFont("helvetica", "bold");
      doc.text("LISTA DE CLIENTES", 14, y);
      y += 5;

      const clientesData = clientes?.map(c => [
        c.nome_completo,
        c.telefone || "N/A",
        c.email || "N/A",
        c.bloqueado ? "Bloqueado" : "Ativo",
        formatDatePT(c.created_at)
      ]) || [];

      if (clientesData.length > 0) {
        autoTable(doc, {
          startY: y,
          head: [["Nome", "Telefone", "Email", "Status", "Data Cadastro"]],
          body: clientesData,
          theme: "striped",
          styles: { fontSize: 9 },
          headStyles: { fillColor: [91, 79, 191] },
          margin: { top: LETTERHEAD_CONTENT_TOP, bottom: LETTERHEAD_CONTENT_BOTTOM },
        });
      }

      applyLetterheadAllPages(doc, lh);
      doc.save(`Relatorio_Clientes_${new Date().toISOString().split('T')[0]}.pdf`);
      toast.success("Relatório gerado com sucesso!");
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
      toast.error("Erro ao gerar relatório");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex gap-2">
      <Button onClick={gerarPDF} disabled={loading} variant="outline" className="flex-1">
        <Download className="mr-2 h-4 w-4" />
        {loading ? "Gerando..." : "PDF"}
      </Button>
    </div>
  );
}
