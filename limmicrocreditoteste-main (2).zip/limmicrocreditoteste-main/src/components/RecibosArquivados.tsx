import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Archive, ChevronDown, Eye, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ReciboPagamento } from "@/components/ReciboPagamento";

interface PagArquivado {
  id: string;
  valor: number;
  data_pagamento: string;
  tipo: string | null;
  observacoes: string | null;
  emprestimo_id: string | null;
  snapshot_cliente_nome: string | null;
  snapshot_cliente_telefone: string | null;
  snapshot_emprestimo_valor: number | null;
  snapshot_emprestimo_taxa_juros: number | null;
  snapshot_emprestimo_valor_total: number | null;
}

/**
 * Lista pagamentos "arquivados": aqueles cujo empréstimo ou cliente foi apagado.
 * Ficam sempre acessíveis como prova de pagamento — só desaparecem se o próprio
 * pagamento for apagado explicitamente pelo usuário.
 */
export function RecibosArquivados() {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState<PagArquivado[]>([]);
  const [search, setSearch] = useState("");
  const [reciboOpen, setReciboOpen] = useState(false);
  const [selecionado, setSelecionado] = useState<PagArquivado | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await supabase
        .from("pagamentos")
        .select("id, valor, data_pagamento, tipo, observacoes, emprestimo_id, snapshot_cliente_nome, snapshot_cliente_telefone, snapshot_emprestimo_valor, snapshot_emprestimo_taxa_juros, snapshot_emprestimo_valor_total, arquivado")
        .eq("arquivado", true)
        .order("data_pagamento", { ascending: false })
        .limit(500);
      setRows((data as any) || []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (open) load();
  }, [open, load]);

  const fmt = (n: number | null) =>
    new Intl.NumberFormat("pt-PT", { minimumFractionDigits: 2 }).format(Number(n || 0));

  const filtered = rows.filter((r) => {
    const s = search.trim().toLowerCase();
    if (!s) return true;
    return (
      r.snapshot_cliente_nome?.toLowerCase().includes(s) ||
      r.snapshot_cliente_telefone?.includes(s)
    );
  });

  return (
    <Card>
      <Collapsible open={open} onOpenChange={setOpen}>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/40 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Archive className="h-5 w-5 text-muted-foreground" />
                <CardTitle className="text-base">Recibos Arquivados</CardTitle>
                <Badge variant="outline" className="ml-2">
                  Provas permanentes
                </Badge>
              </div>
              <ChevronDown
                className={`h-5 w-5 transition-transform ${open ? "rotate-180" : ""}`}
              />
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Pagamentos cujo empréstimo ou cliente foi eliminado. Continuam disponíveis como prova
              de pagamento e só desaparecem se você apagar o pagamento diretamente.
            </p>
          </CardHeader>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <CardContent className="space-y-3">
            <div className="relative max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Procurar por nome ou telefone..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>

            {loading ? (
              <div className="text-center py-8 text-muted-foreground text-sm">A carregar...</div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground text-sm">
                Nenhum recibo arquivado.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Cliente (histórico)</TableHead>
                      <TableHead>Telefone</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead className="text-right">Valor</TableHead>
                      <TableHead className="text-right">Recibo</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map((r) => (
                      <TableRow key={r.id}>
                        <TableCell>
                          {new Date(r.data_pagamento).toLocaleDateString("pt-PT")}
                        </TableCell>
                        <TableCell className="font-medium">
                          {r.snapshot_cliente_nome || "—"}
                        </TableCell>
                        <TableCell>{r.snapshot_cliente_telefone || "—"}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{r.tipo || "Parcela"}</Badge>
                        </TableCell>
                        <TableCell className="text-right font-semibold">
                          {fmt(r.valor)} MZN
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelecionado(r);
                              setReciboOpen(true);
                            }}
                          >
                            <Eye className="h-4 w-4 mr-1" /> Ver
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </CollapsibleContent>
      </Collapsible>

      {selecionado && (
        <ReciboPagamento
          open={reciboOpen}
          onOpenChange={setReciboOpen}
          pagamento={{
            id: selecionado.id,
            valor: selecionado.valor,
            data_pagamento: selecionado.data_pagamento,
            observacoes: selecionado.observacoes || "",
            emprestimo_id: selecionado.emprestimo_id || "",
            cliente_id: "",
            emprestimo: {
              id: selecionado.emprestimo_id || "",
              valor: Number(selecionado.snapshot_emprestimo_valor || 0),
              taxa_juros: Number(selecionado.snapshot_emprestimo_taxa_juros || 0),
              valor_total: Number(selecionado.snapshot_emprestimo_valor_total || 0),
              valor_pago: 0,
              cliente: {
                nome_completo: selecionado.snapshot_cliente_nome || "—",
                telefone: selecionado.snapshot_cliente_telefone || "—",
              },
            },
          }}
        />
      )}
    </Card>
  );
}
