import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  PiggyBank,
  ArrowUpCircle,
  ArrowDownCircle,
  Lock,
  Plus,
  Building2,
  Smartphone,
  Eye,
  Clock,
  Pencil,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { useCapitalData } from "@/hooks/useCapitalData";
import { useContasFinanceiras, ContaFinanceira, diasParaProximoAjuste } from "@/hooks/useContasFinanceiras";
import { useUserRole } from "@/hooks/useUserRole";
import { useState } from "react";

function ContaCard({
  conta,
  onAddSaldo,
  onEditSaldo,
  podeEditar,
}: {
  conta: ContaFinanceira;
  onAddSaldo: (contaId: string) => void;
  onEditSaldo: (contaId: string) => void;
  podeEditar: boolean;
}) {
  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("pt-MZ", { style: "currency", currency: "MZN", minimumFractionDigits: 0 }).format(value);

  const hoje = new Date().toISOString().split("T")[0];
  const jaRecarregouHoje = conta.ultima_recarga === hoje;
  const temDiferenca = conta.saldo_contabilistico !== conta.saldo_disponivel;
  const diasRestantes = diasParaProximoAjuste(conta);

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <div className="flex items-center gap-2">
          {conta.tipo === "banco" ? (
            <Building2 className="h-4 w-4 text-primary" />
          ) : (
            <Smartphone className="h-4 w-4 text-green-600" />
          )}
          <CardTitle className="text-sm font-medium">{conta.nome}</CardTitle>
        </div>
        <div className="flex items-center gap-1">
          {podeEditar && (
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={() => onEditSaldo(conta.id)}
              disabled={diasRestantes > 0}
              title={diasRestantes > 0 ? `Editável em ${diasRestantes} dia(s)` : "Editar saldos (1x cada 90 dias)"}
            >
              <Pencil className="h-3.5 w-3.5" />
            </Button>
          )}
          <Badge variant={conta.tipo === "banco" ? "default" : "secondary"} className="text-xs">
            {conta.tipo === "banco" ? "Banco" : "Carteira"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <Eye className="h-3 w-3" /> Saldo Disponível
          </p>
          <p className="text-xl font-bold text-green-600">{formatCurrency(conta.saldo_disponivel)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <Clock className="h-3 w-3" /> Saldo Contabilístico
          </p>
          <p className={`text-lg font-semibold ${temDiferenca ? "text-amber-600" : "text-foreground"}`}>
            {formatCurrency(conta.saldo_contabilistico)}
          </p>
          {temDiferenca && (
            <p className="text-xs text-amber-600 mt-0.5">
              Actualiza às 00:00 ({formatCurrency(conta.saldo_contabilistico - conta.saldo_disponivel)} pendente)
            </p>
          )}
        </div>
        <Button
          size="sm"
          variant="outline"
          className="w-full"
          onClick={() => onAddSaldo(conta.id)}
          disabled={jaRecarregouHoje}
        >
          <Plus className="h-3 w-3 mr-1" />
          {jaRecarregouHoje ? "Já adicionou hoje" : "Adicionar Saldo"}
        </Button>
      </CardContent>
    </Card>
  );
}


export function CapitalDashboard() {
  const {
    capitalGlobal,
    capitalMensal,
    capitalEvolution,
    loading: loadingCapital,
    capitalConfigurado,
    variacaoMensal,
    configurarCapitalGlobal,
    editarCapitalGlobal,
    podeEditarCapitalGlobal,
    adicionarEntradaCapital,
  } = useCapitalData();

  const {
    contas,
    bancos,
    carteiras,
    loading: loadingContas,
    totalSaldoDisponivel,
    totalSaldoContabilistico,
    adicionarSaldo,
    ajustarSaldoConta,
    refetch: refetchContas,
  } = useContasFinanceiras();

  const { role } = useUserRole();
  const podeEditarSaldos = role === "superadmin";


  const [valorCapitalGlobal, setValorCapitalGlobal] = useState("");
  const [showConfigDialog, setShowConfigDialog] = useState(false);
  const [showEntradaDialog, setShowEntradaDialog] = useState(false);
  const [showSaldoDialog, setShowSaldoDialog] = useState(false);
  const [selectedContaId, setSelectedContaId] = useState<string | null>(null);
  const [saldoValor, setSaldoValor] = useState("");
  const [entradaValor, setEntradaValor] = useState("");
  const [entradaDescricao, setEntradaDescricao] = useState("");
  const [entradaData, setEntradaData] = useState(new Date().toISOString().split("T")[0]);
  const [entradaContaId, setEntradaContaId] = useState<string>("");
  const [savingConfig, setSavingConfig] = useState(false);
  const [savingEntrada, setSavingEntrada] = useState(false);
  const [savingSaldo, setSavingSaldo] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editValor, setEditValor] = useState("");
  const [savingEdit, setSavingEdit] = useState(false);
  const [showAjusteDialog, setShowAjusteDialog] = useState(false);
  const [ajusteContaId, setAjusteContaId] = useState<string>("");
  const [ajusteDisponivel, setAjusteDisponivel] = useState("");
  const [ajusteContabilistico, setAjusteContabilistico] = useState("");
  const [ajusteMotivo, setAjusteMotivo] = useState("");
  const [savingAjuste, setSavingAjuste] = useState(false);

  const ajusteConta = contas.find((c) => c.id === ajusteContaId);

  const handleSelectAjusteConta = (id: string) => {
    setAjusteContaId(id);
    const c = contas.find((x) => x.id === id);
    setAjusteDisponivel(c ? String(c.saldo_disponivel) : "");
    setAjusteContabilistico(c ? String(c.saldo_contabilistico) : "");
  };

  const handleOpenAjusteDialog = (contaId?: string) => {
    setAjusteMotivo("");
    if (contaId) handleSelectAjusteConta(contaId);
    else { setAjusteContaId(""); setAjusteDisponivel(""); setAjusteContabilistico(""); }
    setShowAjusteDialog(true);
  };

  const handleAjustarSaldo = async () => {
    if (!ajusteContaId) return;
    const disp = parseFloat(ajusteDisponivel);
    const cont = parseFloat(ajusteContabilistico);
    if (isNaN(disp) || isNaN(cont)) return;
    setSavingAjuste(true);
    const success = await ajustarSaldoConta(ajusteContaId, disp, cont, ajusteMotivo.trim() || undefined);
    setSavingAjuste(false);
    if (success) { setShowAjusteDialog(false); setAjusteContaId(""); setAjusteMotivo(""); }
  };


  const loading = loadingCapital || loadingContas;

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("pt-MZ", { style: "currency", currency: "MZN", minimumFractionDigits: 0 }).format(value);

  const handleConfigurarCapital = async () => {
    const valor = parseFloat(valorCapitalGlobal);
    if (isNaN(valor) || valor <= 0) return;
    setSavingConfig(true);
    const success = await configurarCapitalGlobal(valor);
    setSavingConfig(false);
    if (success) { setShowConfigDialog(false); setValorCapitalGlobal(""); }
  };

  const handleEditarCapital = async () => {
    const valor = parseFloat(editValor);
    if (isNaN(valor) || valor <= 0) return;
    setSavingEdit(true);
    const success = await editarCapitalGlobal(valor);
    setSavingEdit(false);
    if (success) { setShowEditDialog(false); setEditValor(""); }
  };

  const handleAdicionarEntrada = async () => {
    const valor = parseFloat(entradaValor);
    if (isNaN(valor) || valor <= 0 || !entradaDescricao.trim() || !entradaContaId) return;
    setSavingEntrada(true);
    const success = await adicionarEntradaCapital(valor, entradaDescricao.trim(), entradaData, entradaContaId);
    setSavingEntrada(false);
    if (success) {
      setShowEntradaDialog(false);
      setEntradaValor("");
      setEntradaDescricao("");
      setEntradaData(new Date().toISOString().split("T")[0]);
      setEntradaContaId("");
      await refetchContas();
    }
  };

  const handleOpenSaldoDialog = (contaId: string) => {
    setSelectedContaId(contaId);
    setSaldoValor("");
    setShowSaldoDialog(true);
  };

  const handleAdicionarSaldo = async () => {
    if (!selectedContaId) return;
    const valor = parseFloat(saldoValor);
    if (isNaN(valor) || valor <= 0) return;
    setSavingSaldo(true);
    const success = await adicionarSaldo(selectedContaId, valor);
    setSavingSaldo(false);
    if (success) { setShowSaldoDialog(false); setSaldoValor(""); setSelectedContaId(null); }
  };

  const selectedConta = contas.find(c => c.id === selectedContaId);

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}><CardHeader className="pb-2"><Skeleton className="h-4 w-32" /></CardHeader><CardContent><Skeleton className="h-8 w-40" /></CardContent></Card>
          ))}
        </div>
      </div>
    );
  }

  // Se capital não configurado
  if (!capitalConfigurado) {
    return (
      <Card className="border-dashed">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PiggyBank className="h-5 w-5 text-primary" />
            Configuração Inicial do Capital
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">
            Configure o capital inicial global da sua instituição. Este valor será a soma de todos os saldos dos bancos e carteiras móveis.
          </p>
          <Dialog open={showConfigDialog} onOpenChange={setShowConfigDialog}>
            <DialogTrigger asChild>
              <Button><Wallet className="h-4 w-4 mr-2" />Configurar Capital Inicial</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2"><Lock className="h-5 w-5" />Configurar Capital Inicial Global</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label>Valor do Capital Inicial (MZN)</Label>
                  <Input type="number" placeholder="Ex: 1000000" value={valorCapitalGlobal} onChange={(e) => setValorCapitalGlobal(e.target.value)} />
                </div>
                <div className="bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-md p-3">
                  <p className="text-sm text-amber-800 dark:text-amber-200 flex items-start gap-2">
                    <Lock className="h-4 w-4 mt-0.5 shrink-0" />
                    <span><strong>Atenção:</strong> Este valor é permanente e não pode ser alterado.</span>
                  </p>
                </div>
                <Button className="w-full" onClick={handleConfigurarCapital} disabled={savingConfig || !valorCapitalGlobal}>
                  {savingConfig ? "Salvando..." : "Confirmar Capital Inicial"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>
    );
  }

  const capitalCards = [
    {
      title: "Capital Inicial Global",
      value: formatCurrency(capitalGlobal?.valor || 0),
      icon: PiggyBank,
      description: "Referência histórica",
      locked: true,
    },
    {
      title: "Total Saldo Disponível",
      value: formatCurrency(totalSaldoDisponivel),
      icon: Wallet,
      description: "Disponível para empréstimos",
      highlight: true,
      editableSaldos: true,
    },
    {
      title: "Total Saldo Contabilístico",
      value: formatCurrency(totalSaldoContabilistico),
      icon: TrendingUp,
      description: "Inclui pendentes (actualiza às 00:00)",
      editableSaldos: true,
    },

    {
      title: "Variação Mensal",
      value: `${variacaoMensal >= 0 ? "+" : ""}${variacaoMensal.toFixed(1)}%`,
      icon: variacaoMensal >= 0 ? ArrowUpCircle : ArrowDownCircle,
      description: capitalMensal?.mes_ano || "Mês actual",
      positive: variacaoMensal >= 0,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Cards de Capital */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {capitalCards.map((card) => {
          const Icon = card.icon;
          return (
            <Card key={card.title} className={`hover:shadow-lg transition-shadow duration-300 ${card.highlight ? "border-primary/50 bg-primary/5" : ""}`}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  {card.title}
                  {card.locked && <Lock className="h-3 w-3 text-muted-foreground/50" />}
                </CardTitle>
                <div className="flex items-center gap-1">
                  {card.locked && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => {
                        setEditValor(capitalGlobal?.valor?.toString() || "");
                        setShowEditDialog(true);
                      }}
                      disabled={!podeEditarCapitalGlobal()}
                      title={podeEditarCapitalGlobal() ? "Editar capital inicial" : "Já editou este mês"}
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                  )}
                  {"editableSaldos" in card && card.editableSaldos && podeEditarSaldos && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => handleOpenAjusteDialog()}
                      title="Editar saldos das contas (1x cada 90 dias)"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                  )}

                  <Icon className={`h-5 w-5 ${card.positive !== undefined ? (card.positive ? "text-green-600" : "text-red-600") : "text-primary"}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${card.positive !== undefined ? (card.positive ? "text-green-600" : "text-red-600") : "text-foreground"}`}>
                  {card.value}
                </div>
                <p className="text-xs mt-1 text-muted-foreground">{card.description}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Bancos */}
      <div>
        <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <Building2 className="h-5 w-5 text-primary" /> Bancos
        </h3>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {bancos.map(conta => (
            <ContaCard key={conta.id} conta={conta} onAddSaldo={handleOpenSaldoDialog} onEditSaldo={handleOpenAjusteDialog} podeEditar={podeEditarSaldos} />
          ))}
        </div>
      </div>

      {/* Carteiras Móveis */}
      <div>
        <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <Smartphone className="h-5 w-5 text-green-600" /> Carteiras Móveis
        </h3>
        <div className="grid gap-4 md:grid-cols-2">
          {carteiras.map(conta => (
            <ContaCard key={conta.id} conta={conta} onAddSaldo={handleOpenSaldoDialog} onEditSaldo={handleOpenAjusteDialog} podeEditar={podeEditarSaldos} />

          ))}
        </div>
      </div>

      {/* Movimentação do Mês e Entradas */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-lg">Movimentação do Mês</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-muted-foreground">Créditos Concedidos</span>
                <span className="font-medium text-red-600">- {formatCurrency(capitalMensal?.total_creditos_concedidos || 0)}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-muted-foreground">Reembolsos Recebidos</span>
                <span className="font-medium text-green-600">+ {formatCurrency(capitalMensal?.total_reembolsos_capital || 0)}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-muted-foreground">Juros Recebidos</span>
                <span className="font-medium text-green-600">+ {formatCurrency(capitalMensal?.total_juros_recebidos || 0)}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-muted-foreground">Entradas Extras</span>
                <span className="font-medium text-green-600">+ {formatCurrency(capitalMensal?.total_entradas_extras || 0)}</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-muted-foreground">Despesas/Perdas</span>
                <span className="font-medium text-red-600">- {formatCurrency(capitalMensal?.total_despesas_perdas || 0)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Entradas Extras de Capital</CardTitle>
            <Dialog open={showEntradaDialog} onOpenChange={setShowEntradaDialog}>
              <DialogTrigger asChild>
                <Button size="sm"><Plus className="h-4 w-4 mr-1" />Adicionar</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Registrar Entrada de Capital</DialogTitle></DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label>Valor (MZN)</Label>
                    <Input type="number" placeholder="Ex: 50000" value={entradaValor} onChange={(e) => setEntradaValor(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Banco ou Carteira Móvel</Label>
                    <Select value={entradaContaId} onValueChange={setEntradaContaId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o banco ou carteira" />
                      </SelectTrigger>
                      <SelectContent>
                        {bancos.length > 0 && (
                          <>
                            <SelectItem value="__bank_header" disabled>── Bancos ──</SelectItem>
                            {bancos.map(c => (
                              <SelectItem key={c.id} value={c.id}>
                                <span className="flex items-center gap-2">
                                  <Building2 className="h-3 w-3" /> {c.nome}
                                </span>
                              </SelectItem>
                            ))}
                          </>
                        )}
                        {carteiras.length > 0 && (
                          <>
                            <SelectItem value="__wallet_header" disabled>── Carteiras Móveis ──</SelectItem>
                            {carteiras.map(c => (
                              <SelectItem key={c.id} value={c.id}>
                                <span className="flex items-center gap-2">
                                  <Smartphone className="h-3 w-3" /> {c.nome}
                                </span>
                              </SelectItem>
                            ))}
                          </>
                        )}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">O valor será adicionado ao saldo contabilístico e ficará disponível às 00:00.</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Descrição</Label>
                    <Textarea placeholder="Ex: Aporte de capital dos sócios" value={entradaDescricao} onChange={(e) => setEntradaDescricao(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Data</Label>
                    <Input type="date" value={entradaData} onChange={(e) => setEntradaData(e.target.value)} />
                  </div>
                  <Button className="w-full" onClick={handleAdicionarEntrada} disabled={savingEntrada || !entradaValor || !entradaDescricao || !entradaContaId}>
                    {savingEntrada ? "Registrando..." : "Registrar Entrada"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Registre aportes de capital, investimentos ou outras entradas que aumentem o capital disponível.
            </p>
            <div className="text-center py-6 text-muted-foreground">
              <PiggyBank className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Entradas extras são automaticamente contabilizadas no capital mensal.</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Gráfico de Evolução */}
      {capitalEvolution.length > 0 && (
        <Card>
          <CardHeader><CardTitle>Evolução do Capital</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={capitalEvolution}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis tickFormatter={(value) => new Intl.NumberFormat("pt-MZ", { notation: "compact", compactDisplay: "short" }).format(value)} />
                <Tooltip formatter={(value: number) => [formatCurrency(value), "Capital"]} labelFormatter={(label) => `Período: ${label}`} />
                <Legend />
                <Line type="monotone" dataKey="capital" stroke="hsl(210, 85%, 48%)" strokeWidth={2} name="Capital (MZN)" dot={{ fill: "hsl(210, 85%, 48%)" }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Dialog Adicionar Saldo */}
      <Dialog open={showSaldoDialog} onOpenChange={setShowSaldoDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adicionar Saldo - {selectedConta?.nome}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            {selectedConta && (
              <div className="p-3 bg-muted rounded-lg space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Saldo Disponível Actual:</span>
                  <span className="font-medium text-green-600">{formatCurrency(selectedConta.saldo_disponivel)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Saldo Contabilístico:</span>
                  <span className="font-medium">{formatCurrency(selectedConta.saldo_contabilistico)}</span>
                </div>
              </div>
            )}
            <div className="space-y-2">
              <Label>Valor a Adicionar (MZN)</Label>
              <Input type="number" placeholder="Ex: 100000" value={saldoValor} onChange={(e) => setSaldoValor(e.target.value)} />
            </div>
            <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-md p-3">
              <p className="text-sm text-blue-800 dark:text-blue-200">
                O saldo será adicionado imediatamente ao saldo disponível e contabilístico. Só é permitido adicionar saldo <strong>uma vez por dia</strong> por conta.
              </p>
            </div>
            <Button className="w-full" onClick={handleAdicionarSaldo} disabled={savingSaldo || !saldoValor}>
              {savingSaldo ? "Adicionando..." : "Confirmar Adição de Saldo"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog Editar Capital Global */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Pencil className="h-5 w-5" />Editar Capital Inicial Global</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="p-3 bg-muted rounded-lg">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Valor Actual:</span>
                <span className="font-medium">{formatCurrency(capitalGlobal?.valor || 0)}</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Novo Valor do Capital Inicial (MZN)</Label>
              <Input type="number" placeholder="Ex: 1500000" value={editValor} onChange={(e) => setEditValor(e.target.value)} />
            </div>
            <div className="bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-md p-3">
              <p className="text-sm text-amber-800 dark:text-amber-200 flex items-start gap-2">
                <Lock className="h-4 w-4 mt-0.5 shrink-0" />
                <span><strong>Atenção:</strong> Esta edição só pode ser feita uma vez por mês.</span>
              </p>
            </div>
            <Button className="w-full" onClick={handleEditarCapital} disabled={savingEdit || !editValor}>
              {savingEdit ? "Salvando..." : "Confirmar Alteração"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog Ajustar Saldos da Conta (1x cada 90 dias) */}
      <Dialog open={showAjusteDialog} onOpenChange={setShowAjusteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="h-5 w-5" /> Editar Saldos da Conta
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label>Conta</Label>
              <Select value={ajusteContaId} onValueChange={handleSelectAjusteConta}>
                <SelectTrigger><SelectValue placeholder="Selecione a conta" /></SelectTrigger>
                <SelectContent>
                  {contas.map((c) => {
                    const d = diasParaProximoAjuste(c);
                    return (
                      <SelectItem key={c.id} value={c.id} disabled={d > 0}>
                        {c.nome} {d > 0 ? `(editável em ${d}d)` : ""}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>
            {ajusteConta && (
              <div className="p-3 bg-muted rounded-lg space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Saldo Disponível Actual:</span>
                  <span className="font-medium text-green-600">{formatCurrency(ajusteConta.saldo_disponivel)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Saldo Contabilístico Actual:</span>
                  <span className="font-medium">{formatCurrency(ajusteConta.saldo_contabilistico)}</span>
                </div>
              </div>
            )}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Novo Saldo Disponível (MZN)</Label>
                <Input type="number" value={ajusteDisponivel} onChange={(e) => setAjusteDisponivel(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Novo Saldo Contabilístico (MZN)</Label>
                <Input type="number" value={ajusteContabilistico} onChange={(e) => setAjusteContabilistico(e.target.value)} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Motivo (opcional)</Label>
              <Textarea placeholder="Ex: correcção de capital" value={ajusteMotivo} onChange={(e) => setAjusteMotivo(e.target.value)} />
            </div>
            <div className="bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-md p-3">
              <p className="text-sm text-amber-800 dark:text-amber-200 flex items-start gap-2">
                <Lock className="h-4 w-4 mt-0.5 shrink-0" />
                <span><strong>Atenção:</strong> pode aumentar ou diminuir o capital, mas cada conta só pode ser editada <strong>uma vez a cada 90 dias</strong>. O movimento fica registado no extrato.</span>
              </p>
            </div>
            <Button className="w-full" onClick={handleAjustarSaldo} disabled={savingAjuste || !ajusteContaId || ajusteDisponivel === "" || ajusteContabilistico === ""}>
              {savingAjuste ? "Salvando..." : "Confirmar Alteração de Saldos"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>

  );
}
