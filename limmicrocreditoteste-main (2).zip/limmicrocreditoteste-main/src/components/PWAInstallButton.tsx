import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import {
  consumeDeferredPrompt,
  isAppInstalled,
  subscribePWAInstall,
  type BeforeInstallPromptEvent,
} from "@/lib/pwaInstall";

export function PWAInstallButton() {
  const [installed, setInstalled] = useState<boolean>(() => isAppInstalled());
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [installing, setInstalling] = useState(false);

  useEffect(() => {
    if (installed) return;

    const unsub = subscribePWAInstall((d) => setDeferred(d));

    const mq = window.matchMedia("(display-mode: standalone)");
    const mqHandler = (e: MediaQueryListEvent) => {
      if (e.matches) {
        try { localStorage.setItem("pwa-installed", "true"); } catch {}
        setInstalled(true);
      }
    };
    mq.addEventListener("change", mqHandler);

    const installedHandler = () => setInstalled(true);
    window.addEventListener("appinstalled", installedHandler);

    return () => {
      unsub();
      mq.removeEventListener("change", mqHandler);
      window.removeEventListener("appinstalled", installedHandler);
    };
  }, [installed]);

  const isIOS = typeof navigator !== "undefined" &&
    /iPad|iPhone|iPod/.test(navigator.userAgent) &&
    !(window as any).MSStream;

  const handleInstall = async () => {
    const prompt = consumeDeferredPrompt();

    if (!prompt) {
      if (isIOS) {
        toast({
          title: "Instalar no iPhone/iPad",
          description: "Toque em Partilhar (↑) na barra do Safari e escolha “Adicionar ao ecrã principal”.",
        });
      } else {
        toast({
          title: "Instalação não disponível agora",
          description: "Abra o menu do navegador (⋮) e escolha “Instalar app” ou “Adicionar ao ecrã principal”.",
        });
      }
      return;
    }

    setInstalling(true);
    try {
      await prompt.prompt();
      const { outcome } = await prompt.userChoice;
      if (outcome === "accepted") {
        try { localStorage.setItem("pwa-installed", "true"); } catch {}
        setInstalled(true);
      }
    } catch (err) {
      console.error("Install error:", err);
    } finally {
      setInstalling(false);
      setDeferred(null);
    }
  };

  if (installed) return null;

  return (
    <Button
      onClick={handleInstall}
      disabled={installing}
      size="sm"
      className="animate-pulse bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg"
    >
      <Download className="h-4 w-4 mr-1" />
      {installing ? "A instalar..." : "Instalar App"}
    </Button>
  );
}
