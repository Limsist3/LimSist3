import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2 } from "lucide-react";
import { TIPOS_GARANTIA } from "@/utils/provincias";

export interface GarantiaItem {
  tipo: string;
  descricao: string;
  preco: number;
}

interface GarantiasFormProps {
  garantias: GarantiaItem[];
  onChange: (garantias: GarantiaItem[]) => void;
  maxItems?: number;
}

export function garantiasToJson(garantias: GarantiaItem[]): string {
  const filtered = garantias.filter(g => g.descricao.trim());
  return filtered.length > 0 ? JSON.stringify(filtered) : "";
}

export function jsonToGarantias(json: string | null | undefined): GarantiaItem[] {
  if (!json) return [{ tipo: "", descricao: "", preco: 0 }];
  try {
    const parsed = JSON.parse(json);
    if (Array.isArray(parsed) && parsed.length > 0) return parsed;
  } catch {
    // Legacy format: plain text lines
    if (json.trim()) {
      return json.split('\n').filter(l => l.trim()).map(l => ({
        tipo: "Bens Domesticos",
        descricao: l.trim(),
        preco: 0,
      }));
    }
  }
  return [{ tipo: "", descricao: "", preco: 0 }];
}

export function GarantiasForm({ garantias, onChange, maxItems = 10 }: GarantiasFormProps) {
  const addItem = () => {
    if (garantias.length >= maxItems) return;
    onChange([...garantias, { tipo: "", descricao: "", preco: 0 }]);
  };

  const removeItem = (index: number) => {
    if (garantias.length <= 1) return;
    onChange(garantias.filter((_, i) => i !== index));
  };

  const updateItem = (index: number, field: keyof GarantiaItem, value: string | number) => {
    const updated = [...garantias];
    updated[index] = { ...updated[index], [field]: value };
    onChange(updated);
  };

  const total = garantias.reduce((sum, g) => sum + (g.preco || 0), 0);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-semibold">Garantias (máx. {maxItems})</Label>
        {garantias.length < maxItems && (
          <Button type="button" variant="outline" size="sm" onClick={addItem}>
            <Plus className="h-3 w-3 mr-1" /> Adicionar
          </Button>
        )}
      </div>

      <div className="space-y-2">
        {garantias.map((item, index) => (
          <div key={index} className="grid grid-cols-12 gap-2 items-end">
            <div className="col-span-3">
              {index === 0 && <Label className="text-xs text-muted-foreground">Tipo</Label>}
              <Select value={item.tipo} onValueChange={(v) => updateItem(index, "tipo", v)}>
                <SelectTrigger className="h-9 text-xs">
                  <SelectValue placeholder="Tipo" />
                </SelectTrigger>
                <SelectContent>
                  {TIPOS_GARANTIA.map((t) => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                  <SelectItem value="Bens Domesticos">Bens Domesticos</SelectItem>
                  <SelectItem value="Equipamento">Equipamento</SelectItem>
                  <SelectItem value="Imóvel">Imóvel</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-5">
              {index === 0 && <Label className="text-xs text-muted-foreground">Descrição</Label>}
              <Input
                className="h-9 text-xs"
                value={item.descricao}
                onChange={(e) => updateItem(index, "descricao", e.target.value)}
                placeholder="Ex: Tv plasma samsung 42"
              />
            </div>
            <div className="col-span-3">
              {index === 0 && <Label className="text-xs text-muted-foreground">Preço (MT)</Label>}
              <Input
                className="h-9 text-xs"
                type="number"
                value={item.preco || ""}
                onChange={(e) => updateItem(index, "preco", parseFloat(e.target.value) || 0)}
                placeholder="0.00"
              />
            </div>
            <div className="col-span-1">
              {index === 0 && <Label className="text-xs text-muted-foreground">&nbsp;</Label>}
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-9 w-9 p-0"
                onClick={() => removeItem(index)}
                disabled={garantias.length <= 1}
              >
                <Trash2 className="h-3 w-3 text-destructive" />
              </Button>
            </div>
          </div>
        ))}
      </div>

      {total > 0 && (
        <div className="text-right text-xs font-semibold text-muted-foreground">
          Total estimado: {total.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT
        </div>
      )}
    </div>
  );
}
