import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Download, Printer, FileSpreadsheet } from "lucide-react";
import jsPDF from "jspdf";
import "jspdf-autotable";
import { createFormattedExcel, formatMZN } from "@/lib/excelExport";

interface RelatorioDespesasProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function RelatorioDespesas({ open, onOpenChange }: RelatorioDespesasProps) {
  const [config, setConfig] = useState<any>(null);
  const [tipoFiltro, setTipoFiltro] = useState<"mensal" | "periodo">("mensal");
  const [mesSelecionado, setMesSelecionado] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  });
  const [dataInicio, setDataInicio] = useState("");
  const [dataFim, setDataFim] = useState("");
  const [despesas, setDespesas] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      carregarConfig();
      carregarDespesas();
    }
  }, [open, tipoFiltro, mesSelecionado, dataInicio, dataFim]);

  const carregarConfig = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) return;
    const { data } = await supabase
      .from("configuracoes_empresa")
      .select("*")
      .eq("user_id", session.user.id)
      .single();
    setConfig(data);
  };

  const carregarDespesas = async () => {
    setLoading(true);
    let query = supabase.from("despesas").select("*, contas_financeiras(nome, tipo)").order("data", { ascending: true });

    if (tipoFiltro === "mensal") {
      const inicio = `${mesSelecionado}-01`;
      const [y, m] = mesSelecionado.split("-").map(Number);
      const fim = new Date(y, m, 0).toISOString().split("T")[0];
      query = query.gte("data", inicio).lte("data", fim);
    } else if (dataInicio && dataFim) {
      query = query.gte("data", dataInicio).lte("data", dataFim);
    }

    const { data } = await query;
    setDespesas(data || []);
    setLoading(false);
  };

  const formatCurrency = (v: number) =>
    new Intl.NumberFormat("pt-MZ", { style: "currency", currency: "MZN" }).format(v);

  const total = despesas.reduce((s, d) => s + (d.valor || 0), 0);

  const getPeriodoLabel = () => {
    if (tipoFiltro === "mensal") {
      const [y, m] = mesSelecionado.split("-");
      const meses = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
      return `${meses[parseInt(m) - 1]} de ${y}`;
    }
    if (dataInicio && dataFim) {
      return `${new Date(dataInicio).toLocaleDateString("pt-PT")} a ${new Date(dataFim).toLocaleDateString("pt-PT")}`;
    }
    return "Período personalizado";
  };

  // Group by category
  const porCategoria: Record<string, number> = despesas.reduce((acc: Record<string, number>, d: any) => {
    acc[d.categoria] = (acc[d.categoria] || 0) + (d.valor || 0);
    return acc;
  }, {});

  const gerarPDF = () => {
    try {
      const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4", compress: true });
      const pw = doc.internal.pageSize.getWidth();
      const ml = 14;
      const mr = pw - 14;
      let y = 15;

      // Company header
      if (config) {
        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.text(config.nome_empresa || "Empresa", pw / 2, y, { align: "center" });
        y += 5;
        doc.setFontSize(8);
        doc.setFont("helvetica", "normal");
        if (config.endereco) { doc.text(config.endereco, pw / 2, y, { align: "center" }); y += 4; }
        const info = [config.nuit ? `NUIT: ${config.nuit}` : "", config.telefone ? `Tel: ${config.telefone}` : "", config.email || ""].filter(Boolean).join(" | ");
        if (info) { doc.text(info, pw / 2, y, { align: "center" }); y += 4; }
      }

      // Separator
      y += 2;
      doc.setDrawColor(0);
      doc.setLineWidth(0.5);
      doc.line(ml, y, mr, y);
      y += 6;

      // Title
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("RELATÓRIO DE DESPESAS", pw / 2, y, { align: "center" });
      y += 5;
      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      doc.text(`Período: ${getPeriodoLabel()}`, pw / 2, y, { align: "center" });
      y += 4;
      doc.text(`Data de emissão: ${new Date().toLocaleDateString("pt-PT")}`, pw / 2, y, { align: "center" });
      y += 8;

      // Summary by category
      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.text("RESUMO POR CATEGORIA", ml, y);
      y += 5;

      const catEntries = Object.entries(porCategoria).sort((a, b) => b[1] - a[1]);
      (doc as any).autoTable({
        startY: y,
        head: [["Categoria", "Valor (MZN)", "% do Total"]],
        body: catEntries.map(([cat, val]) => [
          cat,
          formatCurrency(val),
          `${((val / total) * 100).toFixed(1)}%`,
        ]),
        foot: [["TOTAL", formatCurrency(total), "100%"]],
        margin: { left: ml, right: 14 },
        styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: "bold" },
        footStyles: { fillColor: [230, 230, 230], textColor: 0, fontStyle: "bold" },
        theme: "grid",
      });

      y = (doc as any).lastAutoTable.finalY + 8;

      // Detail table
      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.text("DETALHE DAS DESPESAS", ml, y);
      y += 5;

      (doc as any).autoTable({
        startY: y,
        head: [["#", "Data", "Categoria", "Descrição", "Conta", "Valor (MZN)"]],
        body: despesas.map((d, i) => [
          i + 1,
          new Date(d.data).toLocaleDateString("pt-PT"),
          d.categoria,
          d.descricao?.substring(0, 40) || "-",
          d.contas_financeiras?.nome || "-",
          formatCurrency(d.valor),
        ]),
        foot: [["", "", "", "", "TOTAL", formatCurrency(total)]],
        margin: { left: ml, right: 14 },
        styles: { fontSize: 7, cellPadding: 1.5 },
        headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: "bold" },
        footStyles: { fillColor: [230, 230, 230], textColor: 0, fontStyle: "bold" },
        theme: "grid",
        columnStyles: {
          0: { cellWidth: 8 },
          1: { cellWidth: 22 },
          2: { cellWidth: 30 },
          3: { cellWidth: 50 },
          4: { cellWidth: 30 },
          5: { cellWidth: 28, halign: "right" },
        },
      });

      y = (doc as any).lastAutoTable.finalY + 10;

      // Signature lines
      if (y < doc.internal.pageSize.getHeight() - 40) {
        const sigW = 60;
        doc.setLineWidth(0.2);
        doc.line(ml + 10, y + 15, ml + 10 + sigW, y + 15);
        doc.line(mr - 10 - sigW, y + 15, mr - 10, y + 15);
        doc.setFontSize(7);
        doc.text("Elaborado por", ml + 10 + sigW / 2, y + 19, { align: "center" });
        doc.text("Aprovado por", mr - 10 - sigW / 2, y + 19, { align: "center" });
      }

      // Footer
      const ph = doc.internal.pageSize.getHeight();
      doc.setFontSize(6);
      doc.text("Documento gerado automaticamente pelo sistema LIMSIST", pw / 2, ph - 8, { align: "center" });
      doc.text("www.limsist.com", pw / 2, ph - 5, { align: "center" });

      const nomeArquivo = `Relatorio_Despesas_${getPeriodoLabel().replace(/\s/g, "_")}.pdf`;
      doc.save(nomeArquivo);
      toast.success("Relatório PDF gerado!");
    } catch (err) {
      console.error(err);
      toast.error("Erro ao gerar PDF");
    }
  };

  const gerarExcel = () => {
    try {
      const sections = [
        {
          title: "RESUMO POR CATEGORIA",
          headers: ["Categoria", "Valor (MZN)", "% do Total"],
          data: [
            ...Object.entries(porCategoria).sort((a, b) => b[1] - a[1]).map(([cat, val]) => [
              cat, formatMZN(val), `${((val / total) * 100).toFixed(1)}%`,
            ]),
            ["TOTAL", formatMZN(total), "100%"],
          ],
        },
        {
          title: "DETALHE DAS DESPESAS",
          headers: ["#", "Data", "Categoria", "Descrição", "Conta", "Valor (MZN)"],
          data: [
            ...despesas.map((d, i) => [
              i + 1,
              new Date(d.data).toLocaleDateString("pt-PT"),
              d.categoria,
              d.descricao || "-",
              d.contas_financeiras?.nome || "-",
              formatMZN(d.valor),
            ]),
            ["", "", "", "", "TOTAL", formatMZN(total)],
          ],
        },
      ];

      createFormattedExcel(sections, `Relatorio_Despesas_${getPeriodoLabel().replace(/\s/g, "_")}.xlsx`, "Despesas", {
        nomeEmpresa: config?.nome_empresa,
        endereco: config?.endereco,
        telefone: config?.telefone,
        email: config?.email,
        nuit: config?.nuit,
        titulo: "RELATÓRIO DE DESPESAS",
        subtitulo: `Período: ${getPeriodoLabel()}`,
        data: new Date().toLocaleDateString("pt-PT"),
      });
      toast.success("Excel gerado!");
    } catch (err) {
      console.error(err);
      toast.error("Erro ao gerar Excel");
    }
  };

  const imprimirPDF = () => gerarPDF();

  // Generate month options for last 12 months
  const mesesOpcoes = Array.from({ length: 12 }, (_, i) => {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    const val = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const meses = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    return { value: val, label: `${meses[d.getMonth()]} ${d.getFullYear()}` };
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Relatório de Despesas</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Period filter */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Tipo de Período</Label>
              <Select value={tipoFiltro} onValueChange={(v: "mensal" | "periodo") => setTipoFiltro(v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="mensal">Mensal</SelectItem>
                  <SelectItem value="periodo">Período personalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {tipoFiltro === "mensal" ? (
              <div>
                <Label>Mês</Label>
                <Select value={mesSelecionado} onValueChange={setMesSelecionado}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {mesesOpcoes.map((m) => (
                      <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <>
                <div>
                  <Label>Data Início</Label>
                  <Input type="date" value={dataInicio} onChange={(e) => setDataInicio(e.target.value)} />
                </div>
                <div>
                  <Label>Data Fim</Label>
                  <Input type="date" value={dataFim} onChange={(e) => setDataFim(e.target.value)} />
                </div>
              </>
            )}
          </div>

          {/* Preview */}
          {config && (
            <div className="text-center border-b pb-3">
              {config.logo_url && (
                <img src={config.logo_url} alt="Logo" className="h-14 w-14 object-contain mx-auto mb-1" />
              )}
              <h3 className="font-bold text-lg">{config.nome_empresa}</h3>
              <p className="text-xs text-muted-foreground">{config.endereco}</p>
              <p className="text-xs text-muted-foreground">
                {[config.nuit ? `NUIT: ${config.nuit}` : "", config.telefone ? `Tel: ${config.telefone}` : "", config.email].filter(Boolean).join(" | ")}
              </p>
            </div>
          )}

          <div className="text-center">
            <h2 className="font-bold text-lg">RELATÓRIO DE DESPESAS</h2>
            <p className="text-sm text-muted-foreground">Período: {getPeriodoLabel()}</p>
          </div>

          {/* Summary */}
          <div className="border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-primary text-primary-foreground">
                <tr>
                  <th className="text-left p-2">Categoria</th>
                  <th className="text-right p-2">Valor</th>
                  <th className="text-right p-2">%</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(porCategoria).sort((a, b) => b[1] - a[1]).map(([cat, val]) => (
                  <tr key={cat} className="border-t">
                    <td className="p-2">{cat}</td>
                    <td className="text-right p-2">{formatCurrency(val)}</td>
                    <td className="text-right p-2">{((val / total) * 100).toFixed(1)}%</td>
                  </tr>
                ))}
                <tr className="border-t bg-muted font-bold">
                  <td className="p-2">TOTAL</td>
                  <td className="text-right p-2">{formatCurrency(total)}</td>
                  <td className="text-right p-2">100%</td>
                </tr>
              </tbody>
            </table>
          </div>

          <p className="text-sm text-muted-foreground text-center">
            {despesas.length} despesa(s) no período selecionado
          </p>

          {/* Actions */}
          <div className="flex gap-2">
            <Button onClick={gerarPDF} className="flex-1" disabled={despesas.length === 0}>
              <Download className="mr-2 h-4 w-4" />
              PDF
            </Button>
            <Button onClick={gerarExcel} variant="outline" className="flex-1" disabled={despesas.length === 0}>
              <FileSpreadsheet className="mr-2 h-4 w-4" />
              Excel
            </Button>
            <Button onClick={imprimirPDF} variant="outline" className="flex-1" disabled={despesas.length === 0}>
              <Printer className="mr-2 h-4 w-4" />
              Imprimir
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
