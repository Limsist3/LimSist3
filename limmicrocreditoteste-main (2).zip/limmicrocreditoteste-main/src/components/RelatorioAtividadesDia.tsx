import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CalendarIcon, Download, FileSpreadsheet } from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { createFormattedExcel, formatDatePT } from "@/lib/excelExport";
import { loadLetterhead, applyLetterheadAllPages, LETTERHEAD_CONTENT_TOP, LETTERHEAD_CONTENT_BOTTOM } from "@/lib/letterhead";

interface Atividade {
  tipo: string;
  descricao: string;
  hora: string;
  detalhes: string;
}

export const RelatorioAtividadesDia = () => {
  const [date, setDate] = useState<Date>();
  const [atividades, setAtividades] = useState<Atividade[]>([]);
  const [config, setConfig] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const buscarAtividades = async () => {
    if (!date) {
      toast.error("Selecione uma data");
      return;
    }

    setLoading(true);
    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) throw new Error("Usuário não autenticado");

      // Carregar configurações da empresa
      const { data: configData } = await supabase
        .from("configuracoes_empresa")
        .select("*")
        .eq("user_id", user.id)
        .single();

      setConfig(configData);

      const dataFormatada = format(date, "yyyy-MM-dd");
      const atividadesEncontradas: Atividade[] = [];

      // Buscar empréstimos
      const { data: emprestimos } = await supabase
        .from("emprestimos")
        .select("*, clientes(nome_completo)")
        .eq("user_id", user.id)
        .eq("data_desembolso", dataFormatada);

      emprestimos?.forEach((emp: any) => {
        atividadesEncontradas.push({
          tipo: "Empréstimo",
          descricao: `Empréstimo desembolsado para ${emp.clientes.nome_completo}`,
          hora: format(new Date(emp.created_at), "HH:mm:ss", { locale: pt }),
          detalhes: `Valor: ${emp.valor.toLocaleString("pt-MZ")} MT | Duração: ${emp.duracao_meses} meses | Taxa: ${emp.taxa_juros}%`
        });
      });

      // Buscar pagamentos
      const { data: pagamentos } = await supabase
        .from("pagamentos")
        .select("*, emprestimos!inner(*, clientes(nome_completo))")
        .eq("emprestimos.user_id", user.id)
        .eq("data_pagamento", dataFormatada);

      pagamentos?.forEach((pag: any) => {
        atividadesEncontradas.push({
          tipo: "Pagamento",
          descricao: `Pagamento recebido de ${pag.emprestimos.clientes.nome_completo}`,
          hora: format(new Date(pag.created_at), "HH:mm:ss", { locale: pt }),
          detalhes: `Valor: ${pag.valor.toLocaleString("pt-MZ")} MT | Tipo: ${pag.tipo}`
        });
      });

      // Buscar clientes criados
      const { data: clientes } = await supabase
        .from("clientes")
        .select("*")
        .eq("user_id", user.id)
        .gte("created_at", `${dataFormatada}T00:00:00`)
        .lt("created_at", `${dataFormatada}T23:59:59`);

      clientes?.forEach((cli: any) => {
        atividadesEncontradas.push({
          tipo: "Cliente",
          descricao: `Cliente cadastrado: ${cli.nome_completo}`,
          hora: format(new Date(cli.created_at), "HH:mm:ss", { locale: pt }),
          detalhes: `Telefone: ${cli.telefone} | ${cli.provincia || 'N/A'}`
        });
      });

      // Buscar despesas
      const { data: despesas } = await supabase
        .from("despesas")
        .select("*")
        .eq("user_id", user.id)
        .eq("data", dataFormatada);

      despesas?.forEach((desp: any) => {
        atividadesEncontradas.push({
          tipo: "Despesa",
          descricao: `Despesa registrada: ${desp.descricao}`,
          hora: format(new Date(desp.created_at), "HH:mm:ss", { locale: pt }),
          detalhes: `Valor: ${desp.valor.toLocaleString("pt-MZ")} MT | Categoria: ${desp.categoria}`
        });
      });

      // Ordenar por hora
      atividadesEncontradas.sort((a, b) => a.hora.localeCompare(b.hora));

      setAtividades(atividadesEncontradas);

      if (atividadesEncontradas.length === 0) {
        toast.info("Nenhuma atividade encontrada para esta data");
      } else {
        toast.success(`${atividadesEncontradas.length} atividades encontradas`);
      }
    } catch (error) {
      console.error("Erro ao buscar atividades:", error);
      toast.error("Erro ao buscar atividades");
    } finally {
      setLoading(false);
    }
  };

  const gerarPDF = async () => {
    if (!date || atividades.length === 0) return;

    const lh = await loadLetterhead();
    const doc = new jsPDF({ compress: true });
    const pageWidth = doc.internal.pageSize.getWidth();
    let y = LETTERHEAD_CONTENT_TOP;

    doc.setFontSize(15);
    doc.setFont("helvetica", "bold");
    doc.text("RELATÓRIO DE ATIVIDADES DO DIA", pageWidth / 2, y, { align: "center" });
    y += 7;
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(`Data: ${format(date, "dd/MM/yyyy", { locale: pt })}`, pageWidth / 2, y, { align: "center" });
    y += 8;

    autoTable(doc, {
      startY: y,
      head: [["Hora", "Tipo", "Descrição", "Detalhes"]],
      body: atividades.map(ativ => [ativ.hora, ativ.tipo, ativ.descricao, ativ.detalhes]),
      theme: "grid",
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [91, 79, 191], textColor: 255 },
      margin: { top: LETTERHEAD_CONTENT_TOP, bottom: LETTERHEAD_CONTENT_BOTTOM },
    });

    const finalY = (doc as any).lastAutoTable.finalY + 6;
    doc.setFontSize(9);
    doc.setFont("helvetica", "bold");
    doc.text(`Total de atividades: ${atividades.length}`, 14, finalY);

    applyLetterheadAllPages(doc, lh);
    doc.save(`Atividades_${format(date, "dd-MM-yyyy")}.pdf`);
    toast.success("PDF gerado com sucesso!");
  };

  const gerarExcel = () => {
    if (!date || atividades.length === 0) return;

    const atividadesData = atividades.map(ativ => [
      ativ.hora,
      ativ.tipo,
      ativ.descricao,
      ativ.detalhes
    ]);

    // Adicionar linha de total
    atividadesData.push([]);
    atividadesData.push(["Total de atividades:", atividades.length.toString(), "", ""]);

    createFormattedExcel(
      [
        {
          title: "ATIVIDADES DO DIA",
          headers: ["Hora", "Tipo", "Descrição", "Detalhes"],
          data: atividadesData
        }
      ],
      `Atividades_${format(date, "dd-MM-yyyy")}.xlsx`,
      "Atividades",
      {
        nomeEmpresa: config?.nome_empresa,
        endereco: config?.endereco,
        telefone: config?.telefone,
        email: config?.email,
        titulo: "RELATÓRIO DE ATIVIDADES DO DIA",
        data: format(date, "dd/MM/yyyy", { locale: pt })
      }
    );

    toast.success("Excel gerado com sucesso!");
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Relatório de Atividades do Dia</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2 items-end">
          <div className="flex-1">
            <label className="text-sm font-medium mb-2 block">Selecionar Data</label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !date && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, "dd/MM/yyyy", { locale: pt }) : "Escolha uma data"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  initialFocus
                  locale={pt}
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>
          <Button onClick={buscarAtividades} disabled={loading || !date}>
            {loading ? "Buscando..." : "Buscar Atividades"}
          </Button>
          {atividades.length > 0 && (
            <>
              <Button onClick={gerarExcel} variant="outline">
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Excel
              </Button>
              <Button onClick={gerarPDF} variant="outline">
                <Download className="h-4 w-4 mr-2" />
                PDF
              </Button>
            </>
          )}
        </div>

        {atividades.length > 0 && (
          <div className="border rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted">
                <tr>
                  <th className="text-left p-2 text-sm font-medium">Hora</th>
                  <th className="text-left p-2 text-sm font-medium">Tipo</th>
                  <th className="text-left p-2 text-sm font-medium">Descrição</th>
                  <th className="text-left p-2 text-sm font-medium">Detalhes</th>
                </tr>
              </thead>
              <tbody>
                {atividades.map((ativ, idx) => (
                  <tr key={idx} className="border-t hover:bg-muted/50">
                    <td className="p-2 text-sm">{ativ.hora}</td>
                    <td className="p-2 text-sm">
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                        {ativ.tipo}
                      </span>
                    </td>
                    <td className="p-2 text-sm">{ativ.descricao}</td>
                    <td className="p-2 text-sm text-muted-foreground">{ativ.detalhes}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {atividades.length > 0 && (
          <div className="text-sm text-muted-foreground text-center pt-2 border-t">
            Total de atividades: {atividades.length}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
