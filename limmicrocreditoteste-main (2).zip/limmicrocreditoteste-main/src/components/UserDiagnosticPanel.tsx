import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { LogOut, RefreshCw, Trash2, AlertTriangle, Activity, KeyRound } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";
import { ConfirmDialog } from "@/components/ConfirmDialog";

interface ErrorRow {
  id: string;
  message: string;
  stack: string | null;
  url: string | null;
  user_agent: string | null;
  created_at: string;
}

interface CommandRow {
  id: string;
  command: string;
  status: string;
  created_at: string;
  executed_at: string | null;
}

interface Props {
  userId: string;
  userName?: string;
}

export function UserDiagnosticPanel({ userId, userName }: Props) {
  const [errors, setErrors] = useState<ErrorRow[]>([]);
  const [commands, setCommands] = useState<CommandRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [pendingAction, setPendingAction] = useState<null | "force_logout" | "clear_cache" | "reload" | "reset_password">(null);
  const [sending, setSending] = useState(false);

  const fetchAll = async () => {
    setLoading(true);
    const [{ data: errs }, { data: cmds }] = await Promise.all([
      supabase.from("user_error_logs").select("*").eq("user_id", userId).order("created_at", { ascending: false }).limit(50),
      supabase.from("admin_commands").select("*").eq("target_user_id", userId).order("created_at", { ascending: false }).limit(20),
    ]);
    setErrors((errs as ErrorRow[]) || []);
    setCommands((cmds as CommandRow[]) || []);
    setLoading(false);
  };

  useEffect(() => { fetchAll(); /* eslint-disable-next-line */ }, [userId]);

  const sendCommand = async (command: "force_logout" | "clear_cache" | "reload") => {
    setSending(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Sem sessão");
      const { error } = await supabase.from("admin_commands").insert([{
        target_user_id: userId,
        issued_by: user.id,
        command,
      }]);
      if (error) throw error;
      toast.success(
        command === "force_logout" ? "Sessão será terminada no dispositivo do usuário." :
        command === "clear_cache" ? "Cache será limpa no dispositivo do usuário." :
        "App será recarregada no dispositivo do usuário."
      );
      fetchAll();
    } catch (e: any) {
      toast.error(e.message || "Falha ao enviar comando");
    } finally {
      setSending(false);
      setPendingAction(null);
    }
  };

  const resetPassword = async () => {
    setSending(true);
    try {
      const { data, error } = await supabase.functions.invoke("resetar-senha-usuario", {
        body: { user_id: userId },
      });
      if (error) throw error;
      if ((data as any)?.error) throw new Error((data as any).error);
      toast.success(`Senha de ${userName || "usuário"} restaurada para 123456.`);
    } catch (e: any) {
      toast.error(e.message || "Falha ao restaurar senha");
    } finally {
      setSending(false);
      setPendingAction(null);
    }
  };

  const cmdLabel = (c: string) =>
    c === "force_logout" ? "Forçar logout" :
    c === "clear_cache" ? "Limpar cache" :
    c === "reload" ? "Recarregar" : c;

  const confirmText = pendingAction === "force_logout"
    ? `Terminar sessão de ${userName || "este usuário"}? Ele será deslogado imediatamente em todos os dispositivos abertos.`
    : pendingAction === "reset_password"
    ? `Restaurar a senha de ${userName || "este usuário"} para 123456? Ele poderá entrar imediatamente com essa senha.`
    : pendingAction === "clear_cache"
    ? `Limpar cache local no dispositivo de ${userName || "este usuário"}? Será recarregado depois.`
    : `Recarregar a app no dispositivo de ${userName || "este usuário"}?`;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Activity className="h-4 w-4" /> Ações de diagnóstico
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button size="sm" variant="outline" onClick={() => setPendingAction("reload")} disabled={sending}>
            <RefreshCw className="h-4 w-4 mr-2" /> Recarregar app
          </Button>
          <Button size="sm" variant="outline" onClick={() => setPendingAction("clear_cache")} disabled={sending}>
            <Trash2 className="h-4 w-4 mr-2" /> Limpar cache
          </Button>
          <Button size="sm" variant="outline" onClick={() => setPendingAction("reset_password")} disabled={sending}>
            <KeyRound className="h-4 w-4 mr-2" /> Restaurar senha (123456)
          </Button>
          <Button size="sm" variant="destructive" onClick={() => setPendingAction("force_logout")} disabled={sending}>
            <LogOut className="h-4 w-4 mr-2" /> Forçar logout
          </Button>
          <Button size="sm" variant="ghost" onClick={fetchAll} className="ml-auto">
            <RefreshCw className="h-4 w-4 mr-2" /> Atualizar
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <AlertTriangle className="h-4 w-4 text-amber-500" /> Erros recentes ({errors.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-sm text-muted-foreground">A carregar...</p>
          ) : errors.length === 0 ? (
            <p className="text-sm text-muted-foreground">Sem erros registados nos últimos 50 eventos.</p>
          ) : (
            <div className="max-h-[400px] overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[140px]">Quando</TableHead>
                    <TableHead>Mensagem</TableHead>
                    <TableHead className="w-[200px]">Página</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {errors.map(e => (
                    <TableRow key={e.id}>
                      <TableCell className="text-xs">{format(new Date(e.created_at), "dd/MM HH:mm:ss")}</TableCell>
                      <TableCell className="text-xs font-mono break-all">
                        {e.message}
                        {e.stack && (
                          <details className="mt-1">
                            <summary className="cursor-pointer text-muted-foreground">stack</summary>
                            <pre className="text-[10px] whitespace-pre-wrap">{e.stack}</pre>
                          </details>
                        )}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground break-all">{e.url}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Comandos enviados</CardTitle>
        </CardHeader>
        <CardContent>
          {commands.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhum comando enviado a este usuário.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Comando</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Enviado</TableHead>
                  <TableHead>Executado</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {commands.map(c => (
                  <TableRow key={c.id}>
                    <TableCell>{cmdLabel(c.command)}</TableCell>
                    <TableCell>
                      <Badge variant={c.status === "executed" ? "default" : c.status === "failed" ? "destructive" : "secondary"}>
                        {c.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs">{format(new Date(c.created_at), "dd/MM HH:mm")}</TableCell>
                    <TableCell className="text-xs">{c.executed_at ? format(new Date(c.executed_at), "dd/MM HH:mm") : "—"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <ConfirmDialog
        open={!!pendingAction}
        onOpenChange={(o) => !o && setPendingAction(null)}
        title="Confirmar ação"
        description={confirmText}
        confirmLabel="Sim, executar"
        variant={pendingAction === "force_logout" ? "destructive" : "default"}
        onConfirm={() => {
          if (pendingAction === "reset_password") return resetPassword();
          if (pendingAction) return sendCommand(pendingAction);
        }}
      />
    </div>
  );
}
