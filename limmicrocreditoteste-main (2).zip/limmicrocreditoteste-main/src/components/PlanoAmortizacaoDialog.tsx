import { useCallback, useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CalendarClock, Receipt } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { gerarTabelaAmortizacao } from "@/lib/amortization";
import { calcularPlanoComEstado, PlanoAmortizacaoDetalhado } from "@/components/PlanoAmortizacaoDetalhado";
import { ReciboPagamento } from "@/components/ReciboPagamento";

export interface EmprestimoPlano {
  id: string;
  cliente_id: string;
  clientes?: { nome_completo?: string; telefone?: string } | null;
  valor: number;
  taxa_juros: number;
  taxa_mora?: number;
  duracao_meses: number;
  tipo_juros?: string;
  sistema_amortizacao?: string;
  modalidade_reembolso?: string;
  data_desembolso: string;
  data_reembolso?: string;
  valor_total: number;
  valor_pago: number;
  mora_paga?: number;
}

interface PagamentoLinha {
  id: string;
  valor: number;
  data_pagamento: string;
  observacoes: string | null;
  tipo: string | null;
}

const fmt = (n: number) =>
  `${(Number(n) || 0).toLocaleString("pt-MZ", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} MT`;

const data = (d?: string | null) => (d ? new Date(d).toLocaleDateString("pt-MZ") : "-");

export function PlanoAmortizacaoDialog({ emprestimo, compact = false }: { emprestimo: EmprestimoPlano; compact?: boolean }) {
  const [open, setOpen] = useState(false);
  const [pagamentos, setPagamentos] = useState<PagamentoLinha[]>([]);
  const [loading, setLoading] = useState(false);
  const [reciboOpen, setReciboOpen] = useState(false);
  const [reciboData, setReciboData] = useState<any>(null);

  const carregar = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase
      .from("pagamentos")
      .select("id, valor, data_pagamento, observacoes, tipo")
      .eq("emprestimo_id", emprestimo.id)
      .order("data_pagamento", { ascending: true });
    setPagamentos((rows as PagamentoLinha[]) || []);
    setLoading(false);
  }, [emprestimo.id]);

  useEffect(() => {
    if (open) carregar();
  }, [open, carregar]);

  const plano = useMemo(() => {
    if (!open) return [];
    const base = gerarTabelaAmortizacao(
      Number(emprestimo.valor) || 0,
      Number(emprestimo.taxa_juros) || 0,
      Number(emprestimo.duracao_meses) || 1,
      emprestimo.modalidade_reembolso || "mensal",
      emprestimo.data_desembolso,
      (emprestimo.sistema_amortizacao as "price" | "sac") || "price",
      emprestimo.tipo_juros || "Simples"
    );
    return calcularPlanoComEstado(base, Number(emprestimo.valor_pago) || 0, Number(emprestimo.taxa_mora) || 0);
  }, [open, emprestimo]);

  const total = Number(emprestimo.valor_total) || 0;
  const pago = Number(emprestimo.valor_pago) || 0;
  const divida = Math.max(0, total - pago);
  const pagas = plano.filter((p) => p.estado === "paga").length;
  const vencidas = plano.filter((p) => p.estado === "vencida");
  const moraAcumulada = vencidas.reduce((s, p) => s + p.mora, 0);
  const moraPaga = Number(emprestimo.mora_paga) || 0;
  const proxima = plano.find((p) => p.estado !== "paga");
  const pct = total > 0 ? Math.min(100, (pago / total) * 100) : 0;

  const abrirRecibo = (p: PagamentoLinha) => {
    setReciboData({
      id: p.id,
      valor: p.valor,
      data_pagamento: p.data_pagamento,
      observacoes: p.observacoes || "",
      emprestimo_id: emprestimo.id,
      cliente_id: emprestimo.cliente_id,
      emprestimo: {
        id: emprestimo.id,
        valor: emprestimo.valor,
        taxa_juros: emprestimo.taxa_juros,
        valor_total: total,
        valor_pago: pago,
        cliente: {
          nome_completo: emprestimo.clientes?.nome_completo || "Cliente",
          telefone: emprestimo.clientes?.telefone || "",
        },
      },
    });
    setReciboOpen(true);
  };

  return (
    <>
      <Button
        variant={compact ? "ghost" : "outline"}
        size="sm"
        onClick={() => setOpen(true)}
        title="Plano de amortização"
        className={compact ? "" : "flex-1"}
      >
        <CalendarClock className="h-4 w-4" />
        {!compact && <span className="ml-2">Plano</span>}
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CalendarClock className="h-5 w-5 text-primary" />
              Plano de Amortização — {emprestimo.clientes?.nome_completo || "Cliente"}
            </DialogTitle>
            <DialogDescription>
              Desembolso {data(emprestimo.data_desembolso)} · Reembolso final {data(emprestimo.data_reembolso)} ·{" "}
              {emprestimo.duracao_meses} meses · Taxa {emprestimo.taxa_juros}% ({emprestimo.tipo_juros || "Simples"})
            </DialogDescription>
          </DialogHeader>

          <ScrollArea className="flex-1 pr-3">
            <div className="space-y-4">
              {/* Resumo financeiro */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                <div className="rounded-lg border bg-card p-3">
                  <p className="text-[11px] text-muted-foreground">Valor financiado</p>
                  <p className="text-sm font-bold">{fmt(emprestimo.valor)}</p>
                </div>
                <div className="rounded-lg border bg-card p-3">
                  <p className="text-[11px] text-muted-foreground">Total a pagar</p>
                  <p className="text-sm font-bold">{fmt(total)}</p>
                </div>
                <div className="rounded-lg border bg-card p-3">
                  <p className="text-[11px] text-muted-foreground">Já pago</p>
                  <p className="text-sm font-bold text-success">{fmt(pago)}</p>
                </div>
                <div className="rounded-lg border bg-card p-3">
                  <p className="text-[11px] text-muted-foreground">Saldo disponível (em dívida)</p>
                  <p className="text-sm font-bold text-destructive">{fmt(divida)}</p>
                </div>
                <div className="rounded-lg border bg-card p-3">
                  <p className="text-[11px] text-muted-foreground">Prestações pagas</p>
                  <p className="text-sm font-bold">
                    {pagas} / {plano.length}
                  </p>
                </div>
                <div className="rounded-lg border bg-card p-3">
                  <p className="text-[11px] text-muted-foreground">Prestações em dívida</p>
                  <p className="text-sm font-bold text-destructive">{vencidas.length}</p>
                </div>
                <div className="rounded-lg border bg-card p-3">
                  <p className="text-[11px] text-muted-foreground">Juros de mora acumulados</p>
                  <p className="text-sm font-bold text-destructive">{fmt(moraAcumulada)}</p>
                </div>
                <div className="rounded-lg border bg-card p-3">
                  <p className="text-[11px] text-muted-foreground">Mora já paga</p>
                  <p className="text-sm font-bold text-success">{fmt(moraPaga)}</p>
                </div>
              </div>

              {/* Progresso */}
              <div>
                <div className="flex justify-between text-[11px] text-muted-foreground mb-1">
                  <span>Progresso de pagamento</span>
                  <span>{pct.toFixed(1)}%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
                  <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${pct}%` }} />
                </div>
              </div>

              {proxima && (
                <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 text-xs">
                  <span className="font-semibold">Próxima prestação:</span> nº {proxima.numero} —{" "}
                  {fmt(proxima.divida)} com vencimento em {data(proxima.dataVencimento)}
                  {vencidas.length > 0 && (
                    <Badge variant="destructive" className="ml-2 text-[10px] px-1 py-0">
                      {vencidas.length} prestação(ões) não paga(s)
                    </Badge>
                  )}
                </div>
              )}

              {/* Tabela de prestações */}
              <div className="rounded-lg border p-2">
                <PlanoAmortizacaoDetalhado
                  valor={Number(emprestimo.valor) || 0}
                  taxaJuros={Number(emprestimo.taxa_juros) || 0}
                  duracaoMeses={Number(emprestimo.duracao_meses) || 1}
                  modalidadeReembolso={emprestimo.modalidade_reembolso || "mensal"}
                  dataDesembolso={emprestimo.data_desembolso}
                  sistema={(emprestimo.sistema_amortizacao as "price" | "sac") || "price"}
                  tipoJuros={emprestimo.tipo_juros || "Simples"}
                  taxaMora={Number(emprestimo.taxa_mora) || 0}
                  totalPago={pago}
                  defaultOpen
                />
              </div>

              {/* Pagamentos registados + recibos */}
              <div className="rounded-lg border p-3">
                <p className="text-xs font-semibold mb-2 flex items-center gap-2">
                  <Receipt className="h-4 w-4 text-primary" />
                  Pagamentos registados ({pagamentos.length})
                </p>
                {loading ? (
                  <p className="text-xs text-muted-foreground">A carregar…</p>
                ) : pagamentos.length === 0 ? (
                  <p className="text-xs text-muted-foreground">Ainda não há pagamentos registados neste empréstimo.</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-xs p-1">Data</TableHead>
                        <TableHead className="text-xs p-1">Tipo</TableHead>
                        <TableHead className="text-xs p-1 text-right">Valor</TableHead>
                        <TableHead className="text-xs p-1">Observações</TableHead>
                        <TableHead className="text-xs p-1 text-right">Recibo</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {pagamentos.map((p) => (
                        <TableRow key={p.id}>
                          <TableCell className="text-xs p-1">{data(p.data_pagamento)}</TableCell>
                          <TableCell className="text-xs p-1">{p.tipo || "Prestação"}</TableCell>
                          <TableCell className="text-xs p-1 text-right font-medium">{fmt(p.valor)}</TableCell>
                          <TableCell className="text-xs p-1 text-muted-foreground truncate max-w-[220px]">
                            {p.observacoes || "-"}
                          </TableCell>
                          <TableCell className="text-xs p-1 text-right">
                            <Button variant="ghost" size="sm" onClick={() => abrirRecibo(p)}>
                              <Receipt className="h-3.5 w-3.5" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </div>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {reciboData && <ReciboPagamento open={reciboOpen} onOpenChange={setReciboOpen} pagamento={reciboData} />}
    </>
  );
}
