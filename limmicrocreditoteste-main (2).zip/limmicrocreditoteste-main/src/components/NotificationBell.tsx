import { useState, useEffect, useRef, useCallback } from "react";
import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";

interface Notification {
  id: string;
  user_id?: string;
  titulo: string;
  mensagem: string;
  tipo: string;
  lida: boolean;
  global: boolean;
  created_at: string;
}

const REPEAT_SOUND_INTERVAL = 30 * 1000; // 30 segundos — toca até o usuário ler

export function NotificationBell() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const repeatSoundRef = useRef<NodeJS.Timeout | null>(null);
  const repeatCountRef = useRef(0);

  const playNotificationSound = useCallback(() => {
    try {
      const audio = new Audio("data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuByPDaizsIGGS57OihUBELTKXh8LhlHgU2jdXzzHkpBSh+zPDajzsIGWe87Oeg");
      audio.volume = 0.5;
      audio.play().catch(() => {});
    } catch {}
  }, []);

  // Som de notificação: repete a cada 30s enquanto houver não lidas; pára ao ler
  useEffect(() => {
    if (repeatSoundRef.current) {
      clearInterval(repeatSoundRef.current);
      repeatSoundRef.current = null;
    }

    if (unreadCount > 0) {
      // Toca imediatamente uma vez
      playNotificationSound();
      repeatSoundRef.current = setInterval(() => {
        // Só toca se a aba estiver visível, para não desperdiçar recursos
        if (document.visibilityState === "visible") {
          playNotificationSound();
        }
      }, REPEAT_SOUND_INTERVAL);
    }

    return () => {
      if (repeatSoundRef.current) clearInterval(repeatSoundRef.current);
    };
  }, [unreadCount, playNotificationSound]);

  // Get user once
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) setUserId(session.user.id);
    });
  }, []);

  useEffect(() => {
    if (!userId) return;
    fetchNotifications();
    const cleanupNotif = setupRealtimeSubscription();
    // NOTA: canal de chat removido daqui — Chat.tsx já tem realtime próprio
    // e o INSERT em notificacoes feito por trigger/Chat já é apanhado pelo
    // canal personal acima. Reduz subscrições por usuário e melhora performance.
    // Defer overdue check para 30s após login (não bloqueia experiência inicial)
    const t = setTimeout(() => {
      if ('requestIdleCallback' in window) {
        (window as any).requestIdleCallback(() => checkOverdueLoans());
      } else {
        checkOverdueLoans();
      }
    }, 30000);
    return () => { cleanupNotif(); clearTimeout(t); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  const setupChatSubscription = () => {
    const channel = supabase
      .channel("chat-notif-bell")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "mensagens_chat", filter: `receiver_id=eq.${userId}` },
        async (payload) => {
          const msg = payload.new as { id: string; sender_id: string; receiver_id: string; mensagem: string };

          const { data: profile } = await supabase
            .from("user_profiles")
            .select("full_name, nome_instituicao")
            .eq("user_id", msg.sender_id)
            .maybeSingle();

          const senderName = profile?.nome_instituicao || profile?.full_name || "Usuário";

          await supabase.from("notificacoes").insert({
            user_id: userId,
            titulo: `💬 Nova mensagem de ${senderName}`,
            mensagem: msg.mensagem.substring(0, 100),
            tipo: "info",
            global: false,
          });

          playNotificationSound();
        }
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  };

  const fetchNotifications = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return;
      const userId = session.user.id;

      // Fetch personal notifications (including read copies of globals)
      const { data: personal, error: e1 } = await supabase
        .from("notificacoes")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(20);

      // Fetch unread global notifications
      const { data: globals, error: e2 } = await supabase
        .from("notificacoes")
        .select("*")
        .eq("global", true)
        .is("user_id", null)
        .eq("lida", false)
        .order("created_at", { ascending: false })
        .limit(20);

      if (e1) throw e1;
      if (e2) throw e2;

      const personalList = personal || [];
      const globalList = globals || [];

      // Filter out global notifications the user already has a read copy of
      const readGlobalTitles = new Set(
        personalList.filter(n => n.lida).map(n => `${n.titulo}|${n.mensagem}`)
      );
      const filteredGlobals = globalList.filter(
        g => !readGlobalTitles.has(`${g.titulo}|${g.mensagem}`)
      );

      const combined = [...personalList, ...filteredGlobals]
        .sort((a, b) => new Date(b.created_at!).getTime() - new Date(a.created_at!).getTime())
        .slice(0, 30);

      setNotifications(combined);
      setUnreadCount(combined.filter(n => !n.lida).length);
    } catch (error) {
      console.error("Erro ao buscar notificações:", error);
    }
  };

  const setupRealtimeSubscription = () => {
    // Dois canais filtrados no servidor para reduzir tráfego com muitos utilizadores
    const personalChannel = supabase
      .channel(`notificacoes-personal-${userId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "notificacoes", filter: `user_id=eq.${userId}` },
        (payload) => handleNew(payload.new as Notification)
      )
      .subscribe();

    const globalChannel = supabase
      .channel("notificacoes-global")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "notificacoes", filter: `global=eq.true` },
        (payload) => handleNew(payload.new as Notification)
      )
      .subscribe();

    const handleNew = (newNotification: Notification) => {
      setNotifications(prev => {
        if (prev.some(n => n.id === newNotification.id)) return prev;
        return [newNotification, ...prev];
      });
      if (!newNotification.lida) {
        setUnreadCount(prev => prev + 1);
        playNotificationSound();
        const emoji = newNotification.tipo === "info" ? "ℹ️" :
          newNotification.tipo === "success" ? "✅" :
          newNotification.tipo === "warning" ? "⚠️" : "❌";
        toast(`${emoji} ${newNotification.titulo}`, {
          description: newNotification.mensagem,
        });
      }
    };

    return () => {
      supabase.removeChannel(personalChannel);
      supabase.removeChannel(globalChannel);
    };
  };

  const checkOverdueLoans = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return;
      const userId = session.user.id;

      const { data: emprestimos, error } = await supabase
        .from("emprestimos")
        .select("id, data_reembolso, clientes(nome_completo)")
        .eq("user_id", userId)
        .eq("status", "Ativo")
        .lt("data_reembolso", new Date().toISOString());

      if (error) throw error;

      if (emprestimos && emprestimos.length > 0) {
        const today = new Date().toISOString().split('T')[0];
        const { data: existingNotification } = await supabase
          .from("notificacoes")
          .select("id")
          .eq("user_id", userId)
          .eq("tipo", "warning")
          .ilike("titulo", "%empréstimo%atraso%")
          .gte("created_at", today)
          .maybeSingle();

        if (!existingNotification) {
          await supabase.from("notificacoes").insert({
            user_id: userId,
            titulo: `${emprestimos.length} Empréstimo(s) em Atraso`,
            mensagem: `Você tem ${emprestimos.length} empréstimo(s) com pagamento em atraso. Verifique a lista de empréstimos.`,
            tipo: "warning",
            global: false,
          });
        }
      }
    } catch (error) {
      console.error("Erro ao verificar empréstimos em atraso:", error);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return;
      const userId = session.user.id;

      const notification = notifications.find(n => n.id === notificationId);
      if (!notification || notification.lida) return;

      if (notification.global && notification.user_id !== userId) {
        // Create a personal read copy and remove the global from view
        await supabase.from("notificacoes").insert({
          user_id: userId,
          titulo: notification.titulo,
          mensagem: notification.mensagem,
          tipo: notification.tipo,
          global: false,
          lida: true,
        });
        setNotifications(prev => prev.filter(n => n.id !== notificationId));
        setUnreadCount(prev => Math.max(0, prev - 1));
        return;
      }

      const { error } = await supabase
        .from("notificacoes")
        .update({ lida: true })
        .eq("id", notificationId);

      if (error) throw error;

      setNotifications(prev =>
        prev.map(n => n.id === notificationId ? { ...n, lida: true } : n)
      );
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      console.error("Erro ao marcar como lida:", error);
    }
  };

  const markAllAsRead = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return;
      const userId = session.user.id;

      const unreadNotifications = notifications.filter(n => !n.lida);
      if (unreadNotifications.length === 0) return;

      const personalUnread = unreadNotifications.filter(n => n.user_id === userId);
      const globalUnread = unreadNotifications.filter(n => n.global && n.user_id !== userId);

      if (personalUnread.length > 0) {
        await supabase
          .from("notificacoes")
          .update({ lida: true })
          .in("id", personalUnread.map(n => n.id));
      }

      if (globalUnread.length > 0) {
        const copies = globalUnread.map(n => ({
          user_id: userId,
          titulo: n.titulo,
          mensagem: n.mensagem,
          tipo: n.tipo,
          global: false,
          lida: true,
        }));
        await supabase.from("notificacoes").insert(copies);
      }

      setNotifications(prev => prev
        .filter(n => !globalUnread.some(g => g.id === n.id))
        .map(n => personalUnread.some(p => p.id === n.id) ? { ...n, lida: true } : n)
      );
      setUnreadCount(0);
      toast.success("Todas as notificações foram marcadas como lidas");
    } catch (error) {
      console.error("Erro ao marcar todas como lidas:", error);
      toast.error("Erro ao marcar notificações como lidas");
    }
  };

  const getNotificationIcon = (tipo: string) => {
    switch (tipo) {
      case "success": return "✅";
      case "warning": return "⚠️";
      case "error": return "❌";
      default: return "ℹ️";
    }
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className={`h-5 w-5 ${unreadCount > 0 ? "animate-bounce" : ""}`} />
          {unreadCount > 0 && (
            <Badge
              className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs"
              variant="destructive"
            >
              {unreadCount > 9 ? "9+" : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="font-semibold">Notificações</h3>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" onClick={markAllAsRead} className="text-xs">
              Marcar todas como lidas
            </Button>
          )}
        </div>
        <ScrollArea className="h-[400px]">
          {notifications.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              <Bell className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>Nenhuma notificação</p>
            </div>
          ) : (
            <div className="divide-y">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 hover:bg-muted/50 cursor-pointer transition-colors ${
                    !notification.lida ? "bg-muted/30" : ""
                  }`}
                  onClick={() => !notification.lida && markAsRead(notification.id)}
                >
                  <div className="flex items-start gap-3">
                    <span className="text-xl">{getNotificationIcon(notification.tipo)}</span>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-start justify-between gap-2">
                        <p className="font-medium text-sm leading-tight">{notification.titulo}</p>
                        {!notification.lida && (
                          <div className="h-2 w-2 rounded-full bg-primary flex-shrink-0 mt-1" />
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground leading-snug">{notification.mensagem}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(notification.created_at), "dd/MM/yyyy HH:mm")}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
