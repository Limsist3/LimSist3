import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Download, Upload, DatabaseBackup, Loader2 } from "lucide-react";
import { ConfirmDialog } from "@/components/ConfirmDialog";

export function BackupGlobalSection() {
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pendingFile, setPendingFile] = useState<File | null>(null);

  const handleExport = async () => {
    setExporting(true);
    try {
      const { data, error } = await supabase.functions.invoke("backup-global", { body: { action: "export" } });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      const jsonString = JSON.stringify(data);
      const dateStr = new Date().toISOString().split("T")[0];
      let blob: Blob;
      let filename = `backup_geral_limsist_${dateStr}.json`;

      if (typeof (window as any).CompressionStream !== "undefined") {
        try {
          const stream = new Blob([jsonString], { type: "application/json" })
            .stream()
            .pipeThrough(new (window as any).CompressionStream("gzip"));
          blob = await new Response(stream).blob();
          filename += ".gz";
        } catch {
          blob = new Blob([jsonString], { type: "application/json" });
        }
      } else {
        blob = new Blob([jsonString], { type: "application/json" });
      }

      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);

      const total = Object.values(data?.counts ?? {}).reduce((s: number, n: any) => s + Number(n || 0), 0);
      toast.success(`Backup geral exportado: ${total} registos de ${Object.keys(data?.tables ?? {}).length} módulos e ${data?.authUsers?.length ?? 0} contas.`);
    } catch (err) {
      console.error("Erro no backup geral:", err);
      toast.error(err instanceof Error ? err.message : "Erro ao exportar backup geral");
    } finally {
      setExporting(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!/\.(json|gz)$/i.test(file.name)) {
      toast.error("Selecione um ficheiro .json ou .json.gz");
      return;
    }
    setPendingFile(file);
    setConfirmOpen(true);
    e.target.value = "";
  };

  const handleImport = async () => {
    if (!pendingFile) return;
    setImporting(true);
    setConfirmOpen(false);
    try {
      let text: string;
      if (/\.gz$/i.test(pendingFile.name) && typeof (window as any).DecompressionStream !== "undefined") {
        const stream = pendingFile.stream().pipeThrough(new (window as any).DecompressionStream("gzip"));
        text = await new Response(stream).text();
      } else {
        text = await pendingFile.text();
      }
      const backupData = JSON.parse(text);

      const { data, error } = await supabase.functions.invoke("backup-global", {
        body: { action: "import", backupData },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      const failed = Number(data?.totalFailedRows || 0);
      const contas = data?.createdUsers
        ? `, ${data.createdUsers} contas restauradas${data?.defaultPassword ? ` (algumas com senha ${data.defaultPassword})` : " com as senhas originais"}`
        : "";
      const msg = `Restauro concluído: ${data?.totalImportedRows ?? 0} registos em ${data?.importedTables ?? 0} módulos${contas}.`;
      if (failed > 0) toast.warning(`${msg} ${failed} registos incompatíveis ignorados.`);
      else toast.success(msg);
    } catch (err) {
      console.error("Erro ao importar backup geral:", err);
      toast.error(err instanceof Error ? err.message : "Erro ao importar backup geral");
    } finally {
      setImporting(false);
      setPendingFile(null);
    }
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DatabaseBackup className="h-5 w-5" /> Backup Geral da Plataforma
          </CardTitle>
          <CardDescription>
            Exporta ou restaura todos os dados de todos os usuários mãe, agentes e secretariado — incluindo contas de acesso.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="border rounded-lg p-4 space-y-3">
            <h4 className="font-semibold flex items-center gap-2">
              <Download className="h-4 w-4" /> Exportar Tudo
            </h4>
            <p className="text-sm text-muted-foreground">
              Descarrega a totalidade da plataforma (todos os módulos e utilizadores) num único ficheiro comprimido.
            </p>
            <Button onClick={handleExport} disabled={exporting} className="w-full">
              {exporting ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> A exportar...</> : <><Download className="h-4 w-4 mr-2" /> Exportar Backup Geral</>}
            </Button>
          </div>

          <div className="border rounded-lg p-4 space-y-3">
            <h4 className="font-semibold flex items-center gap-2">
              <Upload className="h-4 w-4" /> Importar Tudo
            </h4>
            <p className="text-sm text-muted-foreground">
              Restaura um backup geral. Todas as contas (usuário mãe, agentes e secretariado) voltam com as suas senhas
              originais e ficam 100% operacionais — ninguém precisa de criar conta de novo.
            </p>
            <label>
              <input type="file" accept=".json,.gz,application/gzip,application/json" onChange={handleFileSelect} className="hidden" disabled={importing} />
              <Button asChild className="w-full" variant="outline" disabled={importing}>
                <span>
                  {importing ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> A restaurar...</> : <><Upload className="h-4 w-4 mr-2" /> Selecionar Ficheiro</>}
                </span>
              </Button>
            </label>
          </div>
        </CardContent>
      </Card>

      <ConfirmDialog
        open={confirmOpen}
        onOpenChange={setConfirmOpen}
        description={`Restaurar o backup geral "${pendingFile?.name}"? Registos com o mesmo ID serão actualizados em toda a plataforma.`}
        onConfirm={handleImport}
        confirmLabel="Restaurar"
        variant="default"
      />
    </>
  );
}
