import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { FileCheck2, Download, Printer, Save } from "lucide-react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import emblema from "@/assets/emblema-mocambique.png";

// Modelo 30 — Declaração Periódica ISPC (réplica editável)
// A UI é uma réplica estruturada, com secções e etiquetas nos lugares certos.
// A exportação (PDF/impressão) captura EXACTAMENTE o que está preenchido.

const initialForm = {
  tipo: "inicial" as "inicial" | "substituicao",
  ano: String(new Date().getFullYear()),
  trimestre: "",
  prazo: "dentro" as "dentro" | "fora",
  nuit: "",
  area_fiscal: "",
  nome_sujeito: "",
  atividade_principal: "",
  codigo_cae: "",
  // 6 - Domicílio Fiscal
  rua: "", nr_porta: "", andar: "", flat: "", codigo_postal: "", caixa_postal: "",
  provincia: "", dm_tipo: "distrito" as "distrito" | "municipio", distrito_municipio: "",
  pdm_tipo: "posto" as "posto" | "distrito", posto_dm: "", localidade: "",
  bairro: "", povoacao: "", celula: "", quarteirao: "", casa_nr: "",
  telefone_fixo: "", telemovel: "", fax: "",
  email: "", email_alt: "",
  // 7
  sem_operacoes: false,
  // 8 Modalidade
  modalidade: "" as "" | "unica" | "quatro" | "tres",
  // 9 Apuramento
  campo01: "", campo02: "", campo03: "", campo04: "", campo05: "",
  // 10 Autenticação
  data_dia: "", data_mes: "", data_ano: "",
  nome_assinatura: "", assinatura: "",
  // 11 Uso exclusivo
  nr_entrada: "", nr_insercao: "",
  serv_data_dia: "", serv_data_mes: "", serv_data_ano: "",
  nome_funcionario: "", assinatura_funcionario: "",
  nr_receita: "",
  rec_data_dia: "", rec_data_mes: "", rec_data_ano: "",
};

const MAPPED_COLS = new Set([
  "ano","trimestre","nuit","nome_sujeito","codigo_cae","rua","nr_porta","andar",
  "caixa_postal","bairro","celula","quarteirao","casa_nr","codigo_postal","localidade",
  "distrito","provincia","telefone_fixo","telemovel","fax","email","modalidade",
  "sem_operacoes","assinatura",
]);

export function DeclaracaoISPC() {
  const [form, setForm] = useState<typeof initialForm>(initialForm);
  const [existingId, setExistingId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("declaracoes_ispc").select("*").order("updated_at", { ascending: false }).limit(1).maybeSingle();
      if (data) {
        setExistingId(data.id);
        const flat = Object.fromEntries(Object.entries(data).filter(([k]) => k !== "dados_extra").map(([k, v]) => [k, v == null ? "" : v]));
        const extra = (data as any).dados_extra || {};
        setForm({ ...initialForm, ...(flat as any), ...(Object.fromEntries(Object.entries(extra).map(([k, v]) => [k, v == null ? "" : v])) as any) });
      }
    })();
  }, []);

  const set = (k: keyof typeof initialForm, v: any) => setForm((f) => ({ ...f, [k]: v }));

  // Auto: campo02 = campo01 * 3%
  useEffect(() => {
    const v = parseFloat(form.campo01) || 0;
    if (v > 0) set("campo02", (v * 0.03).toFixed(2));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.campo01]);

  useEffect(() => {
    const c2 = parseFloat(form.campo02) || 0;
    const c3 = parseFloat(form.campo03) || 0;
    const c4 = parseFloat(form.campo04) || 0;
    const base = form.modalidade === "tres" ? c2 : (c3 > 0 ? c3 : c2);
    set("campo05", (base + c4).toFixed(2));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.campo02, form.campo03, form.campo04, form.modalidade]);

  const guardar = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    const user = session?.user;
    if (!user) { toast.error("Sessão expirada"); return; }
    const payload: any = { user_id: user.id, dados_extra: {} };
    Object.entries(form).forEach(([k, v]) => {
      if (MAPPED_COLS.has(k)) {
        if (k === "sem_operacoes") payload[k] = !!v;
        else payload[k] = v || null;
      } else {
        payload.dados_extra[k] = v ?? null;
      }
    });
    const res = existingId
      ? await supabase.from("declaracoes_ispc").update(payload).eq("id", existingId)
      : await supabase.from("declaracoes_ispc").insert([payload]).select("id").maybeSingle();
    if (res.error) { console.warn(res.error); toast.error("Erro ao guardar"); return; }
    if (!existingId && (res as any).data?.id) setExistingId((res as any).data.id);
    toast.success("Declaração guardada");
  };

  // Captura o form estruturado como imagem e exporta A4 — o print é IGUAL ao editado
  const exportar = async (print: boolean) => {
    if (!printRef.current) return;
    setBusy(true);
    try {
      const el = printRef.current;
      el.classList.add("m30-export");
      const canvas = await html2canvas(el, {
        scale: 2,
        backgroundColor: "#ffffff",
        useCORS: true,
        windowWidth: el.scrollWidth,
      });
      el.classList.remove("m30-export");
      const imgData = canvas.toDataURL("image/jpeg", 0.92);
      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4", compress: true });
      const pageW = pdf.internal.pageSize.getWidth();
      const pageH = pdf.internal.pageSize.getHeight();
      const ratio = canvas.height / canvas.width;
      const imgW = pageW;
      const imgH = Math.min(pageH, imgW * ratio);
      pdf.addImage(imgData, "JPEG", 0, 0, imgW, imgH, undefined, "FAST");
      if (print) {
        const url = pdf.output("bloburl");
        window.open(url, "_blank");
      } else {
        pdf.save(`ISPC-M30-${form.ano || ""}-T${form.trimestre || ""}.pdf`);
      }
    } catch (e) {
      console.error(e);
      toast.error("Erro ao gerar PDF");
    } finally {
      setBusy(false);
    }
  };

  // ===== Estilos inline usados no bloco imprimível =====
  const cell = "border border-black px-1 py-0.5 text-[10px]";
  const sectionTitle = "bg-[#e8e2bd] border border-black px-2 py-0.5 text-[10px] font-bold";
  const inp = "border-0 border-b border-dotted border-black bg-transparent outline-none text-[10px] px-1 w-full print:border-black";
  const chk = (on: boolean) => (
    <span className="inline-block w-3 h-3 border border-black align-middle text-center leading-[10px] text-[10px] font-bold">
      {on ? "X" : ""}
    </span>
  );
  const digitBoxes = (val: string, len: number, onChange: (v: string) => void) => {
    const chars = val.padEnd(len, " ").slice(0, len).split("");
    return (
      <span className="inline-flex align-middle">
        {chars.map((c, i) => (
          <input
            key={i}
            value={c.trim()}
            maxLength={1}
            onChange={(e) => {
              const arr = val.padEnd(len, " ").split("");
              arr[i] = e.target.value.slice(-1) || " ";
              onChange(arr.join("").trimEnd());
            }}
            className="w-4 h-4 text-center text-[10px] border border-black mx-[1px] bg-transparent outline-none"
          />
        ))}
      </span>
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileCheck2 className="h-5 w-5 text-primary" />
          Modelo 30 — Declaração Periódica ISPC (Editável)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2 mb-4 pb-3 border-b">
          <Button onClick={guardar} size="sm" disabled={busy}><Save className="h-4 w-4 mr-1" />Guardar</Button>
          <Button variant="outline" size="sm" onClick={() => exportar(false)} disabled={busy}><Download className="h-4 w-4 mr-1" />Descarregar PDF</Button>
          <Button variant="outline" size="sm" onClick={() => exportar(true)} disabled={busy}><Printer className="h-4 w-4 mr-1" />Imprimir</Button>
        </div>

        <p className="text-xs text-muted-foreground mb-3">
          Preencha cada campo na sua secção correcta. Ao descarregar/imprimir, o documento sai
          <strong> exactamente como foi editado</strong> — numa página A4.
        </p>

        {/* ============ BLOCO IMPRIMÍVEL A4 ============ */}
        <div className="overflow-x-auto">
          <div
            ref={printRef}
            className="mx-auto bg-white text-black"
            style={{ width: "794px", padding: "18px 22px", fontFamily: "Arial, Helvetica, sans-serif" }}
          >
            {/* Aviso topo */}
            <div className="text-center text-[9px] font-bold">
              SE PREENCHER MANUALMENTE, POR FAVOR UTILIZE LETRA DE IMPRENSA
            </div>

            {/* Cabeçalho */}
            <div className="flex border border-black mt-1">
              <div className="flex items-center gap-2 p-1 w-[42%] border-r border-black">
                <img src={emblema} alt="Emblema Moçambique" className="h-12 w-12 object-contain" />
                <div className="text-center flex-1 text-[10px] leading-tight">
                  <div>República de Moçambique</div>
                  <div>Ministério das Finanças</div>
                  <div className="font-bold">Autoridade Tributária de Moçambique</div>
                  <div>DIRECÇÃO GERAL DE IMPOSTOS</div>
                </div>
              </div>
              <div className="flex-1 bg-[#c9a94a] text-center flex flex-col justify-center border-r border-black">
                <div className="text-[11px] font-bold">DECLARAÇÃO PERIÓDICA</div>
                <div className="text-[14px] font-extrabold tracking-wider">MODELO 30</div>
              </div>
              <div className="w-[18%] text-center flex flex-col justify-center px-1">
                <div className="text-[16px] font-extrabold">ISPC</div>
                <div className="text-[7px] leading-tight">IMPOSTO SIMPLIFICADO PARA PEQUENOS CONTRIBUINTES</div>
              </div>
            </div>

            {/* 1 - Tipo */}
            <div className={sectionTitle}>1 – TIPO DE DECLARAÇÃO</div>
            <div className="border border-t-0 border-black flex items-center p-2 gap-8 text-[10px]">
              <label className="flex items-center gap-2 cursor-pointer">
                <span onClick={() => set("tipo", "inicial")}>{chk(form.tipo === "inicial")}</span>
                Declaração Inicial
              </label>
              <label className="flex items-center gap-2 cursor-pointer ml-auto">
                <span onClick={() => set("tipo", "substituicao")}>{chk(form.tipo === "substituicao")}</span>
                Declaração de Substituição
              </label>
            </div>

            {/* 2 e 3 */}
            <div className="grid grid-cols-2">
              <div>
                <div className={sectionTitle}>2 – PERÍODO A QUE RESPEITA</div>
                <div className="border border-t-0 border-black p-2 flex items-center gap-2 text-[10px]">
                  <span>Ano</span>
                  {digitBoxes(form.ano, 4, (v) => set("ano", v))}
                  <span>Trimestre</span>
                  <input value={form.trimestre} onChange={(e) => set("trimestre", e.target.value)} className={`${inp} w-14 text-center`} />
                  <div className="ml-auto flex flex-col gap-1">
                    <label className="flex items-center gap-1 cursor-pointer">
                      Dentro do Prazo <span onClick={() => set("prazo", "dentro")}>{chk(form.prazo === "dentro")}</span>
                    </label>
                    <label className="flex items-center gap-1 cursor-pointer">
                      Fora do Prazo <span onClick={() => set("prazo", "fora")}>{chk(form.prazo === "fora")}</span>
                    </label>
                  </div>
                </div>
              </div>
              <div className="border-l-0">
                <div className={sectionTitle}>3 – NÚMERO ÚNICO DE IDENTIFICAÇÃO TRIBUTÁRIA (NUIT)</div>
                <div className="border border-t-0 border-black p-2 text-[10px]">
                  <div className="flex justify-center">{digitBoxes(form.nuit, 9, (v) => set("nuit", v))}</div>
                  <div className="mt-1 flex items-center gap-1">
                    <span>Área Fiscal:</span>
                    <input value={form.area_fiscal} onChange={(e) => set("area_fiscal", e.target.value)} className={inp} />
                  </div>
                </div>
              </div>
            </div>

            {/* 4 - Nome */}
            <div className={sectionTitle}>4 – NOME/DESIGNAÇÃO SOCIAL</div>
            <div className="border border-t-0 border-black p-2">
              <input value={form.nome_sujeito} onChange={(e) => set("nome_sujeito", e.target.value)} className={inp} />
            </div>

            {/* 5 - Actividade */}
            <div className={sectionTitle}>5 – ACTIVIDADE ECONÓMICA PRINCIPAL</div>
            <div className="border border-t-0 border-black p-2 flex gap-2 items-end">
              <div className="flex-1">
                <div className="text-[9px]">Actividade</div>
                <input value={form.atividade_principal} onChange={(e) => set("atividade_principal", e.target.value)} className={inp} />
              </div>
              <div className="w-56">
                <div className="text-[9px]">Código de Actividade Económica (CAE)</div>
                <div className="flex justify-end">{digitBoxes(form.codigo_cae, 5, (v) => set("codigo_cae", v))}</div>
              </div>
            </div>

            {/* 6 - Domicílio Fiscal */}
            <div className={sectionTitle}>6 – DOMICÍLIO FISCAL DA ACTIVIDADE</div>
            <div className="border border-t-0 border-black p-2 text-[10px] space-y-1">
              <div className="grid grid-cols-12 gap-1 items-center">
                <span className="col-span-1">Rua/Avenida:</span>
                <input value={form.rua} onChange={(e) => set("rua", e.target.value)} className={`${inp} col-span-5`} />
                <span className="col-span-1 text-right">Nº</span>
                <input value={form.nr_porta} onChange={(e) => set("nr_porta", e.target.value)} className={`${inp} col-span-1`} />
                <span className="col-span-1 text-right">Andar</span>
                <input value={form.andar} onChange={(e) => set("andar", e.target.value)} className={`${inp} col-span-1`} />
                <span className="col-span-1 text-right">Flat</span>
                <input value={form.flat} onChange={(e) => set("flat", e.target.value)} className={`${inp} col-span-1`} />
              </div>
              <div className="grid grid-cols-12 gap-1 items-center">
                <span className="col-span-2">Código Postal:</span>
                <input value={form.codigo_postal} onChange={(e) => set("codigo_postal", e.target.value)} className={`${inp} col-span-3`} />
                <span className="col-span-2 text-right">Caixa Postal:</span>
                <input value={form.caixa_postal} onChange={(e) => set("caixa_postal", e.target.value)} className={`${inp} col-span-5`} />
              </div>
              <div className="grid grid-cols-12 gap-1 items-center">
                <span className="col-span-1">Província:</span>
                <input value={form.provincia} onChange={(e) => set("provincia", e.target.value)} className={`${inp} col-span-4`} />
                <label className="col-span-1 flex items-center gap-1 justify-end cursor-pointer">
                  <span onClick={() => set("dm_tipo", "distrito")}>{chk(form.dm_tipo === "distrito")}</span>Distrito
                </label>
                <label className="col-span-2 flex items-center gap-1 cursor-pointer">
                  <span onClick={() => set("dm_tipo", "municipio")}>{chk(form.dm_tipo === "municipio")}</span>Município
                </label>
                <input value={form.distrito_municipio} onChange={(e) => set("distrito_municipio", e.target.value)} className={`${inp} col-span-4`} />
              </div>
              <div className="grid grid-cols-12 gap-1 items-center">
                <label className="col-span-2 flex items-center gap-1 cursor-pointer">
                  <span onClick={() => set("pdm_tipo", "posto")}>{chk(form.pdm_tipo === "posto")}</span>Posto Adm.
                </label>
                <label className="col-span-2 flex items-center gap-1 cursor-pointer">
                  <span onClick={() => set("pdm_tipo", "distrito")}>{chk(form.pdm_tipo === "distrito")}</span>Distrito Mun.
                </label>
                <input value={form.posto_dm} onChange={(e) => set("posto_dm", e.target.value)} className={`${inp} col-span-3`} />
                <span className="col-span-1 text-right">Localidade:</span>
                <input value={form.localidade} onChange={(e) => set("localidade", e.target.value)} className={`${inp} col-span-4`} />
              </div>
              <div className="grid grid-cols-12 gap-1 items-center">
                <span className="col-span-1">Bairro:</span>
                <input value={form.bairro} onChange={(e) => set("bairro", e.target.value)} className={`${inp} col-span-3`} />
                <span className="col-span-1 text-right">Povoação:</span>
                <input value={form.povoacao} onChange={(e) => set("povoacao", e.target.value)} className={`${inp} col-span-2`} />
                <span className="col-span-1 text-right">Célula:</span>
                <input value={form.celula} onChange={(e) => set("celula", e.target.value)} className={`${inp} col-span-1`} />
                <span className="col-span-1 text-right">Quart.:</span>
                <input value={form.quarteirao} onChange={(e) => set("quarteirao", e.target.value)} className={`${inp} col-span-1`} />
                <span className="col-span-1 text-right">Nº Casa:</span>
                <input value={form.casa_nr} onChange={(e) => set("casa_nr", e.target.value)} className={`${inp} col-span-1`} />
              </div>
              <div className="grid grid-cols-12 gap-1 items-center">
                <span className="col-span-1">Tel. Fixo:</span>
                <input value={form.telefone_fixo} onChange={(e) => set("telefone_fixo", e.target.value)} className={`${inp} col-span-3`} />
                <span className="col-span-1 text-right">Telemóvel:</span>
                <input value={form.telemovel} onChange={(e) => set("telemovel", e.target.value)} className={`${inp} col-span-3`} />
                <span className="col-span-1 text-right">Fax:</span>
                <input value={form.fax} onChange={(e) => set("fax", e.target.value)} className={`${inp} col-span-3`} />
              </div>
              <div className="grid grid-cols-12 gap-1 items-center">
                <span className="col-span-1">E-mail:</span>
                <input value={form.email} onChange={(e) => set("email", e.target.value)} className={`${inp} col-span-4`} />
                <span className="col-span-2 text-right">E-mail alternativo:</span>
                <input value={form.email_alt} onChange={(e) => set("email_alt", e.target.value)} className={`${inp} col-span-5`} />
              </div>
            </div>

            {/* 7 */}
            <div className={sectionTitle}>7 – INEXISTÊNCIA DE OPERAÇÕES</div>
            <div className="border border-t-0 border-black p-2 text-[10px] flex items-center gap-2">
              <span>Se no período a que esta declaração respeita não realizou operações activas nem passivas, assinale</span>
              <span onClick={() => set("sem_operacoes", !form.sem_operacoes)} className="cursor-pointer">{chk(!!form.sem_operacoes)}</span>
              <span>e passa para o quadro 10</span>
            </div>

            {/* 8 */}
            <div className={sectionTitle}>8 – MODALIDADE DE PAGAMENTO</div>
            <div className="border border-t-0 border-black p-2 text-[10px] grid grid-cols-2 gap-2">
              <div>
                <div className="text-[9px] italic mb-1">Se optou pela taxa de 75.000,00 MT, indique a modalidade:</div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <span onClick={() => set("modalidade", "unica")}>{chk(form.modalidade === "unica")}</span>
                  Pagamento em única prestação
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <span onClick={() => set("modalidade", "quatro")}>{chk(form.modalidade === "quatro")}</span>
                  Pagamento em quatro prestações
                </label>
              </div>
              <div>
                <div className="text-[9px] italic mb-1">&nbsp;</div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <span onClick={() => set("modalidade", "tres")}>{chk(form.modalidade === "tres")}</span>
                  Se optou pela taxa de 3%
                </label>
              </div>
            </div>

            {/* 9 */}
            <div className={sectionTitle}>9 – APURAMENTO DO IMPOSTO</div>
            <div className="border border-t-0 border-black p-2 text-[10px]">
              <div className="grid grid-cols-[1fr_60px_140px] gap-1 items-center">
                <div className="col-span-3 flex justify-end pr-1 font-semibold border-b border-black pb-0.5">
                  Valor respeitante ao trimestre
                </div>

                <div>Total de vendas e/ou serviços prestados</div>
                <div className="text-center border border-black">01</div>
                <input value={form.campo01} onChange={(e) => set("campo01", e.target.value)} className={`${inp} text-right`} />

                <div>Imposto apurado à taxa de 3% (=01 x 3%)</div>
                <div className="text-center border border-black">02</div>
                <input value={form.campo02} onChange={(e) => set("campo02", e.target.value)} className={`${inp} text-right`} />

                <div>Imposto a pagar a taxa fixa</div>
                <div className="text-center border border-black">03</div>
                <input value={form.campo03} onChange={(e) => set("campo03", e.target.value)} className={`${inp} text-right`} />

                <div>Juros compensatórios</div>
                <div className="text-center border border-black">04</div>
                <input value={form.campo04} onChange={(e) => set("campo04", e.target.value)} className={`${inp} text-right`} />

                <div className="text-[9px]">05 = 02+04 (Taxa 3%) &nbsp; ou &nbsp; 05 = 03+04 (Taxa Fixa)</div>
                <div className="text-center border border-black font-bold">05</div>
                <input value={form.campo05} onChange={(e) => set("campo05", e.target.value)} className={`${inp} text-right font-bold`} />
              </div>
            </div>

            {/* 10 e 11 */}
            <div className="grid grid-cols-2">
              <div>
                <div className={sectionTitle}>10 – AUTENTICAÇÃO DO SUJEITO PASSIVO</div>
                <div className="border border-t-0 border-black p-2 text-[10px] space-y-1">
                  <div className="flex items-center gap-1">
                    <span>Data:</span>
                    <input value={form.data_dia} onChange={(e) => set("data_dia", e.target.value)} className={`${inp} w-10 text-center`} placeholder="dd" />
                    <span>/</span>
                    <input value={form.data_mes} onChange={(e) => set("data_mes", e.target.value)} className={`${inp} w-10 text-center`} placeholder="mm" />
                    <span>/</span>
                    <input value={form.data_ano} onChange={(e) => set("data_ano", e.target.value)} className={`${inp} w-14 text-center`} placeholder="aaaa" />
                  </div>
                  <div className="flex items-center gap-1">
                    <span>Nome:</span>
                    <input value={form.nome_assinatura} onChange={(e) => set("nome_assinatura", e.target.value)} className={inp} />
                  </div>
                  <div className="flex items-center gap-1">
                    <span>Assinatura:</span>
                    <input value={form.assinatura} onChange={(e) => set("assinatura", e.target.value)} className={inp} />
                  </div>
                </div>
              </div>
              <div>
                <div className={sectionTitle}>11 – USO EXCLUSIVO DOS SERVIÇOS</div>
                <div className="border border-t-0 border-black p-2 text-[10px] space-y-1">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <div>Nº Entrada</div>
                      <input value={form.nr_entrada} onChange={(e) => set("nr_entrada", e.target.value)} className={inp} />
                      <div>Nº Inserção</div>
                      <input value={form.nr_insercao} onChange={(e) => set("nr_insercao", e.target.value)} className={inp} />
                    </div>
                    <div>
                      <div>Nº Receita</div>
                      <input value={form.nr_receita} onChange={(e) => set("nr_receita", e.target.value)} className={inp} />
                      <div>Data recibo:</div>
                      <div className="flex items-center gap-1">
                        <input value={form.rec_data_dia} onChange={(e) => set("rec_data_dia", e.target.value)} className={`${inp} w-8 text-center`} />/
                        <input value={form.rec_data_mes} onChange={(e) => set("rec_data_mes", e.target.value)} className={`${inp} w-8 text-center`} />/
                        <input value={form.rec_data_ano} onChange={(e) => set("rec_data_ano", e.target.value)} className={`${inp} w-12 text-center`} />
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <span>Funcionário:</span>
                    <input value={form.nome_funcionario} onChange={(e) => set("nome_funcionario", e.target.value)} className={inp} />
                  </div>
                  <div className="flex items-center gap-1">
                    <span>Assinatura:</span>
                    <input value={form.assinatura_funcionario} onChange={(e) => set("assinatura_funcionario", e.target.value)} className={inp} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
