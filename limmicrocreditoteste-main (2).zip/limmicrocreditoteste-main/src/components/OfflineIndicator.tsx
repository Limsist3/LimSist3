import { useOfflineSync } from '@/hooks/useOfflineSync';
import { Cloud, CloudOff, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';

export const OfflineIndicator = () => {
  const { isOnline, isSyncing, pendingCount, syncPendingOperations } = useOfflineSync();

  if (isOnline && pendingCount === 0) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <div className={`flex items-center gap-2 px-4 py-2 rounded-lg shadow-lg ${
        isOnline ? 'bg-primary text-primary-foreground' : 'bg-warning text-warning-foreground'
      }`}>
        {isOnline ? (
          <>
            <Cloud className="h-5 w-5" />
            <span className="text-sm font-medium">Online</span>
            {pendingCount > 0 && (
              <>
                <span className="text-sm">
                  ({pendingCount} pendente{pendingCount > 1 ? 's' : ''})
                </span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={syncPendingOperations}
                  disabled={isSyncing}
                  className="h-6 px-2"
                >
                  {isSyncing ? (
                    <RefreshCw className="h-4 w-4 animate-spin" />
                  ) : (
                    <RefreshCw className="h-4 w-4" />
                  )}
                </Button>
              </>
            )}
          </>
        ) : (
          <>
            <CloudOff className="h-5 w-5" />
            <span className="text-sm font-medium">Modo Offline</span>
            {pendingCount > 0 && (
              <span className="text-sm">
                ({pendingCount} pendente{pendingCount > 1 ? 's' : ''})
              </span>
            )}
          </>
        )}
      </div>
    </div>
  );
};
