import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { MessageSquare, CheckCircle2, XCircle, Plus, CreditCard, History, Pencil, Trash2 } from "lucide-react";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { format } from "date-fns";

interface SmsPacote {
  id: string; nome: string; quantidade_sms: number; preco: number; numero_mpesa: string; numero_emola: string; nome_titular: string; ativo: boolean; validade_dias: number;
}
interface SmsRecarga {
  id: string; user_id: string; pacote_id: string; quantidade_sms: number; valor: number; metodo_pagamento: string; status: string; comprovativo_url: string | null; created_at: string;
}
interface SmsEnvio {
  id: string; user_id: string; telefone: string; mensagem: string; tipo: string; status: string; erro: string | null; created_at: string;
}
interface UserProfile {
  user_id: string; full_name: string | null; email: string | null;
}

export function SmsAdminSection() {
  const [pacotes, setPacotes] = useState<SmsPacote[]>([]);
  const [recargas, setRecargas] = useState<SmsRecarga[]>([]);
  const [envios, setEnvios] = useState<SmsEnvio[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [pacoteOpen, setPacoteOpen] = useState(false);
  const [saldoOpen, setSaldoOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<string>("");
  const [saldoInput, setSaldoInput] = useState<string>("");
  const [saldoDias, setSaldoDias] = useState<string>("30");

  const [pacoteForm, setPacoteForm] = useState<Partial<SmsPacote>>({
    nome: "", quantidade_sms: 100, preco: 0, numero_mpesa: "", numero_emola: "", nome_titular: "", validade_dias: 30, ativo: true,
  });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => { void load(); }, []);

  async function load() {
    const [pacotesRes, recargasRes, enviosRes, usersRes] = await Promise.all([
      supabase.from("sms_pacotes").select("*").order("preco"),
      supabase.from("sms_recargas").select("*").order("created_at", { ascending: false }).limit(50),
      supabase.from("sms_envios").select("*").order("created_at", { ascending: false }).limit(50),
      supabase.from("user_profiles").select("user_id, full_name, email").order("full_name"),
    ]);
    setPacotes((pacotesRes.data as SmsPacote[]) || []);
    setRecargas((recargasRes.data as SmsRecarga[]) || []);
    setEnvios((enviosRes.data as SmsEnvio[]) || []);
    setUsers((usersRes.data as UserProfile[]) || []);
    setLoading(false);
  }

  const getUserName = (userId: string) => users.find(u => u.user_id === userId)?.full_name || userId.slice(0, 8);

  function resetPacoteForm() {
    setEditingId(null);
    setPacoteForm({ nome: "", quantidade_sms: 100, preco: 0, numero_mpesa: "", numero_emola: "", nome_titular: "", validade_dias: 30, ativo: true });
  }

  function openNovoPacote() {
    resetPacoteForm();
    setPacoteOpen(true);
  }

  function openEditarPacote(p: SmsPacote) {
    setEditingId(p.id);
    setPacoteForm({ ...p });
    setPacoteOpen(true);
  }

  async function handleSavePacote() {
    if (!pacoteForm.nome || !pacoteForm.quantidade_sms || pacoteForm.preco === undefined) return;
    const payload = {
      nome: pacoteForm.nome,
      quantidade_sms: pacoteForm.quantidade_sms,
      preco: pacoteForm.preco,
      numero_mpesa: pacoteForm.numero_mpesa || "",
      numero_emola: pacoteForm.numero_emola || "",
      nome_titular: pacoteForm.nome_titular || "",
      validade_dias: pacoteForm.validade_dias || 30,
      ativo: pacoteForm.ativo ?? true,
    };
    const { error } = editingId
      ? await supabase.from("sms_pacotes").update(payload).eq("id", editingId)
      : await supabase.from("sms_pacotes").insert(payload);
    if (error) toast.error("Erro ao guardar pacote: " + error.message);
    else {
      toast.success(editingId ? "Pacote actualizado" : "Pacote criado");
      setPacoteOpen(false);
      resetPacoteForm();
      void load();
    }
  }

  async function handleDeletePacote() {
    if (!deleteId) return;
    const { error } = await supabase.from("sms_pacotes").delete().eq("id", deleteId);
    if (error) toast.error("Erro ao apagar pacote: " + error.message);
    else { toast.success("Pacote apagado"); void load(); }
    setDeleteId(null);
  }

  async function handleAprovar(id: string) {
    const { data, error } = await supabase.rpc("sms_aprovar_recarga", { p_recarga_id: id });
    const result = data as any;
    if (error || !result?.success) toast.error("Erro ao aprovar: " + (error?.message || result?.error));
    else { toast.success("Recarga aprovada"); void load(); }
  }

  async function handleRejeitar(id: string) {
    const motivo = prompt("Motivo da rejeição?");
    if (!motivo) return;
    const { data, error } = await supabase.rpc("sms_rejeitar_recarga", { p_recarga_id: id, p_motivo: motivo });
    const result = data as any;
    if (error || !result?.success) toast.error("Erro ao rejeitar: " + (error?.message || result?.error));
    else { toast.success("Recarga rejeitada"); void load(); }
  }

  async function handleDefinirSaldo() {
    if (!selectedUser) return;
    const saldo = parseInt(saldoInput, 10);
    if (isNaN(saldo) || saldo < 0) { toast.error("Saldo inválido"); return; }
    const dias = parseInt(saldoDias, 10) || 30;
    const { data, error } = await supabase.rpc("sms_definir_saldo", { p_user_id: selectedUser, p_saldo: saldo, p_dias: dias });
    const result = data as any;
    if (error || !result?.success) toast.error("Erro ao definir saldo: " + (error?.message || result?.error));
    else { toast.success("Saldo definido"); setSaldoOpen(false); setSelectedUser(""); setSaldoInput(""); void load(); }
  }

  async function handleTogglePacote(id: string, ativo: boolean) {
    const { error } = await supabase.from("sms_pacotes").update({ ativo: !ativo }).eq("id", id);
    if (error) toast.error("Erro: " + error.message);
    else { toast.success("Pacote actualizado"); void load(); }
  }

  if (loading) return <p className="text-muted-foreground">A carregar...</p>;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" /> Gestão de SMS
          </CardTitle>
          <CardDescription>
            Configure pacotes, aprove recargas e defina saldos de SMS por instituição.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-wrap gap-3">
            <Button onClick={openNovoPacote}><Plus className="h-4 w-4 mr-2" /> Novo Pacote</Button>
            <Button variant="outline" onClick={() => setSaldoOpen(true)}><CreditCard className="h-4 w-4 mr-2" /> Definir Saldo</Button>
          </div>

          <div className="space-y-2">
            <h3 className="font-semibold">Pacotes de SMS</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>SMS</TableHead>
                  <TableHead>Preço</TableHead>
                  <TableHead>M-Pesa / e-Mola</TableHead>
                  <TableHead>Validade</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pacotes.map(p => (
                  <TableRow key={p.id}>
                    <TableCell>{p.nome}</TableCell>
                    <TableCell>{p.quantidade_sms}</TableCell>
                    <TableCell>{p.preco.toLocaleString("pt-PT")} MZN</TableCell>
                    <TableCell>{p.numero_mpesa} / {p.numero_emola}</TableCell>
                    <TableCell>{p.validade_dias} dias</TableCell>
                    <TableCell><Badge variant={p.ativo ? "default" : "secondary"}>{p.ativo ? "Activo" : "Inactivo"}</Badge></TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="sm" onClick={() => handleTogglePacote(p.id, p.ativo)}>
                          {p.ativo ? "Desactivar" : "Activar"}
                        </Button>
                        <Button variant="ghost" size="icon" title="Editar" onClick={() => openEditarPacote(p)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" title="Apagar" onClick={() => setDeleteId(p.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="space-y-2">
            <h3 className="font-semibold flex items-center gap-2"><CreditCard className="h-4 w-4" /> Pedidos de Recarga</h3>
            {recargas.length === 0 ? <p className="text-sm text-muted-foreground">Sem pedidos pendentes.</p> : (
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Data</TableHead><TableHead>Utilizador</TableHead><TableHead>Pacote</TableHead><TableHead>Valor</TableHead><TableHead>Método</TableHead><TableHead>Estado</TableHead><TableHead></TableHead></TableRow>
                </TableHeader>
                <TableBody>
                  {recargas.map(r => (
                    <TableRow key={r.id}>
                      <TableCell>{format(new Date(r.created_at), "dd/MM/yyyy HH:mm")}</TableCell>
                      <TableCell>{getUserName(r.user_id)}</TableCell>
                      <TableCell>{r.quantidade_sms} SMS</TableCell>
                      <TableCell>{r.valor.toLocaleString("pt-PT")} MZN</TableCell>
                      <TableCell>{r.metodo_pagamento}</TableCell>
                      <TableCell><Badge variant={r.status === "aprovado" ? "default" : r.status === "rejeitado" ? "destructive" : "secondary"}>{r.status}</Badge></TableCell>
                      <TableCell>
                        {r.status === "pendente" && (
                          <div className="flex gap-1">
                            <Button size="icon" variant="ghost" onClick={() => handleAprovar(r.id)}><CheckCircle2 className="h-4 w-4 text-emerald-600" /></Button>
                            <Button size="icon" variant="ghost" onClick={() => handleRejeitar(r.id)}><XCircle className="h-4 w-4 text-destructive" /></Button>
                          </div>
                        )}
                        {r.comprovativo_url && <a href={r.comprovativo_url} target="_blank" rel="noopener noreferrer" className="text-xs text-primary">Ver comprovativo</a>}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>

          <div className="space-y-2">
            <h3 className="font-semibold flex items-center gap-2"><History className="h-4 w-4" /> Últimos Envios (todas as instituições)</h3>
            {envios.length === 0 ? <p className="text-sm text-muted-foreground">Sem envios.</p> : (
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Data</TableHead><TableHead>Instituição</TableHead><TableHead>Telefone</TableHead><TableHead>Tipo</TableHead><TableHead>Estado</TableHead></TableRow>
                </TableHeader>
                <TableBody>
                  {envios.map(e => (
                    <TableRow key={e.id}>
                      <TableCell>{format(new Date(e.created_at), "dd/MM/yyyy HH:mm")}</TableCell>
                      <TableCell>{getUserName(e.user_id)}</TableCell>
                      <TableCell>{e.telefone}</TableCell>
                      <TableCell>{e.tipo}</TableCell>
                      <TableCell><Badge variant={e.status === "enviado" ? "default" : "destructive"}>{e.status}</Badge>{e.erro && <div className="text-xs text-destructive">{e.erro}</div>}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={pacoteOpen} onOpenChange={(o) => { setPacoteOpen(o); if (!o) resetPacoteForm(); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editingId ? "Editar Pacote de SMS" : "Novo Pacote de SMS"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2"><Label>Nome</Label><Input value={pacoteForm.nome} onChange={e => setPacoteForm(f => ({ ...f, nome: e.target.value }))} /></div>
            <div><Label>Quantidade de SMS</Label><Input type="number" value={pacoteForm.quantidade_sms} onChange={e => setPacoteForm(f => ({ ...f, quantidade_sms: parseInt(e.target.value) || 0 }))} /></div>
            <div><Label>Preço (MZN)</Label><Input type="number" value={pacoteForm.preco} onChange={e => setPacoteForm(f => ({ ...f, preco: parseFloat(e.target.value) || 0 }))} /></div>
            <div><Label>Nº M-Pesa</Label><Input value={pacoteForm.numero_mpesa} onChange={e => setPacoteForm(f => ({ ...f, numero_mpesa: e.target.value }))} /></div>
            <div><Label>Nº e-Mola</Label><Input value={pacoteForm.numero_emola} onChange={e => setPacoteForm(f => ({ ...f, numero_emola: e.target.value }))} /></div>
            <div><Label>Nome Titular</Label><Input value={pacoteForm.nome_titular} onChange={e => setPacoteForm(f => ({ ...f, nome_titular: e.target.value }))} /></div>
            <div><Label>Validade (dias)</Label><Input type="number" value={pacoteForm.validade_dias} onChange={e => setPacoteForm(f => ({ ...f, validade_dias: parseInt(e.target.value) || 30 }))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPacoteOpen(false)}>Cancelar</Button>
            <Button onClick={handleSavePacote} disabled={!pacoteForm.nome || !pacoteForm.quantidade_sms}>{editingId ? "Guardar Alterações" : "Criar Pacote"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={saldoOpen} onOpenChange={setSaldoOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Definir Saldo de SMS</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Instituição</Label>
              <select className="w-full border rounded-md p-2" value={selectedUser} onChange={e => setSelectedUser(e.target.value)}>
                <option value="">Selecione</option>
                {users.map(u => <option key={u.user_id} value={u.user_id}>{u.full_name || u.email || u.user_id}</option>)}
              </select>
            </div>
            <div><Label>Saldo (SMS)</Label><Input type="number" min={0} value={saldoInput} onChange={e => setSaldoInput(e.target.value)} /></div>
            <div><Label>Validade (dias)</Label><Input type="number" min={1} value={saldoDias} onChange={e => setSaldoDias(e.target.value)} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSaldoOpen(false)}>Cancelar</Button>
            <Button onClick={handleDefinirSaldo} disabled={!selectedUser || saldoInput === ""}>Definir</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteId}
        onOpenChange={(o) => { if (!o) setDeleteId(null); }}
        title="Apagar pacote de SMS?"
        description="Esta acção é permanente. Recargas já aprovadas não são afectadas."
        confirmLabel="Apagar"
        variant="destructive"
        onConfirm={handleDeletePacote}
      />
    </div>
  );
}
