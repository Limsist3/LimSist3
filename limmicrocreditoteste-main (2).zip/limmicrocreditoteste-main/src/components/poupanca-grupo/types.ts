export interface PgGrupo {
  id: string;
  user_id: string;
  nome: string;
  codigo: string;
  gestor: string | null;
  data_inicio: string;
  estado: string;
  ciclo_dias: number;
  permitir_rendimento: boolean;
  taxa_rendimento: number;
  assist_tipo: string;
  assist_valor: number;
  permitir_emprestimos: boolean;
  taxa_juros: number;
  tipo_juros: string;
  prazo_meses: number;
  taxa_mora_diaria: number;
  multa_tipo: string;
  multa_valor: number;
  dias_tolerancia: number;
  limite_emprestimo_pct: number;
  observacoes: string | null;
}

export interface PgMembro {
  id: string;
  grupo_id: string;
  nome: string;
  bi: string | null;
  nuit: string | null;
  telefone: string | null;
  endereco: string | null;
  estado: string;
  data_entrada: string;
  data_saida: string | null;
}

export interface PgSaldo {
  capital: number;
  rendimentos: number;
  levantamentos: number;
  saldo: number;
  divida: number;
  bloqueado: number;
  disponivel: number;
  liquido: number;
}

export interface PgStats {
  saldo_total: number;
  divida_total: number;
  clientes_inadimplentes: number;
  total_poupado: number;
  total_rendimentos: number;
  total_levantamentos: number;
  receita_assistencia: number;
  total_emprestado: number;
  total_recuperado: number;
  receita_juros: number;
  receita_mora: number;
  receita_multa: number;
  clientes_ativos: number;
  total_membros: number;
  emprestimos_activos: number;
}

export const MZN = (v: number) =>
  `${(Number(v) || 0).toLocaleString("pt-PT", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} MT`;

export const numOf = (s: string) => parseFloat(String(s).replace(",", ".")) || 0;

export const dataPT = (d?: string | null) =>
  d ? new Date(d).toLocaleDateString("pt-PT") : "-";

export const TIPO_LABEL: Record<string, string> = {
  deposito: "Depósito",
  rendimento: "Rendimento",
  assistencia: "Assistência técnica",
  emprestimo: "Empréstimo concedido",
  pagamento: "Pagamento de capital",
  juros: "Pagamento de juros",
  mora: "Pagamento de mora",
  multa: "Pagamento de multa",
  levantamento: "Levantamento",
  estorno: "Estorno",
  ajuste: "Ajuste",
};
