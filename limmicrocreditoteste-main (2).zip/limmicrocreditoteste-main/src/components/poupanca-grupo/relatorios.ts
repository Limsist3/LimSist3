import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import { loadLetterhead, applyLetterheadAllPages, LETTERHEAD_CONTENT_TOP, LETTERHEAD_CONTENT_BOTTOM } from "@/lib/letterhead";
import { formatDatePT } from "@/lib/excelExport";
import { PgGrupo, PgMembro, PgSaldo, PgStats, TIPO_LABEL, dataPT } from "./types";

interface Dados {
  grupo: PgGrupo;
  membros: { membro: PgMembro; saldo?: PgSaldo }[];
  stats: PgStats | null;
  movimentos: any[];
  emprestimos: any[];
}

const n2 = (v: number) =>
  (Number(v) || 0).toLocaleString("pt-PT", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export async function gerarRelatorioGrupoPdf({ grupo, membros, stats, movimentos, emprestimos }: Dados) {
  try {
    const lh = await loadLetterhead();
    const doc = new jsPDF({ compress: true });
    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = { top: LETTERHEAD_CONTENT_TOP, bottom: LETTERHEAD_CONTENT_BOTTOM };
    let y = LETTERHEAD_CONTENT_TOP;

    doc.setFontSize(14);
    doc.setFont("helvetica", "bold");
    doc.text("RELATORIO DE POUPANCA EM GRUPO", pageWidth / 2, y, { align: "center" });
    y += 6;
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.text(`${grupo.nome} (${grupo.codigo}) - ${formatDatePT(new Date())}`, pageWidth / 2, y, { align: "center" });
    y += 6;

    autoTable(doc, {
      startY: y,
      body: [
        ["Gestor:", grupo.gestor || "-", "Inicio:", dataPT(grupo.data_inicio)],
        ["Ciclo:", `${grupo.ciclo_dias} dias`, "Rendimento:", grupo.permitir_rendimento ? `${grupo.taxa_rendimento}%` : "Nao"],
        ["Juros:", `${grupo.taxa_juros}% (${grupo.tipo_juros})`, "Mora diaria:", `${grupo.taxa_mora_diaria}%`],
        ["Multa:", grupo.multa_tipo === "percentagem" ? `${grupo.multa_valor}%` : `${n2(grupo.multa_valor)} MT`, "Tolerancia:", `${grupo.dias_tolerancia} dias`],
      ],
      theme: "grid",
      styles: { fontSize: 8, cellPadding: 1.5 },
      columnStyles: { 0: { fontStyle: "bold", cellWidth: 28 }, 2: { fontStyle: "bold", cellWidth: 28 } },
      margin,
    });

    if (stats) {
      autoTable(doc, {
        startY: (doc as any).lastAutoTable.finalY + 5,
        head: [["Resumo financeiro", "Valor (MT)"]],
        body: [
          ["Total poupado", n2(stats.total_poupado)],
          ["Rendimentos creditados", n2(stats.total_rendimentos)],
          ["Levantamentos", n2(stats.total_levantamentos)],
          ["Saldo total do grupo", n2(stats.saldo_total)],
          ["Total emprestado", n2(stats.total_emprestado)],
          ["Total recuperado", n2(stats.total_recuperado)],
          ["Divida em aberto", n2(stats.divida_total)],
          ["Receita de juros", n2(stats.receita_juros)],
          ["Receita de mora", n2(stats.receita_mora)],
          ["Receita de multas", n2(stats.receita_multa)],
          ["Assistencia tecnica", n2(stats.receita_assistencia)],
          ["Membros activos", String(stats.clientes_ativos)],
          ["Inadimplentes", String(stats.clientes_inadimplentes)],
        ],
        theme: "grid",
        styles: { fontSize: 8, cellPadding: 1.5 },
        headStyles: { fillColor: [91, 79, 191], fontStyle: "bold" },
        columnStyles: { 1: { halign: "right" } },
        margin,
      });
    }

    autoTable(doc, {
      startY: (doc as any).lastAutoTable.finalY + 5,
      head: [["Membro", "Capital", "Rendimentos", "Levantado", "Saldo", "Divida", "Disponivel"]],
      body: membros.map(({ membro, saldo }) => [
        membro.nome,
        n2(saldo?.capital || 0), n2(saldo?.rendimentos || 0), n2(saldo?.levantamentos || 0),
        n2(saldo?.saldo || 0), n2(saldo?.divida || 0), n2(saldo?.disponivel || 0),
      ]),
      theme: "grid",
      styles: { fontSize: 8, cellPadding: 1.5 },
      headStyles: { fillColor: [91, 79, 191], fontStyle: "bold" },
      columnStyles: { 1: { halign: "right" }, 2: { halign: "right" }, 3: { halign: "right" }, 4: { halign: "right" }, 5: { halign: "right" }, 6: { halign: "right" } },
      margin,
    });

    if (emprestimos.length) {
      autoTable(doc, {
        startY: (doc as any).lastAutoTable.finalY + 5,
        head: [["Membro", "Desembolso", "Vencimento", "Capital", "Juros", "Pago", "Mora", "Multa", "Devido"]],
        body: emprestimos.map((e) => [
          e.nome, dataPT(e.data_desembolso), dataPT(e.data_vencimento),
          n2(e.valor), n2(e.valor_juros), n2(e.valor_pago),
          n2(e.mora?.mora_pendente || 0), n2(e.mora?.multa_pendente || 0),
          n2(e.mora?.total_devido ?? Math.max((e.valor_total || 0) - (e.valor_pago || 0), 0)),
        ]),
        theme: "grid",
        styles: { fontSize: 7, cellPadding: 1.2 },
        headStyles: { fillColor: [91, 79, 191], fontStyle: "bold" },
        margin,
      });
    }

    if (movimentos.length) {
      autoTable(doc, {
        startY: (doc as any).lastAutoTable.finalY + 5,
        head: [["Data", "Operacao", "Descricao", "Valor"]],
        body: movimentos.slice(0, 200).map((m) => [
          dataPT(m.data),
          (TIPO_LABEL[m.tipo] || m.tipo) + (m.estornado ? " (estornado)" : ""),
          m.descricao || "",
          n2(m.valor),
        ]),
        theme: "grid",
        styles: { fontSize: 7, cellPadding: 1.2 },
        headStyles: { fillColor: [91, 79, 191], fontStyle: "bold" },
        columnStyles: { 3: { halign: "right" } },
        margin,
      });
    }

    applyLetterheadAllPages(doc, lh);
    doc.save(`Poupanca_Grupo_${grupo.codigo}_${new Date().toISOString().split("T")[0]}.pdf`);
    toast.success("Relatório gerado!");
  } catch (e) {
    console.error(e);
    toast.error("Erro ao gerar relatório");
  }
}

export function gerarRelatorioGrupoExcel({ grupo, membros, stats, movimentos, emprestimos }: Dados) {
  try {
    const wb = XLSX.utils.book_new();

    const resumo: (string | number)[][] = [
      ["RELATÓRIO DE POUPANÇA EM GRUPO"],
      [grupo.nome, grupo.codigo],
      ["Data", formatDatePT(new Date())],
      [],
      ["Resumo financeiro", "Valor (MT)"],
    ];
    if (stats) {
      resumo.push(
        ["Total poupado", stats.total_poupado],
        ["Rendimentos creditados", stats.total_rendimentos],
        ["Levantamentos", stats.total_levantamentos],
        ["Saldo total do grupo", stats.saldo_total],
        ["Total emprestado", stats.total_emprestado],
        ["Total recuperado", stats.total_recuperado],
        ["Dívida em aberto", stats.divida_total],
        ["Receita de juros", stats.receita_juros],
        ["Receita de mora", stats.receita_mora],
        ["Receita de multas", stats.receita_multa],
        ["Assistência técnica", stats.receita_assistencia],
        ["Membros activos", stats.clientes_ativos],
        ["Inadimplentes", stats.clientes_inadimplentes],
      );
    }
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(resumo), "Resumo");

    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([
      ["Membro", "BI", "NUIT", "Telefone", "Capital", "Rendimentos", "Levantado", "Saldo", "Dívida", "Disponível"],
      ...membros.map(({ membro, saldo }) => [
        membro.nome, membro.bi || "", membro.nuit || "", membro.telefone || "",
        saldo?.capital || 0, saldo?.rendimentos || 0, saldo?.levantamentos || 0,
        saldo?.saldo || 0, saldo?.divida || 0, saldo?.disponivel || 0,
      ]),
    ]), "Membros");

    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([
      ["Membro", "Desembolso", "Vencimento", "Capital", "Juros", "Total", "Pago", "Mora", "Multa", "Devido", "Estado"],
      ...emprestimos.map((e) => [
        e.nome, dataPT(e.data_desembolso), dataPT(e.data_vencimento),
        e.valor, e.valor_juros, e.valor_total, e.valor_pago,
        e.mora?.mora_pendente || 0, e.mora?.multa_pendente || 0,
        e.mora?.total_devido ?? Math.max((e.valor_total || 0) - (e.valor_pago || 0), 0),
        e.estado,
      ]),
    ]), "Empréstimos");

    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([
      ["Data", "Operação", "Descrição", "Valor", "Estornado"],
      ...movimentos.map((m) => [
        dataPT(m.data), TIPO_LABEL[m.tipo] || m.tipo, m.descricao || "", m.valor, m.estornado ? "Sim" : "Não",
      ]),
    ]), "Extrato");

    XLSX.writeFile(wb, `Poupanca_Grupo_${grupo.codigo}_${new Date().toISOString().split("T")[0]}.xlsx`);
    toast.success("Excel gerado!");
  } catch (e) {
    console.error(e);
    toast.error("Erro ao gerar Excel");
  }
}
