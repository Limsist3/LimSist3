import { useState, useEffect, useCallback, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Plus, RefreshCw, Wallet, TrendingUp, AlertTriangle, Users2, Banknote,
  FileText, Undo2, Trash2, Pencil,
} from "lucide-react";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";
import { PgGrupo, PgMembro, PgSaldo, PgStats, MZN, numOf, dataPT, TIPO_LABEL } from "./types";
import { gerarRelatorioGrupoPdf, gerarRelatorioGrupoExcel } from "./relatorios";

interface Props {
  grupo: PgGrupo;
  onGrupoChange: () => void;
}

const addDias = (iso: string, dias: number) => {
  const d = new Date(iso);
  d.setDate(d.getDate() + dias);
  return d.toISOString().split("T")[0];
};
const addMeses = (iso: string, meses: number) => {
  const d = new Date(iso);
  d.setMonth(d.getMonth() + meses);
  return d.toISOString().split("T")[0];
};
const hoje = () => new Date().toISOString().split("T")[0];

export function PoupancaGrupoDetalhe({ grupo, onGrupoChange }: Props) {
  const [membros, setMembros] = useState<PgMembro[]>([]);
  const [saldos, setSaldos] = useState<Record<string, PgSaldo>>({});
  const [stats, setStats] = useState<PgStats | null>(null);
  const [depositos, setDepositos] = useState<any[]>([]);
  const [emprestimos, setEmprestimos] = useState<any[]>([]);
  const [moras, setMoras] = useState<Record<string, any>>({});
  const [movimentos, setMovimentos] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);

  // dialogs
  const [dlgMembro, setDlgMembro] = useState(false);
  const [membroEdit, setMembroEdit] = useState<PgMembro | null>(null);
  const [fMembro, setFMembro] = useState({ nome: "", bi: "", nuit: "", telefone: "", endereco: "", estado: "ativo", data_entrada: hoje() });
  const [delMembro, setDelMembro] = useState<PgMembro | null>(null);

  const [dlgDeposito, setDlgDeposito] = useState(false);
  const [fDeposito, setFDeposito] = useState({ membro_id: "", valor: "", data: hoje(), taxa: "", ciclo: "", metodo: "Numerário", obs: "" });

  const [dlgLevant, setDlgLevant] = useState(false);
  const [fLevant, setFLevant] = useState({ membro_id: "", valor: "", data: hoje(), obs: "" });

  const [dlgEmp, setDlgEmp] = useState(false);
  const [fEmp, setFEmp] = useState({ membro_id: "", valor: "", taxa: "", tipo_juros: "", prazo: "", data: hoje(), obs: "" });

  const [dlgPag, setDlgPag] = useState<any | null>(null);
  const [fPag, setFPag] = useState({ valor: "", tipo: "capital", data: hoje(), metodo: "Numerário", obs: "" });

  const [dlgCiclo, setDlgCiclo] = useState(false);
  const [ciclo, setCiclo] = useState<any>(null);
  const [confirmEncerrar, setConfirmEncerrar] = useState(false);
  const [estornoMov, setEstornoMov] = useState<any | null>(null);

  const [extratoMembro, setExtratoMembro] = useState<string>("todos");

  const loadAll = useCallback(async () => {
    const [mRes, dRes, eRes, movRes, sRes] = await Promise.all([
      supabase.from("pg_membros").select("*").eq("grupo_id", grupo.id).order("nome"),
      supabase.from("pg_depositos").select("*").eq("grupo_id", grupo.id).order("data_deposito", { ascending: false }).limit(300),
      supabase.from("pg_emprestimos").select("*").eq("grupo_id", grupo.id).order("data_desembolso", { ascending: false }).limit(300),
      supabase.from("pg_movimentos").select("*").eq("grupo_id", grupo.id).order("data", { ascending: false }).order("created_at", { ascending: false }).limit(500),
      supabase.rpc("pg_stats_grupo", { p_grupo_id: grupo.id }),
    ]);

    const mem = ((mRes.data || []) as unknown as PgMembro[]);
    setMembros(mem);
    setDepositos(dRes.data || []);
    setEmprestimos(eRes.data || []);
    setMovimentos(movRes.data || []);
    setStats((sRes.data as unknown as PgStats) || null);

    const saldoEntries = await Promise.all(
      mem.map(async (m) => {
        const { data } = await supabase.rpc("pg_saldo_membro", { p_membro_id: m.id });
        return [m.id, data as unknown as PgSaldo] as const;
      })
    );
    setSaldos(Object.fromEntries(saldoEntries));

    const emps = (eRes.data || []).filter((e: any) => e.estado !== "pago" && e.estado !== "cancelado");
    const moraEntries = await Promise.all(
      emps.map(async (e: any) => {
        const { data } = await supabase.rpc("pg_mora_emprestimo", { p_emprestimo_id: e.id });
        return [e.id, data] as const;
      })
    );
    setMoras(Object.fromEntries(moraEntries));
  }, [grupo.id]);

  useEffect(() => {
    (async () => {
      await supabase.rpc("pg_processar_rendimentos", { p_grupo_id: grupo.id });
      loadAll();
    })();
  }, [grupo.id, loadAll]);

  useRealtimeRefresh(
    ["pg_membros", "pg_depositos", "pg_emprestimos", "pg_pagamentos", "pg_movimentos"],
    loadAll, true, 1500
  );

  const membroNome = (id?: string | null) => membros.find((m) => m.id === id)?.nome || "-";

  // ---------- Membros ----------
  const abrirMembro = (m?: PgMembro) => {
    setMembroEdit(m || null);
    setFMembro(m
      ? { nome: m.nome, bi: m.bi || "", nuit: m.nuit || "", telefone: m.telefone || "", endereco: m.endereco || "", estado: m.estado, data_entrada: m.data_entrada }
      : { nome: "", bi: "", nuit: "", telefone: "", endereco: "", estado: "ativo", data_entrada: hoje() });
    setDlgMembro(true);
  };

  const salvarMembro = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fMembro.nome.trim()) { toast.error("Indique o nome"); return; }
    setBusy(true);
    const { data: { session } } = await supabase.auth.getSession();
    const payload = {
      nome: fMembro.nome.trim(), bi: fMembro.bi || null, nuit: fMembro.nuit || null,
      telefone: fMembro.telefone || null, endereco: fMembro.endereco || null,
      estado: fMembro.estado, data_entrada: fMembro.data_entrada,
    };
    const { error } = membroEdit
      ? await supabase.from("pg_membros").update(payload).eq("id", membroEdit.id)
      : await supabase.from("pg_membros").insert([{ ...payload, grupo_id: grupo.id, user_id: session?.user?.id }]);
    setBusy(false);
    if (error) { toast.error("Erro ao gravar membro"); return; }
    toast.success(membroEdit ? "Membro actualizado" : "Membro adicionado");
    setDlgMembro(false);
    loadAll();
  };

  const eliminarMembro = async () => {
    if (!delMembro) return;
    const { error } = await supabase.from("pg_membros").delete().eq("id", delMembro.id);
    if (error) { toast.error("Erro ao eliminar membro"); return; }
    toast.success("Membro eliminado");
    setDelMembro(null);
    loadAll();
  };

  // ---------- Depósitos ----------
  const abrirDeposito = () => {
    setFDeposito({
      membro_id: membros[0]?.id || "", valor: "", data: hoje(),
      taxa: String(grupo.permitir_rendimento ? grupo.taxa_rendimento : 0),
      ciclo: String(grupo.ciclo_dias), metodo: "Numerário", obs: "",
    });
    setDlgDeposito(true);
  };

  const salvarDeposito = async (e: React.FormEvent) => {
    e.preventDefault();
    const valor = numOf(fDeposito.valor);
    if (!fDeposito.membro_id) { toast.error("Seleccione o membro"); return; }
    if (valor <= 0) { toast.error("Valor inválido"); return; }
    setBusy(true);
    const { data: { session } } = await supabase.auth.getSession();
    const uid = session?.user?.id;
    const ciclo_dias = Math.max(1, Math.round(numOf(fDeposito.ciclo)) || grupo.ciclo_dias);
    const taxa = grupo.permitir_rendimento ? numOf(fDeposito.taxa) : 0;
    const assist = grupo.assist_tipo === "percentagem"
      ? +(valor * (grupo.assist_valor / 100)).toFixed(2)
      : +(grupo.assist_valor || 0);

    const { data: dep, error } = await supabase.from("pg_depositos").insert([{
      user_id: uid, grupo_id: grupo.id, membro_id: fDeposito.membro_id,
      valor, taxa_rendimento: taxa, ciclo_dias,
      data_deposito: fDeposito.data, data_vencimento: addDias(fDeposito.data, ciclo_dias),
      assistencia_valor: assist, metodo: fDeposito.metodo, observacoes: fDeposito.obs || null,
    }]).select().single();

    if (error || !dep) { setBusy(false); toast.error("Erro ao registar depósito"); return; }

    const movs: any[] = [{
      user_id: uid, grupo_id: grupo.id, membro_id: fDeposito.membro_id, tipo: "deposito",
      valor, afeta_saldo: true, data: fDeposito.data, referencia_id: dep.id,
      descricao: `Depósito (ciclo de ${ciclo_dias} dias, vence ${dataPT(addDias(fDeposito.data, ciclo_dias))})`,
    }];
    if (assist > 0) {
      movs.push({
        user_id: uid, grupo_id: grupo.id, membro_id: fDeposito.membro_id, tipo: "assistencia",
        valor: assist, afeta_saldo: false, data: fDeposito.data, referencia_id: dep.id,
        descricao: "Assistência técnica cobrada à instituição (não afecta o saldo do membro)",
      });
    }
    await supabase.from("pg_movimentos").insert(movs);
    setBusy(false);
    toast.success("Depósito registado");
    setDlgDeposito(false);
    loadAll();
  };

  const processarRendimentos = async () => {
    setBusy(true);
    const { data, error } = await supabase.rpc("pg_processar_rendimentos", { p_grupo_id: grupo.id });
    setBusy(false);
    if (error) { toast.error("Erro ao processar rendimentos"); return; }
    const r: any = data;
    toast.success(r?.processados ? `${r.processados} rendimento(s) creditado(s): ${MZN(r.total_rendimento)}` : "Nenhum ciclo vencido por processar");
    loadAll();
  };

  // ---------- Levantamento ----------
  const salvarLevantamento = async (e: React.FormEvent) => {
    e.preventDefault();
    const valor = numOf(fLevant.valor);
    const s = saldos[fLevant.membro_id];
    if (!fLevant.membro_id) { toast.error("Seleccione o membro"); return; }
    if (valor <= 0) { toast.error("Valor inválido"); return; }
    if (s && valor > s.disponivel) { toast.error(`Disponível apenas ${MZN(s.disponivel)} (saldo bloqueado por dívida)`); return; }
    setBusy(true);
    const { data: { session } } = await supabase.auth.getSession();
    const { error } = await supabase.from("pg_movimentos").insert([{
      user_id: session?.user?.id, grupo_id: grupo.id, membro_id: fLevant.membro_id,
      tipo: "levantamento", valor, afeta_saldo: true, data: fLevant.data,
      descricao: fLevant.obs || "Levantamento de poupança",
    }]);
    setBusy(false);
    if (error) { toast.error("Erro ao registar levantamento"); return; }
    toast.success("Levantamento registado");
    setDlgLevant(false);
    setFLevant({ membro_id: "", valor: "", data: hoje(), obs: "" });
    loadAll();
  };

  // ---------- Empréstimos ----------
  const abrirEmprestimo = () => {
    setFEmp({
      membro_id: membros[0]?.id || "", valor: "", taxa: String(grupo.taxa_juros),
      tipo_juros: grupo.tipo_juros, prazo: String(grupo.prazo_meses), data: hoje(), obs: "",
    });
    setDlgEmp(true);
  };

  const previewEmp = useMemo(() => {
    const v = numOf(fEmp.valor), t = numOf(fEmp.taxa) / 100, n = Math.max(1, Math.round(numOf(fEmp.prazo)) || 1);
    const juros = fEmp.tipo_juros === "composto" ? v * (Math.pow(1 + t, n) - 1) : v * t * n;
    return { juros: +juros.toFixed(2), total: +(v + juros).toFixed(2) };
  }, [fEmp]);

  const salvarEmprestimo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!grupo.permitir_emprestimos) { toast.error("Empréstimos desactivados neste grupo"); return; }
    const valor = numOf(fEmp.valor);
    if (!fEmp.membro_id) { toast.error("Seleccione o membro"); return; }
    if (valor <= 0) { toast.error("Valor inválido"); return; }
    const s = saldos[fEmp.membro_id];
    const limite = s ? s.disponivel * (grupo.limite_emprestimo_pct / 100) : 0;
    if (s && valor > limite) {
      toast.error(`Limite deste membro: ${MZN(limite)} (${grupo.limite_emprestimo_pct}% do saldo disponível)`);
      return;
    }
    setBusy(true);
    const { data: { session } } = await supabase.auth.getSession();
    const uid = session?.user?.id;
    const prazo = Math.max(1, Math.round(numOf(fEmp.prazo)) || 1);
    const { data: emp, error } = await supabase.from("pg_emprestimos").insert([{
      user_id: uid, grupo_id: grupo.id, membro_id: fEmp.membro_id,
      valor, taxa_juros: numOf(fEmp.taxa), tipo_juros: fEmp.tipo_juros, prazo_meses: prazo,
      data_desembolso: fEmp.data, data_vencimento: addMeses(fEmp.data, prazo),
      valor_juros: previewEmp.juros, valor_total: previewEmp.total,
      taxa_mora_diaria: grupo.taxa_mora_diaria, multa_tipo: grupo.multa_tipo,
      multa_valor: grupo.multa_valor, dias_tolerancia: grupo.dias_tolerancia,
      observacoes: fEmp.obs || null,
    }]).select().single();

    if (error || !emp) { setBusy(false); toast.error("Erro ao registar empréstimo"); return; }

    await supabase.from("pg_movimentos").insert([{
      user_id: uid, grupo_id: grupo.id, membro_id: fEmp.membro_id, tipo: "emprestimo",
      valor, afeta_saldo: false, data: fEmp.data, referencia_id: emp.id,
      descricao: `Empréstimo concedido - total a pagar ${MZN(previewEmp.total)} até ${dataPT(addMeses(fEmp.data, prazo))}`,
    }]);
    setBusy(false);
    toast.success("Empréstimo registado");
    setDlgEmp(false);
    loadAll();
  };

  const abrirPagamento = (emp: any) => {
    setFPag({ valor: "", tipo: "capital", data: hoje(), metodo: "Numerário", obs: "" });
    setDlgPag(emp);
  };

  const salvarPagamento = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dlgPag) return;
    const valor = numOf(fPag.valor);
    if (valor <= 0) { toast.error("Valor inválido"); return; }
    setBusy(true);
    const { data, error } = await supabase.rpc("pg_registar_pagamento", {
      p_emprestimo_id: dlgPag.id, p_valor: valor, p_tipo: fPag.tipo,
      p_data: fPag.data, p_metodo: fPag.metodo, p_obs: fPag.obs || null,
    });
    setBusy(false);
    const r: any = data;
    if (error || (r && r.success === false)) { toast.error(r?.error || "Erro ao registar pagamento"); return; }
    toast.success("Pagamento registado");
    setDlgPag(null);
    loadAll();
  };

  // ---------- Estorno ----------
  const estornar = async () => {
    if (!estornoMov) return;
    const { error } = await supabase.from("pg_movimentos").update({ estornado: true }).eq("id", estornoMov.id);
    if (error) { toast.error("Erro ao estornar"); return; }
    if (estornoMov.tipo === "deposito" && estornoMov.referencia_id) {
      await supabase.from("pg_depositos").update({ estado: "cancelado" }).eq("id", estornoMov.referencia_id);
    }
    toast.success("Movimento estornado");
    setEstornoMov(null);
    loadAll();
  };

  // ---------- Ciclo ----------
  const simularCiclo = async () => {
    setBusy(true);
    const { data, error } = await supabase.rpc("pg_encerrar_ciclo", { p_grupo_id: grupo.id, p_simular: true });
    setBusy(false);
    if (error) { toast.error("Erro ao calcular encerramento"); return; }
    setCiclo(data);
    setDlgCiclo(true);
    loadAll();
  };

  const encerrarCiclo = async () => {
    const { error } = await supabase.rpc("pg_encerrar_ciclo", { p_grupo_id: grupo.id, p_simular: false });
    if (error) { toast.error("Erro ao encerrar ciclo"); return; }
    toast.success("Ciclo encerrado");
    setConfirmEncerrar(false);
    setDlgCiclo(false);
    onGrupoChange();
    loadAll();
  };

  const movimentosFiltrados = movimentos.filter(
    (m) => extratoMembro === "todos" || m.membro_id === extratoMembro
  );

  const relatorioDados = () => ({
    grupo,
    membros: membros.map((m) => ({ membro: m, saldo: saldos[m.id] })),
    stats,
    movimentos: movimentosFiltrados,
    emprestimos: emprestimos.map((e) => ({ ...e, nome: membroNome(e.membro_id), mora: moras[e.id] })),
  });

  const Metric = ({ icon: Icon, label, value, tone = "" }: any) => (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Icon className="h-4 w-4" /> {label}
        </div>
        <p className={`mt-1 text-lg font-bold ${tone}`}>{value}</p>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 className="text-lg font-semibold">{grupo.nome}</h3>
          <p className="text-xs text-muted-foreground">
            {grupo.codigo} · Ciclo {grupo.ciclo_dias} dias ·{" "}
            {grupo.permitir_rendimento ? `Rendimento ${grupo.taxa_rendimento}%` : "Sem rendimento"} ·{" "}
            Mora {grupo.taxa_mora_diaria}%/dia
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={processarRendimentos} disabled={busy}>
            <RefreshCw className="mr-2 h-4 w-4" /> Processar rendimentos
          </Button>
          <Button variant="outline" size="sm" onClick={() => gerarRelatorioGrupoPdf(relatorioDados())}>
            <FileText className="mr-2 h-4 w-4" /> PDF
          </Button>
          <Button variant="outline" size="sm" onClick={() => gerarRelatorioGrupoExcel(relatorioDados())}>
            Excel
          </Button>
        </div>
      </div>

      <Tabs defaultValue="painel">
        <TabsList className="flex-wrap">
          <TabsTrigger value="painel">Painel</TabsTrigger>
          <TabsTrigger value="membros">Membros</TabsTrigger>
          <TabsTrigger value="depositos">Depósitos</TabsTrigger>
          <TabsTrigger value="emprestimos">Empréstimos</TabsTrigger>
          <TabsTrigger value="extrato">Extrato</TabsTrigger>
          <TabsTrigger value="ciclo">Ciclo</TabsTrigger>
        </TabsList>

        {/* PAINEL */}
        <TabsContent value="painel" className="mt-4 space-y-4">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Metric icon={Wallet} label="Saldo total do grupo" value={MZN(stats?.saldo_total || 0)} />
            <Metric icon={TrendingUp} label="Rendimentos creditados" value={MZN(stats?.total_rendimentos || 0)} />
            <Metric icon={Banknote} label="Total emprestado" value={MZN(stats?.total_emprestado || 0)} />
            <Metric icon={AlertTriangle} label="Dívida em aberto" value={MZN(stats?.divida_total || 0)} tone="text-destructive" />
            <Metric icon={Users2} label="Membros activos" value={`${stats?.clientes_ativos || 0} / ${stats?.total_membros || 0}`} />
            <Metric icon={AlertTriangle} label="Inadimplentes" value={String(stats?.clientes_inadimplentes || 0)} />
            <Metric icon={Banknote} label="Receita de juros" value={MZN(stats?.receita_juros || 0)} />
            <Metric icon={Banknote} label="Assistência técnica" value={MZN(stats?.receita_assistencia || 0)} />
          </div>

          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">Posição por membro</CardTitle></CardHeader>
            <CardContent className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Membro</TableHead>
                    <TableHead className="text-right">Capital</TableHead>
                    <TableHead className="text-right">Rendimentos</TableHead>
                    <TableHead className="text-right">Levantado</TableHead>
                    <TableHead className="text-right">Saldo</TableHead>
                    <TableHead className="text-right">Dívida</TableHead>
                    <TableHead className="text-right">Disponível</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {membros.map((m) => {
                    const s = saldos[m.id];
                    return (
                      <TableRow key={m.id}>
                        <TableCell className="font-medium">{m.nome}</TableCell>
                        <TableCell className="text-right">{MZN(s?.capital || 0)}</TableCell>
                        <TableCell className="text-right">{MZN(s?.rendimentos || 0)}</TableCell>
                        <TableCell className="text-right">{MZN(s?.levantamentos || 0)}</TableCell>
                        <TableCell className="text-right font-semibold">{MZN(s?.saldo || 0)}</TableCell>
                        <TableCell className="text-right text-destructive">{MZN(s?.divida || 0)}</TableCell>
                        <TableCell className="text-right">{MZN(s?.disponivel || 0)}</TableCell>
                      </TableRow>
                    );
                  })}
                  {membros.length === 0 && (
                    <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground">Sem membros registados</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* MEMBROS */}
        <TabsContent value="membros" className="mt-4 space-y-3">
          <Button size="sm" onClick={() => abrirMembro()}>
            <Plus className="mr-2 h-4 w-4" /> Adicionar membro
          </Button>
          <Card>
            <CardContent className="overflow-x-auto p-0 sm:p-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>BI</TableHead>
                    <TableHead>NUIT</TableHead>
                    <TableHead>Telefone</TableHead>
                    <TableHead>Entrada</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead className="text-right">Saldo</TableHead>
                    <TableHead className="text-right">Acções</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {membros.map((m) => (
                    <TableRow key={m.id}>
                      <TableCell className="font-medium">{m.nome}</TableCell>
                      <TableCell>{m.bi || "-"}</TableCell>
                      <TableCell>{m.nuit || "-"}</TableCell>
                      <TableCell>{m.telefone || "-"}</TableCell>
                      <TableCell>{dataPT(m.data_entrada)}</TableCell>
                      <TableCell><Badge variant={m.estado === "ativo" ? "default" : "secondary"}>{m.estado}</Badge></TableCell>
                      <TableCell className="text-right">{MZN(saldos[m.id]?.saldo || 0)}</TableCell>
                      <TableCell className="text-right whitespace-nowrap">
                        <Button variant="ghost" size="icon" onClick={() => abrirMembro(m)}><Pencil className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => setDelMembro(m)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {membros.length === 0 && (
                    <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground">Sem membros</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* DEPÓSITOS */}
        <TabsContent value="depositos" className="mt-4 space-y-3">
          <div className="flex flex-wrap gap-2">
            <Button size="sm" onClick={abrirDeposito} disabled={membros.length === 0}>
              <Plus className="mr-2 h-4 w-4" /> Novo depósito
            </Button>
            <Button size="sm" variant="outline" onClick={() => { setFLevant({ membro_id: membros[0]?.id || "", valor: "", data: hoje(), obs: "" }); setDlgLevant(true); }} disabled={membros.length === 0}>
              Levantamento
            </Button>
          </div>
          <Card>
            <CardContent className="overflow-x-auto p-0 sm:p-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Membro</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead className="text-right">Valor</TableHead>
                    <TableHead className="text-right">Taxa</TableHead>
                    <TableHead>Vencimento do ciclo</TableHead>
                    <TableHead className="text-right">Rendimento</TableHead>
                    <TableHead className="text-right">Assistência</TableHead>
                    <TableHead>Estado</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {depositos.map((d) => (
                    <TableRow key={d.id}>
                      <TableCell>{membroNome(d.membro_id)}</TableCell>
                      <TableCell>{dataPT(d.data_deposito)}</TableCell>
                      <TableCell className="text-right">{MZN(d.valor)}</TableCell>
                      <TableCell className="text-right">{d.taxa_rendimento}%</TableCell>
                      <TableCell>{dataPT(d.data_vencimento)}</TableCell>
                      <TableCell className="text-right">{d.rendimento_creditado ? MZN(d.rendimento_valor) : "-"}</TableCell>
                      <TableCell className="text-right">{MZN(d.assistencia_valor)}</TableCell>
                      <TableCell>
                        <Badge variant={d.estado === "cancelado" ? "destructive" : d.rendimento_creditado ? "secondary" : "default"}>
                          {d.estado === "cancelado" ? "Cancelado" : d.rendimento_creditado ? "Ciclo concluído" : "Em curso"}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                  {depositos.length === 0 && (
                    <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground">Sem depósitos</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* EMPRÉSTIMOS */}
        <TabsContent value="emprestimos" className="mt-4 space-y-3">
          <Button size="sm" onClick={abrirEmprestimo} disabled={membros.length === 0 || !grupo.permitir_emprestimos}>
            <Plus className="mr-2 h-4 w-4" /> Novo empréstimo interno
          </Button>
          {!grupo.permitir_emprestimos && (
            <p className="text-xs text-muted-foreground">Empréstimos desactivados nas configurações deste grupo.</p>
          )}
          <Card>
            <CardContent className="overflow-x-auto p-0 sm:p-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Membro</TableHead>
                    <TableHead>Desembolso</TableHead>
                    <TableHead>Vencimento</TableHead>
                    <TableHead className="text-right">Capital</TableHead>
                    <TableHead className="text-right">Juros</TableHead>
                    <TableHead className="text-right">Pago</TableHead>
                    <TableHead className="text-right">Mora</TableHead>
                    <TableHead className="text-right">Multa</TableHead>
                    <TableHead className="text-right">Total devido</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead className="text-right">Acções</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {emprestimos.map((e) => {
                    const m = moras[e.id];
                    return (
                      <TableRow key={e.id}>
                        <TableCell>{membroNome(e.membro_id)}</TableCell>
                        <TableCell>{dataPT(e.data_desembolso)}</TableCell>
                        <TableCell>{dataPT(e.data_vencimento)}</TableCell>
                        <TableCell className="text-right">{MZN(e.valor)}</TableCell>
                        <TableCell className="text-right">{MZN(e.valor_juros)}</TableCell>
                        <TableCell className="text-right">{MZN(e.valor_pago)}</TableCell>
                        <TableCell className="text-right">{MZN(m?.mora_pendente || 0)}</TableCell>
                        <TableCell className="text-right">{MZN(m?.multa_pendente || 0)}</TableCell>
                        <TableCell className="text-right font-semibold">{MZN(m?.total_devido ?? Math.max(e.valor_total - e.valor_pago, 0))}</TableCell>
                        <TableCell>
                          <Badge variant={e.estado === "pago" ? "secondary" : (m?.dias_atraso || 0) > 0 ? "destructive" : "default"}>
                            {e.estado === "pago" ? "Pago" : (m?.dias_atraso || 0) > 0 ? `Atraso ${m.dias_atraso}d` : "Activo"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          {e.estado !== "pago" && e.estado !== "cancelado" && (
                            <Button size="sm" variant="outline" onClick={() => abrirPagamento(e)}>Pagar</Button>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                  {emprestimos.length === 0 && (
                    <TableRow><TableCell colSpan={11} className="text-center text-muted-foreground">Sem empréstimos</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* EXTRATO */}
        <TabsContent value="extrato" className="mt-4 space-y-3">
          <div className="max-w-xs">
            <Label>Filtrar por membro</Label>
            <Select value={extratoMembro} onValueChange={setExtratoMembro}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os membros</SelectItem>
                {membros.map((m) => <SelectItem key={m.id} value={m.id}>{m.nome}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <Card>
            <CardContent className="overflow-x-auto p-0 sm:p-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data</TableHead>
                    <TableHead>Membro</TableHead>
                    <TableHead>Operação</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead className="text-right">Valor</TableHead>
                    <TableHead className="text-right">Acções</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {movimentosFiltrados.map((mv) => (
                    <TableRow key={mv.id} className={mv.estornado ? "opacity-50 line-through" : ""}>
                      <TableCell>{dataPT(mv.data)}</TableCell>
                      <TableCell>{membroNome(mv.membro_id)}</TableCell>
                      <TableCell>{TIPO_LABEL[mv.tipo] || mv.tipo}</TableCell>
                      <TableCell className="max-w-[320px] truncate text-xs text-muted-foreground">{mv.descricao}</TableCell>
                      <TableCell className="text-right">{MZN(mv.valor)}</TableCell>
                      <TableCell className="text-right">
                        {!mv.estornado && ["deposito", "levantamento", "rendimento"].includes(mv.tipo) && (
                          <Button size="icon" variant="ghost" onClick={() => setEstornoMov(mv)} title="Estornar">
                            <Undo2 className="h-4 w-4" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                  {movimentosFiltrados.length === 0 && (
                    <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground">Sem movimentos</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* CICLO */}
        <TabsContent value="ciclo" className="mt-4 space-y-3">
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">Encerramento de ciclo</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">
                O encerramento processa os rendimentos vencidos e calcula o valor líquido de cada membro
                (saldo poupado + rendimentos − dívidas, mora e multas).
              </p>
              <Button onClick={simularCiclo} disabled={busy}>Calcular encerramento</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* DIALOG MEMBRO */}
      <Dialog open={dlgMembro} onOpenChange={setDlgMembro}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{membroEdit ? "Editar membro" : "Novo membro"}</DialogTitle>
            <DialogDescription>Dados do membro do grupo de poupança.</DialogDescription>
          </DialogHeader>
          <form onSubmit={salvarMembro} className="space-y-3">
            <div><Label>Nome completo *</Label><Input value={fMembro.nome} onChange={(e) => setFMembro({ ...fMembro, nome: e.target.value })} required /></div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div><Label>BI</Label><Input value={fMembro.bi} onChange={(e) => setFMembro({ ...fMembro, bi: e.target.value })} /></div>
              <div><Label>NUIT</Label><Input value={fMembro.nuit} onChange={(e) => setFMembro({ ...fMembro, nuit: e.target.value })} /></div>
              <div><Label>Telefone</Label><Input value={fMembro.telefone} onChange={(e) => setFMembro({ ...fMembro, telefone: e.target.value })} /></div>
              <div><Label>Data de entrada</Label><Input type="date" value={fMembro.data_entrada} onChange={(e) => setFMembro({ ...fMembro, data_entrada: e.target.value })} /></div>
            </div>
            <div><Label>Endereço</Label><Input value={fMembro.endereco} onChange={(e) => setFMembro({ ...fMembro, endereco: e.target.value })} /></div>
            <div>
              <Label>Estado</Label>
              <Select value={fMembro.estado} onValueChange={(v) => setFMembro({ ...fMembro, estado: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ativo">Activo</SelectItem>
                  <SelectItem value="inativo">Inactivo</SelectItem>
                  <SelectItem value="bloqueado">Bloqueado</SelectItem>
                  <SelectItem value="saiu">Saiu do grupo</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDlgMembro(false)}>Cancelar</Button>
              <Button type="submit" disabled={busy}>Gravar</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* DIALOG DEPÓSITO */}
      <Dialog open={dlgDeposito} onOpenChange={setDlgDeposito}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Novo depósito</DialogTitle>
            <DialogDescription>Cada depósito tem o seu próprio ciclo e rendimento.</DialogDescription>
          </DialogHeader>
          <form onSubmit={salvarDeposito} className="space-y-3">
            <div>
              <Label>Membro *</Label>
              <Select value={fDeposito.membro_id} onValueChange={(v) => setFDeposito({ ...fDeposito, membro_id: v })}>
                <SelectTrigger><SelectValue placeholder="Seleccione" /></SelectTrigger>
                <SelectContent>{membros.map((m) => <SelectItem key={m.id} value={m.id}>{m.nome}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div><Label>Valor (MT) *</Label><Input value={fDeposito.valor} onChange={(e) => setFDeposito({ ...fDeposito, valor: e.target.value })} required /></div>
              <div><Label>Data</Label><Input type="date" value={fDeposito.data} onChange={(e) => setFDeposito({ ...fDeposito, data: e.target.value })} /></div>
              <div><Label>Ciclo (dias)</Label><Input value={fDeposito.ciclo} onChange={(e) => setFDeposito({ ...fDeposito, ciclo: e.target.value })} /></div>
              <div>
                <Label>Taxa de rendimento (%)</Label>
                <Input value={fDeposito.taxa} disabled={!grupo.permitir_rendimento} onChange={(e) => setFDeposito({ ...fDeposito, taxa: e.target.value })} />
              </div>
            </div>
            <div><Label>Método</Label><Input value={fDeposito.metodo} onChange={(e) => setFDeposito({ ...fDeposito, metodo: e.target.value })} /></div>
            <div><Label>Observações</Label><Textarea value={fDeposito.obs} onChange={(e) => setFDeposito({ ...fDeposito, obs: e.target.value })} /></div>
            <p className="text-xs text-muted-foreground">
              Vence a {dataPT(addDias(fDeposito.data, Math.max(1, Math.round(numOf(fDeposito.ciclo)) || grupo.ciclo_dias)))}
              {grupo.permitir_rendimento && numOf(fDeposito.taxa) > 0 &&
                ` · rendimento previsto ${MZN(numOf(fDeposito.valor) * numOf(fDeposito.taxa) / 100)}`}
            </p>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDlgDeposito(false)}>Cancelar</Button>
              <Button type="submit" disabled={busy}>Registar depósito</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* DIALOG LEVANTAMENTO */}
      <Dialog open={dlgLevant} onOpenChange={setDlgLevant}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Levantamento</DialogTitle>
            <DialogDescription>Só é permitido levantar o valor disponível (não bloqueado por dívida).</DialogDescription>
          </DialogHeader>
          <form onSubmit={salvarLevantamento} className="space-y-3">
            <div>
              <Label>Membro *</Label>
              <Select value={fLevant.membro_id} onValueChange={(v) => setFLevant({ ...fLevant, membro_id: v })}>
                <SelectTrigger><SelectValue placeholder="Seleccione" /></SelectTrigger>
                <SelectContent>{membros.map((m) => <SelectItem key={m.id} value={m.id}>{m.nome}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {fLevant.membro_id && (
              <p className="text-xs text-muted-foreground">Disponível: {MZN(saldos[fLevant.membro_id]?.disponivel || 0)}</p>
            )}
            <div className="grid gap-3 sm:grid-cols-2">
              <div><Label>Valor (MT) *</Label><Input value={fLevant.valor} onChange={(e) => setFLevant({ ...fLevant, valor: e.target.value })} required /></div>
              <div><Label>Data</Label><Input type="date" value={fLevant.data} onChange={(e) => setFLevant({ ...fLevant, data: e.target.value })} /></div>
            </div>
            <div><Label>Observações</Label><Input value={fLevant.obs} onChange={(e) => setFLevant({ ...fLevant, obs: e.target.value })} /></div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDlgLevant(false)}>Cancelar</Button>
              <Button type="submit" disabled={busy}>Registar</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* DIALOG EMPRÉSTIMO */}
      <Dialog open={dlgEmp} onOpenChange={setDlgEmp}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Novo empréstimo interno</DialogTitle>
            <DialogDescription>O saldo poupado do membro serve de garantia.</DialogDescription>
          </DialogHeader>
          <form onSubmit={salvarEmprestimo} className="space-y-3">
            <div>
              <Label>Membro *</Label>
              <Select value={fEmp.membro_id} onValueChange={(v) => setFEmp({ ...fEmp, membro_id: v })}>
                <SelectTrigger><SelectValue placeholder="Seleccione" /></SelectTrigger>
                <SelectContent>{membros.map((m) => <SelectItem key={m.id} value={m.id}>{m.nome}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {fEmp.membro_id && (
              <p className="text-xs text-muted-foreground">
                Limite: {MZN((saldos[fEmp.membro_id]?.disponivel || 0) * (grupo.limite_emprestimo_pct / 100))}
              </p>
            )}
            <div className="grid gap-3 sm:grid-cols-2">
              <div><Label>Valor (MT) *</Label><Input value={fEmp.valor} onChange={(e) => setFEmp({ ...fEmp, valor: e.target.value })} required /></div>
              <div><Label>Taxa de juros (%)</Label><Input value={fEmp.taxa} onChange={(e) => setFEmp({ ...fEmp, taxa: e.target.value })} /></div>
              <div>
                <Label>Tipo de juros</Label>
                <Select value={fEmp.tipo_juros} onValueChange={(v) => setFEmp({ ...fEmp, tipo_juros: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="simples">Simples</SelectItem>
                    <SelectItem value="composto">Composto</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Prazo (meses)</Label><Input value={fEmp.prazo} onChange={(e) => setFEmp({ ...fEmp, prazo: e.target.value })} /></div>
              <div><Label>Data de desembolso</Label><Input type="date" value={fEmp.data} onChange={(e) => setFEmp({ ...fEmp, data: e.target.value })} /></div>
            </div>
            <div><Label>Observações</Label><Input value={fEmp.obs} onChange={(e) => setFEmp({ ...fEmp, obs: e.target.value })} /></div>
            <p className="text-xs text-muted-foreground">
              Juros {MZN(previewEmp.juros)} · Total a pagar {MZN(previewEmp.total)} até {dataPT(addMeses(fEmp.data, Math.max(1, Math.round(numOf(fEmp.prazo)) || 1)))}
            </p>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDlgEmp(false)}>Cancelar</Button>
              <Button type="submit" disabled={busy}>Conceder empréstimo</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* DIALOG PAGAMENTO */}
      <Dialog open={!!dlgPag} onOpenChange={(o) => !o && setDlgPag(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Registar pagamento</DialogTitle>
            <DialogDescription>
              {dlgPag && `${membroNome(dlgPag.membro_id)} · Total devido ${MZN(moras[dlgPag.id]?.total_devido ?? Math.max(dlgPag.valor_total - dlgPag.valor_pago, 0))}`}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={salvarPagamento} className="space-y-3">
            {dlgPag && moras[dlgPag.id] && (
              <div className="rounded-md border p-2 text-xs text-muted-foreground">
                Capital em dívida: {MZN(moras[dlgPag.id].saldo_devedor)} · Mora: {MZN(moras[dlgPag.id].mora_pendente)} · Multa: {MZN(moras[dlgPag.id].multa_pendente)}
              </div>
            )}
            <div className="grid gap-3 sm:grid-cols-2">
              <div><Label>Valor (MT) *</Label><Input value={fPag.valor} onChange={(e) => setFPag({ ...fPag, valor: e.target.value })} required /></div>
              <div>
                <Label>Tipo</Label>
                <Select value={fPag.tipo} onValueChange={(v) => setFPag({ ...fPag, tipo: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="capital">Capital / prestação</SelectItem>
                    <SelectItem value="juros">Juros</SelectItem>
                    <SelectItem value="mora">Mora</SelectItem>
                    <SelectItem value="multa">Multa</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Data</Label><Input type="date" value={fPag.data} onChange={(e) => setFPag({ ...fPag, data: e.target.value })} /></div>
              <div><Label>Método</Label><Input value={fPag.metodo} onChange={(e) => setFPag({ ...fPag, metodo: e.target.value })} /></div>
            </div>
            <div><Label>Observações</Label><Input value={fPag.obs} onChange={(e) => setFPag({ ...fPag, obs: e.target.value })} /></div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDlgPag(null)}>Cancelar</Button>
              <Button type="submit" disabled={busy}>Registar pagamento</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* DIALOG CICLO */}
      <Dialog open={dlgCiclo} onOpenChange={setDlgCiclo}>
        <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Encerramento de ciclo</DialogTitle>
            <DialogDescription>Valor líquido a receber por cada membro.</DialogDescription>
          </DialogHeader>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Membro</TableHead>
                <TableHead className="text-right">Saldo</TableHead>
                <TableHead className="text-right">Dívida</TableHead>
                <TableHead className="text-right">Líquido</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(ciclo?.itens || []).map((i: any) => (
                <TableRow key={i.membro_id}>
                  <TableCell>{i.nome}</TableCell>
                  <TableCell className="text-right">{MZN(i.saldo)}</TableCell>
                  <TableCell className="text-right">{MZN(i.divida)}</TableCell>
                  <TableCell className={`text-right font-semibold ${i.devedor ? "text-destructive" : ""}`}>{MZN(i.liquido)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <p className="text-sm font-semibold">Total líquido: {MZN(ciclo?.total_liquido || 0)}</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDlgCiclo(false)}>Fechar</Button>
            <Button variant="destructive" onClick={() => setConfirmEncerrar(true)}>Encerrar grupo</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={confirmEncerrar}
        onOpenChange={setConfirmEncerrar}
        title="Encerrar grupo"
        description="O grupo passa ao estado Encerrado. Os dados e o histórico mantêm-se disponíveis."
        variant="destructive"
        onConfirm={encerrarCiclo}
      />
      <ConfirmDialog
        open={!!delMembro}
        onOpenChange={(o) => !o && setDelMembro(null)}
        title="Eliminar membro"
        description={`Eliminar "${delMembro?.nome}" remove também os seus depósitos, empréstimos e movimentos.`}
        variant="destructive"
        onConfirm={eliminarMembro}
      />
      <ConfirmDialog
        open={!!estornoMov}
        onOpenChange={(o) => !o && setEstornoMov(null)}
        title="Estornar movimento"
        description="O movimento deixa de contar para o saldo do membro, mas permanece visível no extrato como estornado."
        variant="destructive"
        onConfirm={estornar}
      />
    </div>
  );
}
