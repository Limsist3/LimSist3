import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Users2, Settings2, ArrowLeft, Trash2, Pencil } from "lucide-react";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";
import { PoupancaGrupoDetalhe } from "./PoupancaGrupoDetalhe";
import { PgGrupo, numOf, dataPT } from "./types";

const emptyForm = {
  nome: "",
  codigo: "",
  gestor: "",
  data_inicio: new Date().toISOString().split("T")[0],
  ciclo_dias: "30",
  permitir_rendimento: true,
  taxa_rendimento: "10",
  assist_tipo: "fixo",
  assist_valor: "0",
  permitir_emprestimos: true,
  taxa_juros: "10",
  tipo_juros: "simples",
  prazo_meses: "1",
  taxa_mora_diaria: "2",
  multa_tipo: "fixo",
  multa_valor: "0",
  dias_tolerancia: "0",
  limite_emprestimo_pct: "100",
  observacoes: "",
};

export function PoupancaGrupo2Section() {
  const [grupos, setGrupos] = useState<PgGrupo[]>([]);
  const [selecionado, setSelecionado] = useState<PgGrupo | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editando, setEditando] = useState<PgGrupo | null>(null);
  const [form, setForm] = useState({ ...emptyForm });
  const [confirmDel, setConfirmDel] = useState<PgGrupo | null>(null);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    const { data, error } = await supabase
      .from("pg_grupos")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) return;
    const rows = (data || []) as unknown as PgGrupo[];
    setGrupos(rows);
    setSelecionado((prev) => (prev ? rows.find((g) => g.id === prev.id) || null : null));
  };

  useEffect(() => { load(); }, []);
  useRealtimeRefresh(["pg_grupos"], load, true, 1200);

  const abrirNovo = () => {
    setEditando(null);
    setForm({ ...emptyForm, codigo: `GP-${Date.now().toString().slice(-6)}` });
    setDialogOpen(true);
  };

  const abrirEdicao = (g: PgGrupo) => {
    setEditando(g);
    setForm({
      nome: g.nome,
      codigo: g.codigo,
      gestor: g.gestor || "",
      data_inicio: g.data_inicio,
      ciclo_dias: String(g.ciclo_dias),
      permitir_rendimento: g.permitir_rendimento,
      taxa_rendimento: String(g.taxa_rendimento),
      assist_tipo: g.assist_tipo,
      assist_valor: String(g.assist_valor),
      permitir_emprestimos: g.permitir_emprestimos,
      taxa_juros: String(g.taxa_juros),
      tipo_juros: g.tipo_juros,
      prazo_meses: String(g.prazo_meses),
      taxa_mora_diaria: String(g.taxa_mora_diaria),
      multa_tipo: g.multa_tipo,
      multa_valor: String(g.multa_valor),
      dias_tolerancia: String(g.dias_tolerancia),
      limite_emprestimo_pct: String(g.limite_emprestimo_pct),
      observacoes: g.observacoes || "",
    });
    setDialogOpen(true);
  };

  const salvar = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nome.trim()) { toast.error("Indique o nome do grupo"); return; }
    setLoading(true);
    const { data: { session } } = await supabase.auth.getSession();
    const payload = {
      nome: form.nome.trim(),
      codigo: form.codigo.trim() || `GP-${Date.now().toString().slice(-6)}`,
      gestor: form.gestor || null,
      data_inicio: form.data_inicio,
      ciclo_dias: Math.max(1, Math.round(numOf(form.ciclo_dias)) || 30),
      permitir_rendimento: form.permitir_rendimento,
      taxa_rendimento: numOf(form.taxa_rendimento),
      assist_tipo: form.assist_tipo,
      assist_valor: numOf(form.assist_valor),
      permitir_emprestimos: form.permitir_emprestimos,
      taxa_juros: numOf(form.taxa_juros),
      tipo_juros: form.tipo_juros,
      prazo_meses: Math.max(1, Math.round(numOf(form.prazo_meses)) || 1),
      taxa_mora_diaria: numOf(form.taxa_mora_diaria),
      multa_tipo: form.multa_tipo,
      multa_valor: numOf(form.multa_valor),
      dias_tolerancia: Math.max(0, Math.round(numOf(form.dias_tolerancia))),
      limite_emprestimo_pct: numOf(form.limite_emprestimo_pct),
      observacoes: form.observacoes || null,
    };

    const { error } = editando
      ? await supabase.from("pg_grupos").update(payload).eq("id", editando.id)
      : await supabase.from("pg_grupos").insert([{ ...payload, user_id: session?.user?.id }]);
    setLoading(false);
    if (error) { toast.error("Erro ao gravar grupo"); return; }
    toast.success(editando ? "Grupo actualizado!" : "Grupo criado!");
    setDialogOpen(false);
    load();
  };

  const eliminar = async () => {
    if (!confirmDel) return;
    const { error } = await supabase.from("pg_grupos").delete().eq("id", confirmDel.id);
    if (error) { toast.error("Erro ao eliminar grupo"); return; }
    toast.success("Grupo eliminado");
    if (selecionado?.id === confirmDel.id) setSelecionado(null);
    setConfirmDel(null);
    load();
  };

  if (selecionado) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" size="sm" onClick={() => setSelecionado(null)}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Voltar aos grupos
        </Button>
        <PoupancaGrupoDetalhe grupo={selecionado} onGrupoChange={load} />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 className="text-lg font-semibold">Poupança em Grupo</h3>
          <p className="text-sm text-muted-foreground">
            Grupos com ciclos individuais, rendimentos, empréstimos internos, mora e multas.
          </p>
        </div>
        <Button onClick={abrirNovo}>
          <Plus className="mr-2 h-4 w-4" /> Novo Grupo
        </Button>
      </div>

      {grupos.length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center text-muted-foreground">
            <Users2 className="mx-auto mb-3 h-10 w-10 opacity-50" />
            Ainda não existem grupos. Crie o primeiro grupo para começar.
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Grupos registados ({grupos.length})</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Código</TableHead>
                  <TableHead>Nome</TableHead>
                  <TableHead>Gestor</TableHead>
                  <TableHead>Início</TableHead>
                  <TableHead>Ciclo</TableHead>
                  <TableHead>Rendimento</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead className="text-right">Acções</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {grupos.map((g) => (
                  <TableRow key={g.id} className="cursor-pointer" onClick={() => setSelecionado(g)}>
                    <TableCell className="font-mono text-xs">{g.codigo}</TableCell>
                    <TableCell className="font-medium">{g.nome}</TableCell>
                    <TableCell>{g.gestor || "-"}</TableCell>
                    <TableCell>{dataPT(g.data_inicio)}</TableCell>
                    <TableCell>{g.ciclo_dias} dias</TableCell>
                    <TableCell>{g.permitir_rendimento ? `${g.taxa_rendimento}%` : "Não"}</TableCell>
                    <TableCell>
                      <Badge variant={g.estado === "Ativo" ? "default" : "secondary"}>{g.estado}</Badge>
                    </TableCell>
                    <TableCell className="text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" onClick={() => abrirEdicao(g)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => setConfirmDel(g)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings2 className="h-4 w-4" />
              {editando ? "Editar Grupo" : "Novo Grupo de Poupança"}
            </DialogTitle>
            <DialogDescription>
              Configure o grupo. Estas regras são aplicadas por omissão a novos depósitos e empréstimos.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={salvar} className="space-y-5">
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <Label>Nome do grupo *</Label>
                <Input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} required />
              </div>
              <div>
                <Label>Código</Label>
                <Input value={form.codigo} onChange={(e) => setForm({ ...form, codigo: e.target.value })} />
              </div>
              <div>
                <Label>Gestor responsável</Label>
                <Input value={form.gestor} onChange={(e) => setForm({ ...form, gestor: e.target.value })} />
              </div>
              <div>
                <Label>Data de início</Label>
                <Input type="date" value={form.data_inicio} onChange={(e) => setForm({ ...form, data_inicio: e.target.value })} />
              </div>
            </div>

            <div className="rounded-lg border p-3 space-y-3">
              <p className="text-sm font-semibold">Poupança e rendimento</p>
              <div className="flex items-center justify-between">
                <Label className="text-sm font-normal">Permitir rendimento sobre poupança</Label>
                <Switch
                  checked={form.permitir_rendimento}
                  onCheckedChange={(v) => setForm({ ...form, permitir_rendimento: v })}
                />
              </div>
              <div className="grid gap-3 sm:grid-cols-3">
                <div>
                  <Label>Duração do ciclo (dias)</Label>
                  <Input value={form.ciclo_dias} onChange={(e) => setForm({ ...form, ciclo_dias: e.target.value })} />
                </div>
                <div>
                  <Label>Taxa de rendimento (%)</Label>
                  <Input
                    value={form.taxa_rendimento}
                    disabled={!form.permitir_rendimento}
                    onChange={(e) => setForm({ ...form, taxa_rendimento: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Limite empréstimo (% saldo)</Label>
                  <Input value={form.limite_emprestimo_pct} onChange={(e) => setForm({ ...form, limite_emprestimo_pct: e.target.value })} />
                </div>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <Label>Assistência técnica</Label>
                  <Select value={form.assist_tipo} onValueChange={(v) => setForm({ ...form, assist_tipo: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fixo">Valor fixo por depósito</SelectItem>
                      <SelectItem value="percentagem">Percentagem do depósito</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>{form.assist_tipo === "percentagem" ? "Assistência (%)" : "Assistência (MT)"}</Label>
                  <Input value={form.assist_valor} onChange={(e) => setForm({ ...form, assist_valor: e.target.value })} />
                </div>
              </div>
            </div>

            <div className="rounded-lg border p-3 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold">Empréstimos internos</p>
                <Switch
                  checked={form.permitir_emprestimos}
                  onCheckedChange={(v) => setForm({ ...form, permitir_emprestimos: v })}
                />
              </div>
              <div className="grid gap-3 sm:grid-cols-3">
                <div>
                  <Label>Taxa de juros (%)</Label>
                  <Input value={form.taxa_juros} onChange={(e) => setForm({ ...form, taxa_juros: e.target.value })} />
                </div>
                <div>
                  <Label>Tipo de juros</Label>
                  <Select value={form.tipo_juros} onValueChange={(v) => setForm({ ...form, tipo_juros: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="simples">Simples</SelectItem>
                      <SelectItem value="composto">Composto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Prazo padrão (meses)</Label>
                  <Input value={form.prazo_meses} onChange={(e) => setForm({ ...form, prazo_meses: e.target.value })} />
                </div>
                <div>
                  <Label>Mora diária (%)</Label>
                  <Input value={form.taxa_mora_diaria} onChange={(e) => setForm({ ...form, taxa_mora_diaria: e.target.value })} />
                </div>
                <div>
                  <Label>Multa por atraso</Label>
                  <Select value={form.multa_tipo} onValueChange={(v) => setForm({ ...form, multa_tipo: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fixo">Valor fixo</SelectItem>
                      <SelectItem value="percentagem">Percentagem do saldo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>{form.multa_tipo === "percentagem" ? "Multa (%)" : "Multa (MT)"}</Label>
                  <Input value={form.multa_valor} onChange={(e) => setForm({ ...form, multa_valor: e.target.value })} />
                </div>
                <div>
                  <Label>Dias de tolerância</Label>
                  <Input value={form.dias_tolerancia} onChange={(e) => setForm({ ...form, dias_tolerancia: e.target.value })} />
                </div>
              </div>
            </div>

            <div>
              <Label>Observações</Label>
              <Textarea value={form.observacoes} onChange={(e) => setForm({ ...form, observacoes: e.target.value })} />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={loading}>{editando ? "Gravar alterações" : "Criar grupo"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!confirmDel}
        onOpenChange={(o) => !o && setConfirmDel(null)}
        title="Eliminar grupo"
        description={`Eliminar "${confirmDel?.nome}" remove também membros, depósitos, empréstimos e movimentos deste grupo. Esta acção não pode ser revertida.`}
        onConfirm={eliminar}
      />
    </div>
  );
}
