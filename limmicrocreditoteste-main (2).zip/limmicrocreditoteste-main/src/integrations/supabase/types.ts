export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      admin_commands: {
        Row: {
          command: string
          created_at: string
          executed_at: string | null
          id: string
          issued_by: string
          payload: Json | null
          status: string
          target_user_id: string
        }
        Insert: {
          command: string
          created_at?: string
          executed_at?: string | null
          id?: string
          issued_by: string
          payload?: Json | null
          status?: string
          target_user_id: string
        }
        Update: {
          command?: string
          created_at?: string
          executed_at?: string | null
          id?: string
          issued_by?: string
          payload?: Json | null
          status?: string
          target_user_id?: string
        }
        Relationships: []
      }
      agente_atividades: {
        Row: {
          agente_id: string
          created_at: string | null
          data_hora: string | null
          descricao: string
          id: string
        }
        Insert: {
          agente_id: string
          created_at?: string | null
          data_hora?: string | null
          descricao: string
          id?: string
        }
        Update: {
          agente_id?: string
          created_at?: string | null
          data_hora?: string | null
          descricao?: string
          id?: string
        }
        Relationships: []
      }
      arquivos: {
        Row: {
          cliente_id: string | null
          created_at: string | null
          emprestimo_id: string | null
          id: string
          nome_arquivo: string
          tamanho: number | null
          tipo: string
          url_arquivo: string
          user_id: string
        }
        Insert: {
          cliente_id?: string | null
          created_at?: string | null
          emprestimo_id?: string | null
          id?: string
          nome_arquivo: string
          tamanho?: number | null
          tipo: string
          url_arquivo: string
          user_id: string
        }
        Update: {
          cliente_id?: string | null
          created_at?: string | null
          emprestimo_id?: string | null
          id?: string
          nome_arquivo?: string
          tamanho?: number | null
          tipo?: string
          url_arquivo?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "arquivos_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "arquivos_emprestimo_id_fkey"
            columns: ["emprestimo_id"]
            isOneToOne: false
            referencedRelation: "emprestimos"
            referencedColumns: ["id"]
          },
        ]
      }
      capital_global: {
        Row: {
          configurado: boolean
          created_at: string | null
          data_configuracao: string
          id: string
          ultima_edicao: string | null
          user_id: string
          valor: number
        }
        Insert: {
          configurado?: boolean
          created_at?: string | null
          data_configuracao?: string
          id?: string
          ultima_edicao?: string | null
          user_id: string
          valor: number
        }
        Update: {
          configurado?: boolean
          created_at?: string | null
          data_configuracao?: string
          id?: string
          ultima_edicao?: string | null
          user_id?: string
          valor?: number
        }
        Relationships: []
      }
      capital_mensal: {
        Row: {
          capital_actual: number
          capital_inicial_mes: number
          created_at: string | null
          data_fecho: string | null
          fechado: boolean
          id: string
          mes_ano: string
          total_creditos_concedidos: number
          total_despesas_perdas: number
          total_entradas_extras: number
          total_juros_recebidos: number
          total_reembolsos_capital: number
          updated_at: string | null
          user_id: string
        }
        Insert: {
          capital_actual?: number
          capital_inicial_mes?: number
          created_at?: string | null
          data_fecho?: string | null
          fechado?: boolean
          id?: string
          mes_ano: string
          total_creditos_concedidos?: number
          total_despesas_perdas?: number
          total_entradas_extras?: number
          total_juros_recebidos?: number
          total_reembolsos_capital?: number
          updated_at?: string | null
          user_id: string
        }
        Update: {
          capital_actual?: number
          capital_inicial_mes?: number
          created_at?: string | null
          data_fecho?: string | null
          fechado?: boolean
          id?: string
          mes_ano?: string
          total_creditos_concedidos?: number
          total_despesas_perdas?: number
          total_entradas_extras?: number
          total_juros_recebidos?: number
          total_reembolsos_capital?: number
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      central_risco: {
        Row: {
          created_at: string
          id: string
          instituicao: string
          motivo: string
          nome_completo: string
          nuit_bi: string
          observacao: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          instituicao: string
          motivo: string
          nome_completo: string
          nuit_bi: string
          observacao?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          instituicao?: string
          motivo?: string
          nome_completo?: string
          nuit_bi?: string
          observacao?: string | null
          user_id?: string
        }
        Relationships: []
      }
      clientes: {
        Row: {
          agente_id: string | null
          bairro: string | null
          bi: string | null
          bloqueado: boolean | null
          created_at: string | null
          data_nascimento: string | null
          distrito: string | null
          email: string | null
          genero: string | null
          id: string
          nome_completo: string
          nuit: string | null
          provincia: string | null
          rua: string | null
          telefone: string
          updated_at: string | null
          user_id: string
          usuario_mae_id: string | null
        }
        Insert: {
          agente_id?: string | null
          bairro?: string | null
          bi?: string | null
          bloqueado?: boolean | null
          created_at?: string | null
          data_nascimento?: string | null
          distrito?: string | null
          email?: string | null
          genero?: string | null
          id?: string
          nome_completo: string
          nuit?: string | null
          provincia?: string | null
          rua?: string | null
          telefone: string
          updated_at?: string | null
          user_id: string
          usuario_mae_id?: string | null
        }
        Update: {
          agente_id?: string | null
          bairro?: string | null
          bi?: string | null
          bloqueado?: boolean | null
          created_at?: string | null
          data_nascimento?: string | null
          distrito?: string | null
          email?: string | null
          genero?: string | null
          id?: string
          nome_completo?: string
          nuit?: string | null
          provincia?: string | null
          rua?: string | null
          telefone?: string
          updated_at?: string | null
          user_id?: string
          usuario_mae_id?: string | null
        }
        Relationships: []
      }
      configuracao_pagamento: {
        Row: {
          created_at: string | null
          id: string
          instrucoes: string | null
          nome_titular: string | null
          nome_titular_emola: string | null
          nome_titular_mpesa: string | null
          numero_emola: string | null
          numero_mpesa: string | null
          numero_notificacoes: string | null
          score_minimo: number
          tempo_maximo_pagamento_min: number
          tempo_validacao_horas: number
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          instrucoes?: string | null
          nome_titular?: string | null
          nome_titular_emola?: string | null
          nome_titular_mpesa?: string | null
          numero_emola?: string | null
          numero_mpesa?: string | null
          numero_notificacoes?: string | null
          score_minimo?: number
          tempo_maximo_pagamento_min?: number
          tempo_validacao_horas?: number
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          instrucoes?: string | null
          nome_titular?: string | null
          nome_titular_emola?: string | null
          nome_titular_mpesa?: string | null
          numero_emola?: string | null
          numero_mpesa?: string | null
          numero_notificacoes?: string | null
          score_minimo?: number
          tempo_maximo_pagamento_min?: number
          tempo_validacao_horas?: number
          updated_at?: string | null
        }
        Relationships: []
      }
      configuracoes_empresa: {
        Row: {
          animacoes: boolean | null
          ano_inicio_atividades: number | null
          aumento_capital_proprio: number | null
          caixa: number | null
          capitais_alheios_estrangeiros: number | null
          capitais_alheios_nacionais: number | null
          capital_base: number | null
          capital_inicial_banco: number | null
          capital_inicial_emola: number | null
          capital_inicial_mpesa: number | null
          capitalizacao_automatica: boolean
          capitalizacao_dias_carencia: number
          cor_primaria_documentos: string | null
          cor_secundaria_documentos: string | null
          created_at: string | null
          diretor_nome: string | null
          diretor_posicao: string | null
          donativos_obtidos: number | null
          email: string | null
          emprestimos_obtidos: number | null
          endereco: string | null
          id: string
          idioma: string | null
          logo_url: string | null
          modo_compacto: boolean | null
          moeda: string | null
          mora_automatica: boolean
          nome_empresa: string | null
          nuit: string | null
          num_trabalhadores: number | null
          outros_activos: number | null
          provincia: string | null
          sidebar_fixa: boolean | null
          taxa_juros_padrao: number | null
          taxa_mora_padrao: number | null
          telefax: string | null
          telefone: string | null
          tema: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          animacoes?: boolean | null
          ano_inicio_atividades?: number | null
          aumento_capital_proprio?: number | null
          caixa?: number | null
          capitais_alheios_estrangeiros?: number | null
          capitais_alheios_nacionais?: number | null
          capital_base?: number | null
          capital_inicial_banco?: number | null
          capital_inicial_emola?: number | null
          capital_inicial_mpesa?: number | null
          capitalizacao_automatica?: boolean
          capitalizacao_dias_carencia?: number
          cor_primaria_documentos?: string | null
          cor_secundaria_documentos?: string | null
          created_at?: string | null
          diretor_nome?: string | null
          diretor_posicao?: string | null
          donativos_obtidos?: number | null
          email?: string | null
          emprestimos_obtidos?: number | null
          endereco?: string | null
          id?: string
          idioma?: string | null
          logo_url?: string | null
          modo_compacto?: boolean | null
          moeda?: string | null
          mora_automatica?: boolean
          nome_empresa?: string | null
          nuit?: string | null
          num_trabalhadores?: number | null
          outros_activos?: number | null
          provincia?: string | null
          sidebar_fixa?: boolean | null
          taxa_juros_padrao?: number | null
          taxa_mora_padrao?: number | null
          telefax?: string | null
          telefone?: string | null
          tema?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          animacoes?: boolean | null
          ano_inicio_atividades?: number | null
          aumento_capital_proprio?: number | null
          caixa?: number | null
          capitais_alheios_estrangeiros?: number | null
          capitais_alheios_nacionais?: number | null
          capital_base?: number | null
          capital_inicial_banco?: number | null
          capital_inicial_emola?: number | null
          capital_inicial_mpesa?: number | null
          capitalizacao_automatica?: boolean
          capitalizacao_dias_carencia?: number
          cor_primaria_documentos?: string | null
          cor_secundaria_documentos?: string | null
          created_at?: string | null
          diretor_nome?: string | null
          diretor_posicao?: string | null
          donativos_obtidos?: number | null
          email?: string | null
          emprestimos_obtidos?: number | null
          endereco?: string | null
          id?: string
          idioma?: string | null
          logo_url?: string | null
          modo_compacto?: boolean | null
          moeda?: string | null
          mora_automatica?: boolean
          nome_empresa?: string | null
          nuit?: string | null
          num_trabalhadores?: number | null
          outros_activos?: number | null
          provincia?: string | null
          sidebar_fixa?: boolean | null
          taxa_juros_padrao?: number | null
          taxa_mora_padrao?: number | null
          telefax?: string | null
          telefone?: string | null
          tema?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      contas_financeiras: {
        Row: {
          ativo: boolean
          created_at: string | null
          id: string
          nome: string
          saldo_contabilistico: number
          saldo_disponivel: number
          tipo: string
          ultima_recarga: string | null
          ultimo_ajuste_saldo: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          ativo?: boolean
          created_at?: string | null
          id?: string
          nome: string
          saldo_contabilistico?: number
          saldo_disponivel?: number
          tipo: string
          ultima_recarga?: string | null
          ultimo_ajuste_saldo?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          ativo?: boolean
          created_at?: string | null
          id?: string
          nome?: string
          saldo_contabilistico?: number
          saldo_disponivel?: number
          tipo?: string
          ultima_recarga?: string | null
          ultimo_ajuste_saldo?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      cupoes_acesso: {
        Row: {
          codigo: string
          created_at: string
          criado_por: string
          duracao_dias: number
          id: string
          observacoes: string | null
          pacote_nome: string
          resgatado_em: string | null
          resgatado_por: string | null
          status: string
          updated_at: string
          validade_cupao: string | null
        }
        Insert: {
          codigo: string
          created_at?: string
          criado_por: string
          duracao_dias: number
          id?: string
          observacoes?: string | null
          pacote_nome: string
          resgatado_em?: string | null
          resgatado_por?: string | null
          status?: string
          updated_at?: string
          validade_cupao?: string | null
        }
        Update: {
          codigo?: string
          created_at?: string
          criado_por?: string
          duracao_dias?: number
          id?: string
          observacoes?: string | null
          pacote_nome?: string
          resgatado_em?: string | null
          resgatado_por?: string | null
          status?: string
          updated_at?: string
          validade_cupao?: string | null
        }
        Relationships: []
      }
      declaracoes_ispc: {
        Row: {
          andar: string | null
          ano: string | null
          assinatura: string | null
          bairro: string | null
          caixa_postal: string | null
          casa_nr: string | null
          celula: string | null
          codigo_cae: string | null
          codigo_postal: string | null
          created_at: string
          dados_extra: Json | null
          data_assinatura: string | null
          distrito: string | null
          email: string | null
          fax: string | null
          id: string
          imposto_3_ano: number | null
          imposto_3_trim: number | null
          imposto_fixo_ano: number | null
          imposto_fixo_trim: number | null
          juros_ano: number | null
          juros_trim: number | null
          localidade: string | null
          modalidade: string | null
          nome_sujeito: string | null
          nr_flat: string | null
          nr_porta: string | null
          nuit: string | null
          provincia: string | null
          quarteirao: string | null
          rua: string | null
          sem_operacoes: boolean | null
          telefone_fixo: string | null
          telemovel: string | null
          total_ano: number | null
          total_trim: number | null
          trimestre: string | null
          updated_at: string
          user_id: string
          valor_extenso: string | null
          vendas_ano: number | null
          vendas_trimestre: number | null
        }
        Insert: {
          andar?: string | null
          ano?: string | null
          assinatura?: string | null
          bairro?: string | null
          caixa_postal?: string | null
          casa_nr?: string | null
          celula?: string | null
          codigo_cae?: string | null
          codigo_postal?: string | null
          created_at?: string
          dados_extra?: Json | null
          data_assinatura?: string | null
          distrito?: string | null
          email?: string | null
          fax?: string | null
          id?: string
          imposto_3_ano?: number | null
          imposto_3_trim?: number | null
          imposto_fixo_ano?: number | null
          imposto_fixo_trim?: number | null
          juros_ano?: number | null
          juros_trim?: number | null
          localidade?: string | null
          modalidade?: string | null
          nome_sujeito?: string | null
          nr_flat?: string | null
          nr_porta?: string | null
          nuit?: string | null
          provincia?: string | null
          quarteirao?: string | null
          rua?: string | null
          sem_operacoes?: boolean | null
          telefone_fixo?: string | null
          telemovel?: string | null
          total_ano?: number | null
          total_trim?: number | null
          trimestre?: string | null
          updated_at?: string
          user_id: string
          valor_extenso?: string | null
          vendas_ano?: number | null
          vendas_trimestre?: number | null
        }
        Update: {
          andar?: string | null
          ano?: string | null
          assinatura?: string | null
          bairro?: string | null
          caixa_postal?: string | null
          casa_nr?: string | null
          celula?: string | null
          codigo_cae?: string | null
          codigo_postal?: string | null
          created_at?: string
          dados_extra?: Json | null
          data_assinatura?: string | null
          distrito?: string | null
          email?: string | null
          fax?: string | null
          id?: string
          imposto_3_ano?: number | null
          imposto_3_trim?: number | null
          imposto_fixo_ano?: number | null
          imposto_fixo_trim?: number | null
          juros_ano?: number | null
          juros_trim?: number | null
          localidade?: string | null
          modalidade?: string | null
          nome_sujeito?: string | null
          nr_flat?: string | null
          nr_porta?: string | null
          nuit?: string | null
          provincia?: string | null
          quarteirao?: string | null
          rua?: string | null
          sem_operacoes?: boolean | null
          telefone_fixo?: string | null
          telemovel?: string | null
          total_ano?: number | null
          total_trim?: number | null
          trimestre?: string | null
          updated_at?: string
          user_id?: string
          valor_extenso?: string | null
          vendas_ano?: number | null
          vendas_trimestre?: number | null
        }
        Relationships: []
      }
      despesas: {
        Row: {
          categoria: string
          conta_financeira_id: string | null
          created_at: string | null
          data: string
          descricao: string
          id: string
          user_id: string
          valor: number
        }
        Insert: {
          categoria: string
          conta_financeira_id?: string | null
          created_at?: string | null
          data: string
          descricao: string
          id?: string
          user_id: string
          valor: number
        }
        Update: {
          categoria?: string
          conta_financeira_id?: string | null
          created_at?: string | null
          data?: string
          descricao?: string
          id?: string
          user_id?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "despesas_conta_financeira_id_fkey"
            columns: ["conta_financeira_id"]
            isOneToOne: false
            referencedRelation: "contas_financeiras"
            referencedColumns: ["id"]
          },
        ]
      }
      emprestimos: {
        Row: {
          avalista_bi: string | null
          avalista_endereco: string | null
          avalista_nome: string | null
          avalista_telefone: string | null
          capitalizado: boolean
          capitalizado_em: string | null
          cliente_id: string
          conta_financeira_id: string | null
          created_at: string | null
          custos_administrativos: number | null
          data_desembolso: string
          data_reembolso: string | null
          detalhes_garantia: string | null
          duracao_meses: number
          id: string
          modalidade_desembolso: string | null
          modalidade_reembolso: string | null
          mora_paga: number
          observacoes: string | null
          parcela_mensal: number | null
          sistema_amortizacao: string | null
          status: string | null
          taxa_juros: number
          taxa_mora: number | null
          testemunha_bi: string | null
          testemunha_nome: string | null
          tipo_garantia: string | null
          tipo_juros: string | null
          updated_at: string | null
          user_id: string
          usuario_mae_id: string | null
          valor: number
          valor_capitalizado: number
          valor_pago: number | null
          valor_total: number | null
        }
        Insert: {
          avalista_bi?: string | null
          avalista_endereco?: string | null
          avalista_nome?: string | null
          avalista_telefone?: string | null
          capitalizado?: boolean
          capitalizado_em?: string | null
          cliente_id: string
          conta_financeira_id?: string | null
          created_at?: string | null
          custos_administrativos?: number | null
          data_desembolso: string
          data_reembolso?: string | null
          detalhes_garantia?: string | null
          duracao_meses: number
          id?: string
          modalidade_desembolso?: string | null
          modalidade_reembolso?: string | null
          mora_paga?: number
          observacoes?: string | null
          parcela_mensal?: number | null
          sistema_amortizacao?: string | null
          status?: string | null
          taxa_juros: number
          taxa_mora?: number | null
          testemunha_bi?: string | null
          testemunha_nome?: string | null
          tipo_garantia?: string | null
          tipo_juros?: string | null
          updated_at?: string | null
          user_id: string
          usuario_mae_id?: string | null
          valor: number
          valor_capitalizado?: number
          valor_pago?: number | null
          valor_total?: number | null
        }
        Update: {
          avalista_bi?: string | null
          avalista_endereco?: string | null
          avalista_nome?: string | null
          avalista_telefone?: string | null
          capitalizado?: boolean
          capitalizado_em?: string | null
          cliente_id?: string
          conta_financeira_id?: string | null
          created_at?: string | null
          custos_administrativos?: number | null
          data_desembolso?: string
          data_reembolso?: string | null
          detalhes_garantia?: string | null
          duracao_meses?: number
          id?: string
          modalidade_desembolso?: string | null
          modalidade_reembolso?: string | null
          mora_paga?: number
          observacoes?: string | null
          parcela_mensal?: number | null
          sistema_amortizacao?: string | null
          status?: string | null
          taxa_juros?: number
          taxa_mora?: number | null
          testemunha_bi?: string | null
          testemunha_nome?: string | null
          tipo_garantia?: string | null
          tipo_juros?: string | null
          updated_at?: string | null
          user_id?: string
          usuario_mae_id?: string | null
          valor?: number
          valor_capitalizado?: number
          valor_pago?: number | null
          valor_total?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "emprestimos_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "emprestimos_conta_financeira_id_fkey"
            columns: ["conta_financeira_id"]
            isOneToOne: false
            referencedRelation: "contas_financeiras"
            referencedColumns: ["id"]
          },
        ]
      }
      entradas_capital: {
        Row: {
          created_at: string | null
          data: string
          descricao: string
          id: string
          user_id: string
          valor: number
        }
        Insert: {
          created_at?: string | null
          data: string
          descricao: string
          id?: string
          user_id: string
          valor: number
        }
        Update: {
          created_at?: string | null
          data?: string
          descricao?: string
          id?: string
          user_id?: string
          valor?: number
        }
        Relationships: []
      }
      grupos_poupanca: {
        Row: {
          created_at: string | null
          data_fim: string | null
          data_inicio: string | null
          id: string
          local: string | null
          nome: string
          presidente: string | null
          secretario: string | null
          total_emprestado: number | null
          total_poupado: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          data_fim?: string | null
          data_inicio?: string | null
          id?: string
          local?: string | null
          nome: string
          presidente?: string | null
          secretario?: string | null
          total_emprestado?: number | null
          total_poupado?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          data_fim?: string | null
          data_inicio?: string | null
          id?: string
          local?: string | null
          nome?: string
          presidente?: string | null
          secretario?: string | null
          total_emprestado?: number | null
          total_poupado?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      historico_renovacoes: {
        Row: {
          created_at: string | null
          data_fim: string
          data_inicio: string
          dias_adicionados: number
          id: string
          observacoes: string | null
          pacote_nome: string | null
          registrado_por: string | null
          tipo: string
          user_id: string
          valor: number | null
        }
        Insert: {
          created_at?: string | null
          data_fim: string
          data_inicio?: string
          dias_adicionados: number
          id?: string
          observacoes?: string | null
          pacote_nome?: string | null
          registrado_por?: string | null
          tipo?: string
          user_id: string
          valor?: number | null
        }
        Update: {
          created_at?: string | null
          data_fim?: string
          data_inicio?: string
          dias_adicionados?: number
          id?: string
          observacoes?: string | null
          pacote_nome?: string | null
          registrado_por?: string | null
          tipo?: string
          user_id?: string
          valor?: number | null
        }
        Relationships: []
      }
      incoming_payments: {
        Row: {
          codigo_transacao: string
          created_at: string
          id: string
          mensagem_original: string | null
          metodo: string
          numero_destino: string | null
          numero_origem: string | null
          pacote_nome: string | null
          status: string
          submetido_por: string | null
          subscription_request_id: string | null
          valido: boolean | null
          valor: number
        }
        Insert: {
          codigo_transacao: string
          created_at?: string
          id?: string
          mensagem_original?: string | null
          metodo: string
          numero_destino?: string | null
          numero_origem?: string | null
          pacote_nome?: string | null
          status?: string
          submetido_por?: string | null
          subscription_request_id?: string | null
          valido?: boolean | null
          valor: number
        }
        Update: {
          codigo_transacao?: string
          created_at?: string
          id?: string
          mensagem_original?: string | null
          metodo?: string
          numero_destino?: string | null
          numero_origem?: string | null
          pacote_nome?: string | null
          status?: string
          submetido_por?: string | null
          subscription_request_id?: string | null
          valido?: boolean | null
          valor?: number
        }
        Relationships: []
      }
      link_ativacao_uso: {
        Row: {
          ativado_em: string
          duracao_dias: number
          expira_em: string
          id: string
          user_id: string
        }
        Insert: {
          ativado_em?: string
          duracao_dias: number
          expira_em: string
          id?: string
          user_id: string
        }
        Update: {
          ativado_em?: string
          duracao_dias?: number
          expira_em?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      links_ativacao: {
        Row: {
          ativo: boolean
          created_at: string
          duracao_dias: number
          id: string
          nome: string
          total_ativacoes: number
          updated_at: string
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          duracao_dias: number
          id?: string
          nome: string
          total_ativacoes?: number
          updated_at?: string
        }
        Update: {
          ativo?: boolean
          created_at?: string
          duracao_dias?: number
          id?: string
          nome?: string
          total_ativacoes?: number
          updated_at?: string
        }
        Relationships: []
      }
      membros_poupanca: {
        Row: {
          bonus: number | null
          created_at: string | null
          divida: number | null
          grupo_id: string
          id: string
          nome: string
          outros1: number | null
          outros2: number | null
          producao: number | null
          telefone: string | null
          updated_at: string | null
          valor_emprestimo: number | null
          valor_pago: number | null
          valor_poupado: number | null
        }
        Insert: {
          bonus?: number | null
          created_at?: string | null
          divida?: number | null
          grupo_id: string
          id?: string
          nome: string
          outros1?: number | null
          outros2?: number | null
          producao?: number | null
          telefone?: string | null
          updated_at?: string | null
          valor_emprestimo?: number | null
          valor_pago?: number | null
          valor_poupado?: number | null
        }
        Update: {
          bonus?: number | null
          created_at?: string | null
          divida?: number | null
          grupo_id?: string
          id?: string
          nome?: string
          outros1?: number | null
          outros2?: number | null
          producao?: number | null
          telefone?: string | null
          updated_at?: string | null
          valor_emprestimo?: number | null
          valor_pago?: number | null
          valor_poupado?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "membros_poupanca_grupo_id_fkey"
            columns: ["grupo_id"]
            isOneToOne: false
            referencedRelation: "grupos_poupanca"
            referencedColumns: ["id"]
          },
        ]
      }
      mensagens_chat: {
        Row: {
          created_at: string
          id: string
          lida: boolean
          mensagem: string
          receiver_id: string
          sender_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          lida?: boolean
          mensagem: string
          receiver_id: string
          sender_id: string
        }
        Update: {
          created_at?: string
          id?: string
          lida?: boolean
          mensagem?: string
          receiver_id?: string
          sender_id?: string
        }
        Relationships: []
      }
      movimentos_conta: {
        Row: {
          conta_financeira_id: string
          created_at: string | null
          descricao: string | null
          id: string
          referencia_id: string | null
          saldo_contabilistico_antes: number
          saldo_contabilistico_depois: number
          saldo_disponivel_antes: number
          saldo_disponivel_depois: number
          tipo_movimento: string
          user_id: string
          valor: number
        }
        Insert: {
          conta_financeira_id: string
          created_at?: string | null
          descricao?: string | null
          id?: string
          referencia_id?: string | null
          saldo_contabilistico_antes?: number
          saldo_contabilistico_depois?: number
          saldo_disponivel_antes?: number
          saldo_disponivel_depois?: number
          tipo_movimento: string
          user_id: string
          valor: number
        }
        Update: {
          conta_financeira_id?: string
          created_at?: string | null
          descricao?: string | null
          id?: string
          referencia_id?: string | null
          saldo_contabilistico_antes?: number
          saldo_contabilistico_depois?: number
          saldo_disponivel_antes?: number
          saldo_disponivel_depois?: number
          tipo_movimento?: string
          user_id?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "movimentos_conta_conta_financeira_id_fkey"
            columns: ["conta_financeira_id"]
            isOneToOne: false
            referencedRelation: "contas_financeiras"
            referencedColumns: ["id"]
          },
        ]
      }
      notificacoes: {
        Row: {
          created_at: string | null
          enviado_por: string | null
          global: boolean | null
          id: string
          lida: boolean | null
          mensagem: string
          tipo: string
          titulo: string
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          enviado_por?: string | null
          global?: boolean | null
          id?: string
          lida?: boolean | null
          mensagem: string
          tipo?: string
          titulo: string
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          enviado_por?: string | null
          global?: boolean | null
          id?: string
          lida?: boolean | null
          mensagem?: string
          tipo?: string
          titulo?: string
          user_id?: string | null
        }
        Relationships: []
      }
      pacotes_plataforma: {
        Row: {
          ativo: boolean
          checkout_url: string | null
          created_at: string | null
          duracao_dias: number
          id: string
          nome: string
          preco: number
          updated_at: string | null
        }
        Insert: {
          ativo?: boolean
          checkout_url?: string | null
          created_at?: string | null
          duracao_dias?: number
          id?: string
          nome: string
          preco: number
          updated_at?: string | null
        }
        Update: {
          ativo?: boolean
          checkout_url?: string | null
          created_at?: string | null
          duracao_dias?: number
          id?: string
          nome?: string
          preco?: number
          updated_at?: string | null
        }
        Relationships: []
      }
      pagamentos: {
        Row: {
          agente_id: string | null
          arquivado: boolean
          conta_financeira_id: string | null
          created_at: string | null
          data_pagamento: string
          emprestimo_id: string | null
          id: string
          observacoes: string | null
          snapshot_cliente_nome: string | null
          snapshot_cliente_telefone: string | null
          snapshot_data: string | null
          snapshot_emprestimo_taxa_juros: number | null
          snapshot_emprestimo_valor: number | null
          snapshot_emprestimo_valor_total: number | null
          tipo: string | null
          usuario_mae_id: string | null
          valor: number
        }
        Insert: {
          agente_id?: string | null
          arquivado?: boolean
          conta_financeira_id?: string | null
          created_at?: string | null
          data_pagamento: string
          emprestimo_id?: string | null
          id?: string
          observacoes?: string | null
          snapshot_cliente_nome?: string | null
          snapshot_cliente_telefone?: string | null
          snapshot_data?: string | null
          snapshot_emprestimo_taxa_juros?: number | null
          snapshot_emprestimo_valor?: number | null
          snapshot_emprestimo_valor_total?: number | null
          tipo?: string | null
          usuario_mae_id?: string | null
          valor: number
        }
        Update: {
          agente_id?: string | null
          arquivado?: boolean
          conta_financeira_id?: string | null
          created_at?: string | null
          data_pagamento?: string
          emprestimo_id?: string | null
          id?: string
          observacoes?: string | null
          snapshot_cliente_nome?: string | null
          snapshot_cliente_telefone?: string | null
          snapshot_data?: string | null
          snapshot_emprestimo_taxa_juros?: number | null
          snapshot_emprestimo_valor?: number | null
          snapshot_emprestimo_valor_total?: number | null
          tipo?: string | null
          usuario_mae_id?: string | null
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "pagamentos_conta_financeira_id_fkey"
            columns: ["conta_financeira_id"]
            isOneToOne: false
            referencedRelation: "contas_financeiras"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pagamentos_emprestimo_id_fkey"
            columns: ["emprestimo_id"]
            isOneToOne: false
            referencedRelation: "emprestimos"
            referencedColumns: ["id"]
          },
        ]
      }
      pagamentos_plataforma: {
        Row: {
          codigo_transacao: string
          created_at: string | null
          data_envio: string | null
          data_limite_validacao: string | null
          data_validacao: string | null
          forma_pagamento: string
          id: string
          id_transacao_externo: string | null
          imagem_url: string | null
          motivo_rejeicao: string | null
          ocr_resultado: Json | null
          pacote_id: string
          score: number | null
          status: string
          updated_at: string | null
          user_id: string
          validado_por: string | null
          valor: number
        }
        Insert: {
          codigo_transacao: string
          created_at?: string | null
          data_envio?: string | null
          data_limite_validacao?: string | null
          data_validacao?: string | null
          forma_pagamento?: string
          id?: string
          id_transacao_externo?: string | null
          imagem_url?: string | null
          motivo_rejeicao?: string | null
          ocr_resultado?: Json | null
          pacote_id: string
          score?: number | null
          status?: string
          updated_at?: string | null
          user_id: string
          validado_por?: string | null
          valor: number
        }
        Update: {
          codigo_transacao?: string
          created_at?: string | null
          data_envio?: string | null
          data_limite_validacao?: string | null
          data_validacao?: string | null
          forma_pagamento?: string
          id?: string
          id_transacao_externo?: string | null
          imagem_url?: string | null
          motivo_rejeicao?: string | null
          ocr_resultado?: Json | null
          pacote_id?: string
          score?: number | null
          status?: string
          updated_at?: string | null
          user_id?: string
          validado_por?: string | null
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "pagamentos_plataforma_pacote_id_fkey"
            columns: ["pacote_id"]
            isOneToOne: false
            referencedRelation: "pacotes_plataforma"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_attempts: {
        Row: {
          attempt_count: number
          blocked_until: string | null
          id: string
          last_reason: string | null
          pacote_id: string | null
          updated_at: string
          user_id: string
          window_started_at: string
        }
        Insert: {
          attempt_count?: number
          blocked_until?: string | null
          id?: string
          last_reason?: string | null
          pacote_id?: string | null
          updated_at?: string
          user_id: string
          window_started_at?: string
        }
        Update: {
          attempt_count?: number
          blocked_until?: string | null
          id?: string
          last_reason?: string | null
          pacote_id?: string | null
          updated_at?: string
          user_id?: string
          window_started_at?: string
        }
        Relationships: []
      }
      payment_keys: {
        Row: {
          activo: boolean
          created_at: string
          id: string
          metodo: string
          nome_conta: string | null
          numero_conta: string
        }
        Insert: {
          activo?: boolean
          created_at?: string
          id?: string
          metodo: string
          nome_conta?: string | null
          numero_conta: string
        }
        Update: {
          activo?: boolean
          created_at?: string
          id?: string
          metodo?: string
          nome_conta?: string | null
          numero_conta?: string
        }
        Relationships: []
      }
      payment_proofs: {
        Row: {
          ai_raw_response: Json | null
          amount_paid: number | null
          approved_at: string | null
          attempt_number: number | null
          created_at: string
          customer_email: string | null
          customer_name: string | null
          fee: number | null
          fraud_reason: string | null
          fraud_suspected: boolean | null
          id: string
          operator: string
          pacote_id: string | null
          recipient_name: string | null
          recipient_number: string | null
          rejected_at: string | null
          rejection_code: string | null
          rejection_reason: string | null
          screenshot_url: string | null
          transaction_datetime: string | null
          transaction_id: string | null
          user_id: string
          validation_status: string
        }
        Insert: {
          ai_raw_response?: Json | null
          amount_paid?: number | null
          approved_at?: string | null
          attempt_number?: number | null
          created_at?: string
          customer_email?: string | null
          customer_name?: string | null
          fee?: number | null
          fraud_reason?: string | null
          fraud_suspected?: boolean | null
          id?: string
          operator: string
          pacote_id?: string | null
          recipient_name?: string | null
          recipient_number?: string | null
          rejected_at?: string | null
          rejection_code?: string | null
          rejection_reason?: string | null
          screenshot_url?: string | null
          transaction_datetime?: string | null
          transaction_id?: string | null
          user_id: string
          validation_status?: string
        }
        Update: {
          ai_raw_response?: Json | null
          amount_paid?: number | null
          approved_at?: string | null
          attempt_number?: number | null
          created_at?: string
          customer_email?: string | null
          customer_name?: string | null
          fee?: number | null
          fraud_reason?: string | null
          fraud_suspected?: boolean | null
          id?: string
          operator?: string
          pacote_id?: string | null
          recipient_name?: string | null
          recipient_number?: string | null
          rejected_at?: string | null
          rejection_code?: string | null
          rejection_reason?: string | null
          screenshot_url?: string | null
          transaction_datetime?: string | null
          transaction_id?: string | null
          user_id?: string
          validation_status?: string
        }
        Relationships: []
      }
      pg_depositos: {
        Row: {
          assistencia_valor: number
          ciclo_dias: number
          created_at: string
          data_deposito: string
          data_vencimento: string
          estado: string
          grupo_id: string
          id: string
          membro_id: string
          metodo: string | null
          observacoes: string | null
          rendimento_creditado: boolean
          rendimento_valor: number
          taxa_rendimento: number
          user_id: string
          valor: number
        }
        Insert: {
          assistencia_valor?: number
          ciclo_dias?: number
          created_at?: string
          data_deposito?: string
          data_vencimento: string
          estado?: string
          grupo_id: string
          id?: string
          membro_id: string
          metodo?: string | null
          observacoes?: string | null
          rendimento_creditado?: boolean
          rendimento_valor?: number
          taxa_rendimento?: number
          user_id: string
          valor: number
        }
        Update: {
          assistencia_valor?: number
          ciclo_dias?: number
          created_at?: string
          data_deposito?: string
          data_vencimento?: string
          estado?: string
          grupo_id?: string
          id?: string
          membro_id?: string
          metodo?: string | null
          observacoes?: string | null
          rendimento_creditado?: boolean
          rendimento_valor?: number
          taxa_rendimento?: number
          user_id?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "pg_depositos_grupo_id_fkey"
            columns: ["grupo_id"]
            isOneToOne: false
            referencedRelation: "pg_grupos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pg_depositos_membro_id_fkey"
            columns: ["membro_id"]
            isOneToOne: false
            referencedRelation: "pg_membros"
            referencedColumns: ["id"]
          },
        ]
      }
      pg_emprestimos: {
        Row: {
          created_at: string
          data_desembolso: string
          data_vencimento: string
          dias_tolerancia: number
          estado: string
          grupo_id: string
          id: string
          membro_id: string
          mora_paga: number
          multa_paga: number
          multa_tipo: string
          multa_valor: number
          observacoes: string | null
          prazo_meses: number
          taxa_juros: number
          taxa_mora_diaria: number
          tipo_juros: string
          updated_at: string
          user_id: string
          valor: number
          valor_juros: number
          valor_pago: number
          valor_total: number
        }
        Insert: {
          created_at?: string
          data_desembolso?: string
          data_vencimento: string
          dias_tolerancia?: number
          estado?: string
          grupo_id: string
          id?: string
          membro_id: string
          mora_paga?: number
          multa_paga?: number
          multa_tipo?: string
          multa_valor?: number
          observacoes?: string | null
          prazo_meses?: number
          taxa_juros?: number
          taxa_mora_diaria?: number
          tipo_juros?: string
          updated_at?: string
          user_id: string
          valor: number
          valor_juros?: number
          valor_pago?: number
          valor_total?: number
        }
        Update: {
          created_at?: string
          data_desembolso?: string
          data_vencimento?: string
          dias_tolerancia?: number
          estado?: string
          grupo_id?: string
          id?: string
          membro_id?: string
          mora_paga?: number
          multa_paga?: number
          multa_tipo?: string
          multa_valor?: number
          observacoes?: string | null
          prazo_meses?: number
          taxa_juros?: number
          taxa_mora_diaria?: number
          tipo_juros?: string
          updated_at?: string
          user_id?: string
          valor?: number
          valor_juros?: number
          valor_pago?: number
          valor_total?: number
        }
        Relationships: [
          {
            foreignKeyName: "pg_emprestimos_grupo_id_fkey"
            columns: ["grupo_id"]
            isOneToOne: false
            referencedRelation: "pg_grupos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pg_emprestimos_membro_id_fkey"
            columns: ["membro_id"]
            isOneToOne: false
            referencedRelation: "pg_membros"
            referencedColumns: ["id"]
          },
        ]
      }
      pg_grupos: {
        Row: {
          assist_tipo: string
          assist_valor: number
          ciclo_dias: number
          codigo: string
          created_at: string
          data_inicio: string
          dias_tolerancia: number
          estado: string
          gestor: string | null
          id: string
          limite_emprestimo_pct: number
          multa_tipo: string
          multa_valor: number
          nome: string
          observacoes: string | null
          permitir_emprestimos: boolean
          permitir_rendimento: boolean
          prazo_meses: number
          taxa_juros: number
          taxa_mora_diaria: number
          taxa_rendimento: number
          tipo_juros: string
          updated_at: string
          user_id: string
        }
        Insert: {
          assist_tipo?: string
          assist_valor?: number
          ciclo_dias?: number
          codigo: string
          created_at?: string
          data_inicio?: string
          dias_tolerancia?: number
          estado?: string
          gestor?: string | null
          id?: string
          limite_emprestimo_pct?: number
          multa_tipo?: string
          multa_valor?: number
          nome: string
          observacoes?: string | null
          permitir_emprestimos?: boolean
          permitir_rendimento?: boolean
          prazo_meses?: number
          taxa_juros?: number
          taxa_mora_diaria?: number
          taxa_rendimento?: number
          tipo_juros?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          assist_tipo?: string
          assist_valor?: number
          ciclo_dias?: number
          codigo?: string
          created_at?: string
          data_inicio?: string
          dias_tolerancia?: number
          estado?: string
          gestor?: string | null
          id?: string
          limite_emprestimo_pct?: number
          multa_tipo?: string
          multa_valor?: number
          nome?: string
          observacoes?: string | null
          permitir_emprestimos?: boolean
          permitir_rendimento?: boolean
          prazo_meses?: number
          taxa_juros?: number
          taxa_mora_diaria?: number
          taxa_rendimento?: number
          tipo_juros?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      pg_membros: {
        Row: {
          bi: string | null
          created_at: string
          data_entrada: string
          data_saida: string | null
          endereco: string | null
          estado: string
          grupo_id: string
          id: string
          nome: string
          nuit: string | null
          observacoes: string | null
          telefone: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          bi?: string | null
          created_at?: string
          data_entrada?: string
          data_saida?: string | null
          endereco?: string | null
          estado?: string
          grupo_id: string
          id?: string
          nome: string
          nuit?: string | null
          observacoes?: string | null
          telefone?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          bi?: string | null
          created_at?: string
          data_entrada?: string
          data_saida?: string | null
          endereco?: string | null
          estado?: string
          grupo_id?: string
          id?: string
          nome?: string
          nuit?: string | null
          observacoes?: string | null
          telefone?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "pg_membros_grupo_id_fkey"
            columns: ["grupo_id"]
            isOneToOne: false
            referencedRelation: "pg_grupos"
            referencedColumns: ["id"]
          },
        ]
      }
      pg_movimentos: {
        Row: {
          afeta_saldo: boolean
          created_at: string
          data: string
          descricao: string | null
          estornado: boolean
          grupo_id: string
          id: string
          membro_id: string | null
          referencia_id: string | null
          tipo: string
          user_id: string
          valor: number
        }
        Insert: {
          afeta_saldo?: boolean
          created_at?: string
          data?: string
          descricao?: string | null
          estornado?: boolean
          grupo_id: string
          id?: string
          membro_id?: string | null
          referencia_id?: string | null
          tipo: string
          user_id: string
          valor?: number
        }
        Update: {
          afeta_saldo?: boolean
          created_at?: string
          data?: string
          descricao?: string | null
          estornado?: boolean
          grupo_id?: string
          id?: string
          membro_id?: string | null
          referencia_id?: string | null
          tipo?: string
          user_id?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "pg_movimentos_grupo_id_fkey"
            columns: ["grupo_id"]
            isOneToOne: false
            referencedRelation: "pg_grupos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pg_movimentos_membro_id_fkey"
            columns: ["membro_id"]
            isOneToOne: false
            referencedRelation: "pg_membros"
            referencedColumns: ["id"]
          },
        ]
      }
      pg_pagamentos: {
        Row: {
          created_at: string
          data_pagamento: string
          emprestimo_id: string
          grupo_id: string
          id: string
          membro_id: string
          metodo: string | null
          observacoes: string | null
          tipo: string
          user_id: string
          valor: number
        }
        Insert: {
          created_at?: string
          data_pagamento?: string
          emprestimo_id: string
          grupo_id: string
          id?: string
          membro_id: string
          metodo?: string | null
          observacoes?: string | null
          tipo?: string
          user_id: string
          valor: number
        }
        Update: {
          created_at?: string
          data_pagamento?: string
          emprestimo_id?: string
          grupo_id?: string
          id?: string
          membro_id?: string
          metodo?: string | null
          observacoes?: string | null
          tipo?: string
          user_id?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "pg_pagamentos_emprestimo_id_fkey"
            columns: ["emprestimo_id"]
            isOneToOne: false
            referencedRelation: "pg_emprestimos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pg_pagamentos_grupo_id_fkey"
            columns: ["grupo_id"]
            isOneToOne: false
            referencedRelation: "pg_grupos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pg_pagamentos_membro_id_fkey"
            columns: ["membro_id"]
            isOneToOne: false
            referencedRelation: "pg_membros"
            referencedColumns: ["id"]
          },
        ]
      }
      poupanca_investimento_ganhos: {
        Row: {
          created_at: string
          data_pagamento: string | null
          id: string
          mes_referencia: string
          observacoes: string | null
          pago: boolean
          poupanca_id: string
          updated_at: string
          user_id: string
          valor_ganho: number
        }
        Insert: {
          created_at?: string
          data_pagamento?: string | null
          id?: string
          mes_referencia: string
          observacoes?: string | null
          pago?: boolean
          poupanca_id: string
          updated_at?: string
          user_id: string
          valor_ganho?: number
        }
        Update: {
          created_at?: string
          data_pagamento?: string | null
          id?: string
          mes_referencia?: string
          observacoes?: string | null
          pago?: boolean
          poupanca_id?: string
          updated_at?: string
          user_id?: string
          valor_ganho?: number
        }
        Relationships: [
          {
            foreignKeyName: "poupanca_investimento_ganhos_poupanca_id_fkey"
            columns: ["poupanca_id"]
            isOneToOne: false
            referencedRelation: "poupancas_investimento"
            referencedColumns: ["id"]
          },
        ]
      }
      poupancas_investimento: {
        Row: {
          capital_devolvido: boolean
          cliente_nome: string
          cliente_tipo: string
          contacto: string | null
          created_at: string
          data_devolucao: string | null
          data_fim: string | null
          data_inicio: string
          endereco: string | null
          id: string
          nuit: string | null
          observacoes: string | null
          periodo_meses: number
          status: string
          taxa_mensal: number
          updated_at: string
          user_id: string
          valor_capital: number
        }
        Insert: {
          capital_devolvido?: boolean
          cliente_nome: string
          cliente_tipo?: string
          contacto?: string | null
          created_at?: string
          data_devolucao?: string | null
          data_fim?: string | null
          data_inicio?: string
          endereco?: string | null
          id?: string
          nuit?: string | null
          observacoes?: string | null
          periodo_meses?: number
          status?: string
          taxa_mensal?: number
          updated_at?: string
          user_id: string
          valor_capital?: number
        }
        Update: {
          capital_devolvido?: boolean
          cliente_nome?: string
          cliente_tipo?: string
          contacto?: string | null
          created_at?: string
          data_devolucao?: string | null
          data_fim?: string | null
          data_inicio?: string
          endereco?: string | null
          id?: string
          nuit?: string | null
          observacoes?: string | null
          periodo_meses?: number
          status?: string
          taxa_mensal?: number
          updated_at?: string
          user_id?: string
          valor_capital?: number
        }
        Relationships: []
      }
      sms_config: {
        Row: {
          ativo: boolean
          aviso_2_dias_depois: boolean
          aviso_3_dias_antes: boolean
          aviso_no_dia: boolean
          created_at: string
          hora_envio: number
          id: string
          nome_remetente: string | null
          template_antes: string
          template_depois: string
          template_dia: string
          updated_at: string
          user_id: string
        }
        Insert: {
          ativo?: boolean
          aviso_2_dias_depois?: boolean
          aviso_3_dias_antes?: boolean
          aviso_no_dia?: boolean
          created_at?: string
          hora_envio?: number
          id?: string
          nome_remetente?: string | null
          template_antes?: string
          template_depois?: string
          template_dia?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          ativo?: boolean
          aviso_2_dias_depois?: boolean
          aviso_3_dias_antes?: boolean
          aviso_no_dia?: boolean
          created_at?: string
          hora_envio?: number
          id?: string
          nome_remetente?: string | null
          template_antes?: string
          template_depois?: string
          template_dia?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      sms_envios: {
        Row: {
          cliente_id: string | null
          created_at: string
          emprestimo_id: string | null
          erro: string | null
          id: string
          mensagem: string
          referencia_data: string | null
          status: string
          telefone: string
          tipo: string
          user_id: string
        }
        Insert: {
          cliente_id?: string | null
          created_at?: string
          emprestimo_id?: string | null
          erro?: string | null
          id?: string
          mensagem: string
          referencia_data?: string | null
          status?: string
          telefone: string
          tipo?: string
          user_id: string
        }
        Update: {
          cliente_id?: string | null
          created_at?: string
          emprestimo_id?: string | null
          erro?: string | null
          id?: string
          mensagem?: string
          referencia_data?: string | null
          status?: string
          telefone?: string
          tipo?: string
          user_id?: string
        }
        Relationships: []
      }
      sms_pacotes: {
        Row: {
          ativo: boolean
          created_at: string
          id: string
          nome: string
          nome_titular: string | null
          numero_emola: string | null
          numero_mpesa: string | null
          preco: number
          quantidade_sms: number
          updated_at: string
          validade_dias: number
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          id?: string
          nome: string
          nome_titular?: string | null
          numero_emola?: string | null
          numero_mpesa?: string | null
          preco?: number
          quantidade_sms: number
          updated_at?: string
          validade_dias?: number
        }
        Update: {
          ativo?: boolean
          created_at?: string
          id?: string
          nome?: string
          nome_titular?: string | null
          numero_emola?: string | null
          numero_mpesa?: string | null
          preco?: number
          quantidade_sms?: number
          updated_at?: string
          validade_dias?: number
        }
        Relationships: []
      }
      sms_recargas: {
        Row: {
          codigo_transacao: string | null
          comprovativo_url: string | null
          created_at: string
          id: string
          metodo_pagamento: string
          motivo_rejeicao: string | null
          pacote_id: string | null
          quantidade_sms: number
          status: string
          updated_at: string
          user_id: string
          validado_em: string | null
          validado_por: string | null
          valor: number
        }
        Insert: {
          codigo_transacao?: string | null
          comprovativo_url?: string | null
          created_at?: string
          id?: string
          metodo_pagamento?: string
          motivo_rejeicao?: string | null
          pacote_id?: string | null
          quantidade_sms?: number
          status?: string
          updated_at?: string
          user_id: string
          validado_em?: string | null
          validado_por?: string | null
          valor?: number
        }
        Update: {
          codigo_transacao?: string | null
          comprovativo_url?: string | null
          created_at?: string
          id?: string
          metodo_pagamento?: string
          motivo_rejeicao?: string | null
          pacote_id?: string | null
          quantidade_sms?: number
          status?: string
          updated_at?: string
          user_id?: string
          validado_em?: string | null
          validado_por?: string | null
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "sms_recargas_pacote_id_fkey"
            columns: ["pacote_id"]
            isOneToOne: false
            referencedRelation: "sms_pacotes"
            referencedColumns: ["id"]
          },
        ]
      }
      sms_saldos: {
        Row: {
          created_at: string
          expira_em: string | null
          id: string
          saldo: number
          total_enviadas: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          expira_em?: string | null
          id?: string
          saldo?: number
          total_enviadas?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          expira_em?: string | null
          id?: string
          saldo?: number
          total_enviadas?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      subscription_requests: {
        Row: {
          acesso_temporario: boolean | null
          codigo_submetido: string | null
          comprovativo_imagem_url: string | null
          comprovativo_mensagem: string | null
          comprovativo_texto: string | null
          created_at: string
          data_limite_confirmacao: string | null
          id: string
          metodo_pagamento: string
          motivo_rejeicao: string | null
          plano: string
          status: string
          user_id: string
          valor_esperado: number
        }
        Insert: {
          acesso_temporario?: boolean | null
          codigo_submetido?: string | null
          comprovativo_imagem_url?: string | null
          comprovativo_mensagem?: string | null
          comprovativo_texto?: string | null
          created_at?: string
          data_limite_confirmacao?: string | null
          id?: string
          metodo_pagamento: string
          motivo_rejeicao?: string | null
          plano: string
          status?: string
          user_id: string
          valor_esperado: number
        }
        Update: {
          acesso_temporario?: boolean | null
          codigo_submetido?: string | null
          comprovativo_imagem_url?: string | null
          comprovativo_mensagem?: string | null
          comprovativo_texto?: string | null
          created_at?: string
          data_limite_confirmacao?: string | null
          id?: string
          metodo_pagamento?: string
          motivo_rejeicao?: string | null
          plano?: string
          status?: string
          user_id?: string
          valor_esperado?: number
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          created_at: string
          data_fim: string
          data_inicio: string
          id: string
          plano: string
          request_id: string | null
          status: string
          user_id: string
        }
        Insert: {
          created_at?: string
          data_fim: string
          data_inicio?: string
          id?: string
          plano: string
          request_id?: string | null
          status?: string
          user_id: string
        }
        Update: {
          created_at?: string
          data_fim?: string
          data_inicio?: string
          id?: string
          plano?: string
          request_id?: string | null
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "subscription_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      user_data_quarantine: {
        Row: {
          id: string
          marked_at: string
          notes: string | null
          reason: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          user_id: string
        }
        Insert: {
          id?: string
          marked_at?: string
          notes?: string | null
          reason: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          user_id: string
        }
        Update: {
          id?: string
          marked_at?: string
          notes?: string | null
          reason?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      user_error_logs: {
        Row: {
          context: Json | null
          created_at: string
          id: string
          message: string
          stack: string | null
          url: string | null
          user_agent: string | null
          user_id: string
        }
        Insert: {
          context?: Json | null
          created_at?: string
          id?: string
          message: string
          stack?: string | null
          url?: string | null
          user_agent?: string | null
          user_id: string
        }
        Update: {
          context?: Json | null
          created_at?: string
          id?: string
          message?: string
          stack?: string | null
          url?: string | null
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_profiles: {
        Row: {
          bairro: string | null
          bi_nome_extraido: string | null
          bi_url: string | null
          codigo_usuario: string | null
          created_at: string | null
          distrito: string | null
          email: string | null
          estado: string | null
          expires_at: string
          full_name: string
          id: string
          last_seen: string | null
          nome_instituicao: string | null
          permissoes: Json | null
          provincia: string | null
          role: Database["public"]["Enums"]["app_role"]
          rua: string | null
          status: string
          telefone: string | null
          telefone_alternativo: string | null
          telefone_alternativo2: string | null
          updated_at: string | null
          usage_days: number
          user_id: string
          usuario_mae_id: string | null
          verificacao_motivo_rejeicao: string | null
          verificacao_status: string | null
          verificado: boolean | null
          verificado_em: string | null
          was_user_mae: boolean | null
        }
        Insert: {
          bairro?: string | null
          bi_nome_extraido?: string | null
          bi_url?: string | null
          codigo_usuario?: string | null
          created_at?: string | null
          distrito?: string | null
          email?: string | null
          estado?: string | null
          expires_at?: string
          full_name: string
          id?: string
          last_seen?: string | null
          nome_instituicao?: string | null
          permissoes?: Json | null
          provincia?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          rua?: string | null
          status?: string
          telefone?: string | null
          telefone_alternativo?: string | null
          telefone_alternativo2?: string | null
          updated_at?: string | null
          usage_days?: number
          user_id: string
          usuario_mae_id?: string | null
          verificacao_motivo_rejeicao?: string | null
          verificacao_status?: string | null
          verificado?: boolean | null
          verificado_em?: string | null
          was_user_mae?: boolean | null
        }
        Update: {
          bairro?: string | null
          bi_nome_extraido?: string | null
          bi_url?: string | null
          codigo_usuario?: string | null
          created_at?: string | null
          distrito?: string | null
          email?: string | null
          estado?: string | null
          expires_at?: string
          full_name?: string
          id?: string
          last_seen?: string | null
          nome_instituicao?: string | null
          permissoes?: Json | null
          provincia?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          rua?: string | null
          status?: string
          telefone?: string | null
          telefone_alternativo?: string | null
          telefone_alternativo2?: string | null
          updated_at?: string | null
          usage_days?: number
          user_id?: string
          usuario_mae_id?: string | null
          verificacao_motivo_rejeicao?: string | null
          verificacao_status?: string | null
          verificado?: boolean | null
          verificado_em?: string | null
          was_user_mae?: boolean | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      webhook_pagamentos_recebidos: {
        Row: {
          codigo_transacao: string | null
          created_at: string | null
          email: string | null
          erro: string | null
          id: string
          pacote_nome: string | null
          payload: Json | null
          processado: boolean | null
          user_id: string | null
          valor: number | null
        }
        Insert: {
          codigo_transacao?: string | null
          created_at?: string | null
          email?: string | null
          erro?: string | null
          id?: string
          pacote_nome?: string | null
          payload?: Json | null
          processado?: boolean | null
          user_id?: string | null
          valor?: number | null
        }
        Update: {
          codigo_transacao?: string | null
          created_at?: string | null
          email?: string | null
          erro?: string | null
          id?: string
          pacote_nome?: string | null
          payload?: Json | null
          processado?: boolean | null
          user_id?: string | null
          valor?: number | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      aplicar_capitalizacao_automatica: {
        Args: { p_user_id?: string }
        Returns: Json
      }
      aprovar_pagamento_rigoroso: {
        Args: {
          p_amount: number
          p_operator: string
          p_pacote_id: string
          p_paid_at: string
          p_proof_id: string
          p_transaction_id: string
          p_user_id: string
        }
        Returns: Json
      }
      ativar_via_link: { Args: { p_duracao_dias: number }; Returns: Json }
      calcular_mora_emprestimo: {
        Args: { p_emprestimo_id: string }
        Returns: Json
      }
      classificar_status_emprestimo: {
        Args: {
          p_data_reembolso: string
          p_status_atual?: string
          p_valor_pago: number
          p_valor_total: number
        }
        Returns: string
      }
      confirmar_pagamento_superadmin: {
        Args: { p_request_id: string }
        Returns: Json
      }
      criar_pedido_subscricao: {
        Args: { p_metodo: string; p_pacote_id: string }
        Returns: Json
      }
      dashboard_monthly_super: { Args: { p_months?: number }; Returns: Json }
      dashboard_monthly_user: {
        Args: { p_months?: number; p_scope_user_id: string }
        Returns: Json
      }
      dashboard_stats_agente: { Args: { p_agente_id: string }; Returns: Json }
      dashboard_stats_super: { Args: never; Returns: Json }
      dashboard_stats_user: { Args: { p_scope_user_id: string }; Returns: Json }
      export_auth_users: { Args: never; Returns: Json }
      fechar_mes_capital: {
        Args: { p_mes_ano: string; p_user_id: string }
        Returns: undefined
      }
      gerar_codigo_cupao: { Args: never; Returns: string }
      get_or_create_capital_mensal: {
        Args: { p_user_id: string }
        Returns: string
      }
      get_superadmin_id: { Args: never; Returns: string }
      get_usuario_mae_from_agente: {
        Args: { p_agente_id: string }
        Returns: string
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      inicializar_contas_financeiras: {
        Args: { p_user_id: string }
        Returns: undefined
      }
      is_superadmin: { Args: { _user_id: string }; Returns: boolean }
      limpar_logs_antigos: { Args: never; Returns: undefined }
      limpar_mensagens_antigas: { Args: never; Returns: undefined }
      list_emprestimos_pagamentos_paginated: {
        Args: { p_page?: number; p_page_size?: number; p_search?: string }
        Returns: Json
      }
      list_pagamentos_paginated: {
        Args: { p_page?: number; p_page_size?: number; p_search?: string }
        Returns: Json
      }
      manage_agent: {
        Args: {
          p_agent_user_id: string
          p_estado: string
          p_full_name: string
          p_role: Database["public"]["Enums"]["app_role"]
          p_usuario_mae_id: string
        }
        Returns: undefined
      }
      marcar_expirados_inativos: { Args: never; Returns: undefined }
      mark_inactive_users_for_review: { Args: never; Returns: number }
      pg_encerrar_ciclo: {
        Args: { p_grupo_id: string; p_simular?: boolean }
        Returns: Json
      }
      pg_mora_emprestimo: { Args: { p_emprestimo_id: string }; Returns: Json }
      pg_processar_rendimentos: { Args: { p_grupo_id?: string }; Returns: Json }
      pg_registar_pagamento: {
        Args: {
          p_data?: string
          p_emprestimo_id: string
          p_metodo?: string
          p_obs?: string
          p_tipo: string
          p_valor: number
        }
        Returns: Json
      }
      pg_saldo_membro: { Args: { p_membro_id: string }; Returns: Json }
      pg_stats_grupo: { Args: { p_grupo_id: string }; Returns: Json }
      promote_to_superadmin: {
        Args: { user_email: string }
        Returns: undefined
      }
      recalcular_capital_actual: {
        Args: { p_mes_ano: string; p_user_id: string }
        Returns: undefined
      }
      recalcular_mora_paga: {
        Args: { p_emprestimo_id: string }
        Returns: undefined
      }
      recalcular_valor_pago_emprestimo: {
        Args: { p_emprestimo_id: string }
        Returns: undefined
      }
      reclassificar_status_emprestimos: { Args: never; Returns: number }
      reconciliar_saldos_meia_noite: { Args: never; Returns: undefined }
      registrar_atividade_agente: {
        Args: { p_agente_id: string; p_descricao: string }
        Returns: undefined
      }
      rejeitar_pagamento_superadmin: {
        Args: { p_motivo?: string; p_request_id: string }
        Returns: Json
      }
      relatorio_mora_user: { Args: { p_scope_user_id: string }; Returns: Json }
      resgatar_cupao: { Args: { p_codigo: string }; Returns: Json }
      revogar_acessos_temporarios: { Args: never; Returns: undefined }
      revogar_subscricoes_temporarias: { Args: never; Returns: undefined }
      search_clientes_paginated: {
        Args: { p_page?: number; p_page_size?: number; p_search?: string }
        Returns: Json
      }
      search_emprestimos_paginated: {
        Args: {
          p_page?: number
          p_page_size?: number
          p_search?: string
          p_status?: string
        }
        Returns: Json
      }
      show_limit: { Args: never; Returns: number }
      show_trgm: { Args: { "": string }; Returns: string[] }
      sms_aprovar_recarga: { Args: { p_recarga_id: string }; Returns: Json }
      sms_consumir: {
        Args: { p_quantidade?: number; p_user_id: string }
        Returns: Json
      }
      sms_creditar: {
        Args: { p_dias?: number; p_quantidade: number; p_user_id: string }
        Returns: Json
      }
      sms_definir_saldo: {
        Args: { p_dias?: number; p_saldo: number; p_user_id: string }
        Returns: Json
      }
      sms_rejeitar_recarga: {
        Args: { p_motivo: string; p_recarga_id: string }
        Returns: Json
      }
      submeter_sms_pagamento: {
        Args: { p_metodo: string; p_pacote_id: string; p_sms: string }
        Returns: Json
      }
      validar_pagamento_manual: {
        Args: {
          p_codigo: string
          p_comprovativo_url?: string
          p_metodo: string
          p_pacote_id: string
        }
        Returns: Json
      }
    }
    Enums: {
      app_role:
        | "superadmin"
        | "admin"
        | "user"
        | "agente"
        | "secretariado"
        | "contabilista"
        | "auditor"
        | "visualizador"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "superadmin",
        "admin",
        "user",
        "agente",
        "secretariado",
        "contabilista",
        "auditor",
        "visualizador",
      ],
    },
  },
} as const
