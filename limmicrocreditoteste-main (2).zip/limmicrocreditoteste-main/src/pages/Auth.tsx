import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Loader2, CreditCard, WifiOff, KeyRound } from "lucide-react";
import { passwordSchema } from "@/lib/validation";
import { handleError } from "@/lib/errorHandling";
import { useOfflineAuth } from "@/hooks/useOfflineAuth";

export default function Auth() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isRecoveryMode, setIsRecoveryMode] = useState(false);
  const [isNewPasswordMode, setIsNewPasswordMode] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const { cacheSession, offlineLogin } = useOfflineAuth();

  // Handle recovery tokens from URL (hash or query params) and auth events
  useEffect(() => {
    const handleRecoveryDetection = async () => {
      // Check hash fragments (e.g. #type=recovery&access_token=...)
      const hashParams = new URLSearchParams(window.location.hash.substring(1));
      const hashType = hashParams.get("type");

      // Check query params for PKCE code flow (e.g. ?code=...&type=recovery)
      const queryParams = new URLSearchParams(window.location.search);
      const queryCode = queryParams.get("code");
      const queryType = queryParams.get("type");

      if (hashType === "recovery") {
        setIsNewPasswordMode(true);
        setIsRecoveryMode(false);
      } else if (queryCode && queryType === "recovery") {
        // Exchange the PKCE code for a session
        try {
          const { error } = await supabase.auth.exchangeCodeForSession(queryCode);
          if (!error) {
            setIsNewPasswordMode(true);
            setIsRecoveryMode(false);
          } else {
            toast.error("Link de recuperação inválido ou expirado. Solicite um novo.");
          }
        } catch {
          toast.error("Erro ao processar o link de recuperação.");
        }
      } else if (queryCode) {
        // Code without explicit type — try exchange and listen for event
        try {
          await supabase.auth.exchangeCodeForSession(queryCode);
        } catch {
          // will be handled by onAuthStateChange
        }
      }
    };

    handleRecoveryDetection();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") {
        setIsNewPasswordMode(true);
        setIsRecoveryMode(false);
      }
    });
    return () => subscription.unsubscribe();
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Check if online
      if (!navigator.onLine) {
        // Attempt offline login
        const result = await offlineLogin(email, password);
        
        if (result.success) {
          toast.success("Login offline realizado com sucesso!");
          // Store offline session in localStorage for the app to recognize
          localStorage.setItem('offline_session', JSON.stringify({
            user: result.userData,
            isOffline: true
          }));
          navigate("/dashboard");
        } else {
          toast.error(result.error || "Credenciais incorretas para login offline.");
        }
      } else {
        // Online login
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (error) throw error;

        // Cache session for offline use
        await cacheSession(email, password, data.user);

        toast.success("Login realizado com sucesso!");
        navigate("/dashboard");
      }
    } catch (error: any) {
      const errorMsg = handleError("Login", error);
      toast.error(errorMsg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      toast.error("As senhas não coincidem");
      return;
    }

    // Validate password strength
    const passwordValidation = passwordSchema.safeParse(password);
    if (!passwordValidation.success) {
      toast.error(passwordValidation.error.errors[0].message);
      return;
    }

    setIsLoading(true);

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/dashboard`,
        },
      });

      if (error) throw error;

      // Check if user already exists (Supabase returns empty identities for existing emails with auto-confirm)
      if (data.user && data.user.identities && data.user.identities.length === 0) {
        toast.error("Este email já está registado. Por favor, faça login.");
        setIsLoading(false);
        return;
      }

      toast.success("Conta criada! Tem 24 horas grátis para testar a plataforma.");
      navigate("/dashboard");
      setEmail("");
      setPassword("");
      setConfirmPassword("");

    } catch (error: any) {
      const errorMsg = handleError("Signup", error);
      toast.error(errorMsg);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePasswordRecovery = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast.error("Por favor, insira seu e-mail");
      return;
    }

    setIsLoading(true);

    try {
      const redirectUrl = window.location.origin + "/auth";
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: redirectUrl,
      });

      if (error) throw error;

      toast.success("E-mail de recuperação enviado! Verifique sua caixa de entrada e spam.");
      setEmail("");
      setIsRecoveryMode(false);
    } catch (error: any) {
      const errorMsg = handleError("Password Recovery", error);
      toast.error(errorMsg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();

    if (newPassword !== confirmNewPassword) {
      toast.error("As senhas não coincidem");
      return;
    }

    const validation = passwordSchema.safeParse(newPassword);
    if (!validation.success) {
      toast.error(validation.error.errors[0].message);
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;

      // Sign out so user logs in fresh with new password
      await supabase.auth.signOut();
      toast.success("Senha actualizada com sucesso! Faça login com a sua nova senha.");
      setIsNewPasswordMode(false);
      setNewPassword("");
      setConfirmNewPassword("");
      // Clear URL hash
      window.history.replaceState(null, "", window.location.pathname);
    } catch (error: any) {
      const errorMsg = handleError("Update Password", error);
      toast.error(errorMsg);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-primary p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="space-y-2 text-center pb-6">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-full bg-primary flex items-center justify-center">
              {isNewPasswordMode ? (
                <KeyRound className="h-8 w-8 text-primary-foreground" />
              ) : (
                <CreditCard className="h-8 w-8 text-primary-foreground" />
              )}
            </div>
          </div>
          <CardTitle className="text-3xl font-bold">LimSist 2.0</CardTitle>
          <CardDescription className="text-base">
            {isNewPasswordMode ? "Definir Nova Senha" : "Sistema de Gestão para Microcrédito"}
          </CardDescription>
          {!isNewPasswordMode && (
            <p className="text-sm text-muted-foreground">
              Seguro • Confiável • Offline
            </p>
          )}
          {!navigator.onLine && (
            <div className="flex items-center justify-center gap-2 text-warning bg-warning/10 px-3 py-2 rounded-md">
              <WifiOff className="h-4 w-4" />
              <span className="text-sm font-medium">Modo Offline</span>
            </div>
          )}
        </CardHeader>
        <CardContent>
          {isNewPasswordMode ? (
            <form onSubmit={handleUpdatePassword} className="space-y-4">
              <p className="text-sm text-muted-foreground text-center">
                Introduza a sua nova senha para recuperar o acesso à sua conta.
              </p>
              <div className="space-y-2">
                <Label htmlFor="new-password">Nova Senha</Label>
                <Input
                  id="new-password"
                  type="password"
                  placeholder="••••••••"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  disabled={isLoading}
                />
                <p className="text-xs text-muted-foreground">
                  Mínimo 8 caracteres com maiúsculas, minúsculas, números e caracteres especiais
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-new-password">Confirmar Nova Senha</Label>
                <Input
                  id="confirm-new-password"
                  type="password"
                  placeholder="••••••••"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  required
                  disabled={isLoading}
                />
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Actualizando...
                  </>
                ) : (
                  "Actualizar Senha"
                )}
              </Button>
            </form>
          ) : isRecoveryMode ? (
            <div className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-xl font-semibold text-center">Recuperação de Senha</h3>
                <p className="text-sm text-muted-foreground text-center">
                  Esqueceu a sua senha? Não se preocupe, siga os passos abaixo para recuperar o seu acesso.
                </p>
              </div>
              
              <form onSubmit={handlePasswordRecovery} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="recovery-email">E-mail</Label>
                  <Input
                    id="recovery-email"
                    type="email"
                    placeholder="seu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    disabled={isLoading}
                  />
                </div>
                
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>⚠️ <strong>Atenção:</strong></p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>O link de recuperação é válido apenas por 30 minutos.</li>
                    <li>Caso não encontre o e-mail, verifique a sua pasta de Spam/Lixo eletrônico.</li>
                    <li>Crie uma senha forte (mínimo 8 caracteres, com maiúsculas, minúsculas, números e caracteres especiais).</li>
                  </ul>
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Enviando...
                    </>
                  ) : (
                    "Recuperar Senha"
                  )}
                </Button>
                
                <Button
                  type="button"
                  variant="ghost"
                  className="w-full"
                  onClick={() => setIsRecoveryMode(false)}
                  disabled={isLoading}
                >
                  Voltar ao Login
                </Button>
              </form>
            </div>
          ) : (
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="login">Entrar</TabsTrigger>
                <TabsTrigger value="signup">Cadastrar</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="login-email">E-mail</Label>
                    <Input
                      id="login-email"
                      type="email"
                      placeholder="seu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      disabled={isLoading}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="login-password">Senha</Label>
                    <Input
                      id="login-password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      disabled={isLoading}
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Entrando...
                      </>
                    ) : (
                      "Entrar"
                    )}
                  </Button>
                  <Button
                    type="button"
                    variant="link"
                    className="w-full text-sm"
                    onClick={() => setIsRecoveryMode(true)}
                    disabled={isLoading}
                  >
                    Esqueci a senha
                  </Button>
                </form>
              </TabsContent>

            <TabsContent value="signup">
              <form onSubmit={handleSignup} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="signup-email">E-mail</Label>
                  <Input
                    id="signup-email"
                    type="email"
                    placeholder="seu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    disabled={isLoading}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="signup-password">Senha</Label>
                  <Input
                    id="signup-password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    disabled={isLoading}
                  />
                  <p className="text-xs text-muted-foreground">
                    Mínimo 8 caracteres com maiúsculas, minúsculas, números e caracteres especiais
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirm-password">Confirmar Senha</Label>
                  <Input
                    id="confirm-password"
                    type="password"
                    placeholder="••••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    disabled={isLoading}
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Cadastrando...
                    </>
                  ) : (
                    "Cadastrar"
                  )}
                </Button>
              </form>
            </TabsContent>
            </Tabs>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
