import { lazy, Suspense } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DashboardLayout } from "@/components/DashboardLayout";
import {
  TrendingUp,
  Wallet,
  Users,
  AlertTriangle,
  CreditCard,
  DollarSign,
  Calendar,
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { useDashboardData } from "@/hooks/useDashboardData";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useUserRole } from "@/hooks/useUserRole";

const CapitalDashboard = lazy(() => import("@/components/CapitalDashboard").then(m => ({ default: m.CapitalDashboard })));
const SuperAdminDashboard = lazy(() => import("@/components/SuperAdminDashboard").then(m => ({ default: m.SuperAdminDashboard })));
const TabFallback = () => <Skeleton className="h-64 w-full" />;

export default function Dashboard() {
  const { isSuperAdmin, isAgente, isSecretariado } = useUserRole();
  const { stats, monthlyData, portfolioData, inadimplenciaData, loading } = useDashboardData();
  const currentDate = new Date().toLocaleDateString("pt-PT", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-MZ", {
      style: "currency",
      currency: "MZN",
      minimumFractionDigits: 0,
    }).format(value);
  };

  const statsData = [
    {
      title: "Total Emprestado",
      value: formatCurrency(stats.totalEmprestado),
      icon: Wallet,
      rawValue: stats.totalEmprestado,
    },
    {
      title: "Total A Receber",
      value: formatCurrency(stats.totalAReceber),
      icon: DollarSign,
      rawValue: stats.totalAReceber,
    },
    {
      title: "Recebimentos",
      value: formatCurrency(stats.totalRecebimentos),
      icon: TrendingUp,
      rawValue: stats.totalRecebimentos,
    },
    {
      title: "Clientes Ativos",
      value: stats.clientesAtivos.toString(),
      icon: Users,
      rawValue: stats.clientesAtivos,
    },
    {
      title: "Taxa de Inadimplência",
      value: `${stats.taxaInadimplencia.toFixed(1)}%`,
      icon: AlertTriangle,
      rawValue: stats.taxaInadimplencia,
    },
    {
      title: "Empréstimos Ativos",
      value: stats.emprestimosAtivos.toString(),
      icon: CreditCard,
      rawValue: stats.emprestimosAtivos,
    },
  ];

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">
              {isSuperAdmin ? "Dashboard Geral" : "Painel de Controle"}
            </h1>
            <p className="text-muted-foreground flex items-center gap-2 mt-1">
              <Calendar className="h-4 w-4" />
              {currentDate}
            </p>
          </div>
        </div>

        {isSuperAdmin ? (
          <Suspense fallback={<TabFallback />}><SuperAdminDashboard /></Suspense>
        ) : (
          <Tabs defaultValue="operacional" className="w-full">
            <TabsList className={`grid w-full lg:w-auto lg:inline-grid ${isAgente || isSecretariado ? 'grid-cols-1' : 'grid-cols-2'}`}>
              <TabsTrigger value="operacional">Visão Operacional</TabsTrigger>
              {!isAgente && !isSecretariado && (
                <TabsTrigger value="capital">Gestão de Capital</TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="operacional" className="space-y-6 mt-6">
              {/* Stats Grid */}
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {statsData.map((stat) => {
                  const Icon = stat.icon;
                  return (
                    <Card
                      key={stat.title}
                      className="hover:shadow-lg transition-shadow duration-300"
                    >
                      <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-muted-foreground">
                          {stat.title}
                        </CardTitle>
                        <Icon className="h-5 w-5 text-primary" />
                      </CardHeader>
                      <CardContent>
                        {loading ? (
                          <Skeleton className="h-8 w-32" />
                        ) : (
                          <>
                            <div className="text-2xl font-bold text-foreground">
                              {stat.value}
                            </div>
                            <p className="text-xs mt-1 text-muted-foreground">
                              Dados atualizados
                            </p>
                          </>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {/* Charts Row 1 */}
              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Volume Mensal</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={monthlyData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar
                          dataKey="emprestimos"
                          fill="hsl(210, 85%, 48%)"
                          name="Empréstimos"
                        />
                        <Bar
                          dataKey="recebimentos"
                          fill="hsl(142, 76%, 36%)"
                          name="Recebimentos"
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Distribuição da Carteira</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={portfolioData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, value }) =>
                            `${name}: ${Number(value).toLocaleString('pt-MZ', { maximumFractionDigits: 0 })} MT`
                          }
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {portfolioData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              {/* Charts Row 2 */}
              <Card>
                <CardHeader>
                  <CardTitle>Evolução da Inadimplência</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={inadimplenciaData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="taxa"
                        stroke="hsl(0, 84%, 60%)"
                        strokeWidth={2}
                        name="Taxa (%)"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="capital" className="mt-6">
              <Suspense fallback={<TabFallback />}><CapitalDashboard /></Suspense>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </DashboardLayout>
  );
}
