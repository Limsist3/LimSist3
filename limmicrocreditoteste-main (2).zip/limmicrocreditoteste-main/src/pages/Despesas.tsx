import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Receipt, TrendingUp, DollarSign, AlertTriangle, Clock, FileText } from "lucide-react";
import { RelatorioDespesas } from "@/components/RelatorioDespesas";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { CATEGORIAS_DESPESAS } from "@/utils/provincias";
import { despesaSchema } from "@/lib/validation";
import { handleError } from "@/lib/errorHandling";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useContasFinanceiras } from "@/hooks/useContasFinanceiras";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";

export default function Despesas() {
  const [despesas, setDespesas] = useState<any[]>([]);
  const [jurosRecebidos, setJurosRecebidos] = useState(0);
  const [jurosAReceber, setJurosAReceber] = useState(0);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [selectedDespesa, setSelectedDespesa] = useState<any>(null);
  const [categoria, setCategoria] = useState("");
  const [descricao, setDescricao] = useState("");
  const [valor, setValor] = useState("");
  const [data, setData] = useState("");
  const [contaId, setContaId] = useState("");
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [despesaToDelete, setDespesaToDelete] = useState<string | null>(null);
  const [alertaSent, setAlertaSent] = useState(false);
  const [relatorioOpen, setRelatorioOpen] = useState(false);

  const { contas, refetch: refetchContas } = useContasFinanceiras();

  useEffect(() => {
    loadDespesas();
    loadJuros();
  }, []);

  const loadDespesas = async () => {
    const { data } = await supabase.from("despesas").select("*, contas_financeiras(nome, tipo)").order("data", { ascending: false });
    setDespesas(data || []);
  };

  const loadJuros = async () => {
    const mesAtual = new Date().toISOString().slice(0, 7);
    const inicioMes = `${mesAtual}-01`;
    const proximoMes = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1).toISOString().split("T")[0];

    // Juros efectivamente recebidos (pagos) no mês
    const { data: pagamentosJuros } = await supabase
      .from("pagamentos")
      .select("valor")
      .eq("tipo", "Juros")
      .gte("data_pagamento", inicioMes)
      .lt("data_pagamento", proximoMes);

    const totalRecebidos = (pagamentosJuros || []).reduce((acc, p) => acc + (p.valor || 0), 0);
    setJurosRecebidos(totalRecebidos);

    // Juros totais esperados dos empréstimos ativos
    const { data: emprestimos } = await supabase
      .from("emprestimos")
      .select("valor, valor_total, valor_pago, duracao_meses")
      .eq("status", "Ativo");

    if (emprestimos) {
      // Juros mensais esperados = total juros / duração
      const jurosEsperadosMes = emprestimos.reduce((acc, emp) => {
        const jurosTotal = (emp.valor_total || 0) - (emp.valor || 0);
        const jurosMensal = emp.duracao_meses > 0 ? jurosTotal / emp.duracao_meses : 0;
        return acc + jurosMensal;
      }, 0);
      setJurosAReceber(Math.max(0, jurosEsperadosMes - totalRecebidos));
    }
  };

  useRealtimeRefresh(["despesas", "pagamentos", "emprestimos", "contas_financeiras", "movimentos_conta"], () => {
    loadDespesas();
    loadJuros();
    refetchContas();
  }, true, 900);

  const selectedConta = contas.find(c => c.id === contaId);

  const checkAndSendCapitalAlert = async (newTotalDespesas: number) => {
    if (newTotalDespesas > jurosRecebidos) {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return;

      // Check if alert was already sent today
      const hoje = new Date().toISOString().split("T")[0];
      const { data: existing } = await supabase
        .from("notificacoes")
        .select("id")
        .eq("user_id", session.user.id)
        .eq("tipo", "aviso")
        .gte("created_at", hoje)
        .like("titulo", "%Consumindo Capital%")
        .maybeSingle();

      if (!existing) {
        const diferenca = newTotalDespesas - jurosRecebidos;
        await supabase.from("notificacoes").insert({
          user_id: session.user.id,
          titulo: "⚠️ Consumindo Capital",
          mensagem: `As suas despesas (${newTotalDespesas.toFixed(2)} MZN) ultrapassaram os juros produzidos (${jurosRecebidos.toFixed(2)} MZN). Está a consumir ${diferenca.toFixed(2)} MZN do capital.`,
          tipo: "aviso",
          global: false,
        });
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const { data: { session } } = await supabase.auth.getSession();
    const user = session?.user;
    
    if (!user) {
      toast.error("Usuário não autenticado");
      return;
    }

    if (!contaId) {
      toast.error("Selecione uma conta para debitar");
      return;
    }

    const valorNum = parseFloat(valor);

    const validation = despesaSchema.safeParse({ categoria, descricao, valor: valorNum, data });
    if (!validation.success) {
      toast.error(validation.error.errors[0].message);
      return;
    }

    // Check balance
    const { data: contaData } = await supabase
      .from("contas_financeiras")
      .select("*")
      .eq("id", contaId)
      .single();

    if (!contaData || contaData.saldo_disponivel < valorNum) {
      toast.error(`Saldo insuficiente em ${contaData?.nome || "conta"}. Disponível: ${(contaData?.saldo_disponivel || 0).toLocaleString()} MZN`);
      return;
    }

    // Insert despesa
    const { error } = await supabase.from("despesas").insert([{
      user_id: user.id,
      categoria,
      descricao: descricao.trim(),
      valor: valorNum,
      data,
      conta_financeira_id: contaId,
    }]);

    if (error) {
      toast.error(handleError("Create Despesa", error));
      return;
    }

    // Debit account
    const novoSaldo = contaData.saldo_disponivel - valorNum;
    const novoContab = contaData.saldo_contabilistico - valorNum;
    
    await supabase.from("movimentos_conta").insert({
      user_id: user.id,
      conta_financeira_id: contaId,
      tipo_movimento: "despesa",
      valor: -valorNum,
      saldo_disponivel_antes: contaData.saldo_disponivel,
      saldo_disponivel_depois: novoSaldo,
      saldo_contabilistico_antes: contaData.saldo_contabilistico,
      saldo_contabilistico_depois: novoContab,
      descricao: `Despesa: ${categoria} - ${descricao.trim()}`,
    });

    await supabase
      .from("contas_financeiras")
      .update({ saldo_disponivel: novoSaldo, saldo_contabilistico: novoContab })
      .eq("id", contaId);

    // Check capital consumption alert
    const newTotal = totalDespesas + valorNum;
    await checkAndSendCapitalAlert(newTotal);

    toast.success("Despesa registrada e conta debitada!");
    setDialogOpen(false);
    setCategoria(""); setDescricao(""); setValor(""); setData(""); setContaId("");
    loadDespesas();
    refetchContas();
  };

  const handleEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDespesa) return;

    const valorNum = parseFloat(valor);
    const valorAnterior = selectedDespesa.valor;
    const diferenca = valorNum - valorAnterior;

    // If value increased, check balance on account
    if (diferenca > 0 && contaId) {
      const { data: contaData } = await supabase
        .from("contas_financeiras")
        .select("*")
        .eq("id", contaId)
        .single();

      if (!contaData || contaData.saldo_disponivel < diferenca) {
        toast.error(`Saldo insuficiente para o aumento. Disponível: ${(contaData?.saldo_disponivel || 0).toLocaleString()} MZN`);
        return;
      }
    }

    const { error } = await supabase
      .from("despesas")
      .update({
        categoria,
        descricao: descricao.trim(),
        valor: valorNum,
        data,
        conta_financeira_id: contaId || selectedDespesa.conta_financeira_id,
      })
      .eq("id", selectedDespesa.id);

    if (error) {
      toast.error(handleError("Update Despesa", error));
      return;
    }

    // Adjust account balance if value changed and we have an account
    const activeContaId = contaId || selectedDespesa.conta_financeira_id;
    if (diferenca !== 0 && activeContaId) {
      const { data: { session } } = await supabase.auth.getSession();
      const { data: contaData } = await supabase
        .from("contas_financeiras")
        .select("*")
        .eq("id", activeContaId)
        .single();

      if (contaData && session?.user) {
        const novoSaldo = contaData.saldo_disponivel - diferenca;
        const novoContab = contaData.saldo_contabilistico - diferenca;

        await supabase.from("movimentos_conta").insert({
          user_id: session.user.id,
          conta_financeira_id: activeContaId,
          tipo_movimento: "ajuste_despesa",
          valor: -diferenca,
          saldo_disponivel_antes: contaData.saldo_disponivel,
          saldo_disponivel_depois: novoSaldo,
          saldo_contabilistico_antes: contaData.saldo_contabilistico,
          saldo_contabilistico_depois: novoContab,
          descricao: `Ajuste despesa editada: ${categoria}`,
        });

        await supabase
          .from("contas_financeiras")
          .update({ saldo_disponivel: novoSaldo, saldo_contabilistico: novoContab })
          .eq("id", activeContaId);
      }
    }

    toast.success("Despesa atualizada!");
    setEditDialogOpen(false);
    setSelectedDespesa(null);
    setCategoria(""); setDescricao(""); setValor(""); setData(""); setContaId("");
    loadDespesas();
    refetchContas();
  };

  const handleDelete = async () => {
    if (!despesaToDelete) return;
    
    const despesa = despesas.find(d => d.id === despesaToDelete);
    
    const { error } = await supabase
      .from("despesas")
      .delete()
      .eq("id", despesaToDelete);

    if (error) {
      toast.error(handleError("Delete Despesa", error));
    } else {
      // Reverse the debit on the account
      if (despesa?.conta_financeira_id) {
        const { data: { session } } = await supabase.auth.getSession();
        const { data: contaData } = await supabase
          .from("contas_financeiras")
          .select("*")
          .eq("id", despesa.conta_financeira_id)
          .single();

        if (contaData && session?.user) {
          const novoSaldo = contaData.saldo_disponivel + despesa.valor;
          const novoContab = contaData.saldo_contabilistico + despesa.valor;

          await supabase.from("movimentos_conta").insert({
            user_id: session.user.id,
            conta_financeira_id: despesa.conta_financeira_id,
            tipo_movimento: "estorno_despesa",
            valor: despesa.valor,
            saldo_disponivel_antes: contaData.saldo_disponivel,
            saldo_disponivel_depois: novoSaldo,
            saldo_contabilistico_antes: contaData.saldo_contabilistico,
            saldo_contabilistico_depois: novoContab,
            descricao: `Estorno despesa eliminada: ${despesa.categoria}`,
          });

          await supabase
            .from("contas_financeiras")
            .update({ saldo_disponivel: novoSaldo, saldo_contabilistico: novoContab })
            .eq("id", despesa.conta_financeira_id);

          refetchContas();
        }
      }

      toast.success("Despesa excluída e saldo devolvido!");
      loadDespesas();
    }
    setDeleteConfirmOpen(false);
    setDespesaToDelete(null);
  };

  const openEditDialog = (despesa: any) => {
    setSelectedDespesa(despesa);
    setCategoria(despesa.categoria);
    setDescricao(despesa.descricao);
    setValor(despesa.valor.toString());
    setData(despesa.data);
    setContaId(despesa.conta_financeira_id || "");
    setEditDialogOpen(true);
  };

  const totalDespesas = despesas.reduce((acc, d) => acc + parseFloat(d.valor), 0);
  const lucroLiquido = jurosRecebidos - totalDespesas;
  const consumindoCapital = totalDespesas > jurosRecebidos && jurosRecebidos > 0;

  const contasComSaldo = contas.filter(c => c.saldo_disponivel > 0);

  const ContaSelector = ({ value, onChange }: { value: string; onChange: (v: string) => void }) => (
    <div>
      <Label>Conta a debitar *</Label>
      <Select value={value} onValueChange={onChange} required>
        <SelectTrigger><SelectValue placeholder="Selecione a conta" /></SelectTrigger>
        <SelectContent>
          {contasComSaldo.length === 0 && (
            <SelectItem value="none" disabled>Nenhuma conta com saldo disponível</SelectItem>
          )}
          {contasComSaldo.map((conta) => (
            <SelectItem key={conta.id} value={conta.id}>
              {conta.nome} ({conta.tipo === "banco" ? "Banco" : "Carteira"}) - {conta.saldo_disponivel.toLocaleString()} MZN
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {value && selectedConta && (
        <p className="text-xs text-muted-foreground mt-1">
          Saldo disponível: {selectedConta.saldo_disponivel.toLocaleString()} MZN
        </p>
      )}
    </div>
  );

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <Receipt className="h-8 w-8 text-primary" />
              Gestão de Despesas
            </h1>
            <p className="text-muted-foreground mt-1">Controle total das finanças da sua instituição</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setRelatorioOpen(true)}>
              <FileText className="mr-2 h-4 w-4" />Relatório
            </Button>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button><Plus className="mr-2 h-4 w-4" />Nova Despesa</Button>
              </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Registrar Despesa</DialogTitle></DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <ContaSelector value={contaId} onChange={setContaId} />
                <div>
                  <Label>Categoria *</Label>
                  <Select value={categoria} onValueChange={setCategoria} required>
                    <SelectTrigger><SelectValue placeholder="Selecione a categoria" /></SelectTrigger>
                    <SelectContent>
                      {CATEGORIAS_DESPESAS.map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div><Label>Descrição *</Label><Textarea value={descricao} onChange={(e) => setDescricao(e.target.value)} required rows={3} /></div>
                <div><Label>Valor (MZN) *</Label><Input type="number" value={valor} onChange={(e) => setValor(e.target.value)} required /></div>
                <div><Label>Data *</Label><Input type="date" value={data} onChange={(e) => setData(e.target.value)} required /></div>
                <Button type="submit" className="w-full" disabled={contasComSaldo.length === 0}>
                  {contasComSaldo.length === 0 ? "Sem contas com saldo" : "Registrar"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
          </div>
        </div>

        {consumindoCapital && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>⚠️ Atenção:</strong> As despesas ({totalDespesas.toFixed(2)} MZN) ultrapassaram os juros recebidos ({jurosRecebidos.toFixed(2)} MZN). 
              Está a consumir <strong>{(totalDespesas - jurosRecebidos).toFixed(2)} MZN</strong> do capital!
            </AlertDescription>
          </Alert>
        )}

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Despesas</CardTitle>
              <Receipt className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">{totalDespesas.toFixed(2)} MZN</div>
              <p className="text-xs text-muted-foreground mt-1">
                {despesas.length} despesas registradas
              </p>
            </CardContent>
          </Card>

          <Card className={consumindoCapital ? "border-destructive bg-destructive/5" : ""}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                Juros Recebidos
                {consumindoCapital && <AlertTriangle className="h-4 w-4 text-destructive animate-pulse" />}
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${consumindoCapital ? 'text-destructive' : 'text-green-600'}`}>
                {jurosRecebidos.toFixed(2)} MZN
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {consumindoCapital 
                  ? "⚠️ Despesas excedem os juros!" 
                  : "Juros efectivamente pagos este mês"}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Juros a Receber</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-amber-600">{jurosAReceber.toFixed(2)} MZN</div>
              <p className="text-xs text-muted-foreground mt-1">
                Total pendente no mês
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Lucro Líquido</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${lucroLiquido >= 0 ? 'text-green-600' : 'text-destructive'}`}>
                {lucroLiquido.toFixed(2)} MZN
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Juros recebidos - Despesas
              </p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader><CardTitle>Despesas Registradas</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-2">
              {despesas.length === 0 && (
                <p className="text-muted-foreground text-center py-4">Nenhuma despesa registrada</p>
              )}
              {despesas.map((despesa) => (
                <div key={despesa.id} className="flex justify-between items-center p-3 border rounded-lg group hover:bg-muted/50 transition-colors">
                  <div>
                    <p className="font-medium">{despesa.categoria}</p>
                    <p className="text-sm text-muted-foreground">{despesa.descricao}</p>
                    {despesa.contas_financeiras && (
                      <p className="text-xs text-primary mt-1">
                        💳 {despesa.contas_financeiras.nome}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="font-bold text-destructive">{parseFloat(despesa.valor).toFixed(2)} MZN</p>
                      <p className="text-sm text-muted-foreground">{new Date(despesa.data).toLocaleDateString("pt-PT")}</p>
                    </div>
                    <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button variant="ghost" size="sm" onClick={() => openEditDialog(despesa)}>
                        Editar
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => { setDespesaToDelete(despesa.id); setDeleteConfirmOpen(true); }} className="text-destructive">
                        Apagar
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Edit Dialog */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent>
            <DialogHeader><DialogTitle>Editar Despesa</DialogTitle></DialogHeader>
            <form onSubmit={handleEdit} className="space-y-4">
              <ContaSelector value={contaId} onChange={setContaId} />
              <div>
                <Label>Categoria *</Label>
                <Select value={categoria} onValueChange={setCategoria} required>
                  <SelectTrigger><SelectValue placeholder="Selecione a categoria" /></SelectTrigger>
                  <SelectContent>
                    {CATEGORIAS_DESPESAS.map((cat) => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Descrição *</Label><Textarea value={descricao} onChange={(e) => setDescricao(e.target.value)} required rows={3} /></div>
              <div><Label>Valor (MZN) *</Label><Input type="number" value={valor} onChange={(e) => setValor(e.target.value)} required /></div>
              <div><Label>Data *</Label><Input type="date" value={data} onChange={(e) => setData(e.target.value)} required /></div>
              <Button type="submit" className="w-full">Atualizar</Button>
            </form>
          </DialogContent>
        </Dialog>

        <ConfirmDialog
          open={deleteConfirmOpen}
          onOpenChange={setDeleteConfirmOpen}
          description="Tem certeza que deseja excluir esta despesa? O valor será devolvido à conta de origem."
          confirmLabel="Excluir"
          onConfirm={handleDelete}
          variant="destructive"
        />

        <RelatorioDespesas open={relatorioOpen} onOpenChange={setRelatorioOpen} />
      </div>
    </DashboardLayout>
  );
}
