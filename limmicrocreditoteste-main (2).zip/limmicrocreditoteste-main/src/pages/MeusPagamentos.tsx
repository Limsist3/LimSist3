import { useEffect, useState, useMemo, useCallback } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { Receipt, Search, Eye } from "lucide-react";
import { ReciboPagamento } from "@/components/ReciboPagamento";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { useUserRole } from "@/hooks/useUserRole";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";

interface MeuPagamento {
  id: string;
  valor: number;
  data_pagamento: string;
  tipo: string;
  observacoes: string | null;
  created_at: string;
  emprestimo_id: string;
  emprestimo: {
    id: string;
    valor: number;
    taxa_juros: number;
    valor_total: number;
    valor_pago: number;
    cliente_id: string;
    cliente: {
      nome_completo: string;
      telefone: string;
    };
  };
}

export default function MeusPagamentos() {
  const navigate = useNavigate();
  const { isAgente, loading: roleLoading } = useUserRole();
  const [loading, setLoading] = useState(true);
  const [pagamentos, setPagamentos] = useState<MeuPagamento[]>([]);
  const [search, setSearch] = useState("");
  const [reciboOpen, setReciboOpen] = useState(false);
  const [pagamentoSelecionado, setPagamentoSelecionado] = useState<MeuPagamento | null>(null);

  useEffect(() => {
    if (!roleLoading && !isAgente) {
      navigate("/dashboard", { replace: true });
    }
  }, [isAgente, roleLoading, navigate]);

  const loadPagamentos = useCallback(async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from("pagamentos")
        .select(`
          id, valor, data_pagamento, tipo, observacoes, created_at, emprestimo_id,
          emprestimo:emprestimos!inner (
            id, valor, taxa_juros, valor_total, valor_pago, cliente_id,
            cliente:clientes!inner (nome_completo, telefone)
          )
        `)
        .eq("agente_id", user.id)
        .order("data_pagamento", { ascending: false })
        .limit(500);

      if (error) throw error;
      setPagamentos((data as any) || []);
    } catch (err: any) {
      toast.error("Erro ao carregar os seus pagamentos");
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPagamentos();
  }, [loadPagamentos]);

  useRealtimeRefresh(["pagamentos", "emprestimos", "clientes"], loadPagamentos, isAgente && !roleLoading, 900);

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    if (!s) return pagamentos;
    return pagamentos.filter(p =>
      p.emprestimo?.cliente?.nome_completo?.toLowerCase().includes(s) ||
      p.emprestimo?.cliente?.telefone?.includes(s)
    );
  }, [pagamentos, search]);

  const totals = useMemo(() => {
    const total = filtered.reduce((sum, p) => sum + Number(p.valor || 0), 0);
    const hoje = new Date().toISOString().split("T")[0];
    const totalHoje = filtered
      .filter(p => p.data_pagamento === hoje)
      .reduce((sum, p) => sum + Number(p.valor || 0), 0);
    return { total, totalHoje, count: filtered.length };
  }, [filtered]);

  const fmt = (n: number) => new Intl.NumberFormat("pt-PT", { minimumFractionDigits: 2 }).format(n);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Receipt className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-2xl font-bold">Os Meus Pagamentos</h1>
            <p className="text-sm text-muted-foreground">
              Pagamentos registados por si. Reflectidos automaticamente na conta do usuário mãe.
            </p>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Total Geral</CardTitle></CardHeader>
            <CardContent><div className="text-2xl font-bold">{fmt(totals.total)} MZN</div></CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Recebido Hoje</CardTitle></CardHeader>
            <CardContent><div className="text-2xl font-bold text-green-600">{fmt(totals.totalHoje)} MZN</div></CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Nº Pagamentos</CardTitle></CardHeader>
            <CardContent><div className="text-2xl font-bold">{totals.count}</div></CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
              <CardTitle>Histórico</CardTitle>
              <div className="relative w-full sm:w-72">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Procurar cliente ou telefone..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-10 text-muted-foreground">A carregar...</div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">Nenhum pagamento encontrado.</div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Telefone</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead className="text-right">Valor</TableHead>
                      <TableHead className="text-right">Recibo</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map(p => (
                      <TableRow key={p.id}>
                        <TableCell>{new Date(p.data_pagamento).toLocaleDateString("pt-PT")}</TableCell>
                        <TableCell className="font-medium">{p.emprestimo?.cliente?.nome_completo || "-"}</TableCell>
                        <TableCell>{p.emprestimo?.cliente?.telefone || "-"}</TableCell>
                        <TableCell><Badge variant="outline">{p.tipo || "Parcela"}</Badge></TableCell>
                        <TableCell className="text-right font-semibold">{fmt(Number(p.valor))} MZN</TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setPagamentoSelecionado(p);
                              setReciboOpen(true);
                            }}
                          >
                            <Eye className="h-4 w-4 mr-1" /> Ver
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {pagamentoSelecionado && (
        <ReciboPagamento
          open={reciboOpen}
          onOpenChange={setReciboOpen}
          pagamento={{
            id: pagamentoSelecionado.id,
            valor: pagamentoSelecionado.valor,
            data_pagamento: pagamentoSelecionado.data_pagamento,
            observacoes: pagamentoSelecionado.observacoes || "",
            emprestimo_id: pagamentoSelecionado.emprestimo_id,
            cliente_id: pagamentoSelecionado.emprestimo.cliente_id,
            emprestimo: {
              id: pagamentoSelecionado.emprestimo.id,
              valor: pagamentoSelecionado.emprestimo.valor,
              taxa_juros: pagamentoSelecionado.emprestimo.taxa_juros,
              valor_total: pagamentoSelecionado.emprestimo.valor_total,
              valor_pago: pagamentoSelecionado.emprestimo.valor_pago,
              cliente: {
                nome_completo: pagamentoSelecionado.emprestimo.cliente.nome_completo,
                telefone: pagamentoSelecionado.emprestimo.cliente.telefone,
              },
            },
          }}
        />
      )}
    </DashboardLayout>
  );
}
