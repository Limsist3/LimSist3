import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, UserPlus, Pencil, Trash2, Shield, Lock, Bell, Send, Search, BadgeCheck, Eye, RefreshCw } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useUserRole } from "@/hooks/useUserRole";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";
import { format } from "date-fns";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { BackupGlobalSection } from "@/components/BackupGlobalSection";
import { SmsAdminSection } from "@/components/SmsAdminSection";

interface UserProfile {
  id: string;
  user_id: string;
  full_name: string;
  role: "superadmin" | "admin" | "user" | "agente" | "secretariado" | "contabilista" | "auditor" | "visualizador";
  status: string;
  usage_days: number;
  expires_at: string;
  created_at: string;
  email?: string;
  verificado?: boolean;
  codigo_usuario?: string;
  nome_instituicao?: string;
  telefone?: string;
}

interface PlatformStats {
  totalUsers: number;
  activeUsers: number;
  inactiveUsers: number;
  totalEmprestado: number;
  totalReceber: number;
  totalRecebido: number;
}

export default function Administracao() {
  const navigate = useNavigate();
  const { isSuperAdmin, loading: roleLoading } = useUserRole();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [isNewUserDialogOpen, setIsNewUserDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [stats, setStats] = useState<PlatformStats>({
    totalUsers: 0,
    activeUsers: 0,
    inactiveUsers: 0,
    totalEmprestado: 0,
    totalReceber: 0,
    totalRecebido: 0,
  });

  // New user form
  const [newUserEmail, setNewUserEmail] = useState("");
  const [newUserPassword, setNewUserPassword] = useState("");
  const [newUserName, setNewUserName] = useState("");
  const [newUserRole, setNewUserRole] = useState<"user" | "admin" | "agente" | "secretariado">("user");

  // Edit form
  const [editRole, setEditRole] = useState<"user" | "admin" | "superadmin" | "agente" | "secretariado" | "contabilista" | "auditor" | "visualizador">("user");
  const [editStatus, setEditStatus] = useState("active");
  const [editUsageDays, setEditUsageDays] = useState(7);

  // Notification form
  const [notificationTitle, setNotificationTitle] = useState("");
  const [notificationMessage, setNotificationMessage] = useState("");
  const [notificationType, setNotificationType] = useState("info");
  const [isGlobalNotification, setIsGlobalNotification] = useState(true);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [refreshAllOpen, setRefreshAllOpen] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const handleRefreshAllUsers = async () => {
    setRefreshing(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Sem sessão");
      const { data: allProfiles, error: pErr } = await supabase
        .from("user_profiles")
        .select("user_id")
        .neq("user_id", user.id);
      if (pErr) throw pErr;
      const targets = (allProfiles || []).filter(p => p.user_id);
      if (targets.length === 0) {
        toast.info("Nenhum usuário para refrescar.");
        return;
      }
      const rows = targets.map(p => ({
        target_user_id: p.user_id,
        issued_by: user.id,
        command: "reload",
      }));
      // Inserir em lotes de 500 para evitar payloads gigantes
      const CHUNK = 500;
      for (let i = 0; i < rows.length; i += CHUNK) {
        const { error } = await supabase.from("admin_commands").insert(rows.slice(i, i + CHUNK));
        if (error) throw error;
      }
      toast.success(`Comando enviado a ${targets.length} usuários. As apps serão recarregadas.`);
    } catch (e: any) {
      toast.error(e.message || "Falha ao refrescar usuários");
    } finally {
      setRefreshing(false);
      setRefreshAllOpen(false);
    }
  };

  useEffect(() => {
    if (!roleLoading && !isSuperAdmin) {
      toast.error("Acesso negado. Apenas superadministradores podem acessar esta página.");
      navigate("/dashboard");
    }
  }, [isSuperAdmin, roleLoading, navigate]);

  useEffect(() => {
    if (isSuperAdmin) {
      fetchUsers();
      fetchPlatformStats();
    }
  }, [isSuperAdmin]);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const { data: profiles, error: profilesError } = await supabase
        .from("user_profiles")
        .select("*")
        .order("created_at", { ascending: false });

      if (profilesError) throw profilesError;

      setUsers((profiles || []).map(profile => ({
        ...profile,
        email: profile.email || "N/A",
        verificado: (profile as any).verificado || false,
        codigo_usuario: (profile as any).codigo_usuario || null,
        nome_instituicao: (profile as any).nome_instituicao || null,
        telefone: (profile as any).telefone || null,
      })));
    } catch (error: any) {
      console.error("Error fetching users:", error);
      toast.error("Erro ao carregar usuários");
    } finally {
      setLoading(false);
    }
  };

  const filteredUsers = users.filter((u) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      u.full_name?.toLowerCase().includes(term) ||
      u.email?.toLowerCase().includes(term) ||
      u.codigo_usuario?.toLowerCase().includes(term) ||
      u.nome_instituicao?.toLowerCase().includes(term) ||
      u.telefone?.toLowerCase().includes(term)
    );
  });

  const fetchPlatformStats = async () => {
    try {
      // Usa RPC otimizada (executa agregados na BD em vez de descarregar tudo)
      const { data, error } = await supabase.rpc("dashboard_stats_super");
      if (error) throw error;
      const d: any = data || {};
      setStats({
        totalUsers: Number(d.totalUsuarios || 0),
        activeUsers: Number(d.usuariosAtivos || 0),
        inactiveUsers: Number(d.usuariosInativos || 0),
        totalEmprestado: Number(d.totalEmprestadoGlobal || 0),
        totalReceber: Number(d.totalAReceberGlobal || 0),
        totalRecebido: Number(d.totalRecebidoGlobal || 0),
      });
    } catch (error) {
      console.error("Error fetching platform stats:", error);
    }
  };

  useRealtimeRefresh(
    ["user_profiles", "user_roles", "clientes", "emprestimos", "pagamentos", "incoming_payments", "subscription_requests", "historico_renovacoes"],
    () => {
      fetchUsers();
      fetchPlatformStats();
    },
    isSuperAdmin && !roleLoading,
    1000
  );

  const handleCreateUser = async () => {
    try {
      if (!newUserEmail || !newUserPassword || !newUserName) {
        toast.error("Preencha todos os campos");
        return;
      }

      // Create user via Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email: newUserEmail,
        password: newUserPassword,
        options: {
          data: {
            full_name: newUserName
          }
        }
      });

      if (error) throw error;

      // Update role if not default
      if (newUserRole !== "user" && data.user) {
        const { error: roleError } = await supabase
          .from("user_roles")
          .update({ role: newUserRole })
          .eq("user_id", data.user.id);

        if (roleError) throw roleError;

        const { error: profileError } = await supabase
          .from("user_profiles")
          .update({ role: newUserRole })
          .eq("user_id", data.user.id);

        if (profileError) throw profileError;
      }

      toast.success("Usuário criado com sucesso!");
      setIsNewUserDialogOpen(false);
      setNewUserEmail("");
      setNewUserPassword("");
      setNewUserName("");
      setNewUserRole("user");
      fetchUsers();
    } catch (error: any) {
      console.error("Error creating user:", error);
      toast.error(error.message || "Erro ao criar usuário");
    }
  };

  const handleEditUser = async () => {
    if (!selectedUser) return;

    try {
      // Calculate new expiration date
      const expiresAt = editUsageDays === -1 
        ? new Date("2099-12-31").toISOString()
        : new Date(Date.now() + editUsageDays * 24 * 60 * 60 * 1000).toISOString();

      // Update profile
      const { error: profileError } = await supabase
        .from("user_profiles")
        .update({
          role: editRole,
          status: editStatus,
          usage_days: editUsageDays,
          expires_at: expiresAt
        })
        .eq("user_id", selectedUser.user_id);

      if (profileError) throw profileError;

      // Substituir role: apagar tudo e inserir o novo (evita duplicate key
      // quando o usuário já tem múltiplas linhas em user_roles)
      await supabase.from("user_roles").delete().eq("user_id", selectedUser.user_id);
      const { error: roleError } = await supabase
        .from("user_roles")
        .insert({ user_id: selectedUser.user_id, role: editRole });

      if (roleError && !String(roleError.message).includes("duplicate")) throw roleError;

      toast.success("Usuário atualizado com sucesso!");
      setIsEditDialogOpen(false);
      setSelectedUser(null);
      fetchUsers();
    } catch (error: any) {
      console.error("Error updating user:", error);
      toast.error("Erro ao atualizar usuário");
    }
  };

  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<string | null>(null);

  const handleDeleteUser = async () => {
    const userId = userToDelete;
    if (!userId) return;

    try {
      // First delete from user_profiles
      const { error: profileError } = await supabase
        .from("user_profiles")
        .delete()
        .eq("user_id", userId);

      if (profileError) throw profileError;

      // Then delete from user_roles
      const { error: roleError } = await supabase
        .from("user_roles")
        .delete()
        .eq("user_id", userId);

      if (roleError) throw roleError;

      // Finally delete from auth
      const { error } = await supabase.auth.admin.deleteUser(userId);
      if (error) throw error;

      toast.success("Usuário deletado com sucesso!");
      fetchUsers();
    } catch (error: any) {
      console.error("Error deleting user:", error);
      toast.error(error.message || "Erro ao deletar usuário");
    }
    setDeleteConfirmOpen(false);
    setUserToDelete(null);
  };

  const openEditDialog = (user: UserProfile) => {
    setSelectedUser(user);
    setEditRole(user.role);
    setEditStatus(user.status);
    setEditUsageDays(user.usage_days);
    setIsEditDialogOpen(true);
  };

  const handleSendNotification = async () => {
    try {
      if (!notificationTitle || !notificationMessage) {
        toast.error("Preencha o título e a mensagem");
        return;
      }

      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) throw new Error("Usuário não autenticado");

      if (isGlobalNotification) {
        const { error } = await supabase.from("notificacoes").insert({
          titulo: notificationTitle,
          mensagem: notificationMessage,
          tipo: notificationType,
          global: true,
          enviado_por: user.id,
          user_id: null
        });
        if (error) throw error;
      } else {
        if (!selectedUserId) {
          toast.error("Selecione um usuário");
          return;
        }
        const { error } = await supabase.from("notificacoes").insert({
          titulo: notificationTitle,
          mensagem: notificationMessage,
          tipo: notificationType,
          global: false,
          enviado_por: user.id,
          user_id: selectedUserId
        });
        if (error) throw error;
      }

      // Enviar email automaticamente
      try {
        const { data: emailResult } = await supabase.functions.invoke("enviar-notificacao-email", {
          body: {
            titulo: notificationTitle,
            mensagem: notificationMessage,
            tipo: notificationType,
            global: isGlobalNotification,
            user_id: isGlobalNotification ? null : selectedUserId
          }
        });

        if (emailResult?.method === "resend") {
          const sent = emailResult.results?.filter((r: any) => r.status === "sent").length || 0;
          toast.success(`Notificação enviada com sucesso! (${sent} email(s) enviado(s))`);
        } else if (emailResult?.method === "fallback") {
          toast.success("Notificação enviada ao sino! Configure RESEND_API_KEY para enviar também por email.");
        } else {
          toast.success("Notificação enviada com sucesso!");
        }
      } catch (emailError) {
        console.error("Erro ao enviar email:", emailError);
        toast.success("Notificação enviada ao sino! (Email não disponível)");
      }
      setNotificationTitle("");
      setNotificationMessage("");
      setNotificationType("info");
      setIsGlobalNotification(true);
      setSelectedUserId("");
    } catch (error: any) {
      console.error("Error sending notification:", error);
      toast.error("Erro ao enviar notificação");
    }
  };

  if (roleLoading || !isSuperAdmin) {
    return null;
  }

  return (
    <DashboardLayout>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <ShieldCheck className="h-8 w-8 text-primary" />
            Administração
          </h1>
          <Button
            onClick={() => setRefreshAllOpen(true)}
            disabled={refreshing}
            variant="default"
            className="gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
            {refreshing ? "A enviar..." : "Refrescar todos os usuários"}
          </Button>
        </div>

        <ConfirmDialog
          open={refreshAllOpen}
          onOpenChange={setRefreshAllOpen}
          title="Refrescar todos os usuários?"
          description="Esta ação enviará um comando de recarregamento a todos os usuários da plataforma. As suas apps serão recarregadas automaticamente para aplicar as últimas funcionalidades. Deseja continuar?"
          confirmLabel="Sim, refrescar todos"
          onConfirm={handleRefreshAllUsers}
        />

        {/* Platform Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Usuários da Plataforma</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground text-sm">Total</span>
                  <span className="text-2xl font-bold">{stats.totalUsers}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground text-sm">Ativos</span>
                  <Badge variant="default">{stats.activeUsers}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground text-sm">Inativos</span>
                  <Badge variant="secondary">{stats.inactiveUsers}</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Total Emprestado</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {stats.totalEmprestado.toLocaleString("pt-MZ", {
                  style: "currency",
                  currency: "MZN",
                })}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Valor total de empréstimos concedidos
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Valores a Receber/Recebidos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground text-sm">A Receber</span>
                  <span className="text-lg font-semibold">
                    {stats.totalReceber.toLocaleString("pt-MZ", {
                      style: "currency",
                      currency: "MZN",
                    })}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground text-sm">Recebido</span>
                  <span className="text-lg font-semibold text-green-600">
                    {stats.totalRecebido.toLocaleString("pt-MZ", {
                      style: "currency",
                      currency: "MZN",
                    })}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold">Gerenciar Usuários</h2>
          <Dialog open={isNewUserDialogOpen} onOpenChange={setIsNewUserDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <UserPlus className="h-4 w-4 mr-2" />
                Novo Usuário
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Criar Novo Usuário</DialogTitle>
                <DialogDescription>
                  Adicione um novo usuário ao sistema
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="new-name">Nome Completo</Label>
                  <Input
                    id="new-name"
                    value={newUserName}
                    onChange={(e) => setNewUserName(e.target.value)}
                    placeholder="Nome do usuário"
                  />
                </div>
                <div>
                  <Label htmlFor="new-email">E-mail</Label>
                  <Input
                    id="new-email"
                    type="email"
                    value={newUserEmail}
                    onChange={(e) => setNewUserEmail(e.target.value)}
                    placeholder="usuario@email.com"
                  />
                </div>
                <div>
                  <Label htmlFor="new-password">Senha</Label>
                  <Input
                    id="new-password"
                    type="password"
                    value={newUserPassword}
                    onChange={(e) => setNewUserPassword(e.target.value)}
                    placeholder="••••••••"
                  />
                </div>
                <div>
                  <Label htmlFor="new-role">Função</Label>
                  <Select value={newUserRole} onValueChange={(value: any) => setNewUserRole(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="user">Usuário</SelectItem>
                      <SelectItem value="admin">Administrador</SelectItem>
                      <SelectItem value="agente">Agente</SelectItem>
                      <SelectItem value="secretariado">Secretariado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsNewUserDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleCreateUser}>Criar Usuário</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>


        {/* Barra de pesquisa */}
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Pesquisar por nome, instituição, ID, telefone ou email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista de Usuários</CardTitle>
            <CardDescription>
              {searchTerm
                ? `${filteredUsers.length} resultado(s) para "${searchTerm}"`
                : `Gerencie os ${users.length} usuários e suas permissões no sistema`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <p className="text-center py-8 text-muted-foreground">Carregando...</p>
            ) : filteredUsers.length === 0 ? (
              <p className="text-center py-8 text-muted-foreground">
                {searchTerm ? "Nenhum usuário encontrado" : "Nenhum usuário cadastrado"}
              </p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Nome</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Função</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Verificado</TableHead>
                    <TableHead>Expira em</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id} className="cursor-pointer hover:bg-muted/70" onClick={() => navigate(`/usuario/${user.user_id}`)}>
                      <TableCell className="text-xs text-muted-foreground font-mono">
                        {user.codigo_usuario || "—"}
                      </TableCell>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-1.5">
                          {user.full_name}
                          {user.nome_instituicao && (
                            <span className="text-xs text-muted-foreground">({user.nome_instituicao})</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge variant={user.role === "superadmin" ? "default" : "secondary"}>
                          {user.role === "superadmin" && <Shield className="h-3 w-3 mr-1" />}
                          {user.role === "superadmin" ? "SuperAdmin" : 
                           user.role === "admin" ? "Admin" : 
                           user.role === "agente" ? "Agente" :
                           user.role === "secretariado" ? "Secretariado" : "Usuário"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.status === "active" ? "default" : "destructive"}>
                          {user.status === "active" ? "Ativo" : "Inativo"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.verificado ? (
                          <Badge className="bg-emerald-600 text-white gap-1">
                            <BadgeCheck className="h-3 w-3" /> Sim
                          </Badge>
                        ) : (
                          <Badge variant="outline">Não</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {user.usage_days === -1 
                          ? "Ilimitado" 
                          : format(new Date(user.expires_at), "dd/MM/yyyy")}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1" onClick={(e) => e.stopPropagation()}>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => navigate(`/usuario/${user.user_id}`)}
                            title="Ver perfil"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openEditDialog(user)}
                            disabled={user.role === "superadmin"}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => { setUserToDelete(user.user_id); setDeleteConfirmOpen(true); }}
                            disabled={user.role === "superadmin"}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Notification Card */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Enviar Notificação
            </CardTitle>
            <CardDescription>
              Envie notificações para todos os usuários ou para um usuário específico
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="notification-title">Título</Label>
              <Input
                id="notification-title"
                value={notificationTitle}
                onChange={(e) => setNotificationTitle(e.target.value)}
                placeholder="Digite o título da notificação"
              />
            </div>
            
            <div>
              <Label htmlFor="notification-message">Mensagem</Label>
              <Textarea
                id="notification-message"
                value={notificationMessage}
                onChange={(e) => setNotificationMessage(e.target.value)}
                placeholder="Digite a mensagem da notificação"
                rows={4}
              />
            </div>

            <div>
              <Label htmlFor="notification-type">Tipo de Notificação</Label>
              <Select value={notificationType} onValueChange={setNotificationType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="info">ℹ️ Informação</SelectItem>
                  <SelectItem value="success">✅ Sucesso</SelectItem>
                  <SelectItem value="warning">⚠️ Aviso</SelectItem>
                  <SelectItem value="error">❌ Erro</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="global-notification"
                checked={isGlobalNotification}
                onCheckedChange={setIsGlobalNotification}
              />
              <Label htmlFor="global-notification">
                Notificação Global (Todos os usuários)
              </Label>
            </div>

            {!isGlobalNotification && (
              <div>
                <Label htmlFor="user-select">Selecionar Usuário</Label>
                <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Escolha um usuário" />
                  </SelectTrigger>
                  <SelectContent>
                    {users.map((user) => (
                      <SelectItem key={user.user_id} value={user.user_id}>
                        {user.full_name} ({user.email})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="bg-muted p-3 rounded-md text-sm">
              <p className="font-medium mb-1">Tipo: {notificationType === "info" ? "Informação" : 
                notificationType === "success" ? "Sucesso" : 
                notificationType === "warning" ? "Aviso" : "Erro"}</p>
              <p className="text-muted-foreground">
                {isGlobalNotification ? "Esta notificação será enviada para todos os usuários" : 
                 selectedUserId ? `Esta notificação será enviada para ${users.find(u => u.user_id === selectedUserId)?.full_name}` :
                 "Selecione um usuário para enviar a notificação"}
              </p>
            </div>

            <Button 
              onClick={handleSendNotification}
              className="w-full"
            >
              <Send className="h-4 w-4 mr-2" />
              Enviar
            </Button>
          </CardContent>
        </Card>

        {isSuperAdmin && <SmsAdminSection />}

        {isSuperAdmin && <BackupGlobalSection />}

        {/* Edit User Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar Usuário</DialogTitle>
              <DialogDescription>
                Atualize as informações e permissões do usuário
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-role">Função</Label>
                <Select value={editRole} onValueChange={(value: any) => setEditRole(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">Usuário</SelectItem>
                    <SelectItem value="admin">Administrador</SelectItem>
                    <SelectItem value="agente">Agente</SelectItem>
                    <SelectItem value="secretariado">Secretariado</SelectItem>
                    <SelectItem value="superadmin">SuperAdmin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="edit-status">Status da Conta</Label>
                <Select value={editStatus} onValueChange={setEditStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Ativo</SelectItem>
                    <SelectItem value="inactive">Inativo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="edit-usage">Tempo de Uso</Label>
                <Select 
                  value={editUsageDays.toString()} 
                  onValueChange={(value) => setEditUsageDays(parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">7 dias</SelectItem>
                    <SelectItem value="30">30 dias</SelectItem>
                    <SelectItem value="90">90 dias</SelectItem>
                    <SelectItem value="180">180 dias</SelectItem>
                    <SelectItem value="365">365 dias</SelectItem>
                    <SelectItem value="-1">Ilimitado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleEditUser}>Salvar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <ConfirmDialog
        open={deleteConfirmOpen}
        onOpenChange={setDeleteConfirmOpen}
        description="Tem certeza que deseja deletar este usuário? Esta ação não pode ser desfeita."
        confirmLabel="Deletar"
        onConfirm={handleDeleteUser}
        variant="destructive"
      />
    </DashboardLayout>
  );
}
