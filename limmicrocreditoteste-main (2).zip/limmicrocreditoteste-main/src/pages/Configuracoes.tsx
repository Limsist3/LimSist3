import { useState, useEffect, useRef, useCallback } from "react";
import { compressIfImage } from "@/lib/imageCompression";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Settings, Upload, X, BadgeCheck, ShieldCheck, Clock, ArrowLeft, FileText, Phone, MapPin, AlertTriangle, XCircle, MessageSquare, TrendingUp } from "lucide-react";
import { PROVINCIAS_MOCAMBIQUE } from "@/utils/provincias";
import { useUserRole } from "@/hooks/useUserRole";
import { BackupSection } from "@/components/BackupSection";
import { SmsConfigSection } from "@/components/SmsConfigSection";
import { Switch } from "@/components/ui/switch";

export default function Configuracoes() {
  const { role } = useUserRole();
  const [nomeEmpresa, setNomeEmpresa] = useState("");
  const [nuit, setNuit] = useState("");
  const [telefone, setTelefone] = useState("");
  const [email, setEmail] = useState("");
  const [endereco, setEndereco] = useState("");
  const [provincia, setProvincia] = useState("");
  const [numTrabalhadores, setNumTrabalhadores] = useState("");
  const [anoInicioAtividades, setAnoInicioAtividades] = useState("");
  const [diretorNome, setDiretorNome] = useState("");
  const [diretorPosicao, setDiretorPosicao] = useState("DIRECTOR GERAL");
  const [telefax, setTelefax] = useState("");
  const [logoUrl, setLogoUrl] = useState("");
  const [corPrimariaDoc, setCorPrimariaDoc] = useState("#5B4FBF");
  const [corSecundariaDoc, setCorSecundariaDoc] = useState("#1E1B4B");
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [capitalizacaoAuto, setCapitalizacaoAuto] = useState(false);
  const [capitalizacaoDias, setCapitalizacaoDias] = useState("3");
  const [capitalizando, setCapitalizando] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Dados para relatórios
  const [capitaisAlheiosNacionais, setCapitaisAlheiosNacionais] = useState("");
  const [capitaisAlheiosEstrangeiros, setCapitaisAlheiosEstrangeiros] = useState("");
  const [emprestimosObtidos, setEmprestimosObtidos] = useState("");
  const [donativosObtidos, setDonativosObtidos] = useState("");
  const [aumentoCapitalProprio, setAumentoCapitalProprio] = useState("");
  const [caixa, setCaixa] = useState("");
  const [outrosActivos, setOutrosActivos] = useState("");

  // Verificação
  const [showVerificacao, setShowVerificacao] = useState(false);
  const [verificado, setVerificado] = useState(false);
  const [verificadoEm, setVerificadoEm] = useState<string | null>(null);
  const [verificacaoStatus, setVerificacaoStatus] = useState("nao_submetido");
  const [motivoRejeicao, setMotivoRejeicao] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [biUrl, setBiUrl] = useState<string | null>(null);

  // Verificação form fields
  const [vFullName, setVFullName] = useState("");
  const [vTelefone, setVTelefone] = useState("");
  const [vTelefoneAlt, setVTelefoneAlt] = useState("");
  const [vTelefoneAlt2, setVTelefoneAlt2] = useState("");
  const [vEmail, setVEmail] = useState("");
  const [vProvincia, setVProvincia] = useState("");
  const [vDistrito, setVDistrito] = useState("");
  const [vBairro, setVBairro] = useState("");
  const [vRua, setVRua] = useState("");
  const [vNomeInstituicao, setVNomeInstituicao] = useState("");

  const isUsuarioMae = role === "user" || role === "admin";

  useEffect(() => {
    carregarConfig();
    carregarVerificacao();
  }, []);

  const carregarConfig = async () => {
    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) return;

      const { data, error } = await supabase
        .from("configuracoes_empresa")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) { console.error("Erro ao carregar configurações:", error); return; }

      if (data) {
        setNomeEmpresa(data.nome_empresa || "");
        setNuit(data.nuit || "");
        setTelefone(data.telefone || "");
        setEmail(data.email || "");
        setEndereco(data.endereco || "");
        setProvincia((data as any).provincia || "");
        setNumTrabalhadores(data.num_trabalhadores?.toString() || "");
        setAnoInicioAtividades(data.ano_inicio_atividades?.toString() || "");
        setDiretorNome(data.diretor_nome || "");
        setDiretorPosicao(data.diretor_posicao || "DIRECTOR GERAL");
        setTelefax(data.telefax || "");
        setLogoUrl(data.logo_url || "");
        setCorPrimariaDoc((data as any).cor_primaria_documentos || "#5B4FBF");
        setCorSecundariaDoc((data as any).cor_secundaria_documentos || "#1E1B4B");
        setCapitalizacaoAuto(Boolean((data as any).capitalizacao_automatica));
        setCapitalizacaoDias(((data as any).capitalizacao_dias_carencia ?? 3).toString());
        setCapitaisAlheiosNacionais((data as any).capitais_alheios_nacionais?.toString() || "");
        setCapitaisAlheiosEstrangeiros((data as any).capitais_alheios_estrangeiros?.toString() || "");
        setEmprestimosObtidos((data as any).emprestimos_obtidos?.toString() || "");
        setDonativosObtidos((data as any).donativos_obtidos?.toString() || "");
        setAumentoCapitalProprio((data as any).aumento_capital_proprio?.toString() || "");
        setCaixa((data as any).caixa?.toString() || "");
        setOutrosActivos((data as any).outros_activos?.toString() || "");
      }
    } catch (err) {
      console.error("Erro ao carregar configurações:", err);
    }
  };

  const carregarVerificacao = async () => {
    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) return;

      const { data, error } = await supabase
        .from("user_profiles")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) throw error;
      if (!data) return;
      const profile = data as any;
      setVerificado(profile.verificado || false);
      setVerificadoEm(profile.verificado_em || null);
      setVerificacaoStatus(profile.verificacao_status || "nao_submetido");
      setMotivoRejeicao(profile.verificacao_motivo_rejeicao || null);
      setBiUrl(profile.bi_url || null);
      setVFullName(profile.full_name || "");
      setVTelefone(profile.telefone || "");
      setVTelefoneAlt(profile.telefone_alternativo || "");
      setVTelefoneAlt2(profile.telefone_alternativo2 || "");
      setVEmail(profile.email || "");
      setVProvincia(profile.provincia || "");
      setVDistrito(profile.distrito || "");
      setVBairro(profile.bairro || "");
      setVRua(profile.rua || "");
      setVNomeInstituicao(profile.nome_instituicao || "");
    } catch (err) {
      console.error("Erro ao carregar verificação:", err);
    }
  };

  const handleSave = async () => {
    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) { toast.error("Usuário não autenticado"); return; }

      const { data: existing } = await supabase
        .from("configuracoes_empresa")
        .select("id")
        .eq("user_id", user.id)
        .maybeSingle();

      const configData: any = {
        user_id: user.id,
        nome_empresa: nomeEmpresa || null,
        nuit: nuit || null,
        telefone: telefone || null,
        email: email || null,
        endereco: endereco || null,
        provincia: provincia || null,
        num_trabalhadores: numTrabalhadores ? parseInt(numTrabalhadores) : 0,
        ano_inicio_atividades: anoInicioAtividades ? parseInt(anoInicioAtividades) : null,
        diretor_nome: diretorNome || null,
        diretor_posicao: diretorPosicao || "DIRECTOR GERAL",
        telefax: telefax || null,
        logo_url: logoUrl || null,
        cor_primaria_documentos: corPrimariaDoc || "#5B4FBF",
        cor_secundaria_documentos: corSecundariaDoc || "#1E1B4B",
        capitalizacao_automatica: capitalizacaoAuto,
        capitalizacao_dias_carencia: Math.min(90, Math.max(1, parseInt(capitalizacaoDias) || 3)),
        capitais_alheios_nacionais: capitaisAlheiosNacionais ? parseFloat(capitaisAlheiosNacionais) : 0,
        capitais_alheios_estrangeiros: capitaisAlheiosEstrangeiros ? parseFloat(capitaisAlheiosEstrangeiros) : 0,
        emprestimos_obtidos: emprestimosObtidos ? parseFloat(emprestimosObtidos) : 0,
        donativos_obtidos: donativosObtidos ? parseFloat(donativosObtidos) : 0,
        aumento_capital_proprio: aumentoCapitalProprio ? parseFloat(aumentoCapitalProprio) : 0,
        caixa: caixa ? parseFloat(caixa) : 0,
        outros_activos: outrosActivos ? parseFloat(outrosActivos) : 0,
      };

      let error;
      if (existing) {
        const result = await supabase.from("configuracoes_empresa").update(configData).eq("id", existing.id);
        error = result.error;
      } else {
        const result = await supabase.from("configuracoes_empresa").insert([configData]);
        error = result.error;
      }

      if (error) {
        toast.error("Erro ao salvar configurações: " + error.message);
      } else {
        toast.success("Configurações salvas com sucesso!");
        carregarConfig();
      }
    } catch (err: any) {
      toast.error("Erro inesperado ao salvar");
    }
  };

  const executarCapitalizacao = async () => {
    try {
      setCapitalizando(true);
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;
      if (!user) { toast.error("Usuário não autenticado"); return; }

      const { data, error } = await supabase.rpc("aplicar_capitalizacao_automatica", { p_user_id: user.id } as any);
      if (error) { toast.error("Erro ao capitalizar: " + error.message); return; }

      const res = (data || {}) as { emprestimos_capitalizados?: number; juros_acrescentados?: number };
      const total = res.emprestimos_capitalizados || 0;
      if (total === 0) {
        toast.info("Nenhum empréstimo elegível para capitalização neste momento.");
      } else {
        toast.success(`${total} empréstimo(s) capitalizado(s). Juros acrescentados: ${(res.juros_acrescentados || 0).toLocaleString("pt-MZ", { minimumFractionDigits: 2 })} MT`);
      }
    } catch {
      toast.error("Erro inesperado ao capitalizar");
    } finally {
      setCapitalizando(false);
    }
  };

  const handleBIUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Accept any image format or PDF
    const isImage = file.type.startsWith("image/");
    const isPdf = file.type === "application/pdf";
    if (!isImage && !isPdf) {
      toast.error("Formato não suportado. Use uma imagem (JPG, PNG, etc.) ou PDF.");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast.error("Ficheiro muito grande. Máximo 10MB.");
      return;
    }

    try {
      setUploading(true);
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) return;

      const compressed = await compressIfImage(file);
      const fileExt = compressed.name.split(".").pop();
      const filePath = `${user.id}/bi.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from("documentos")
        .upload(filePath, compressed, { upsert: true });
      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage.from("documentos").getPublicUrl(filePath);
      setBiUrl(urlData.publicUrl);

      await supabase
        .from("user_profiles")
        .update({ bi_url: urlData.publicUrl } as any)
        .eq("user_id", user.id);

      toast.success("BI carregado com sucesso!");
    } catch (error: any) {
      toast.error("Erro ao carregar BI");
    } finally {
      setUploading(false);
    }
  };

  const handleSubmeterVerificacao = async () => {
    // Validate required fields
    if (!vFullName.trim()) { toast.error("Nome completo é obrigatório"); return; }
    if (!vTelefone.trim()) { toast.error("Telefone principal é obrigatório"); return; }
    if (!vProvincia) { toast.error("Província é obrigatória"); return; }
    if (!vDistrito.trim()) { toast.error("Distrito é obrigatório"); return; }
    if (!vBairro.trim()) { toast.error("Bairro é obrigatório"); return; }
    
    if (!biUrl) { toast.error("Deve carregar uma foto ou PDF do BI"); return; }

    setSubmitting(true);
    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) return;

      // Save profile data and set status to pendente
      const { error } = await supabase
        .from("user_profiles")
        .update({
          full_name: vFullName,
          telefone: vTelefone || null,
          telefone_alternativo: vTelefoneAlt || null,
          telefone_alternativo2: vTelefoneAlt2 || null,
          
          provincia: vProvincia || null,
          distrito: vDistrito || null,
          bairro: vBairro || null,
          rua: vRua || null,
          nome_instituicao: vNomeInstituicao || null,
          verificacao_status: "pendente",
          verificacao_motivo_rejeicao: null,
        } as any)
        .eq("user_id", user.id);

      if (error) throw error;

      toast.success("Verificação submetida com sucesso! Aguarde a aprovação do administrador.");
      setVerificacaoStatus("pendente");
      setMotivoRejeicao(null);
      setShowVerificacao(false);
    } catch (error: any) {
      console.error("Error submitting:", error);
      toast.error("Erro ao submeter verificação. Tente novamente.");
    } finally {
      setSubmitting(false);
    }
  };

  if (showVerificacao) {
    return (
      <DashboardLayout>
        <div className="p-6 max-w-3xl mx-auto space-y-6">
          <div className="flex items-center gap-3">
            <Button variant="outline" size="icon" onClick={() => setShowVerificacao(false)}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <ShieldCheck className="h-6 w-6 text-primary" /> Verificação de Conta
            </h1>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Dados Pessoais</CardTitle>
              <CardDescription>
                Preencha todos os campos obrigatórios. O nome completo deve ser igual ao que aparece no seu BI.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Nome Completo (igual ao BI) *</Label>
                  <Input value={vFullName} onChange={(e) => setVFullName(e.target.value)} placeholder="Nome completo" />
                </div>
                <div>
                  <Label>Nome da Instituição</Label>
                  <Input value={vNomeInstituicao} onChange={(e) => setVNomeInstituicao(e.target.value)} placeholder="Nome da empresa" />
                </div>
              </div>

              <h3 className="font-semibold flex items-center gap-2 pt-2">
                <Phone className="h-4 w-4" /> Contactos
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label>Telefone Principal *</Label>
                  <Input value={vTelefone} onChange={(e) => setVTelefone(e.target.value)} placeholder="+258 84 XXX XXXX" />
                </div>
                <div>
                  <Label>Telefone Alternativo 1</Label>
                  <Input value={vTelefoneAlt} onChange={(e) => setVTelefoneAlt(e.target.value)} placeholder="+258 84 XXX XXXX" />
                </div>
                <div>
                  <Label>Telefone Alternativo 2</Label>
                  <Input value={vTelefoneAlt2} onChange={(e) => setVTelefoneAlt2(e.target.value)} placeholder="+258 84 XXX XXXX" />
                </div>
              </div>

              <h3 className="font-semibold flex items-center gap-2 pt-2">
                <MapPin className="h-4 w-4" /> Localização
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Província *</Label>
                  <Select value={vProvincia} onValueChange={setVProvincia}>
                    <SelectTrigger><SelectValue placeholder="Selecione a província" /></SelectTrigger>
                    <SelectContent>
                      {PROVINCIAS_MOCAMBIQUE.map((p) => (
                        <SelectItem key={p} value={p}>{p}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Distrito *</Label>
                  <Input value={vDistrito} onChange={(e) => setVDistrito(e.target.value)} placeholder="Distrito" />
                </div>
                <div>
                  <Label>Bairro *</Label>
                  <Input value={vBairro} onChange={(e) => setVBairro(e.target.value)} placeholder="Bairro" />
                </div>
                <div>
                  <Label>Rua/Avenida</Label>
                  <Input value={vRua} onChange={(e) => setVRua(e.target.value)} placeholder="Rua ou Avenida" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" /> Documento de BI *
              </CardTitle>
              <CardDescription>
                Carregue uma foto clara do seu Bilhete de Identidade (frente). O nome deve ser legível.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {biUrl && (
                <div className="border rounded-lg p-3">
                  {biUrl.endsWith(".pdf") ? (
                    <div className="flex items-center gap-3">
                      <FileText className="h-10 w-10 text-destructive" />
                      <a href={biUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                        Ver documento carregado
                      </a>
                    </div>
                  ) : (
                    <img src={biUrl} alt="BI" className="max-h-[200px] rounded-md object-contain" />
                  )}
                </div>
              )}

              <Label htmlFor="bi-upload-config" className="cursor-pointer">
                <div className="border-2 border-dashed rounded-lg p-6 text-center hover:border-primary transition-colors">
                  <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                  <p className="text-sm font-medium">{uploading ? "A carregar..." : "Clique para carregar foto do BI"}</p>
                  <p className="text-xs text-muted-foreground mt-1">JPG, PNG, WEBP ou PDF (máx. 10MB)</p>
                </div>
              </Label>
              <input
                id="bi-upload-config"
                type="file"
                accept="image/*,application/pdf"
                onChange={handleBIUpload}
                className="hidden"
                disabled={uploading}
              />
            </CardContent>
          </Card>

          <Button onClick={handleSubmeterVerificacao} disabled={submitting} className="w-full" size="lg">
            <ShieldCheck className="h-5 w-5 mr-2" />
            {submitting ? "A submeter..." : "Submeter para Aprovação"}
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  // Determine verification card state
  const renderVerificacaoCard = () => {
    // Only show for usuario mae (user/admin roles), not agente/secretariado
    if (!isUsuarioMae) return null;

    if (verificado) {
      return (
        <Card className="border-emerald-500/30">
          <CardContent className="pt-5 pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <BadgeCheck className="h-8 w-8 text-emerald-600" />
                <div>
                  <h3 className="font-semibold text-lg">Conta Verificada</h3>
                  {verificadoEm && (
                    <p className="text-sm text-muted-foreground">
                      Verificado em {new Date(verificadoEm).toLocaleDateString("pt-PT")}
                    </p>
                  )}
                </div>
              </div>
              <Badge className="bg-emerald-600 text-white gap-1">
                <BadgeCheck className="h-3.5 w-3.5" /> Verificado
              </Badge>
            </div>
          </CardContent>
        </Card>
      );
    }

    if (verificacaoStatus === "pendente") {
      return (
        <Card className="border-amber-500/30">
          <CardContent className="pt-5 pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Clock className="h-8 w-8 text-amber-600" />
                <div>
                  <h3 className="font-semibold text-lg">Verificação Pendente</h3>
                  <p className="text-sm text-muted-foreground">
                    Os seus dados foram submetidos e estão a aguardar aprovação do administrador.
                  </p>
                </div>
              </div>
              <Badge variant="secondary" className="gap-1">
                <Clock className="h-3.5 w-3.5" /> Pendente
              </Badge>
            </div>
          </CardContent>
        </Card>
      );
    }

    if (verificacaoStatus === "rejeitado") {
      return (
        <Card className="border-destructive/30">
          <CardContent className="pt-5 pb-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <XCircle className="h-8 w-8 text-destructive" />
                <div>
                  <h3 className="font-semibold text-lg">Verificação Recusada</h3>
                  <p className="text-sm text-muted-foreground">
                    A sua verificação foi recusada. Pode submeter novamente após corrigir o problema.
                  </p>
                </div>
              </div>
              <Button onClick={() => setShowVerificacao(true)} size="sm">
                <ShieldCheck className="h-4 w-4 mr-2" /> Submeter Novamente
              </Button>
            </div>
            {motivoRejeicao && (
              <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3 flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-destructive mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium text-destructive">Motivo da recusa:</p>
                  <p className="text-sm text-foreground">{motivoRejeicao}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      );
    }

    // nao_submetido
    return (
      <Card className="border-amber-500/30">
        <CardContent className="pt-5 pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Clock className="h-8 w-8 text-amber-600" />
              <div>
                <h3 className="font-semibold text-lg">Conta Não Verificada</h3>
                <p className="text-sm text-muted-foreground">
                  Verifique a sua conta para obter benefícios exclusivos
                </p>
              </div>
            </div>
            <Button onClick={() => setShowVerificacao(true)}>
              <ShieldCheck className="h-4 w-4 mr-2" /> Verificar Agora
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <h1 className="text-3xl font-bold flex items-center gap-3">
          <Settings className="h-8 w-8 text-primary" />
          Configurações do Sistema
        </h1>

        {renderVerificacaoCard()}

        <Card>
          <CardHeader><CardTitle>Logotipo da Empresa</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4">
              {logoUrl ? (
                <div className="relative">
                  <img src={logoUrl} alt="Logo" className="h-20 w-20 object-contain rounded-lg border" />
                  <button onClick={() => setLogoUrl("")} className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1 h-5 w-5 flex items-center justify-center">
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ) : (
                <div className="h-20 w-20 border-2 border-dashed rounded-lg flex items-center justify-center text-muted-foreground">
                  <Upload className="h-6 w-6" />
                </div>
              )}
              <div>
                <input
                  ref={fileInputRef} type="file" accept="image/*" className="hidden"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    setUploadingLogo(true);
                    try {
                      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
                      if (!user) return;
                      const compressed = await compressIfImage(file);
                      const ext = compressed.name.split('.').pop();
                      const path = `${user.id}/logo.${ext}`;
                      const { error: uploadError } = await supabase.storage.from('logos').upload(path, compressed, { upsert: true });
                      if (uploadError) throw uploadError;
                      const { data: urlData } = supabase.storage.from('logos').getPublicUrl(path);
                      setLogoUrl(urlData.publicUrl + '?t=' + Date.now());
                      toast.success("Logotipo carregado!");
                    } catch (err: any) { toast.error("Erro ao carregar logotipo: " + err.message); }
                    finally { setUploadingLogo(false); }
                  }}
                />
                <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()} disabled={uploadingLogo}>
                  <Upload className="mr-2 h-4 w-4" />{uploadingLogo ? "Carregando..." : "Carregar Logotipo"}
                </Button>
                <p className="text-xs text-muted-foreground mt-1">PNG, JPG ou SVG. Máx 2MB.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Informações da Empresa</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div><Label>Nome da Empresa *</Label><Input value={nomeEmpresa} onChange={(e) => setNomeEmpresa(e.target.value)} placeholder="XYZ MICROCRÉDITO, E.I" /></div>
              <div><Label>NUIT *</Label><Input value={nuit} onChange={(e) => setNuit(e.target.value)} placeholder="117236692" /></div>
              <div className="col-span-1 md:col-span-2"><Label>Endereço ou Localização *</Label><Input value={endereco} onChange={(e) => setEndereco(e.target.value)} placeholder="BAIRRO DA MAGOANINE, N° 245, MAPUTO" /></div>
              <div><Label>Província</Label><Input value={provincia} onChange={(e) => setProvincia(e.target.value)} placeholder="Maputo" /></div>
              <div><Label>Telefone *</Label><Input value={telefone} onChange={(e) => setTelefone(e.target.value)} placeholder="84XXXXXXXX" /></div>
              <div><Label>Telefax</Label><Input value={telefax} onChange={(e) => setTelefax(e.target.value)} placeholder="82XXXXXXXX" /></div>
              <div><Label>E-mail</Label><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="empresa@email.com" /></div>
              <div><Label>Nº de Trabalhadores</Label><Input type="number" value={numTrabalhadores} onChange={(e) => setNumTrabalhadores(e.target.value)} placeholder="3" /></div>
              <div><Label>Ano de Início das Atividades</Label><Input type="number" value={anoInicioAtividades} onChange={(e) => setAnoInicioAtividades(e.target.value)} placeholder="2012" /></div>
              <div><Label>Nome do Diretor/Operador</Label><Input value={diretorNome} onChange={(e) => setDiretorNome(e.target.value)} placeholder="XXXXXXXXXXXXXXX" /></div>
              <div><Label>Posição do Diretor</Label><Input value={diretorPosicao} onChange={(e) => setDiretorPosicao(e.target.value)} placeholder="DIRECTOR GERAL" /></div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Dados para Relatórios BM</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">Estes dados são usados automaticamente nos relatórios mensal e trimestral do Banco de Moçambique.</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div><Label>Caixa (MZN)</Label><Input type="number" value={caixa} onChange={(e) => setCaixa(e.target.value)} placeholder="0" /></div>
              <div><Label>Outros Activos (MZN)</Label><Input type="number" value={outrosActivos} onChange={(e) => setOutrosActivos(e.target.value)} placeholder="0" /></div>
              <div><Label>Capitais Alheios Nacionais (MZN)</Label><Input type="number" value={capitaisAlheiosNacionais} onChange={(e) => setCapitaisAlheiosNacionais(e.target.value)} placeholder="0" /></div>
              <div><Label>Capitais Alheios Estrangeiros (MZN)</Label><Input type="number" value={capitaisAlheiosEstrangeiros} onChange={(e) => setCapitaisAlheiosEstrangeiros(e.target.value)} placeholder="0" /></div>
              <div><Label>Empréstimos Obtidos no Período (MZN)</Label><Input type="number" value={emprestimosObtidos} onChange={(e) => setEmprestimosObtidos(e.target.value)} placeholder="0" /></div>
              <div><Label>Donativos Obtidos no Período (MZN)</Label><Input type="number" value={donativosObtidos} onChange={(e) => setDonativosObtidos(e.target.value)} placeholder="0" /></div>
              <div><Label>Aumento do Capital com Recursos Próprios (MZN)</Label><Input type="number" value={aumentoCapitalProprio} onChange={(e) => setAumentoCapitalProprio(e.target.value)} placeholder="0" /></div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Capitalização Automática
            </CardTitle>
            <CardDescription>
              Após a data de reembolso, o sistema aguarda o período de carência e aplica a mesma taxa de juros do
              empréstimo sobre o saldo em dívida, uma única vez por empréstimo.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start justify-between gap-4 rounded-lg border p-4">
              <div className="space-y-1">
                <Label className="text-base">Activar capitalização automática</Label>
                <p className="text-sm text-muted-foreground">
                  Exemplo: dívida de 1.100,00 MT a 30% passa a 1.430,00 MT após o prazo de carência.
                </p>
              </div>
              <Switch checked={capitalizacaoAuto} onCheckedChange={setCapitalizacaoAuto} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Dias de carência após o vencimento</Label>
                <Input
                  type="number"
                  min={1}
                  max={90}
                  value={capitalizacaoDias}
                  onChange={(e) => setCapitalizacaoDias(e.target.value)}
                  placeholder="3"
                  disabled={!capitalizacaoAuto}
                />
                <p className="text-xs text-muted-foreground mt-1">Padrão: 3 dias</p>
              </div>
              <div className="flex items-end">
                <Button
                  variant="outline"
                  onClick={executarCapitalizacao}
                  disabled={!capitalizacaoAuto || capitalizando}
                  className="w-full"
                >
                  {capitalizando ? "A processar..." : "Executar agora"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>


        <Card>
          <CardHeader>
            <CardTitle>Cores dos Documentos</CardTitle>
            <CardDescription>Cores aplicadas no papel timbrado de recibos, contratos e relatórios internos.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Cor Primária (barra de destaque do topo)</Label>
                <div className="flex gap-2 items-center mt-1">
                  <input
                    type="color"
                    value={corPrimariaDoc}
                    onChange={(e) => setCorPrimariaDoc(e.target.value)}
                    className="h-10 w-14 cursor-pointer rounded border border-input bg-background p-1"
                  />
                  <Input
                    value={corPrimariaDoc}
                    onChange={(e) => setCorPrimariaDoc(e.target.value)}
                    placeholder="#5B4FBF"
                    className="flex-1 font-mono"
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-1">Padrão: roxo #5B4FBF</p>
              </div>
              <div>
                <Label>Cor Secundária (faixa inferior e títulos)</Label>
                <div className="flex gap-2 items-center mt-1">
                  <input
                    type="color"
                    value={corSecundariaDoc}
                    onChange={(e) => setCorSecundariaDoc(e.target.value)}
                    className="h-10 w-14 cursor-pointer rounded border border-input bg-background p-1"
                  />
                  <Input
                    value={corSecundariaDoc}
                    onChange={(e) => setCorSecundariaDoc(e.target.value)}
                    placeholder="#1E1B4B"
                    className="flex-1 font-mono"
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-1">Padrão: marinho #1E1B4B</p>
              </div>
            </div>

            <div>
              <Label className="mb-2 block">Pré-visualização do papel timbrado</Label>
              <div className="relative bg-white rounded border overflow-hidden" style={{ aspectRatio: "210/297", maxWidth: "320px" }}>
                {/* Barra topo direita */}
                <div className="absolute top-0 right-7" style={{ width: "55%", height: "3%", backgroundColor: corPrimariaDoc }} />
                <div className="absolute top-0 right-1" style={{ width: "5%", height: "5%", backgroundColor: corSecundariaDoc }} />
                {/* Logo + nome */}
                <div className="absolute top-3 left-3 flex items-center gap-2">
                  {logoUrl ? (
                    <img src={logoUrl} alt="logo" className="h-8 w-8 object-contain" />
                  ) : (
                    <div className="h-8 w-8 rounded border border-dashed border-gray-300" />
                  )}
                  <div>
                    <div className="text-[9px] font-bold uppercase leading-tight" style={{ color: corSecundariaDoc }}>
                      {nomeEmpresa || "NOME DA EMPRESA"}
                    </div>
                    {nuit && <div className="text-[7px] text-gray-500">NUIT: {nuit}</div>}
                  </div>
                </div>
                {/* Conteúdo simulado */}
                <div className="absolute inset-x-3 top-20 text-center">
                  <div className="text-[8px] text-gray-300 italic">— Conteúdo do documento —</div>
                </div>
                {/* Rodapé Local/Contatos */}
                <div className="absolute bottom-4 left-3 right-3 flex gap-4 text-[6px]">
                  <div>
                    <div className="font-bold" style={{ color: corSecundariaDoc }}>Local:</div>
                    <div className="text-gray-600">{endereco || "—"}</div>
                  </div>
                  <div>
                    <div className="font-bold" style={{ color: corSecundariaDoc }}>Contatos:</div>
                    <div className="text-gray-600">{email || "—"}</div>
                    <div className="text-gray-600">{telefone || "—"}</div>
                  </div>
                </div>
                {/* Faixa inferior */}
                <div className="absolute bottom-0 inset-x-0" style={{ height: "3%", backgroundColor: corSecundariaDoc }} />
              </div>
            </div>
          </CardContent>
        </Card>

        <SmsConfigSection />

        <BackupSection />

        <Button onClick={handleSave} className="w-full" size="lg">Salvar Configurações</Button>
      </div>
    </DashboardLayout>
  );
}
