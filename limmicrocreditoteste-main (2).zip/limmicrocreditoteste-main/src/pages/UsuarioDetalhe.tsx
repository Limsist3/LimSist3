import { useEffect, useState, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  ArrowLeft, ShieldCheck, BadgeCheck, User, Phone, MapPin,
  Mail, Building, History, CheckCircle2, XCircle, Clock, FileText, AlertTriangle, Activity
} from "lucide-react";
import { UserDiagnosticPanel } from "@/components/UserDiagnosticPanel";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useUserRole } from "@/hooks/useUserRole";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";
import { format } from "date-fns";

interface UserDetail {
  id: string;
  user_id: string;
  full_name: string;
  email: string | null;
  role: string;
  status: string;
  usage_days: number;
  expires_at: string;
  created_at: string | null;
  verificado: boolean;
  verificado_em: string | null;
  telefone: string | null;
  telefone_alternativo: string | null;
  telefone_alternativo2: string | null;
  provincia: string | null;
  distrito: string | null;
  bairro: string | null;
  rua: string | null;
  nome_instituicao: string | null;
  bi_url: string | null;
  bi_nome_extraido: string | null;
  codigo_usuario: string | null;
  verificacao_status: string | null;
  verificacao_motivo_rejeicao: string | null;
}

interface Renovacao {
  id: string;
  tipo: string;
  pacote_nome: string | null;
  dias_adicionados: number;
  data_inicio: string;
  data_fim: string;
  valor: number;
  observacoes: string | null;
  created_at: string;
}

export default function UsuarioDetalhe() {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  const { isSuperAdmin, loading: roleLoading } = useUserRole();
  const [user, setUser] = useState<UserDetail | null>(null);
  const [renovacoes, setRenovacoes] = useState<Renovacao[]>([]);
  const [loading, setLoading] = useState(true);
  const [motivoRejeicao, setMotivoRejeicao] = useState("");
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    if (!roleLoading && !isSuperAdmin) {
      toast.error("Acesso negado.");
      navigate("/administracao");
    }
  }, [isSuperAdmin, roleLoading, navigate]);

  const fetchUser = useCallback(async () => {
    if (!userId) return;
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from("user_profiles")
        .select("*")
        .eq("user_id", userId)
        .single();
      if (error) throw error;
      setUser(data as any);
    } catch (error) {
      console.error("Error fetching user:", error);
      toast.error("Erro ao carregar dados do utilizador");
    } finally {
      setLoading(false);
    }
  }, [userId]);

  const fetchRenovacoes = useCallback(async () => {
    if (!userId) return;
    try {
      const { data, error } = await supabase
        .from("historico_renovacoes")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      setRenovacoes((data || []) as any);
    } catch (error) {
      console.error("Error fetching renovacoes:", error);
    }
  }, [userId]);

  useEffect(() => {
    if (isSuperAdmin && userId) {
      fetchUser();
      fetchRenovacoes();
    }
  }, [isSuperAdmin, userId, fetchUser, fetchRenovacoes]);

  useRealtimeRefresh(["user_profiles", "user_roles", "historico_renovacoes", "subscription_requests"], () => {
    fetchUser();
    fetchRenovacoes();
  }, isSuperAdmin && !!userId, 900);

  const handleAprovar = async () => {
    if (!user || !userId) return;

    // Only usuario mae (role = user/admin) can be verified
    if (user.role === "agente" || user.role === "secretariado") {
      toast.error("Agentes e secretários não podem receber selo de verificação.");
      return;
    }

    setProcessing(true);
    try {
      // Check for duplicates: same full_name, email, or nome_instituicao among OTHER verified users
      const { data: duplicates, error: dupError } = await supabase
        .from("user_profiles")
        .select("user_id, full_name, email, nome_instituicao, verificado")
        .eq("verificado", true)
        .neq("user_id", userId);

      if (dupError) throw dupError;

      const dupes: string[] = [];
      for (const d of duplicates || []) {
        if (d.full_name && user.full_name && d.full_name.toLowerCase().trim() === user.full_name.toLowerCase().trim()) {
          dupes.push(`Nome completo "${d.full_name}" já existe noutro utilizador verificado`);
        }
        if (d.email && user.email && d.email.toLowerCase().trim() === user.email.toLowerCase().trim()) {
          dupes.push(`Email "${d.email}" já existe noutro utilizador verificado`);
        }
        if (d.nome_instituicao && user.nome_instituicao && d.nome_instituicao.toLowerCase().trim() === user.nome_instituicao.toLowerCase().trim()) {
          dupes.push(`Nome da instituição "${d.nome_instituicao}" já existe noutro utilizador verificado`);
        }
      }

      if (dupes.length > 0) {
        toast.error("Não é possível aprovar: " + dupes[0]);
        setProcessing(false);
        return;
      }

      // Approve
      const { error } = await supabase
        .from("user_profiles")
        .update({
          verificado: true,
          verificado_em: new Date().toISOString(),
          verificacao_status: "aprovado",
          verificacao_motivo_rejeicao: null,
        } as any)
        .eq("user_id", userId);

      if (error) throw error;

      // Send notification to user
      await supabase.from("notificacoes").insert({
        user_id: userId,
        titulo: "✅ Conta Verificada!",
        mensagem: "Parabéns! A sua conta foi verificada com sucesso pelo administrador. Agora tem o selo de verificação na plataforma.",
        tipo: "success",
        global: false,
      });

      toast.success("Utilizador verificado com sucesso!");
      fetchUser();
    } catch (error: any) {
      console.error("Error approving:", error);
      toast.error("Erro ao aprovar verificação");
    } finally {
      setProcessing(false);
    }
  };

  const handleRejeitar = async () => {
    if (!user || !userId) return;
    if (!motivoRejeicao.trim()) {
      toast.error("Deve indicar o motivo da recusa");
      return;
    }

    setProcessing(true);
    try {
      const { error } = await supabase
        .from("user_profiles")
        .update({
          verificado: false,
          verificacao_status: "rejeitado",
          verificacao_motivo_rejeicao: motivoRejeicao.trim(),
        } as any)
        .eq("user_id", userId);

      if (error) throw error;

      // Send notification to user
      await supabase.from("notificacoes").insert({
        user_id: userId,
        titulo: "❌ Verificação Recusada",
        mensagem: `A sua verificação foi recusada. Motivo: ${motivoRejeicao.trim()}. Corrija os dados e submeta novamente nas Configurações.`,
        tipo: "error",
        global: false,
      });

      toast.success("Verificação recusada. O utilizador foi notificado.");
      setMotivoRejeicao("");
      fetchUser();
    } catch (error: any) {
      console.error("Error rejecting:", error);
      toast.error("Erro ao recusar verificação");
    } finally {
      setProcessing(false);
    }
  };

  if (roleLoading || !isSuperAdmin || loading) {
    return (
      <DashboardLayout>
        <div className="p-6 flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (!user) {
    return (
      <DashboardLayout>
        <div className="p-6">
          <p className="text-muted-foreground">Utilizador não encontrado.</p>
          <Button variant="outline" onClick={() => navigate("/administracao")} className="mt-4">
            <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  const isPendente = user.verificacao_status === "pendente";
  const isUsuarioMae = user.role === "user" || user.role === "admin";

  return (
    <DashboardLayout>
      <div className="p-6 max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" size="icon" onClick={() => navigate("/administracao")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold">{user.full_name}</h1>
              {user.verificado ? (
                <Badge className="bg-emerald-600 text-white gap-1">
                  <BadgeCheck className="h-3.5 w-3.5" /> Verificado
                </Badge>
              ) : isPendente ? (
                <Badge variant="secondary" className="gap-1 bg-amber-500/20 text-amber-700">
                  <Clock className="h-3.5 w-3.5" /> Pendente
                </Badge>
              ) : (
                <Badge variant="secondary" className="gap-1">
                  <Clock className="h-3.5 w-3.5" /> Não Verificado
                </Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground">
              ID: {user.codigo_usuario || "N/A"} • {user.email || "Sem email"} • {user.role}
            </p>
          </div>
        </div>

        <Tabs defaultValue="perfil" className="space-y-4">
          <TabsList>
            <TabsTrigger value="perfil">
              <User className="h-4 w-4 mr-2" /> Perfil
            </TabsTrigger>
            <TabsTrigger value="verificacao">
              <ShieldCheck className="h-4 w-4 mr-2" /> Verificação
              {isPendente && (
                <span className="ml-1.5 h-2 w-2 rounded-full bg-amber-500 animate-pulse" />
              )}
            </TabsTrigger>
            <TabsTrigger value="renovacoes">
              <History className="h-4 w-4 mr-2" /> Renovações
            </TabsTrigger>
            <TabsTrigger value="diagnostico">
              <Activity className="h-4 w-4 mr-2" /> Diagnóstico
            </TabsTrigger>
          </TabsList>

          {/* Tab: Perfil - READ ONLY */}
          <TabsContent value="perfil">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" /> Dados do Perfil
                </CardTitle>
                <CardDescription>
                  Informações do utilizador (somente leitura)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <InfoField label="Nome Completo" value={user.full_name} />
                  <InfoField label="Email" value={user.email} />
                  <InfoField label="Instituição" value={user.nome_instituicao} />
                  <InfoField label="Código" value={user.codigo_usuario} />
                </div>

                <div>
                  <h3 className="font-semibold flex items-center gap-2 mb-3">
                    <Phone className="h-4 w-4" /> Contactos
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <InfoField label="Telefone Principal" value={user.telefone} />
                    <InfoField label="Telefone Alternativo 1" value={user.telefone_alternativo} />
                    <InfoField label="Telefone Alternativo 2" value={user.telefone_alternativo2} />
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold flex items-center gap-2 mb-3">
                    <MapPin className="h-4 w-4" /> Localização
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <InfoField label="Província" value={user.provincia} />
                    <InfoField label="Distrito" value={user.distrito} />
                    <InfoField label="Bairro" value={user.bairro} />
                    <InfoField label="Rua/Avenida" value={user.rua} />
                  </div>
                </div>

                <div className="bg-muted/50 rounded-lg p-4">
                  <h3 className="font-semibold mb-2">Informações da Conta</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                    <div>
                      <span className="text-muted-foreground">Função:</span>
                      <p className="font-medium capitalize">{user.role}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Status:</span>
                      <p>
                        <Badge variant={user.status === "active" ? "default" : "destructive"}>
                          {user.status === "active" ? "Ativo" : "Inativo"}
                        </Badge>
                      </p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Registado em:</span>
                      <p className="font-medium">
                        {user.created_at ? format(new Date(user.created_at), "dd/MM/yyyy") : "N/A"}
                      </p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Expira em:</span>
                      <p className="font-medium">
                        {user.usage_days === -1 ? "Ilimitado" : format(new Date(user.expires_at), "dd/MM/yyyy")}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Verificação - SuperAdmin can approve/reject */}
          <TabsContent value="verificacao">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShieldCheck className="h-5 w-5" /> Verificação de Identidade
                </CardTitle>
                <CardDescription>
                  {isUsuarioMae 
                    ? "Analise os dados submetidos pelo utilizador e aprove ou recuse a verificação."
                    : "Agentes e secretários não são elegíveis para verificação."}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {!isUsuarioMae ? (
                  <div className="bg-muted/50 rounded-lg p-6 text-center">
                    <AlertTriangle className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">
                      Este utilizador é <strong>{user.role}</strong>. Apenas Usuários Mãe podem ser verificados.
                    </p>
                  </div>
                ) : (
                  <>
                    {/* Current status */}
                    <div className={`rounded-lg p-4 border-2 ${
                      user.verificado 
                        ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-950/20" 
                        : isPendente 
                          ? "border-amber-500 bg-amber-50 dark:bg-amber-950/20"
                          : user.verificacao_status === "rejeitado"
                            ? "border-destructive bg-destructive/5"
                            : "border-muted bg-muted/30"
                    }`}>
                      <div className="flex items-center gap-3">
                        {user.verificado ? (
                          <CheckCircle2 className="h-8 w-8 text-emerald-600" />
                        ) : isPendente ? (
                          <Clock className="h-8 w-8 text-amber-600" />
                        ) : user.verificacao_status === "rejeitado" ? (
                          <XCircle className="h-8 w-8 text-destructive" />
                        ) : (
                          <XCircle className="h-8 w-8 text-muted-foreground" />
                        )}
                        <div>
                          <h3 className="font-semibold text-lg">
                            {user.verificado ? "Conta Verificada" 
                              : isPendente ? "Aguardando Aprovação"
                              : user.verificacao_status === "rejeitado" ? "Verificação Recusada"
                              : "Não Submetido"}
                          </h3>
                          {user.verificado && user.verificado_em && (
                            <p className="text-sm text-muted-foreground">
                              Verificado em {format(new Date(user.verificado_em), "dd/MM/yyyy HH:mm")}
                            </p>
                          )}
                          {user.verificacao_status === "rejeitado" && user.verificacao_motivo_rejeicao && (
                            <p className="text-sm text-destructive mt-1">
                              Motivo: {user.verificacao_motivo_rejeicao}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Comparison: Name from profile vs BI document */}
                    {isPendente && (
                      <>
                        <div className="bg-muted/50 rounded-lg p-4 space-y-3">
                          <h3 className="font-semibold">Dados para Análise</h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <p className="text-xs text-muted-foreground">Nome Completo (perfil)</p>
                              <p className="text-sm font-semibold">{user.full_name}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Email</p>
                              <p className="text-sm font-semibold">{user.email || "—"}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Instituição</p>
                              <p className="text-sm font-semibold">{user.nome_instituicao || "—"}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Telefone</p>
                              <p className="text-sm font-semibold">{user.telefone || "—"}</p>
                            </div>
                          </div>
                        </div>

                        {/* BI Document */}
                        {user.bi_url ? (
                          <div>
                            <h3 className="font-semibold mb-3 flex items-center gap-2">
                              <FileText className="h-4 w-4" /> Documento de BI Submetido
                            </h3>
                            <div className="border rounded-lg p-3">
                              {user.bi_url.endsWith(".pdf") ? (
                                <div className="flex items-center gap-3">
                                  <FileText className="h-10 w-10 text-destructive" />
                                  <div>
                                    <p className="font-medium">BI (PDF)</p>
                                    <a href={user.bi_url} target="_blank" rel="noopener noreferrer" className="text-primary text-sm hover:underline">
                                      Ver documento
                                    </a>
                                  </div>
                                </div>
                              ) : (
                                <img src={user.bi_url} alt="Documento BI" className="max-h-[400px] rounded-md object-contain" />
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground mt-2">
                              Compare o nome no BI com o nome completo do perfil acima. Devem ser iguais.
                            </p>
                          </div>
                        ) : (
                          <div className="bg-destructive/10 rounded-lg p-4 text-center">
                            <AlertTriangle className="h-6 w-6 text-destructive mx-auto mb-1" />
                            <p className="text-sm text-destructive">O utilizador não submeteu documento de BI.</p>
                          </div>
                        )}

                        {/* Action buttons */}
                        <div className="border-t pt-4 space-y-4">
                          <Button 
                            onClick={handleAprovar} 
                            disabled={processing} 
                            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                            size="lg"
                          >
                            <CheckCircle2 className="h-5 w-5 mr-2" />
                            {processing ? "A processar..." : "Aprovar Verificação"}
                          </Button>
                          
                          <div className="space-y-2">
                            <Label>Motivo da Recusa (obrigatório para recusar)</Label>
                            <Textarea 
                              value={motivoRejeicao}
                              onChange={(e) => setMotivoRejeicao(e.target.value)}
                              placeholder="Ex: O nome no BI não corresponde ao nome do perfil..."
                              rows={3}
                            />
                            <Button 
                              onClick={handleRejeitar} 
                              disabled={processing || !motivoRejeicao.trim()} 
                              variant="destructive"
                              className="w-full"
                              size="lg"
                            >
                              <XCircle className="h-5 w-5 mr-2" />
                              {processing ? "A processar..." : "Recusar Verificação"}
                            </Button>
                          </div>
                        </div>
                      </>
                    )}

                    {/* Show BI for already verified users */}
                    {user.verificado && user.bi_url && (
                      <div>
                        <h3 className="font-semibold mb-3 flex items-center gap-2">
                          <FileText className="h-4 w-4" /> Documento de BI
                        </h3>
                        <div className="border rounded-lg p-3">
                          {user.bi_url.endsWith(".pdf") ? (
                            <div className="flex items-center gap-3">
                              <FileText className="h-10 w-10 text-destructive" />
                              <div>
                                <p className="font-medium">BI (PDF)</p>
                                <a href={user.bi_url} target="_blank" rel="noopener noreferrer" className="text-primary text-sm hover:underline">
                                  Ver documento
                                </a>
                              </div>
                            </div>
                          ) : (
                            <img src={user.bi_url} alt="Documento BI" className="max-h-[300px] rounded-md object-contain" />
                          )}
                        </div>
                      </div>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Renovações */}
          <TabsContent value="renovacoes">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="h-5 w-5" /> Histórico de Renovações
                </CardTitle>
                <CardDescription>Todas as renovações de acesso deste utilizador</CardDescription>
              </CardHeader>
              <CardContent>
                {renovacoes.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">Nenhuma renovação registada.</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Data</TableHead>
                        <TableHead>Tipo</TableHead>
                        <TableHead>Pacote</TableHead>
                        <TableHead>Dias</TableHead>
                        <TableHead>Período</TableHead>
                        <TableHead>Valor</TableHead>
                        <TableHead>Obs.</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {renovacoes.map((r) => (
                        <TableRow key={r.id}>
                          <TableCell>{format(new Date(r.created_at), "dd/MM/yyyy HH:mm")}</TableCell>
                          <TableCell>
                            <Badge variant={r.tipo === "automatico" ? "default" : "secondary"}>
                              {r.tipo === "automatico" ? "Automático" : "Manual"}
                            </Badge>
                          </TableCell>
                          <TableCell>{r.pacote_nome || "—"}</TableCell>
                          <TableCell>{r.dias_adicionados}</TableCell>
                          <TableCell className="text-xs">
                            {format(new Date(r.data_inicio), "dd/MM/yy")} → {format(new Date(r.data_fim), "dd/MM/yy")}
                          </TableCell>
                          <TableCell>
                            {r.valor ? Number(r.valor).toLocaleString("pt-MZ", { style: "currency", currency: "MZN" }) : "—"}
                          </TableCell>
                          <TableCell className="max-w-[150px] truncate">{r.observacoes || "—"}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="diagnostico">
            {userId && <UserDiagnosticPanel userId={userId} userName={user?.full_name} />}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}

function InfoField({ label, value }: { label: string; value: string | null | undefined }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground mb-0.5">{label}</p>
      <p className="text-sm font-medium text-foreground">{value || "—"}</p>
    </div>
  );
}
