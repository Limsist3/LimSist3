import { useState, useEffect, useMemo, useCallback } from "react";
import { compressIfImage } from "@/lib/imageCompression";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Search, Edit, Trash2, Ban, UserPlus, MessageCircle, Mail, Download, Upload, FolderOpen, Eye, FileText, Loader2 } from "lucide-react";
import { createFormattedExcel } from "@/lib/excelExport";
import { PROVINCIAS_MOCAMBIQUE } from "@/utils/provincias";
import { clienteSchema } from "@/lib/validation";
import { handleError } from "@/lib/errorHandling";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useUserRole } from "@/hooks/useUserRole";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";
import { format } from "date-fns";

interface Cliente {
  id: string;
  nome_completo: string;
  telefone: string;
  email?: string;
  nuit?: string;
  bi?: string;
  data_nascimento?: string;
  genero?: string;
  provincia?: string;
  distrito?: string;
  bairro?: string;
  rua?: string;
  bloqueado: boolean;
}

export default function Clientes() {
  const { isAgente } = useUserRole();
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [agentes, setAgentes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCliente, setEditingCliente] = useState<Cliente | null>(null);

  // Form states
  const [nomeCompleto, setNomeCompleto] = useState("");
  const [telefone, setTelefone] = useState("");
  const [email, setEmail] = useState("");
  const [nuit, setNuit] = useState("");
  const [bi, setBi] = useState("");
  const [dataNascimento, setDataNascimento] = useState("");
  const [genero, setGenero] = useState("");
  const [provincia, setProvincia] = useState("");
  const [distrito, setDistrito] = useState("");
  const [bairro, setBairro] = useState("");
  const [rua, setRua] = useState("");
  const [agenteId, setAgenteId] = useState("");
  
  // Document upload states
  const [docFiles, setDocFiles] = useState<File[]>([]);
  const [docTipo, setDocTipo] = useState("");
  const [uploadingDoc, setUploadingDoc] = useState(false);
  
  // Document viewer states
  const [viewingClienteId, setViewingClienteId] = useState<string | null>(null);
  const [viewingClienteNome, setViewingClienteNome] = useState("");
  const [clienteDocumentos, setClienteDocumentos] = useState<any[]>([]);
  const [loadingDocs, setLoadingDocs] = useState(false);
  const [docDialogOpen, setDocDialogOpen] = useState(false);
  
  // Inline upload in Processo dialog
  const [processoDocFiles, setProcessoDocFiles] = useState<File[]>([]);
  const [processoDocTipo, setProcessoDocTipo] = useState("");
  const [uploadingProcessoDoc, setUploadingProcessoDoc] = useState(false);

  const ITEMS_PER_PAGE = 50;
  const [currentPage, setCurrentPage] = useState(1);
  const [totalClientes, setTotalClientes] = useState(0);
  const [debouncedSearch, setDebouncedSearch] = useState("");

  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedSearch(searchTerm);
      setCurrentPage(1);
    }, 300);
    return () => clearTimeout(t);
  }, [searchTerm]);

  useEffect(() => {
    loadClientes();
    if (!isAgente) {
      loadAgentes();
    }
  }, [isAgente, currentPage, debouncedSearch]);

  const loadClientes = async () => {
    try {
      const { data, error } = await (supabase as any).rpc("search_clientes_paginated", {
        p_search: debouncedSearch || "",
        p_page: currentPage,
        p_page_size: ITEMS_PER_PAGE,
      });
      if (error) throw error;
      setClientes(data?.rows || []);
      setTotalClientes(data?.total || 0);
    } catch (error: any) {
      const errorMsg = handleError("Load Clientes", error);
      toast.error(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  const loadAgentes = async () => {
    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      
      const { data, error } = await supabase
        .from("user_profiles")
        .select("user_id, full_name, email")
        .eq("usuario_mae_id", user?.id)
        .eq("role", "agente")
        .eq("estado", "Ativo");

      if (error) throw error;
      setAgentes(data || []);
    } catch (error: any) {
      console.error("Erro ao carregar agentes:", error);
    }
  };

  useRealtimeRefresh(["clientes", "arquivos", "user_profiles"], () => {
    loadClientes();
    if (!isAgente) loadAgentes();
  }, true, 900);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
    if (!user) {
      toast.error("Usuário não autenticado");
      return;
    }

    // Buscar perfil do usuário para obter usuario_mae_id
    const { data: userProfile } = await supabase
      .from("user_profiles")
      .select("usuario_mae_id")
      .eq("user_id", user.id)
      .single();

    // Validate input data
    const validationData = {
      nome_completo: nomeCompleto,
      telefone,
      email: email || "",
      nuit: nuit || "",
      bi: bi || "",
      data_nascimento: dataNascimento,
      genero,
      provincia,
      distrito,
      bairro,
      rua,
    };

    const validation = clienteSchema.safeParse(validationData);
    if (!validation.success) {
      toast.error(validation.error.errors[0].message);
      return;
    }

    // Verificar duplicidade do BI dentro deste user_id (microcrédito)
    const biTrim = bi.trim();
    {
      const dupQuery = supabase
        .from("clientes")
        .select("id, nome_completo")
        .eq("user_id", user.id)
        .ilike("bi", biTrim)
        .limit(1);
      const { data: dup } = editingCliente
        ? await dupQuery.neq("id", editingCliente.id)
        : await dupQuery;
      if (dup && dup.length > 0) {
        toast.error(`BI já registado para o cliente: ${dup[0].nome_completo}`);
        return;
      }
    }

    const clienteData = {
      nome_completo: nomeCompleto.trim(),
      telefone: telefone.trim(),
      email: email.trim() || null,
      nuit: nuit.trim() || null,
      bi: biTrim,
      data_nascimento: dataNascimento || null,
      genero: genero || null,
      provincia: provincia || null,
      distrito: distrito.trim() || null,
      bairro: bairro.trim() || null,
      rua: rua.trim() || null,
      user_id: user.id,
      agente_id: isAgente ? user.id : (agenteId || null),
      usuario_mae_id: isAgente ? userProfile?.usuario_mae_id : user.id,
    };

    try {
      if (editingCliente) {
        const { error } = await supabase
          .from("clientes")
          .update(clienteData)
          .eq("id", editingCliente.id);

        if (error) throw error;
        
        // Registrar atividade se for agente
        if (isAgente) {
          await supabase.rpc('registrar_atividade_agente', {
            p_agente_id: user.id,
            p_descricao: `Atualizou cliente: ${nomeCompleto}`
          });
        }
        
        // Upload documents if any for edited client
        if (docFiles.length > 0 && docTipo) {
          await uploadDocuments(editingCliente.id, user.id);
        }
        toast.success("Cliente atualizado com sucesso!");
      } else {
        const { error } = await supabase.from("clientes").insert([clienteData]);

        if (error) throw error;
        
        // Registrar atividade se for agente
        if (isAgente) {
          await supabase.rpc('registrar_atividade_agente', {
            p_agente_id: user.id,
            p_descricao: `Cadastrou novo cliente: ${nomeCompleto}`
          });
        }
        
        // Upload documents if any
        if (docFiles.length > 0 && docTipo) {
          // Get the new client ID
          const { data: newClient } = await supabase
            .from("clientes")
            .select("id")
            .eq("user_id", user.id)
            .eq("nome_completo", nomeCompleto.trim())
            .order("created_at", { ascending: false })
            .limit(1)
            .single();
          if (newClient) {
            await uploadDocuments(newClient.id, user.id);
          }
        }
        
        toast.success("Cliente cadastrado com sucesso!");
      }

      resetForm();
      loadClientes();
      setDialogOpen(false);
    } catch (error: any) {
      const errorMsg = handleError("Save Cliente", error);
      toast.error(errorMsg);
    }
  };

  const handleEdit = (cliente: Cliente) => {
    setEditingCliente(cliente);
    setNomeCompleto(cliente.nome_completo);
    setTelefone(cliente.telefone);
    setEmail(cliente.email || "");
    setNuit(cliente.nuit || "");
    setBi(cliente.bi || "");
    setDataNascimento(cliente.data_nascimento || "");
    setGenero(cliente.genero || "");
    setProvincia(cliente.provincia || "");
    setDistrito(cliente.distrito || "");
    setBairro(cliente.bairro || "");
    setRua(cliente.rua || "");
    setAgenteId((cliente as any).agente_id || "");
    setDialogOpen(true);
  };

  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [clienteToDelete, setClienteToDelete] = useState<string | null>(null);

  const handleDelete = async () => {
    const id = clienteToDelete;
    if (!id) return;

    try {
      // Buscar empréstimos do cliente para apagar pagamentos e arquivos primeiro
      const { data: emprestimos } = await supabase
        .from("emprestimos")
        .select("id")
        .eq("cliente_id", id);

      if (emprestimos && emprestimos.length > 0) {
        const empIds = emprestimos.map(e => e.id);

        // NÃO apagar pagamentos: recibos ficam preservados como prova de pagamento.
        // Trigger na BD marca 'arquivado=true' e guarda snapshot (nome, telefone, valores).

        // Apagar arquivos associados (documentos, não recibos)
        await supabase.from("arquivos").delete().eq("cliente_id", id);
        for (const empId of empIds) {
          await supabase.from("arquivos").delete().eq("emprestimo_id", empId);
        }

        // Apagar empréstimos do cliente (pagamentos ficam com emprestimo_id NULL + snapshot)
        await supabase.from("emprestimos").delete().eq("cliente_id", id);
      }

      // Agora apagar o cliente
      const { error } = await supabase.from("clientes").delete().eq("id", id);

      if (error) throw error;
      toast.success("Cliente excluído com sucesso!");
      loadClientes();
    } catch (error: any) {
      const errorMsg = handleError("Delete Cliente", error);
      toast.error(errorMsg);
    }
    setDeleteConfirmOpen(false);
    setClienteToDelete(null);
  };

  const toggleBloquear = async (cliente: Cliente) => {
    try {
      const { error } = await supabase
        .from("clientes")
        .update({ bloqueado: !cliente.bloqueado })
        .eq("id", cliente.id);

      if (error) throw error;
      toast.success(
        cliente.bloqueado ? "Cliente desbloqueado!" : "Cliente bloqueado!"
      );
      loadClientes();
    } catch (error: any) {
      const errorMsg = handleError("Toggle Block Cliente", error);
      toast.error(errorMsg);
    }
  };

  const handleEnviarWhatsApp = async (cliente: Cliente) => {
    // Buscar empréstimos ativos e em atraso do cliente
    const { data: emprestimos } = await supabase
      .from("emprestimos")
      .select("*")
      .eq("cliente_id", cliente.id)
      .in("status", ["Ativo", "Atrasado", "Vencido"]);

    if (!emprestimos || emprestimos.length === 0) {
      toast.error("Cliente não possui empréstimos ativos");
      return;
    }

    const hoje = new Date();
    const emAtraso = emprestimos.filter(emp => emp.status === "Atrasado" || emp.status === "Vencido");
    const activos = emprestimos.filter(emp => emp.status === "Ativo");

    let mensagem = "";
    const telefone = cliente.telefone.replace(/\D/g, '');

    if (emAtraso.length > 0) {
      // Cliente com empréstimos VENCIDOS - mensagem de cobrança com dias de atraso e mora
      let detalhesAtraso = "";
      let totalGeralDevido = 0;

      emAtraso.forEach(emp => {
        const saldoDevedor = (emp.valor_total || 0) - (emp.valor_pago || 0);
        const dataReembolso = new Date(emp.data_reembolso || emp.data_desembolso);
        const diffTime = hoje.getTime() - dataReembolso.getTime();
        const diasAtraso = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
        const taxaMora = emp.taxa_mora || 0;
        // Mora diária = (taxa diária %) × saldo × dias
        const jurosMora = (taxaMora / 100) * saldoDevedor * diasAtraso;
        const totalComMora = saldoDevedor + jurosMora;
        totalGeralDevido += totalComMora;

        detalhesAtraso += `\n📌 *Empréstimo:* ${emp.valor?.toLocaleString('pt-MZ')} MT`;
        detalhesAtraso += `\n⏰ *Dias em atraso:* ${diasAtraso} dia(s)`;
        detalhesAtraso += `\n💰 *Saldo devedor:* ${saldoDevedor.toLocaleString('pt-MZ')} MT`;
        if (jurosMora > 0) {
          detalhesAtraso += `\n📈 *Juros de mora:* ${jurosMora.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT`;
        }
        detalhesAtraso += `\n💵 *Total a pagar:* ${totalComMora.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT\n`;
      });

      mensagem = `Olá ${cliente.nome_completo}!\n\n⚠️ *AVISO DE PAGAMENTO EM ATRASO*\n\nInformamos que o(s) seu(s) empréstimo(s) encontra(m)-se em atraso:\n${detalhesAtraso}\n💰 *TOTAL GERAL A PAGAR:* ${totalGeralDevido.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT\n\nPor favor, regularize a sua situação o mais breve possível para evitar o aumento dos juros de mora.\n\nObrigado!`;
    } else if (activos.length > 0) {
      // Cliente com empréstimos ACTIVOS - mensagem amigável apenas com dias restantes
      const proximoEmprestimo = activos.reduce((closest, emp) => {
        if (!emp.data_reembolso) return closest;
        const dataReembolso = new Date(emp.data_reembolso);
        if (!closest || dataReembolso < new Date(closest.data_reembolso!)) return emp;
        return closest;
      }, null as any);

      if (proximoEmprestimo?.data_reembolso) {
        const dataReembolso = new Date(proximoEmprestimo.data_reembolso);
        const diffTime = dataReembolso.getTime() - hoje.getTime();
        const diasRestantes = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        const dataFormatada = dataReembolso.toLocaleDateString('pt-MZ');

        mensagem = `Olá ${cliente.nome_completo}! 😊\n\nEsperamos que esteja bem!\n\nApenas para lembrar que faltam *${diasRestantes} dia(s)* para o pagamento do seu empréstimo.\n\n📅 *Data de pagamento:* ${dataFormatada}\n\nDesejamos um excelente dia!\n\nObrigado! 🙏`;
      } else {
        mensagem = `Olá ${cliente.nome_completo}! 😊\n\nEsperamos que esteja bem!\n\nApenas para lembrar sobre o pagamento da sua parcela mensal.\n\nDesejamos um excelente dia!\n\nObrigado! 🙏`;
      }
    }

    const url = `https://wa.me/${telefone}?text=${encodeURIComponent(mensagem)}`;
    window.open(url, '_blank');
    toast.success(emAtraso.length > 0 ? "WhatsApp aberto com mensagem de cobrança" : "WhatsApp aberto com lembrete de pagamento");
  };

  const handleEnviarEmail = async (cliente: Cliente) => {
    if (!cliente.email) {
      toast.error("Cliente não possui e-mail cadastrado");
      return;
    }

    // Buscar empréstimos ativos do cliente
    const { data: emprestimos } = await supabase
      .from("emprestimos")
      .select("*")
      .eq("cliente_id", cliente.id)
      .eq("status", "Ativo");

    if (!emprestimos || emprestimos.length === 0) {
      toast.error("Cliente não possui empréstimos ativos");
      return;
    }

    // Calcular total em atraso (usando valor_total - valor_pago)
    const totalDevido = emprestimos.reduce((acc, emp) => {
      const valorTotal = emp.valor_total || 0;
      const pago = emp.valor_pago || 0;
      return acc + (valorTotal - pago);
    }, 0);

    try {
      const { error } = await supabase.functions.invoke('enviar-cobranca-email', {
        body: {
          nome: cliente.nome_completo,
          email: cliente.email,
          valorDevido: totalDevido
        }
      });

      if (error) throw error;
      toast.success("E-mail de cobrança enviado com sucesso!");
    } catch (error: any) {
      const errorMsg = handleError("Enviar Email", error);
      toast.error(errorMsg);
    }
  };

  const resetForm = () => {
    setEditingCliente(null);
    setNomeCompleto("");
    setTelefone("");
    setEmail("");
    setNuit("");
    setBi("");
    setDataNascimento("");
    setGenero("");
    setProvincia("");
    setDistrito("");
    setBairro("");
    setRua("");
    setAgenteId("");
    setDocFiles([]);
    setDocTipo("");
  };

  // Upload documents for a client
  const uploadDocuments = async (clienteId: string, userId: string) => {
    if (docFiles.length === 0 || !docTipo) return;
    setUploadingDoc(true);
    try {
      for (const rawFile of docFiles) {
        const file = await compressIfImage(rawFile);
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
        
        const { error: uploadError } = await supabase.storage
          .from('documentos')
          .upload(fileName, file, { cacheControl: '3600', upsert: false });
        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('documentos')
          .getPublicUrl(fileName);

        await supabase.from("arquivos").insert({
          user_id: userId,
          cliente_id: clienteId,
          tipo: docTipo,
          nome_arquivo: rawFile.name,
          url_arquivo: publicUrl,
          tamanho: file.size,
        });
      }
      toast.success("Documentos enviados!");
    } catch (error: any) {
      console.error("Upload error:", error);
      toast.error("Erro ao enviar documentos: " + error.message);
    } finally {
      setUploadingDoc(false);
    }
  };

  // Load documents for a client
  const loadClienteDocumentos = async (clienteId: string, clienteNome: string) => {
    setViewingClienteId(clienteId);
    setViewingClienteNome(clienteNome);
    setLoadingDocs(true);
    setDocDialogOpen(true);
    try {
      const { data, error } = await supabase
        .from("arquivos")
        .select("*")
        .eq("cliente_id", clienteId)
        .order("created_at", { ascending: false });
      console.log("loadClienteDocumentos result:", { data, error, clienteId });
      if (error) throw error;
      setClienteDocumentos(data || []);
    } catch (error: any) {
      toast.error("Erro ao carregar documentos");
    } finally {
      setLoadingDocs(false);
    }
  };

  // Delete a document
  const deleteDocumento = async (docId: string, urlArquivo: string) => {
    try {
      const fileName = urlArquivo.split('/').pop();
      if (fileName) {
        await supabase.storage.from('documentos').remove([fileName]);
      }
      await supabase.from("arquivos").delete().eq("id", docId);
      toast.success("Documento excluído!");
      if (viewingClienteId) loadClienteDocumentos(viewingClienteId, viewingClienteNome);
    } catch (error: any) {
      toast.error("Erro ao excluir documento");
    }
  };

  // Upload document from Processo dialog
  const uploadProcessoDocument = async () => {
    if (!viewingClienteId || processoDocFiles.length === 0 || !processoDocTipo) {
      toast.error("Selecione o tipo e os ficheiros");
      return;
    }
    const { data: { session: __s } } = await supabase.auth.getSession();
    const user = __s?.user;
    if (!user) { toast.error("Não autenticado"); return; }

    setUploadingProcessoDoc(true);
    try {
      for (const rawFile of processoDocFiles) {
        const file = await compressIfImage(rawFile);
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('documentos')
          .upload(fileName, file, { cacheControl: '3600', upsert: false });
        if (uploadError) throw uploadError;
        const { data: { publicUrl } } = supabase.storage.from('documentos').getPublicUrl(fileName);
        const { error: dbError } = await supabase.from("arquivos").insert({
          user_id: user.id,
          cliente_id: viewingClienteId,
          tipo: processoDocTipo,
          nome_arquivo: rawFile.name,
          url_arquivo: publicUrl,
          tamanho: file.size,
        });
        if (dbError) {
          console.error("DB insert error:", dbError);
          throw new Error("Erro ao salvar documento: " + dbError.message);
        }
      }
      toast.success("Documento(s) anexado(s)!");
      setProcessoDocFiles([]);
      setProcessoDocTipo("");
      loadClienteDocumentos(viewingClienteId, viewingClienteNome);
    } catch (error: any) {
      toast.error("Erro ao anexar: " + error.message);
    } finally {
      setUploadingProcessoDoc(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  // Server-side: clientes já vêm filtrados e paginados
  const filteredClientes = clientes;
  const totalPages = Math.max(1, Math.ceil(totalClientes / ITEMS_PER_PAGE));
  const paginatedClientes = clientes;

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <UserPlus className="h-8 w-8 text-primary" />
            Gestão de Clientes
          </h1>
          <Dialog open={dialogOpen} onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Novo Cliente
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingCliente ? "Editar Cliente" : "Novo Cliente"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  {!isAgente && (
                    <div className="col-span-2">
                      <Label>Atribuir a Agente (Opcional)</Label>
                      <Select value={agenteId} onValueChange={setAgenteId}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione um agente (deixe em branco para usuário mãe)" />
                        </SelectTrigger>
                        <SelectContent>
                          {agentes.map((agente) => (
                            <SelectItem key={agente.user_id} value={agente.user_id}>
                              {agente.full_name} ({agente.email})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div className="col-span-2">
                    <Label htmlFor="nome">Nome Completo *</Label>
                    <Input
                      id="nome"
                      value={nomeCompleto}
                      onChange={(e) => setNomeCompleto(e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="telefone">Telefone *</Label>
                    <Input
                      id="telefone"
                      value={telefone}
                      onChange={(e) => setTelefone(e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="email">E-mail</Label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="nuit">NUIT</Label>
                    <Input
                      id="nuit"
                      value={nuit}
                      onChange={(e) => setNuit(e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="bi">Nº do BI *</Label>
                    <Input
                      id="bi"
                      value={bi}
                      onChange={(e) => setBi(e.target.value)}
                      placeholder="Ex: 1101..."
                      required
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Cada BI só pode ser registado uma vez.
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="data">Data de Nascimento *</Label>
                    <Input
                      id="data"
                      type="date"
                      required
                      max={new Date(Date.now() - 18 * 365.25 * 24 * 3600 * 1000).toISOString().slice(0, 10)}
                      value={dataNascimento}
                      onChange={(e) => setDataNascimento(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground mt-1">Apenas clientes com mais de 17 anos.</p>
                  </div>

                  <div>
                    <Label>Gênero</Label>
                    <Select value={genero} onValueChange={setGenero}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Masculino">Masculino</SelectItem>
                        <SelectItem value="Feminino">Feminino</SelectItem>
                        <SelectItem value="Outro">Outro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Província</Label>
                    <Select value={provincia} onValueChange={setProvincia}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a província" />
                      </SelectTrigger>
                      <SelectContent>
                        {PROVINCIAS_MOCAMBIQUE.map((prov) => (
                          <SelectItem key={prov} value={prov}>
                            {prov}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="distrito">Distrito/Cidade</Label>
                    <Input
                      id="distrito"
                      value={distrito}
                      onChange={(e) => setDistrito(e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="bairro">Bairro</Label>
                    <Input
                      id="bairro"
                      value={bairro}
                      onChange={(e) => setBairro(e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="rua">Rua</Label>
                    <Input
                      id="rua"
                      value={rua}
                      onChange={(e) => setRua(e.target.value)}
                    />
                  </div>
                </div>

                {/* Document Upload Section (Optional) */}
                <div className="border-t pt-4 space-y-3">
                  <Label className="text-sm font-semibold flex items-center gap-2">
                    <Upload className="h-4 w-4" /> Documentos (Opcional)
                  </Label>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-xs">Tipo de Documento</Label>
                      <Select value={docTipo} onValueChange={setDocTipo}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o tipo" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="BI">BI</SelectItem>
                          <SelectItem value="Comprovante">Comprovante</SelectItem>
                          <SelectItem value="Renda">Comprovativo de Renda</SelectItem>
                          <SelectItem value="Garantia">Garantia</SelectItem>
                          <SelectItem value="Contrato">Contrato</SelectItem>
                          <SelectItem value="Outro">Outro</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-xs">Ficheiros (PDF/Imagem)</Label>
                      <Input
                        type="file"
                        accept=".jpg,.jpeg,.png,.pdf"
                        multiple
                        onChange={(e) => {
                          const files = Array.from(e.target.files || []);
                          const validFiles = files.filter(f => f.size <= 10 * 1024 * 1024);
                          if (validFiles.length < files.length) toast.error("Ficheiros acima de 10MB foram ignorados");
                          setDocFiles(validFiles);
                        }}
                      />
                    </div>
                  </div>
                  {docFiles.length > 0 && (
                    <p className="text-xs text-muted-foreground">
                      {docFiles.length} ficheiro(s) selecionado(s): {docFiles.map(f => f.name).join(", ")}
                    </p>
                  )}
                </div>

                <Button type="submit" className="w-full" disabled={uploadingDoc}>
                  {uploadingDoc ? (
                    <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Enviando...</>
                  ) : (
                    editingCliente ? "Atualizar" : "Cadastrar"
                  )}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Pesquisar por nome, telefone ou e-mail..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button variant="outline" onClick={() => {
                const headers = ["Nome", "Telefone", "E-mail", "Província", "Status"];
                const data = filteredClientes.map(c => [
                  c.nome_completo,
                  c.telefone,
                  c.email || "-",
                  c.provincia || "-",
                  c.bloqueado ? "Bloqueado" : "Ativo",
                ]);
                createFormattedExcel([{ headers, data }], `Clientes_${new Date().toISOString().split('T')[0]}.xlsx`, "Clientes");
                toast.success("Ficheiro exportado com sucesso!");
              }}>
                <Download className="h-4 w-4 mr-2" /> Exportar
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">Carregando...</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Telefone</TableHead>
                    <TableHead>E-mail</TableHead>
                    <TableHead>Província</TableHead>
                    <TableHead>Cadastrado por</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginatedClientes.map((cliente) => (
                    <TableRow key={cliente.id}>
                      <TableCell className="font-medium">
                        {cliente.nome_completo}
                      </TableCell>
                      <TableCell>{cliente.telefone}</TableCell>
                      <TableCell>{cliente.email || "-"}</TableCell>
                      <TableCell>{cliente.provincia || "-"}</TableCell>
                      <TableCell className="text-sm">
                        <div className="font-medium">{(cliente as any).criado_por_nome || "—"}</div>
                        {(cliente as any).criado_por_role && (
                          <div className="text-xs text-muted-foreground capitalize">{(cliente as any).criado_por_role}</div>
                        )}
                      </TableCell>
                      <TableCell>
                        <span
                          className={`px-2 py-1 rounded-full text-xs ${
                            cliente.bloqueado
                              ? "bg-destructive-light text-destructive"
                              : "bg-success-light text-success"
                          }`}
                        >
                          {cliente.bloqueado ? "Bloqueado" : "Ativo"}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(cliente)}
                            title="Editar"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => loadClienteDocumentos(cliente.id, cliente.nome_completo)}
                            title="Ver Processo / Documentos"
                            className="text-primary hover:text-primary/80"
                          >
                            <FolderOpen className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEnviarWhatsApp(cliente)}
                            title="Enviar cobrança via WhatsApp"
                            className="text-green-600 hover:text-green-700"
                          >
                            <MessageCircle className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEnviarEmail(cliente)}
                            title="Enviar cobrança via E-mail"
                            className="text-blue-600 hover:text-blue-700"
                          >
                            <Mail className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleBloquear(cliente)}
                            title={cliente.bloqueado ? "Desbloquear" : "Bloquear"}
                          >
                            <Ban className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => { setClienteToDelete(cliente.id); setDeleteConfirmOpen(true); }}
                            title="Excluir"
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
            {!loading && filteredClientes.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                Nenhum cliente encontrado
              </div>
            )}
            {!loading && totalPages > 1 && (
              <div className="flex items-center justify-between mt-4 pt-4 border-t">
                <span className="text-sm text-muted-foreground">
                  {totalClientes.toLocaleString('pt-MZ')} cliente(s) — Página {currentPage} de {totalPages}
                </span>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" disabled={currentPage <= 1} onClick={() => setCurrentPage(p => p - 1)}>Anterior</Button>
                  <Button variant="outline" size="sm" disabled={currentPage >= totalPages} onClick={() => setCurrentPage(p => p + 1)}>Próxima</Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <ConfirmDialog
        open={deleteConfirmOpen}
        onOpenChange={setDeleteConfirmOpen}
        description="Tem certeza que deseja excluir este cliente? Todos os empréstimos e pagamentos associados serão removidos."
        confirmLabel="Excluir"
        onConfirm={handleDelete}
        variant="destructive"
      />

      {/* Document Viewer Dialog */}
      <Dialog open={docDialogOpen} onOpenChange={(open) => {
        setDocDialogOpen(open);
        if (!open) { setProcessoDocFiles([]); setProcessoDocTipo(""); }
      }}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FolderOpen className="h-5 w-5 text-primary" />
              Processo de {viewingClienteNome}
            </DialogTitle>
          </DialogHeader>

          {/* Inline upload section */}
          <div className="border rounded-lg p-3 space-y-3 bg-muted/30">
            <Label className="text-sm font-semibold flex items-center gap-2">
              <Upload className="h-4 w-4" /> Anexar Novo Documento
            </Label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Tipo</Label>
                <Select value={processoDocTipo} onValueChange={setProcessoDocTipo}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="BI">BI</SelectItem>
                    <SelectItem value="Comprovante">Comprovante</SelectItem>
                    <SelectItem value="Renda">Comprovativo de Renda</SelectItem>
                    <SelectItem value="Garantia">Garantia</SelectItem>
                    <SelectItem value="Contrato">Contrato</SelectItem>
                    <SelectItem value="Outro">Outro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Ficheiros</Label>
                <Input
                  type="file"
                  accept=".jpg,.jpeg,.png,.pdf"
                  multiple
                  onChange={(e) => {
                    const files = Array.from(e.target.files || []);
                    const valid = files.filter(f => f.size <= 10 * 1024 * 1024);
                    if (valid.length < files.length) toast.error("Ficheiros acima de 10MB ignorados");
                    setProcessoDocFiles(valid);
                  }}
                />
              </div>
            </div>
            {processoDocFiles.length > 0 && (
              <p className="text-xs text-muted-foreground">
                {processoDocFiles.length} ficheiro(s): {processoDocFiles.map(f => f.name).join(", ")}
              </p>
            )}
            <Button
              size="sm"
              className="w-full"
              disabled={uploadingProcessoDoc || processoDocFiles.length === 0 || !processoDocTipo}
              onClick={uploadProcessoDocument}
            >
              {uploadingProcessoDoc ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Enviando...</>
              ) : (
                <><Upload className="mr-2 h-4 w-4" /> Anexar</>
              )}
            </Button>
          </div>
          
          {loadingDocs ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : clienteDocumentos.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Arquivo</TableHead>
                  <TableHead>Tamanho</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {clienteDocumentos.map((doc) => (
                  <TableRow key={doc.id}>
                    <TableCell>{doc.tipo}</TableCell>
                    <TableCell className="flex items-center gap-2 max-w-[200px] truncate">
                      <FileText className="h-4 w-4 shrink-0" />
                      <span className="truncate">{doc.nome_arquivo}</span>
                    </TableCell>
                    <TableCell>{formatFileSize(doc.tamanho || 0)}</TableCell>
                    <TableCell>{format(new Date(doc.created_at), "dd/MM/yyyy")}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex gap-1 justify-end">
                        <Button size="sm" variant="outline" onClick={() => window.open(doc.url_arquivo, '_blank')}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => deleteDocumento(doc.id, doc.url_arquivo)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-muted-foreground text-center py-8">
              Nenhum documento encontrado para este cliente
            </p>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
