import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useUserRole } from "@/hooks/useUserRole";
import { CreditCard, Package, Pencil, RefreshCw, History, CheckCircle2, XCircle, Copy, Smartphone, Inbox, Save, AlertCircle, BarChart3, TrendingUp, Calendar } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { ConfirmDialog } from "@/components/ConfirmDialog";

interface Pacote {
  id: string;
  nome: string;
  preco: number;
  duracao_dias: number;
  ativo: boolean;
}

interface Renovacao {
  id: string;
  user_id: string;
  pacote_nome: string | null;
  valor: number | null;
  dias_adicionados: number;
  data_inicio: string;
  data_fim: string;
  created_at: string;
  tipo: string;
  observacoes: string | null;
}

interface WebhookLog {
  id: string;
  email: string | null;
  pacote_nome: string | null;
  valor: number | null;
  codigo_transacao: string | null;
  processado: boolean | null;
  erro: string | null;
  created_at: string | null;
  user_id: string | null;
}

export default function ConfiguracaoPagamentos() {
  const navigate = useNavigate();
  const { isSuperAdmin, loading: roleLoading } = useUserRole();

  const [pacotes, setPacotes] = useState<Pacote[]>([]);
  const [renovacoes, setRenovacoes] = useState<Renovacao[]>([]);
  const [pendentes, setPendentes] = useState<any[]>([]);
  const [incoming, setIncoming] = useState<any[]>([]);
  const [usersMap, setUsersMap] = useState<Record<string, { name: string; email: string }>>({});
  const [loadingData, setLoadingData] = useState(true);
  const [actioning, setActioning] = useState<string | null>(null);
  const [rejectDialog, setRejectDialog] = useState<{ open: boolean; id: string | null }>({ open: false, id: null });
  const [motivoRejeicao, setMotivoRejeicao] = useState("");

  // Métodos de pagamento (M-Pesa / E-Mola)
  const [configId, setConfigId] = useState<string | null>(null);
  const [numeroMpesa, setNumeroMpesa] = useState("");
  const [numeroEmola, setNumeroEmola] = useState("");
  const [nomeTitularMpesa, setNomeTitularMpesa] = useState("");
  const [nomeTitularEmola, setNomeTitularEmola] = useState("");
  const [instrucoes, setInstrucoes] = useState("");
  const [numeroNotificacoes, setNumeroNotificacoes] = useState("");
  const [savingConfig, setSavingConfig] = useState(false);

  // Dialog edição de pacote
  const [pacoteDialogOpen, setPacoteDialogOpen] = useState(false);
  const [editingPacote, setEditingPacote] = useState<Pacote | null>(null);
  const [pacotePreco, setPacotePreco] = useState("");
  const [pacoteDuracao, setPacoteDuracao] = useState("");

  // Transações
  const [transacoes, setTransacoes] = useState<any[]>([]);
  const [periodoTx, setPeriodoTx] = useState<"hoje" | "semana" | "mes" | "personalizado">("mes");
  const [txInicio, setTxInicio] = useState<string>("");
  const [txFim, setTxFim] = useState<string>("");





  useEffect(() => {
    if (!roleLoading && !isSuperAdmin) {
      toast.error("Acesso negado");
      navigate("/dashboard");
    }
  }, [isSuperAdmin, roleLoading, navigate]);

  useEffect(() => {
    if (isSuperAdmin) loadAll();
  }, [isSuperAdmin]);

  // Realtime: novas renovações, pagamentos recebidos e pedidos pendentes
  useEffect(() => {
    if (!isSuperAdmin) return;
    const channel = supabase
      .channel('config-pagamentos-v4')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'historico_renovacoes' }, () => loadRenovacoes())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'incoming_payments' }, () => loadIncoming())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'subscription_requests' }, () => loadPendentes())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [isSuperAdmin]);

  const loadAll = async () => {
    setLoadingData(true);
    await Promise.all([loadPacotes(), loadRenovacoes(), loadIncoming(), loadPendentes(), loadConfig(), loadTransacoes()]);
    setLoadingData(false);
  };

  const loadTransacoes = useCallback(async () => {
    // Fonte real: subscription_requests (todos os pedidos com status aprovado/rejeitado/pendente/temporario)
    const { data } = await supabase
      .from("subscription_requests")
      .select("id,user_id,valor_esperado,metodo_pagamento,status,codigo_submetido,plano,motivo_rejeicao,created_at,data_limite_confirmacao")
      .order("created_at", { ascending: false })
      .limit(500);
    const list = (data as any[]) || [];
    // Normalizar para shape usado na UI
    const normalized = list.map(r => ({
      id: r.id,
      user_id: r.user_id,
      valor: Number(r.valor_esperado || 0),
      forma_pagamento: r.metodo_pagamento,
      status: r.status,
      codigo_transacao: r.codigo_submetido,
      pacote_nome: r.plano,
      motivo_rejeicao: r.motivo_rejeicao,
      created_at: r.created_at,
    }));
    setTransacoes(normalized);
    const ids = Array.from(new Set(normalized.map(r => r.user_id).filter(Boolean)));
    if (ids.length) {
      const { data: profs } = await supabase
        .from("user_profiles").select("user_id, full_name, email").in("user_id", ids);
      const map: Record<string, { name: string; email: string }> = {};
      (profs as any[] || []).forEach(p => { map[p.user_id] = { name: p.full_name, email: p.email || "" }; });
      setUsersMap(prev => ({ ...prev, ...map }));
    }
  }, []);



  const loadPacotes = async () => {
    const { data, error } = await supabase
      .from("pacotes_plataforma").select("*").order("duracao_dias");
    if (error) { toast.error("Erro ao carregar pacotes"); return; }
    setPacotes((data as any) || []);
  };


  const loadConfig = async () => {
    const { data } = await supabase
      .from("configuracao_pagamento")
      .select("id,numero_mpesa,numero_emola,nome_titular,nome_titular_mpesa,nome_titular_emola,instrucoes,numero_notificacoes")
      .maybeSingle();
    if (data) {
      const d = data as any;
      setConfigId(d.id);
      setNumeroMpesa(d.numero_mpesa || "");
      setNumeroEmola(d.numero_emola || "");
      setNomeTitularMpesa(d.nome_titular_mpesa || d.nome_titular || "");
      setNomeTitularEmola(d.nome_titular_emola || d.nome_titular || "");
      setInstrucoes(d.instrucoes || "");
      setNumeroNotificacoes(d.numero_notificacoes || "");
    }
  };

  const handleSaveConfig = async () => {
    setSavingConfig(true);
    const payload = {
      numero_mpesa: numeroMpesa.trim() || null,
      numero_emola: numeroEmola.trim() || null,
      nome_titular_mpesa: nomeTitularMpesa.trim() || null,
      nome_titular_emola: nomeTitularEmola.trim() || null,
      instrucoes: instrucoes.trim() || null,
      numero_notificacoes: numeroNotificacoes.trim() || null,
    };
    const { error } = configId
      ? await supabase.from("configuracao_pagamento").update(payload).eq("id", configId)
      : await supabase.from("configuracao_pagamento").insert(payload);
    setSavingConfig(false);
    if (error) { toast.error("Erro: " + error.message); return; }
    toast.success("Métodos de pagamento guardados");
    loadConfig();
  };

  const loadRenovacoes = useCallback(async () => {
    const { data, error } = await supabase
      .from("historico_renovacoes").select("*")
      .order("created_at", { ascending: false }).limit(100);
    if (error) return;
    const list = (data as any[]) || [];
    setRenovacoes(list);
    const ids = Array.from(new Set(list.map(r => r.user_id).filter(Boolean)));
    if (ids.length) {
      const { data: profs } = await supabase
        .from("user_profiles").select("user_id, full_name, email").in("user_id", ids);
      const map: Record<string, { name: string; email: string }> = {};
      (profs as any[] || []).forEach(p => { map[p.user_id] = { name: p.full_name, email: p.email || "" }; });
      setUsersMap(prev => ({ ...prev, ...map }));
    }
  }, []);

  const loadIncoming = useCallback(async () => {
    const { data } = await supabase
      .from("incoming_payments").select("*")
      .order("created_at", { ascending: false }).limit(100);
    setIncoming((data as any) || []);
  }, []);

  const loadPendentes = useCallback(async () => {
    const { data } = await supabase
      .from("subscription_requests")
      .select("*")
      .in("status", ["temporario", "pendente"])
      .order("created_at", { ascending: false });
    const list = (data as any[]) || [];
    setPendentes(list);
    const ids = Array.from(new Set(list.map((r) => r.user_id).filter(Boolean)));
    if (ids.length) {
      const { data: profs } = await supabase
        .from("user_profiles").select("user_id, full_name, email").in("user_id", ids);
      const map: Record<string, { name: string; email: string }> = {};
      (profs as any[] || []).forEach((p) => { map[p.user_id] = { name: p.full_name, email: p.email || "" }; });
      setUsersMap((prev) => ({ ...prev, ...map }));
    }
  }, []);

  const handleConfirmar = async (id: string) => {
    if (!confirm("Confirmar este pagamento e activar o pacote completo?")) return;
    setActioning(id);
    const { data, error } = await supabase.rpc("confirmar_pagamento_superadmin", { p_request_id: id });
    setActioning(null);
    if (error) { toast.error(error.message); return; }
    if ((data as any)?.success) {
      toast.success("Pagamento confirmado e pacote activado.");
      loadPendentes(); loadRenovacoes(); loadIncoming();
    } else {
      toast.error((data as any)?.error || "Erro ao confirmar.");
    }
  };

  const openRejeitar = (id: string) => { setMotivoRejeicao(""); setRejectDialog({ open: true, id }); };

  const handleRejeitar = async () => {
    if (!rejectDialog.id) return;
    setActioning(rejectDialog.id);
    const { data, error } = await supabase.rpc("rejeitar_pagamento_superadmin", {
      p_request_id: rejectDialog.id,
      p_motivo: motivoRejeicao || null,
    });
    setActioning(null);
    setRejectDialog({ open: false, id: null });
    if (error) { toast.error(error.message); return; }
    if ((data as any)?.success) {
      toast.success("Pagamento rejeitado.");
      loadPendentes(); loadIncoming();
    } else {
      toast.error((data as any)?.error || "Erro ao rejeitar.");
    }
  };

  // Editar pacote (preço, dias)
  const openEditPacote = (p: Pacote) => {
    setEditingPacote(p);
    setPacotePreco(String(p.preco));
    setPacoteDuracao(String(p.duracao_dias));
    setPacoteDialogOpen(true);
  };

  const handleSavePacote = async () => {
    if (!editingPacote) return;
    const preco = parseFloat(pacotePreco);
    const dias = parseInt(pacoteDuracao);
    if (isNaN(preco) || preco <= 0) { toast.error("Preço inválido"); return; }
    if (isNaN(dias) || dias <= 0) { toast.error("Duração inválida"); return; }

    const { error } = await supabase
      .from("pacotes_plataforma")
      .update({ preco, duracao_dias: dias })
      .eq("id", editingPacote.id);
    if (error) { toast.error("Erro ao salvar"); return; }
    toast.success("Pacote actualizado");
    setPacoteDialogOpen(false);
    setEditingPacote(null);
    loadPacotes();
  };

  const handleTogglePacote = async (id: string, ativo: boolean) => {
    const { error } = await supabase
      .from("pacotes_plataforma")
      .update({ ativo: !ativo })
      .eq("id", id);
    if (error) { toast.error("Erro"); return; }
    loadPacotes();
  };

  const formatCurrency = (v: number | null) =>
    new Intl.NumberFormat("pt-MZ", { style: "currency", currency: "MZN" }).format(v || 0);

  const copy = (txt: string) => {
    navigator.clipboard.writeText(txt);
    toast.success("Copiado");
  };

  // Estatísticas rápidas
  const incomingDisponiveis = incoming.filter(i => i.status === 'disponivel').length;
  const incomingUsados = incoming.filter(i => i.status === 'usado').length;
  const totalPendentes = pendentes.length;
  const totalReceitaMes = renovacoes
    .filter(r => new Date(r.created_at).getMonth() === new Date().getMonth())
    .reduce((s, r) => s + Number(r.valor || 0), 0);

  if (roleLoading || !isSuperAdmin) return null;

  return (
    <DashboardLayout>
      <div className="p-4 md:p-6 space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-3">
            <CreditCard className="h-7 w-7 text-primary" />
            Configuração de Pagamentos
          </h1>
          <Button variant="outline" size="sm" onClick={loadAll} disabled={loadingData}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loadingData ? "animate-spin" : ""}`} /> Atualizar
          </Button>
        </div>

        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="p-4 text-sm space-y-1">
            <p className="font-semibold flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-primary" /> Pagamentos M-Pesa / E-Mola (validação automática)
            </p>
            <p className="text-muted-foreground">
              O utilizador envia o comprovativo (screenshot) e o sistema valida automaticamente. Se aprovado, o plano é activado imediatamente — sem acesso temporário.
              Suporte: <a className="text-primary underline" href="https://wa.me/258875611599" target="_blank" rel="noopener">WhatsApp 875611599</a>.
            </p>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card><CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Pacotes activos</p>
            <p className="text-2xl font-bold">{pacotes.filter(p => p.ativo).length}/{pacotes.length}</p>
          </CardContent></Card>
          <Card className={totalPendentes > 0 ? "border-destructive border-2 animate-pulse" : ""}><CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Por confirmar</p>
            <p className={`text-2xl font-bold ${totalPendentes > 0 ? "text-destructive" : ""}`}>{totalPendentes}</p>
          </CardContent></Card>
          <Card><CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Pagamentos confirmados</p>
            <p className="text-2xl font-bold">{incomingUsados}</p>
          </CardContent></Card>
          <Card><CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Receita do mês</p>
            <p className="text-2xl font-bold text-primary">{formatCurrency(totalReceitaMes)}</p>
          </CardContent></Card>
        </div>

        <Tabs defaultValue="metodos">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="transacoes" className="flex items-center gap-1.5">
              <BarChart3 className="h-4 w-4" /> Transações
            </TabsTrigger>
            <TabsTrigger value="metodos" className="flex items-center gap-1.5">
              <Smartphone className="h-4 w-4" /> Métodos
            </TabsTrigger>
            <TabsTrigger value="pacotes" className="flex items-center gap-1.5">
              <Package className="h-4 w-4" /> Pacotes
            </TabsTrigger>
            <TabsTrigger value="recebidos" className={`flex items-center gap-1.5 ${totalPendentes > 0 ? "text-destructive font-semibold" : ""}`}>
              <Inbox className="h-4 w-4" /> Recebidos
              {totalPendentes > 0 && <Badge variant="destructive" className="ml-1 text-xs animate-pulse">{totalPendentes}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="renovacoes" className="flex items-center gap-1.5">
              <History className="h-4 w-4" /> Renovações
            </TabsTrigger>
          </TabsList>

          {/* === MÉTODOS DE PAGAMENTO === */}
          <TabsContent value="metodos">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Smartphone className="h-5 w-5" /> Detalhes de M-Pesa e E-Mola
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Estes números e instruções aparecem ao utilizador na etapa 2 da compra.
                </p>
              </CardHeader>
              <CardContent className="space-y-4 max-w-2xl">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2 rounded-lg border p-3">
                    <Label className="text-primary font-semibold">M-Pesa</Label>
                    <div>
                      <Label className="text-xs">Número</Label>
                      <Input placeholder="84 ou 85..." value={numeroMpesa} onChange={(e) => setNumeroMpesa(e.target.value)} />
                    </div>
                    <div>
                      <Label className="text-xs">Nome do titular M-Pesa</Label>
                      <Input placeholder="Ex: João Silva" value={nomeTitularMpesa} onChange={(e) => setNomeTitularMpesa(e.target.value)} />
                    </div>
                  </div>
                  <div className="space-y-2 rounded-lg border p-3">
                    <Label className="text-primary font-semibold">E-Mola</Label>
                    <div>
                      <Label className="text-xs">Número</Label>
                      <Input placeholder="86 ou 87..." value={numeroEmola} onChange={(e) => setNumeroEmola(e.target.value)} />
                    </div>
                    <div>
                      <Label className="text-xs">Nome do titular E-Mola</Label>
                      <Input placeholder="Ex: Maria Costa" value={nomeTitularEmola} onChange={(e) => setNomeTitularEmola(e.target.value)} />
                    </div>
                  </div>
                </div>
                <div>
                  <Label>Número para receber pedidos por SMS (superadministrador)</Label>
                  <Input
                    placeholder="Ex: 84XXXXXXX"
                    value={numeroNotificacoes}
                    onChange={(e) => setNumeroNotificacoes(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Recebe automaticamente um SMS (via Hexmo) sempre que um utilizador submeter um pedido
                    de recarga de SMS ou de subscrição.
                  </p>
                </div>
                <div>
                  <Label>Instruções adicionais (opcional)</Label>
                  <Textarea
                    placeholder="Ex: Use o valor exacto. Não use referência."
                    value={instrucoes}
                    onChange={(e) => setInstrucoes(e.target.value)}
                    rows={3}
                  />
                </div>

                <Button onClick={handleSaveConfig} disabled={savingConfig}>
                  <Save className="h-4 w-4 mr-2" /> {savingConfig ? "A guardar..." : "Guardar métodos"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* === PACOTES EXTERNOS === */}
          <TabsContent value="pacotes">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Package className="h-5 w-5" /> Pacotes de Subscrição
                </CardTitle>
                <p className="text-xs text-muted-foreground">
                  Planos de acesso à plataforma. Os pacotes de SMS são geridos separadamente em Administração → SMS.
                </p>
              </CardHeader>
              <CardContent>
                {pacotes.length === 0 ? (
                  <p className="text-center py-8 text-muted-foreground text-sm">Nenhum pacote configurado.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Nome</TableHead>
                          <TableHead>Preço</TableHead>
                          <TableHead>Duração</TableHead>
                          <TableHead>Activo</TableHead>
                          <TableHead className="text-right">Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {pacotes.map((p) => (
                          <TableRow key={p.id}>
                            <TableCell className="font-medium">{p.nome}</TableCell>
                            <TableCell>{formatCurrency(p.preco)}</TableCell>
                            <TableCell>{p.duracao_dias} dias</TableCell>
                            <TableCell>
                              <Switch checked={p.ativo} onCheckedChange={() => handleTogglePacote(p.id, p.ativo)} />
                            </TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="sm" onClick={() => openEditPacote(p)}>
                                <Pencil className="h-3.5 w-3.5 mr-1" /> Editar
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* === RENOVAÇÕES AUTOMÁTICAS === */}
          <TabsContent value="renovacoes">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <History className="h-5 w-5" /> Histórico de Renovações
                </CardTitle>
              </CardHeader>
              <CardContent>
                {renovacoes.length === 0 ? (
                  <p className="text-center py-8 text-muted-foreground text-sm">Nenhuma renovação registada.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Data</TableHead>
                          <TableHead>Usuário</TableHead>
                          <TableHead>Pacote</TableHead>
                          <TableHead>Dias</TableHead>
                          <TableHead>Valor</TableHead>
                          <TableHead>Válido até</TableHead>
                          <TableHead>Tipo</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {renovacoes.map((r) => {
                          const u = usersMap[r.user_id];
                          return (
                            <TableRow key={r.id}>
                              <TableCell className="text-xs whitespace-nowrap">
                                {format(new Date(r.created_at), "dd/MM/yyyy HH:mm")}
                              </TableCell>
                              <TableCell>
                                <p className="text-sm font-medium">{u?.name || "—"}</p>
                                <p className="text-xs text-muted-foreground">{u?.email || ""}</p>
                              </TableCell>
                              <TableCell>{r.pacote_nome || "—"}</TableCell>
                              <TableCell>+{r.dias_adicionados}</TableCell>
                              <TableCell>{formatCurrency(r.valor)}</TableCell>
                              <TableCell className="text-xs">{format(new Date(r.data_fim), "dd/MM/yyyy")}</TableCell>
                              <TableCell>
                                <Badge variant={r.tipo === "webhook" || r.tipo === "automatica" ? "default" : "outline"} className="text-[10px]">
                                  {r.tipo}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* === PAGAMENTOS RECEBIDOS - PEDIDOS POR CONFIRMAR === */}
          <TabsContent value="recebidos" className="space-y-4">
            <Card className={totalPendentes > 0 ? "border-destructive border-2" : ""}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <AlertCircle className={`h-5 w-5 ${totalPendentes > 0 ? "text-destructive animate-pulse" : ""}`} />
                  Pedidos por Confirmar ({totalPendentes})
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Pedidos legados ainda pendentes. O novo fluxo activa o pacote automaticamente após validação do comprovativo.
                </p>
              </CardHeader>
              <CardContent>
                {pendentes.length === 0 ? (
                  <p className="text-center py-8 text-muted-foreground text-sm">Nenhum pedido pendente.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Submetido</TableHead>
                          <TableHead>Utilizador</TableHead>
                          <TableHead>Pacote</TableHead>
                          <TableHead>Método</TableHead>
                          <TableHead>Valor</TableHead>
                          <TableHead>Código SMS</TableHead>
                          <TableHead>Expira</TableHead>
                          <TableHead className="text-right">Acções</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {pendentes.map((r) => {
                          const u = usersMap[r.user_id];
                          return (
                            <TableRow key={r.id}>
                              <TableCell className="text-xs whitespace-nowrap">{format(new Date(r.created_at), "dd/MM HH:mm")}</TableCell>
                              <TableCell>
                                <p className="text-sm font-medium">{u?.name || "—"}</p>
                                <p className="text-xs text-muted-foreground">{u?.email}</p>
                              </TableCell>
                              <TableCell className="text-sm">{r.plano}</TableCell>
                              <TableCell className="text-xs uppercase">{r.metodo_pagamento}</TableCell>
                              <TableCell className="font-semibold text-sm">{formatCurrency(r.valor_esperado)}</TableCell>
                              <TableCell className="font-mono text-xs">{r.codigo_submetido}</TableCell>
                              <TableCell className="text-xs">{r.data_limite_confirmacao ? format(new Date(r.data_limite_confirmacao), "dd/MM HH:mm") : "—"}</TableCell>
                              <TableCell className="text-right space-x-1">
                                <Button size="sm" variant="default" disabled={actioning === r.id} onClick={() => handleConfirmar(r.id)}>
                                  <CheckCircle2 className="h-3.5 w-3.5 mr-1" /> Confirmar
                                </Button>
                                <Button size="sm" variant="destructive" disabled={actioning === r.id} onClick={() => openRejeitar(r.id)}>
                                  <XCircle className="h-3.5 w-3.5 mr-1" /> Rejeitar
                                </Button>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Histórico de pagamentos recebidos */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Inbox className="h-5 w-5" /> Histórico de SMS recebidas
                </CardTitle>
                <p className="text-sm text-muted-foreground">Todos os códigos já submetidos. Cada um só pode ser usado uma vez.</p>
              </CardHeader>
              <CardContent>
                {incoming.length === 0 ? (
                  <p className="text-center py-8 text-muted-foreground text-sm">Nenhum pagamento registado.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Data</TableHead>
                          <TableHead>Método</TableHead>
                          <TableHead>Valor</TableHead>
                          <TableHead>Código</TableHead>
                          <TableHead>Estado</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {incoming.map((p) => (
                          <TableRow key={p.id}>
                            <TableCell className="text-xs whitespace-nowrap">{format(new Date(p.created_at), "dd/MM/yyyy HH:mm")}</TableCell>
                            <TableCell className="text-xs uppercase">{p.metodo}</TableCell>
                            <TableCell className="text-xs font-semibold">{formatCurrency(p.valor)}</TableCell>
                            <TableCell className="font-mono text-xs">{p.codigo_transacao}</TableCell>
                            <TableCell>
                              {p.status === "usado" ? (
                                <Badge variant="default" className="text-[10px]"><CheckCircle2 className="h-3 w-3 mr-1" />Confirmado</Badge>
                              ) : p.status === "pendente_confirmacao" ? (
                                <Badge variant="secondary" className="text-[10px] animate-pulse">Por confirmar</Badge>
                              ) : p.status === "rejeitado" ? (
                                <Badge variant="destructive" className="text-[10px]">Rejeitado</Badge>
                              ) : (
                                <Badge variant="outline" className="text-[10px]">{p.status}</Badge>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* === TRANSACÕES === */}
          <TabsContent value="transacoes" className="space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <BarChart3 className="h-5 w-5" /> Visão geral de transações
                  </CardTitle>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Select value={periodoTx} onValueChange={(v: any) => setPeriodoTx(v)}>
                      <SelectTrigger className="w-[170px]">
                        <Calendar className="h-4 w-4 mr-1" />
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hoje">Hoje</SelectItem>
                        <SelectItem value="semana">Esta semana</SelectItem>
                        <SelectItem value="mes">Este mês</SelectItem>
                        <SelectItem value="personalizado">Personalizado</SelectItem>
                      </SelectContent>
                    </Select>
                    {periodoTx === "personalizado" && (
                      <>
                        <Input type="date" className="w-[150px]" value={txInicio} onChange={(e) => setTxInicio(e.target.value)} />
                        <Input type="date" className="w-[150px]" value={txFim} onChange={(e) => setTxFim(e.target.value)} />
                      </>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {(() => {
                  const now = new Date();
                  let inicio: Date;
                  let fim: Date = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
                  if (periodoTx === "hoje") {
                    inicio = new Date(now.getFullYear(), now.getMonth(), now.getDate());
                  } else if (periodoTx === "semana") {
                    const d = now.getDay() || 7;
                    inicio = new Date(now.getFullYear(), now.getMonth(), now.getDate() - (d - 1));
                  } else if (periodoTx === "mes") {
                    inicio = new Date(now.getFullYear(), now.getMonth(), 1);
                  } else {
                    inicio = txInicio ? new Date(txInicio + "T00:00:00") : new Date(0);
                    fim = txFim ? new Date(txFim + "T23:59:59") : now;
                  }
                  const filtradas = transacoes.filter(t => {
                    const d = new Date(t.created_at);
                    return d >= inicio && d <= fim;
                  });
                  const pagas = filtradas.filter(t => t.status === "aprovado");
                  const falhadas = filtradas.filter(t => t.status === "rejeitado");
                  const pendentes = filtradas.filter(t => t.status === "pendente");
                  const mpesa = pagas.filter(t => (t.forma_pagamento || "").toLowerCase() === "mpesa");
                  const emola = pagas.filter(t => (t.forma_pagamento || "").toLowerCase() === "emola");
                  const totalAprovado = pagas.reduce((s, t) => s + Number(t.valor || 0), 0);
                  const totalMpesa = mpesa.reduce((s, t) => s + Number(t.valor || 0), 0);
                  const totalEmola = emola.reduce((s, t) => s + Number(t.valor || 0), 0);

                  return (
                    <>
                      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                        <Card className="border-green-500/30 bg-green-500/5">
                          <CardContent className="p-3">
                            <p className="text-xs text-muted-foreground flex items-center gap-1"><CheckCircle2 className="h-3 w-3" /> Pagas</p>
                            <p className="text-xl font-bold text-green-600">{pagas.length}</p>
                          </CardContent>
                        </Card>
                        <Card className="border-destructive/30 bg-destructive/5">
                          <CardContent className="p-3">
                            <p className="text-xs text-muted-foreground flex items-center gap-1"><XCircle className="h-3 w-3" /> Falhadas</p>
                            <p className="text-xl font-bold text-destructive">{falhadas.length}</p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-3">
                            <p className="text-xs text-muted-foreground">Pendentes</p>
                            <p className="text-xl font-bold">{pendentes.length}</p>
                          </CardContent>
                        </Card>
                        <Card className="border-primary/30 bg-primary/5">
                          <CardContent className="p-3">
                            <p className="text-xs text-muted-foreground">M-Pesa (aprovadas)</p>
                            <p className="text-lg font-bold">{mpesa.length}</p>
                            <p className="text-xs text-muted-foreground">{formatCurrency(totalMpesa)}</p>
                          </CardContent>
                        </Card>
                        <Card className="border-primary/30 bg-primary/5">
                          <CardContent className="p-3">
                            <p className="text-xs text-muted-foreground">E-Mola (aprovadas)</p>
                            <p className="text-lg font-bold">{emola.length}</p>
                            <p className="text-xs text-muted-foreground">{formatCurrency(totalEmola)}</p>
                          </CardContent>
                        </Card>
                        <Card className="border-2 border-primary bg-primary/10">
                          <CardContent className="p-3">
                            <p className="text-xs text-muted-foreground flex items-center gap-1"><TrendingUp className="h-3 w-3" /> Receita total</p>
                            <p className="text-lg font-bold text-primary">{formatCurrency(totalAprovado)}</p>
                          </CardContent>
                        </Card>
                      </div>

                      <div className="rounded-md border overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Data</TableHead>
                              <TableHead>Usuário</TableHead>
                              <TableHead>Método</TableHead>
                              <TableHead>Código</TableHead>
                              <TableHead className="text-right">Valor</TableHead>
                              <TableHead>Status</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filtradas.length === 0 ? (
                              <TableRow>
                                <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                                  Sem transações no período seleccionado
                                </TableCell>
                              </TableRow>
                            ) : filtradas.slice(0, 100).map(t => {
                              const u = usersMap[t.user_id];
                              const statusVariant = t.status === "aprovado" ? "default" : t.status === "rejeitado" ? "destructive" : "secondary";
                              return (
                                <TableRow key={t.id}>
                                  <TableCell className="text-xs whitespace-nowrap">{format(new Date(t.created_at), "dd/MM/yy HH:mm")}</TableCell>
                                  <TableCell className="text-xs">
                                    <div className="font-medium">{u?.name || "—"}</div>
                                    <div className="text-muted-foreground">{u?.email || t.user_id?.slice(0, 8)}</div>
                                  </TableCell>
                                  <TableCell className="text-xs uppercase">{t.forma_pagamento}</TableCell>
                                  <TableCell className="text-xs font-mono">{t.codigo_transacao}</TableCell>
                                  <TableCell className="text-right text-xs font-semibold">{formatCurrency(Number(t.valor))}</TableCell>
                                  <TableCell>
                                    <Badge variant={statusVariant as any} className="text-xs">
                                      {t.status === "aprovado" ? "Paga" : t.status === "rejeitado" ? "Falhada" : "Pendente"}
                                    </Badge>
                                  </TableCell>
                                </TableRow>
                              );
                            })}
                          </TableBody>
                        </Table>
                      </div>
                    </>
                  );
                })()}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Dialog de edição de pacote */}
        <Dialog open={pacoteDialogOpen} onOpenChange={setPacoteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar pacote: {editingPacote?.nome}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Preço (MTn)</Label>
                <Input type="number" value={pacotePreco} onChange={(e) => setPacotePreco(e.target.value)} />
              </div>
              <div>
                <Label>Duração (dias)</Label>
                <Input type="number" value={pacoteDuracao} onChange={(e) => setPacoteDuracao(e.target.value)} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setPacoteDialogOpen(false)}>Cancelar</Button>
              <Button onClick={handleSavePacote}>Guardar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Dialog de rejeição */}
        <Dialog open={rejectDialog.open} onOpenChange={(o) => setRejectDialog({ open: o, id: o ? rejectDialog.id : null })}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Rejeitar pagamento</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                O pedido será marcado como rejeitado e o código ficará bloqueado para sempre.
              </p>
              <div>
                <Label>Motivo (opcional)</Label>
                <Textarea rows={3} value={motivoRejeicao} onChange={(e) => setMotivoRejeicao(e.target.value)} placeholder="Ex: Valor incorrecto, código inválido..." />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setRejectDialog({ open: false, id: null })}>Cancelar</Button>
              <Button variant="destructive" onClick={handleRejeitar}>Rejeitar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
