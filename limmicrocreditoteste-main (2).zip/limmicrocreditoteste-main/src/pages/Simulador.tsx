import { useState } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Calculator, TrendingUp } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { ReciboSimulador } from "@/components/ReciboSimulador";
import { gerarTabelaAmortizacao, calcularTotaisAmortizacao, type SistemaAmortizacao, type ParcelaAmortizacao } from "@/lib/amortization";

export default function Simulador() {
  const [nomeCliente, setNomeCliente] = useState("");
  const [valor, setValor] = useState("");
  const [periodo, setPeriodo] = useState("");
  const [taxaJuros, setTaxaJuros] = useState("");
  const [taxaPreparo, setTaxaPreparo] = useState("2");
  const [tipoJuros, setTipoJuros] = useState("Simples");
  const [sistemaAmortizacao, setSistemaAmortizacao] = useState<SistemaAmortizacao>("price");
  const [modalidadeReembolso, setModalidadeReembolso] = useState("mensal");
  const [resultado, setResultado] = useState<any>(null);
  const [tabelaParcelas, setTabelaParcelas] = useState<ParcelaAmortizacao[]>([]);

  const calcularEmprestimo = () => {
    const valorNum = parseFloat(valor);
    const periodoNum = parseInt(periodo);
    const taxaNum = parseFloat(taxaJuros);

    const dataHoje = new Date().toISOString().split('T')[0];
    const parcelas = gerarTabelaAmortizacao(
      valorNum, taxaNum, periodoNum, modalidadeReembolso, dataHoje,
      periodoNum > 1 && (tipoJuros === "Composto" || tipoJuros === "SobreSaldo") ? sistemaAmortizacao : 'price',
      tipoJuros
    );

    const totais = calcularTotaisAmortizacao(parcelas);
    setTabelaParcelas(parcelas);

    const saldoDevedor = parcelas.map(p => ({ mes: p.numero, saldo: p.saldoDevedor }));

    setResultado({
      valorEmprestimo: valorNum,
      jurosTotal: totais.totalJuros,
      valorTotal: totais.totalPrestacoes,
      parcelaMensal: parcelas[0]?.prestacao || 0,
      saldoDevedor,
      jurosMensal: totais.totalJuros / periodoNum,
    });
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-MZ", {
      style: "currency",
      currency: "MZN",
    }).format(value);
  };

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-3">
          <Calculator className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">Simulador de Crédito</h1>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Formulário */}
          <Card>
            <CardHeader>
              <CardTitle>Dados da Simulação</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="nome">Nome do Cliente</Label>
                <Input
                  id="nome"
                  value={nomeCliente}
                  onChange={(e) => setNomeCliente(e.target.value)}
                  placeholder="Nome completo"
                />
              </div>

              <div>
                <Label htmlFor="valor">Valor do Empréstimo (MZN)</Label>
                <Input
                  id="valor"
                  type="number"
                  value={valor}
                  onChange={(e) => setValor(e.target.value)}
                  placeholder="10000"
                />
              </div>

              <div>
                <Label htmlFor="periodo">Período (meses)</Label>
                <Input
                  id="periodo"
                  type="number"
                  value={periodo}
                  onChange={(e) => setPeriodo(e.target.value)}
                  placeholder="12"
                  min="1"
                  max="12"
                />
              </div>

              <div>
                <Label htmlFor="taxa">Taxa de Juros (% ao mês)</Label>
                <Input
                  id="taxa"
                  type="number"
                  step="0.1"
                  value={taxaJuros}
                  onChange={(e) => setTaxaJuros(e.target.value)}
                  placeholder="5.0"
                />
              </div>

              <div>
                <Label htmlFor="taxaPreparo">Taxa de Preparo (% do valor)</Label>
                <Input
                  id="taxaPreparo"
                  type="number"
                  step="0.1"
                  min="0"
                  value={taxaPreparo}
                  onChange={(e) => setTaxaPreparo(e.target.value)}
                  placeholder="2.0"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Defina a percentagem que será deduzida do desembolso
                </p>
              </div>

              <div>
                <Label>Tipo de Juros</Label>
                <Select value={tipoJuros} onValueChange={setTipoJuros}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Simples">Juros Simples (Flat)</SelectItem>
                    <SelectItem value="Composto">Juros Composto</SelectItem>
                    <SelectItem value="SobreSaldo">Juros sobre Saldo Devedor</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {parseInt(periodo) > 1 && (tipoJuros === "Composto" || tipoJuros === "SobreSaldo") && (
                <div>
                  <Label>Sistema de Amortização</Label>
                  <Select value={sistemaAmortizacao} onValueChange={(val: SistemaAmortizacao) => setSistemaAmortizacao(val)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="price">Parcelas Fixas (Sistema Price)</SelectItem>
                      <SelectItem value="sac">Parcelas Variáveis (SAC)</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">
                    {sistemaAmortizacao === 'price' 
                      ? 'Todas as prestações têm o mesmo valor' 
                      : 'A amortização é constante, juros diminuem a cada prestação'}
                  </p>
                </div>
              )}

              <div>
                <Label>Modalidade de Reembolso</Label>
                <Select value={modalidadeReembolso} onValueChange={setModalidadeReembolso}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="diaria">Diária</SelectItem>
                    <SelectItem value="semanal">Semanal</SelectItem>
                    <SelectItem value="quinzenal">Quinzenal</SelectItem>
                    <SelectItem value="mensal">Mensal</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button
                onClick={calcularEmprestimo}
                className="w-full"
                disabled={!valor || !periodo || !taxaJuros}
              >
                <Calculator className="mr-2 h-4 w-4" />
                Simular Empréstimo
              </Button>
            </CardContent>
          </Card>

          {/* Resultado */}
          {resultado && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between text-base">
                  Resultado da Simulação
                  <ReciboSimulador
                    nomeCliente={nomeCliente}
                    valor={parseFloat(valor)}
                    periodo={parseInt(periodo)}
                    taxaJuros={parseFloat(taxaJuros)}
                    tipoJuros={tipoJuros}
                    tabelaParcelas={tabelaParcelas}
                    sistemaAmortizacao={sistemaAmortizacao}
                    modalidadeReembolso={modalidadeReembolso}
                    taxaPreparoPercent={parseFloat(taxaPreparo) || 0}
                  />
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="text-xs text-muted-foreground">Valor Empréstimo</p>
                    <p className="text-lg font-bold text-primary">
                      {formatCurrency(resultado.valorEmprestimo)}
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-muted">
                    <p className="text-xs text-muted-foreground">Juros Total</p>
                    <p className="text-lg font-bold text-warning">
                      {formatCurrency(resultado.jurosTotal)}
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-muted">
                    <p className="text-xs text-muted-foreground">Valor Total a Pagar</p>
                    <p className="text-lg font-bold text-destructive">
                      {formatCurrency(resultado.valorTotal)}
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-muted">
                    <p className="text-xs text-muted-foreground">
                      {sistemaAmortizacao === 'sac' && parseInt(periodo) > 1 && (tipoJuros === 'Composto' || tipoJuros === 'SobreSaldo')
                        ? '1ª Parcela' 
                        : 'Parcela'}
                    </p>
                    <p className="text-lg font-bold text-success">
                      {formatCurrency(resultado.parcelaMensal)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Tabela de Amortização */}
        {tabelaParcelas.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">
                Tabela de Amortização 
                {parseInt(periodo) > 1 && (tipoJuros === 'Composto' || tipoJuros === 'SobreSaldo') && (
                  <span className="text-sm font-normal text-muted-foreground ml-2">
                    — {sistemaAmortizacao === 'price' ? 'Sistema Price (Parcelas Fixas)' : 'SAC (Parcelas Variáveis)'}
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs">Nº</TableHead>
                      <TableHead className="text-xs">Vencimento</TableHead>
                      <TableHead className="text-xs text-right">Prestação</TableHead>
                      <TableHead className="text-xs text-right">Capital</TableHead>
                      <TableHead className="text-xs text-right">Juros</TableHead>
                      <TableHead className="text-xs text-right">Saldo Devedor</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {tabelaParcelas.map((p) => (
                      <TableRow key={p.numero}>
                        <TableCell className="text-xs">{p.numero}</TableCell>
                        <TableCell className="text-xs">{new Date(p.dataVencimento).toLocaleDateString('pt-MZ')}</TableCell>
                        <TableCell className="text-xs text-right font-medium">{formatCurrency(p.prestacao)}</TableCell>
                        <TableCell className="text-xs text-right">{formatCurrency(p.amortizacao)}</TableCell>
                        <TableCell className="text-xs text-right">{formatCurrency(p.juros)}</TableCell>
                        <TableCell className="text-xs text-right">{formatCurrency(p.saldoDevedor)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <div className="mt-3 p-2 bg-muted rounded text-xs flex justify-between">
                <span>Total: {formatCurrency(calcularTotaisAmortizacao(tabelaParcelas).totalPrestacoes)}</span>
                <span>Juros: {formatCurrency(calcularTotaisAmortizacao(tabelaParcelas).totalJuros)}</span>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Gráfico */}
        {resultado && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <TrendingUp className="h-5 w-5" />
                Evolução do Saldo Devedor
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={resultado.saldoDevedor}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="mes" label={{ value: "Parcela", position: "insideBottom", offset: -5 }} />
                  <YAxis />
                  <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="saldo"
                    stroke="hsl(210, 85%, 48%)"
                    strokeWidth={2}
                    name="Saldo Devedor (MZN)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
