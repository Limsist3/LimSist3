import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Users, UserPlus, Edit, Lock, Trash2, Calendar, User, Briefcase, ShieldCheck } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PermissoesMembroDialog } from "@/components/PermissoesMembroDialog";
import { ROLES_MEMBRO, labelRole, MembroRole } from "@/lib/permissoes";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface Agente {
  id: string;
  full_name: string;
  email: string;
  role: string;
  estado: string;
  created_at: string;
  usage_days: number;
  expires_at: string;
  total_clientes?: number;
  ultimo_acesso?: string;
}

export default function GestaoAgentes() {
  const [agentes, setAgentes] = useState<Agente[]>([]);
  const [secretariados, setSecretariados] = useState<Agente[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [dialogRole, setDialogRole] = useState<MembroRole>("agente");
  const [outros, setOutros] = useState<Agente[]>([]);
  const [permMembro, setPermMembro] = useState<Agente | null>(null);
  const [permOpen, setPermOpen] = useState(false);
  const [editingAgente, setEditingAgente] = useState<Agente | null>(null);
  const [agenteToDelete, setAgenteToDelete] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    senha: "",
    telefone: "",
  });
  const [stats, setStats] = useState({
    totalAgentes: 0,
    agentesAtivos: 0,
    totalClientes: 0,
    totalSecretariados: 0,
  });

  useEffect(() => {
    loadAgentes();
  }, []);

  const loadAgentes = async () => {
    try {
      setLoading(true);
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) return;

      // Buscar agentes
      const { data: agentesData, error } = await supabase
        .from("user_profiles")
        .select("id, user_id, full_name, email, role, estado, created_at, usage_days, expires_at")
        .eq("usuario_mae_id", user.id)
        .eq("role", "agente");

      if (error) throw error;

      // Buscar secretariados
      const { data: secretariadosData, error: secError } = await supabase
        .from("user_profiles")
        .select("id, user_id, full_name, email, role, estado, created_at, usage_days, expires_at")
        .eq("usuario_mae_id", user.id)
        .eq("role", "secretariado");

      if (secError) throw secError;

      // Buscar restantes membros (contabilista, auditor, visualizador)
      const { data: outrosData, error: outrosError } = await supabase
        .from("user_profiles")
        .select("id, user_id, full_name, email, role, estado, created_at, usage_days, expires_at")
        .eq("usuario_mae_id", user.id)
        .in("role", ["contabilista", "auditor", "visualizador"]);

      if (outrosError) throw outrosError;

      // Contar clientes de cada agente
      const mapWithClientes = async (list: typeof agentesData) => {
        return Promise.all(
          (list || []).map(async (item) => {
            const { count } = await supabase
              .from("clientes")
              .select("*", { count: "exact", head: true })
              .eq("agente_id", item.user_id);
            return {
              id: item.user_id,
              full_name: item.full_name,
              email: item.email || "Email não disponível",
              role: item.role,
              estado: item.estado,
              created_at: item.created_at,
              usage_days: item.usage_days,
              expires_at: item.expires_at,
              total_clientes: count || 0,
            };
          })
        );
      };

      const agentesComClientes = await mapWithClientes(agentesData);
      const secretariadosComClientes = await mapWithClientes(secretariadosData);

      const outrosComClientes = await mapWithClientes(outrosData);

      setAgentes(agentesComClientes);
      setSecretariados(secretariadosComClientes);
      setOutros(outrosComClientes);

      const ativos = agentesComClientes.filter((a) => a.estado === "Ativo").length;
      const totalClientes = agentesComClientes.reduce((sum, a) => sum + (a.total_clientes || 0), 0);

      setStats({
        totalAgentes: agentesComClientes.length,
        agentesAtivos: ativos,
        totalClientes,
        totalSecretariados: secretariadosComClientes.length,
      });
    } catch (error: any) {
      console.error("Erro ao carregar agentes:", error);
      toast.error("Erro ao carregar agentes");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) throw new Error("Usuário não autenticado");

      // Verificar limite por tipo de membro
      if (!editingAgente) {
        const cfg = ROLES_MEMBRO.find((r) => r.value === dialogRole);
        const jaExistentes =
          dialogRole === "agente"
            ? agentes.length
            : dialogRole === "secretariado"
              ? secretariados.length
              : outros.filter((o) => o.role === dialogRole).length;
        if (cfg && jaExistentes >= cfg.limite) {
          toast.error(`Limite de ${cfg.limite} ${cfg.label.toLowerCase()}(s) atingido!`);
          return;
        }
      }

      if (editingAgente) {
        const { error: rpcError } = await supabase.rpc('manage_agent', {
          p_agent_user_id: editingAgente.id,
          p_full_name: formData.nome,
          p_role: editingAgente.role as any,
          p_estado: editingAgente.estado,
          p_usuario_mae_id: user.id
        });

        if (rpcError) throw rpcError;
        toast.success(`${editingAgente.role === 'secretariado' ? 'Secretariado' : 'Agente'} atualizado com sucesso!`);
      } else {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) throw new Error("Sessão não encontrada");

        const response = await supabase.functions.invoke('criar-agente', {
          body: {
            email: formData.email,
            password: formData.senha,
            full_name: formData.nome,
            usuario_mae_id: user.id,
            role: dialogRole,
          }
        });

        if (response.error) {
          throw new Error(response.error.message || "Erro ao criar");
        }

        if (response.data?.error) {
          toast.error(response.data.error);
          return;
        }

        toast.success(response.data.message || `${dialogRole === 'secretariado' ? 'Secretariado' : 'Agente'} cadastrado com sucesso!`);
      }

      setShowDialog(false);
      setFormData({ nome: "", email: "", senha: "", telefone: "" });
      setEditingAgente(null);
      loadAgentes();
    } catch (error: any) {
      console.error("Erro ao salvar:", error);
      toast.error(error.message || "Erro ao salvar");
    }
  };

  const handleBloquearAgente = async (agenteId: string, estadoAtual: string, roleType: string) => {
    try {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) throw new Error("Usuário não autenticado");

      const novoEstado = estadoAtual === "Ativo" ? "Bloqueado" : "Ativo";
      const item = [...agentes, ...secretariados].find(a => a.id === agenteId);

      const { error } = await supabase.rpc('manage_agent', {
        p_agent_user_id: agenteId,
        p_full_name: item?.full_name || '',
        p_role: roleType as any,
        p_estado: novoEstado,
        p_usuario_mae_id: user.id
      });

      if (error) throw error;

      await supabase.rpc('registrar_atividade_agente', {
        p_agente_id: user.id,
        p_descricao: `${novoEstado === "Bloqueado" ? "Bloqueou" : "Desbloqueou"} ${roleType}: ${item?.full_name}`
      });

      toast.success(`${roleType === 'secretariado' ? 'Secretariado' : 'Agente'} ${novoEstado === "Bloqueado" ? "bloqueado" : "desbloqueado"} com sucesso!`);
      loadAgentes();
    } catch (error: any) {
      console.error("Erro ao bloquear/desbloquear:", error);
      toast.error("Erro ao atualizar status");
    }
  };

  const handleDeleteAgente = async () => {
    if (!agenteToDelete) return;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Sessão não encontrada");

      const response = await supabase.functions.invoke('deletar-agente', {
        body: { agente_id: agenteToDelete }
      });

      if (response.error) {
        throw new Error(response.error.message || "Erro ao deletar");
      }

      if (response.data?.error) {
        toast.error(response.data.error);
        return;
      }

      toast.success("Removido com sucesso!");
      setAgenteToDelete(null);
      loadAgentes();
    } catch (error: any) {
      console.error("Erro ao deletar:", error);
      toast.error(error.message || "Erro ao deletar");
    }
  };

  const openCreateDialog = (role: MembroRole) => {
    setDialogRole(role);
    setEditingAgente(null);
    setFormData({ nome: "", email: "", senha: "", telefone: "" });
    setShowDialog(true);
  };

  const openEditDialog = (agente: Agente) => {
    setEditingAgente(agente);
    setDialogRole(agente.role as MembroRole);
    setFormData({
      nome: agente.full_name,
      email: agente.email,
      senha: "",
      telefone: "",
    });
    setShowDialog(true);
  };

  const renderTable = (list: Agente[], roleType: string) => (
    loading ? (
      <div className="flex justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    ) : list.length === 0 ? (
      <div className="text-center py-8 text-muted-foreground">
        Nenhum {roleType === 'secretariado' ? 'secretariado' : 'agente'} cadastrado ainda
      </div>
    ) : (
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Função</TableHead>
              <TableHead>Total Clientes</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Data Cadastro</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {list.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="font-medium">{item.full_name}</TableCell>
                <TableCell>{item.email}</TableCell>
                <TableCell><Badge variant="outline">{labelRole(item.role)}</Badge></TableCell>
                <TableCell>{item.total_clientes || 0}</TableCell>
                <TableCell>
                  <Badge variant={item.estado === "Ativo" ? "default" : "destructive"}>
                    {item.estado}
                  </Badge>
                </TableCell>
                <TableCell>
                  {format(new Date(item.created_at), "dd/MM/yyyy")}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button size="sm" variant="ghost" title="Editar" onClick={() => openEditDialog(item)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="ghost" title="Definir permissões" onClick={() => { setPermMembro(item); setPermOpen(true); }}>
                      <ShieldCheck className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => handleBloquearAgente(item.id, item.estado, roleType)}>
                      <Lock className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setAgenteToDelete(item.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    )
  );

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Gestão de Agentes e Secretariado</h1>
            <p className="text-muted-foreground mt-1">
              Gerencie seus agentes, secretariado e acompanhe suas atividades
            </p>
          </div>
        </div>

        {/* Cards de Resumo */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Agentes</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalAgentes}</div>
              <p className="text-xs text-muted-foreground">{stats.agentesAtivos} ativos</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Secretariado</CardTitle>
              <Briefcase className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalSecretariados}/1</div>
              <p className="text-xs text-muted-foreground">Limite: 1 secretariado</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Clientes</CardTitle>
              <User className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalClientes}</div>
              <p className="text-xs text-muted-foreground">De todos os agentes</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Média por Agente</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {stats.totalAgentes > 0 ? Math.round(stats.totalClientes / stats.totalAgentes) : 0}
              </div>
              <p className="text-xs text-muted-foreground">Clientes por agente</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabs de Agentes e Secretariado */}
        <Tabs defaultValue="agentes">
          <TabsList>
            <TabsTrigger value="agentes">Agentes ({agentes.length}/10)</TabsTrigger>
            <TabsTrigger value="secretariado">Secretariado ({secretariados.length}/1)</TabsTrigger>
            <TabsTrigger value="outros">Outros Membros ({outros.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="agentes">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Lista de Agentes</CardTitle>
                <Button onClick={() => openCreateDialog("agente")} disabled={agentes.length >= 10}>
                  <UserPlus className="mr-2 h-4 w-4" />
                  Cadastrar Agente
                </Button>
              </CardHeader>
              <CardContent>
                {renderTable(agentes, "agente")}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="secretariado">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Secretariado</CardTitle>
                <Button onClick={() => openCreateDialog("secretariado")} disabled={secretariados.length >= 1}>
                  <UserPlus className="mr-2 h-4 w-4" />
                  Cadastrar Secretariado
                </Button>
              </CardHeader>
              <CardContent>
                {renderTable(secretariados, "secretariado")}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="outros">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-2">
                <div>
                  <CardTitle>Contabilista, Auditor e Visualizador</CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    Cada membro só vê e faz o que definir em Permissões.
                  </p>
                </div>
                <div className="flex gap-2 flex-wrap">
                  {ROLES_MEMBRO.filter((r) => !["agente", "secretariado"].includes(r.value)).map((r) => (
                    <Button
                      key={r.value}
                      variant="outline"
                      onClick={() => openCreateDialog(r.value)}
                      disabled={outros.filter((o) => o.role === r.value).length >= r.limite}
                    >
                      <UserPlus className="mr-2 h-4 w-4" />
                      {r.label}
                    </Button>
                  ))}
                </div>
              </CardHeader>
              <CardContent>
                {renderTable(outros, "membro")}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <PermissoesMembroDialog
        open={permOpen}
        onOpenChange={setPermOpen}
        membro={permMembro ? { id: permMembro.id, full_name: permMembro.full_name, role: permMembro.role } : null}
        onSaved={loadAgentes}
      />

      {/* Dialog de Cadastro/Edição */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingAgente ? `Editar ${labelRole(dialogRole)}` : `Cadastrar Novo ${labelRole(dialogRole)}`}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            {!editingAgente && (
              <div>
                <Label>Função</Label>
                <Select value={dialogRole} onValueChange={(v) => setDialogRole(v as MembroRole)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {ROLES_MEMBRO.map((r) => (
                      <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div>
              <Label htmlFor="nome">Nome Completo</Label>
              <Input
                id="nome"
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                disabled={!!editingAgente}
              />
            </div>
            {!editingAgente && (
              <div>
                <Label htmlFor="senha">Senha</Label>
                <Input
                  id="senha"
                  type="password"
                  value={formData.senha}
                  onChange={(e) => setFormData({ ...formData, senha: e.target.value })}
                  required
                  minLength={6}
                />
              </div>
            )}
            <div>
              <Label htmlFor="telefone">Telefone (opcional)</Label>
              <Input
                id="telefone"
                type="tel"
                value={formData.telefone}
                onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowDialog(false);
                  setEditingAgente(null);
                  setFormData({ nome: "", email: "", senha: "", telefone: "" });
                }}
              >
                Cancelar
              </Button>
              <Button type="submit">
                {editingAgente ? "Atualizar" : "Cadastrar"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialog de Confirmação de Exclusão */}
      <AlertDialog open={!!agenteToDelete} onOpenChange={() => setAgenteToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteAgente}>
              Confirmar Exclusão
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
}
