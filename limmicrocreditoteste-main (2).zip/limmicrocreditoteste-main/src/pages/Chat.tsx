import { useState, useEffect, useRef, useCallback } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useUserRole } from "@/hooks/useUserRole";
import { toast } from "sonner";
import { MessageCircle, Send, User, Shield, Check, CheckCheck } from "lucide-react";
import { format } from "date-fns";

interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  mensagem: string;
  lida: boolean;
  created_at: string;
}

interface Conversation {
  user_id: string;
  user_name: string;
  nome_instituicao: string | null;
  last_message: string;
  last_date: string;
  unread_count: number;
}

export default function Chat() {
  const { isSuperAdmin } = useUserRole();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [currentUserId, setCurrentUserId] = useState<string>("");
  const [superadminId, setSuperadminId] = useState<string>("");
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<string>("");
  const [selectedUserName, setSelectedUserName] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    initChat();
  }, [isSuperAdmin]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Play sound on new message
  const playMessageSound = useCallback(() => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 880;
      osc.type = "sine";
      gain.gain.value = 0.3;
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
      setTimeout(() => {
        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.connect(gain2);
        gain2.connect(ctx.destination);
        osc2.frequency.value = 1100;
        osc2.type = "sine";
        gain2.gain.value = 0.3;
        osc2.start();
        osc2.stop(ctx.currentTime + 0.15);
      }, 150);
    } catch {}
  }, []);

  useEffect(() => {
    // Realtime subscription
    const channel = supabase
      .channel("chat-messages")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "mensagens_chat" }, (payload) => {
        const newMsg = payload.new as any;
        // Play sound if message is for current user
        if (newMsg.receiver_id === currentUserId) {
          playMessageSound();
        }
        if (isSuperAdmin) {
          loadConversations();
          if (selectedConversation) loadMessages(selectedConversation);
        } else {
          loadMessages(superadminId);
        }
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [isSuperAdmin, selectedConversation, superadminId, currentUserId, playMessageSound]);

  const fetchSuperadminId = async (): Promise<string | null> => {
    const { data } = await supabase.rpc("get_superadmin_id");
    return data as string | null;
  };

  const initChat = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) return;
    setCurrentUserId(session.user.id);

    if (isSuperAdmin) {
      setSuperadminId(session.user.id);
      await loadConversations();
    } else {
      const sid = await fetchSuperadminId();
      if (sid) {
        setSuperadminId(sid);
        await loadMessages(sid);
      }
    }
  };

  const loadConversations = async () => {
    const { data: msgs } = await supabase
      .from("mensagens_chat")
      .select("*")
      .order("created_at", { ascending: false });

    if (!msgs) return;

    // Group by user (not superadmin)
    const userMap = new Map<string, { messages: Message[] }>();
    for (const msg of msgs) {
      const userId = msg.sender_id === currentUserId ? msg.receiver_id : msg.sender_id;
      // Skip if both sides are superadmin talking to themselves
      if (userId === currentUserId) continue;
      if (!userMap.has(userId)) userMap.set(userId, { messages: [] });
      userMap.get(userId)!.messages.push(msg);
    }

    // Get user names
    const userIds = Array.from(userMap.keys());
    if (userIds.length === 0) { setConversations([]); return; }

    const { data: profiles } = await supabase
      .from("user_profiles")
      .select("user_id, full_name, nome_instituicao")
      .in("user_id", userIds);

    const convs: Conversation[] = userIds.map(uid => {
      const info = userMap.get(uid)!;
      const profile = profiles?.find(p => p.user_id === uid);
      const lastMsg = info.messages[0];
      const unread = info.messages.filter(m => m.receiver_id === currentUserId && !m.lida).length;
      return {
        user_id: uid,
        user_name: profile?.full_name || "Usuário",
        nome_instituicao: profile?.nome_instituicao || null,
        last_message: lastMsg?.mensagem || "",
        last_date: lastMsg?.created_at || "",
        unread_count: unread,
      };
    }).sort((a, b) => new Date(b.last_date).getTime() - new Date(a.last_date).getTime());

    setConversations(convs);
  };

  const loadMessages = async (otherUserId: string) => {
    const { data } = await supabase
      .from("mensagens_chat")
      .select("*")
      .or(`and(sender_id.eq.${currentUserId},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${currentUserId})`)
      .order("created_at", { ascending: true });

    setMessages(data || []);

    // Mark as read
    if (data?.length) {
      await supabase
        .from("mensagens_chat")
        .update({ lida: true })
        .eq("receiver_id", currentUserId)
        .eq("sender_id", otherUserId)
        .eq("lida", false);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    let receiverId = isSuperAdmin ? selectedConversation : superadminId;
    
    if (!receiverId && !isSuperAdmin) {
      const sid = await fetchSuperadminId();
      if (sid) { setSuperadminId(sid); receiverId = sid; }
    }
    
    if (!receiverId) { toast.error("Destinatário não encontrado"); return; }

    const { error } = await supabase.from("mensagens_chat").insert({
      sender_id: currentUserId,
      receiver_id: receiverId,
      mensagem: newMessage.trim(),
    });

    if (error) { toast.error("Erro ao enviar mensagem"); return; }
    setNewMessage("");
  };

  const handleSelectConversation = (userId: string, userName: string) => {
    setSelectedConversation(userId);
    setSelectedUserName(userName);
    loadMessages(userId);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  // Superadmin view
  if (isSuperAdmin) {
    return (
      <DashboardLayout>
        <div className="p-4 md:p-6 h-[calc(100vh-80px)]">
          <div className="flex items-center gap-3 mb-4">
            <MessageCircle className="h-7 w-7 text-primary" />
            <h1 className="text-2xl font-bold">Mensagens dos Usuários</h1>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-[calc(100%-60px)]">
            {/* Conversations list */}
            <Card className="md:col-span-1 flex flex-col">
              <CardHeader className="py-3 px-4">
                <CardTitle className="text-sm">Conversas</CardTitle>
              </CardHeader>
              <CardContent className="flex-1 p-0 overflow-hidden">
                <ScrollArea className="h-full">
                  {conversations.length === 0 && (
                    <p className="text-sm text-muted-foreground p-4 text-center">Nenhuma conversa</p>
                  )}
                  {conversations.map(conv => (
                    <div
                      key={conv.user_id}
                      className={`p-3 border-b cursor-pointer hover:bg-muted/50 transition-colors ${selectedConversation === conv.user_id ? "bg-muted" : ""}`}
                      onClick={() => handleSelectConversation(conv.user_id, conv.user_name)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 min-w-0">
                          <User className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
                          <div className="min-w-0">
                            <p className="text-sm font-medium truncate">{conv.user_name}</p>
                            {conv.nome_instituicao && (
                              <p className="text-xs text-muted-foreground truncate">{conv.nome_instituicao}</p>
                            )}
                          </div>
                        </div>
                        {conv.unread_count > 0 && (
                          <Badge variant="destructive" className="text-xs ml-2">{conv.unread_count}</Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1 truncate">{conv.last_message}</p>
                      {conv.last_date && (
                        <p className="text-xs text-muted-foreground/60 mt-0.5">
                          {format(new Date(conv.last_date), "dd/MM HH:mm")}
                        </p>
                      )}
                    </div>
                  ))}
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Messages */}
            <Card className="md:col-span-2 flex flex-col">
              <CardHeader className="py-3 px-4 border-b">
                <CardTitle className="text-sm flex items-center gap-2">
                  {selectedConversation ? (
                    <><User className="h-4 w-4" /> {selectedUserName}</>
                  ) : "Selecione uma conversa"}
                </CardTitle>
              </CardHeader>
              <CardContent className="flex-1 p-0 flex flex-col overflow-hidden">
                <ScrollArea className="flex-1 p-4">
                  {messages.map(msg => (
                    <div key={msg.id} className={`mb-3 flex ${msg.sender_id === currentUserId ? "justify-end" : "justify-start"}`}>
                      <div className={`max-w-[75%] rounded-lg px-3 py-2 text-sm ${msg.sender_id === currentUserId ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                        <p>{msg.mensagem}</p>
                        <div className="flex items-center gap-1 mt-1">
                          <span className="text-xs opacity-70">{format(new Date(msg.created_at), "HH:mm")}</span>
                          {msg.sender_id === currentUserId && (msg.lida ? <CheckCheck className="h-3 w-3 opacity-70" /> : <Check className="h-3 w-3 opacity-50" />)}
                        </div>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </ScrollArea>
                {selectedConversation && (
                  <div className="p-3 border-t flex gap-2">
                    <Input
                      value={newMessage}
                      onChange={e => setNewMessage(e.target.value)}
                      onKeyDown={handleKeyPress}
                      placeholder="Escreva uma resposta..."
                      className="flex-1"
                    />
                    <Button onClick={sendMessage} size="icon"><Send className="h-4 w-4" /></Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  // Regular user view
  return (
    <DashboardLayout>
      <div className="p-4 md:p-6 h-[calc(100vh-80px)]">
        <div className="flex items-center gap-3 mb-4">
          <MessageCircle className="h-7 w-7 text-primary" />
          <h1 className="text-2xl font-bold">Chat com Suporte</h1>
        </div>
        <Card className="h-[calc(100%-60px)] flex flex-col">
          <CardHeader className="py-3 px-4 border-b">
            <CardTitle className="text-sm flex items-center gap-2">
              <Shield className="h-4 w-4 text-primary" />
              Administrador da Plataforma
            </CardTitle>
          </CardHeader>
          <CardContent className="flex-1 p-0 flex flex-col overflow-hidden">
            <ScrollArea className="flex-1 p-4">
              {messages.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-8">
                  Envie uma mensagem para o administrador da plataforma.
                </p>
              )}
              {messages.map(msg => (
                <div key={msg.id} className={`mb-3 flex ${msg.sender_id === currentUserId ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[75%] rounded-lg px-3 py-2 text-sm ${msg.sender_id === currentUserId ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                    <p>{msg.mensagem}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <span className="text-xs opacity-70">{format(new Date(msg.created_at), "HH:mm")}</span>
                      {msg.sender_id === currentUserId && (msg.lida ? <CheckCheck className="h-3 w-3 opacity-70" /> : <Check className="h-3 w-3 opacity-50" />)}
                    </div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </ScrollArea>
            <div className="p-3 border-t flex gap-2">
              <Input
                value={newMessage}
                onChange={e => setNewMessage(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Escreva sua mensagem..."
                className="flex-1"
              />
              <Button onClick={sendMessage} size="icon"><Send className="h-4 w-4" /></Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
