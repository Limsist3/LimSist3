import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, AlertTriangle, Plus, CheckCircle2, Trash2 } from "lucide-react";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAccessControl } from "@/hooks/useAccessControl";
import { AccountBlocked } from "@/components/AccountBlocked";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";
import { useUserRole } from "@/hooks/useUserRole";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";

export default function CentralRisco() {
  const { accessStatus, loading: accessLoading } = useAccessControl();
  const { isSuperAdmin, loading: roleLoading } = useUserRole();
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResult, setSearchResult] = useState<any>(null);
  const [searched, setSearched] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [registros, setRegistros] = useState<any[]>([]);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [registroToDelete, setRegistroToDelete] = useState<string | null>(null);
  
  // Form states
  const [nomeCompleto, setNomeCompleto] = useState("");
  const [nuitBi, setNuitBi] = useState("");
  const [motivo, setMotivo] = useState("");
  const [observacao, setObservacao] = useState("");

  const motivoOptions = [
    "Atraso maior que 90 dias",
    "Fraude",
    "Dívidas não regularizadas",
    "Outros motivos"
  ];

  useEffect(() => {
    if (isSuperAdmin) {
      loadRegistros();
    }
  }, [isSuperAdmin]);

  const loadRegistros = async () => {
    const { data, error } = await supabase
      .from("central_risco")
      .select("*")
      .order("created_at", { ascending: false });
    
    if (error) {
      console.error("Erro ao carregar registros:", error);
    } else {
      setRegistros(data || []);
    }
  };

  useRealtimeRefresh(["central_risco"], loadRegistros, isSuperAdmin && !roleLoading, 900);

  const getIniciais = (nome: string) => {
    const partes = nome.trim().split(" ");
    if (partes.length === 1) return partes[0].charAt(0) + ".";
    return partes[0].charAt(0) + ". " + partes[partes.length - 1].charAt(0) + ".";
  };

  const handleSearch = async () => {
    if (!searchTerm.trim()) {
      toast.error("Por favor, insira um NUIT ou BI");
      return;
    }

    const { data, error } = await supabase
      .from("central_risco")
      .select("*")
      .eq("nuit_bi", searchTerm.trim())
      .maybeSingle();

    if (error) {
      console.error("Erro na busca:", error);
      toast.error("Erro ao consultar a central de risco");
      return;
    }

    setSearchResult(data);
    setSearched(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
    if (!user) {
      toast.error("Erro de autenticação");
      return;
    }

    const { error } = await supabase.from("central_risco").insert([{
      nome_completo: nomeCompleto,
      nuit_bi: nuitBi,
      motivo,
      instituicao: "LIMSIST",
      observacao: observacao || null,
      user_id: user.id
    }]);

    if (error) {
      console.error("Erro ao cadastrar:", error);
      toast.error("Erro ao cadastrar cliente na central de risco");
    } else {
      toast.success("✅ Cliente registado com sucesso na Central de Risco.");
      setDialogOpen(false);
      // Limpar form
      setNomeCompleto("");
      setNuitBi("");
      setMotivo("");
      setObservacao("");
      // Recarregar se for superadmin
      if (isSuperAdmin) {
        loadRegistros();
      }
    }
  };

  if (accessLoading || roleLoading) {
    return <DashboardLayout><div className="p-8">Carregando...</div></DashboardLayout>;
  }

  if (!accessStatus?.isActive) {
    return <AccountBlocked reason={accessStatus?.reason || "inactive"} expiresAt={accessStatus?.expiresAt} />;
  }

  return (
    <DashboardLayout>
      <div className="p-8 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Central de Risco</h1>
          <p className="text-muted-foreground">LIMSIST - Consulta e cadastro de clientes com risco de crédito</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Consultar Cliente</CardTitle>
            <CardDescription>Busque por NUIT ou Número de BI</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="Digite o NUIT ou BI"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              />
              <Button onClick={handleSearch}>
                <Search className="h-4 w-4 mr-2" />
                Consultar
              </Button>
            </div>

            {searched && (
              <div className="mt-4 p-4 border rounded-lg">
                {searchResult ? (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-destructive">
                      <AlertTriangle className="h-5 w-5" />
                      <span className="font-semibold text-lg">
                        {getIniciais(searchResult.nome_completo)}
                      </span>
                      <span>— Cliente registado na Central de Risco</span>
                    </div>
                    <div className="text-sm text-muted-foreground space-y-1">
                      <p><strong>Data de Registro:</strong> {format(new Date(searchResult.created_at), "dd/MM/yyyy")}</p>
                      <p><strong>Motivo:</strong> {searchResult.motivo}</p>
                      {searchResult.observacao && (
                        <p><strong>Observação:</strong> {searchResult.observacao}</p>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-green-600">
                    <CheckCircle2 className="h-5 w-5" />
                    <span>Cliente não se encontra registado na Central de Risco.</span>
                  </div>
                )}
              </div>
            )}

            <Button onClick={() => setDialogOpen(true)} className="w-full sm:w-auto">
              <Plus className="h-4 w-4 mr-2" />
              Cadastrar Cliente
            </Button>
          </CardContent>
        </Card>

        {isSuperAdmin && (
          <Card>
            <CardHeader>
              <CardTitle>Listagem de Registros</CardTitle>
              <CardDescription>Apenas visível para superadministradores</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Inicial do Nome</TableHead>
                    <TableHead>Motivo</TableHead>
                    <TableHead>Data de Registro</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {registros.map((registro) => (
                    <TableRow key={registro.id}>
                      <TableCell className="font-medium">
                        {getIniciais(registro.nome_completo)}
                      </TableCell>
                      <TableCell>{registro.motivo}</TableCell>
                      <TableCell>{format(new Date(registro.created_at), "dd/MM/yyyy")}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => { setRegistroToDelete(registro.id); setDeleteConfirmOpen(true); }}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Cadastrar Cliente na Central de Risco</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Nome Completo *</Label>
                <Input
                  value={nomeCompleto}
                  onChange={(e) => setNomeCompleto(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>NUIT ou BI *</Label>
                <Input
                  value={nuitBi}
                  onChange={(e) => setNuitBi(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Motivo do Registro *</Label>
                <Select value={motivo} onValueChange={setMotivo} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o motivo" />
                  </SelectTrigger>
                  <SelectContent>
                    {motivoOptions.map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Observação (opcional)</Label>
                <Textarea
                  value={observacao}
                  onChange={(e) => setObservacao(e.target.value)}
                  rows={3}
                />
              </div>
              <Button type="submit" className="w-full">
                Salvar Registro
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        <ConfirmDialog
          open={deleteConfirmOpen}
          onOpenChange={setDeleteConfirmOpen}
          description="Tem certeza que deseja excluir este registro da Central de Risco?"
          confirmLabel="Excluir"
          onConfirm={async () => {
            if (!registroToDelete) return;
            const { error } = await supabase
              .from("central_risco")
              .delete()
              .eq("id", registroToDelete);
            if (error) {
              toast.error("Erro ao deletar registro");
            } else {
              toast.success("Registro deletado com sucesso");
              loadRegistros();
            }
            setDeleteConfirmOpen(false);
            setRegistroToDelete(null);
          }}
          variant="destructive"
        />
      </div>
    </DashboardLayout>
  );
}
