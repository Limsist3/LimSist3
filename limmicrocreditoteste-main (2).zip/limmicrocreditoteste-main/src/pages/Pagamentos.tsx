import { useState, useEffect, useMemo } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Receipt, Plus, Eye, FileText, Pencil, Trash2, ChevronDown, Search, Download } from "lucide-react";
import { ClientSearchInput } from "@/components/ClientSearchInput";
import { createFormattedExcel, formatMZN } from "@/lib/excelExport";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ReciboPagamento } from "@/components/ReciboPagamento";
import { RecibosArquivados } from "@/components/RecibosArquivados";
import { useUserRole } from "@/hooks/useUserRole";
import { useContasFinanceiras } from "@/hooks/useContasFinanceiras";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";
import { gerarTabelaAmortizacao, getParcelaAtual, formatSistema, type ParcelaAmortizacao, type SistemaAmortizacao } from "@/lib/amortization";
import { PlanoAmortizacaoDetalhado } from "@/components/PlanoAmortizacaoDetalhado";
import { decomporPagamento } from "@/lib/decomporPagamento";


interface Emprestimo {
  id: string;
  cliente_id: string;
  valor: number;
  taxa_juros: number;
  taxa_mora: number;
  duracao_meses: number;
  data_desembolso: string;
  data_reembolso: string;
  valor_total: number;
  parcela_mensal: number;
  valor_pago: number;
  status: string;
  tipo_juros: string;
  modalidade_desembolso: string;
  modalidade_reembolso: string;
  tipo_garantia: string;
  detalhes_garantia: string;
  observacoes: string;
  created_at: string;
  clientes: {
    nome_completo: string;
    telefone: string;
    email: string;
    provincia: string;
  };
  // Campos calculados para juros de mora
  diasAtraso?: number;
  jurosMora?: number;
  saldoDevedorTotal?: number;
}

interface Pagamento {
  id: string;
  emprestimo_id: string;
  valor: number;
  data_pagamento: string;
  tipo: string;
  observacoes: string;
  conta_financeira_id: string | null;
}

export default function Pagamentos() {
  const { isAgente } = useUserRole();
  const { contas, registrarReembolso, estornarReembolso, refetch: refetchContas } = useContasFinanceiras();
  const [emprestimosAtivos, setEmprestimosAtivos] = useState<Emprestimo[]>([]);
  const [pagamentos, setPagamentos] = useState<Pagamento[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [detalhesOpen, setDetalhesOpen] = useState(false);
  const [emprestimoSelecionado, setEmprestimoSelecionado] = useState<Emprestimo | null>(null);
  const [pagamentosEmprestimo, setPagamentosEmprestimo] = useState<Pagamento[]>([]);
  const [reciboOpen, setReciboOpen] = useState(false);
  const [pagamentoSelecionado, setPagamentoSelecionado] = useState<any>(null);
  
  // Estados para edição
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [pagamentoParaEditar, setPagamentoParaEditar] = useState<Pagamento | null>(null);
  const [editValor, setEditValor] = useState("");
  const [editData, setEditData] = useState("");
  const [editObservacoes, setEditObservacoes] = useState("");
  
  // Estado para exclusão
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [pagamentoParaDeletar, setPagamentoParaDeletar] = useState<Pagamento | null>(null);
  
  // Form states
  const [emprestimoId, setEmprestimoId] = useState("");
  const [valorPagamento, setValorPagamento] = useState("");
  const [metodoReembolso, setMetodoReembolso] = useState("");
  const [dataPagamento, setDataPagamento] = useState(new Date().toISOString().split('T')[0]);
  const [observacoes, setObservacoes] = useState("");
  const [tipoPagamento, setTipoPagamento] = useState<"normal" | "juros">("normal");
  const [searchFilter, setSearchFilter] = useState("");
  const [clienteSearch, setClienteSearch] = useState("");

  // Paginação server-side (suporta 100k+ registos)
  const PAGE_SIZE = 50;
  const [page, setPage] = useState(1);
  const [totalEmprestimos, setTotalEmprestimos] = useState(0);
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [aba, setAba] = useState<"ativos" | "pagos" | "arquivados">("ativos");
  const [emprestimosPagos, setEmprestimosPagos] = useState<Emprestimo[]>([]);
  const [loadingPagos, setLoadingPagos] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedSearch(searchFilter);
      setPage(1);
    }, 300);
    return () => clearTimeout(t);
  }, [searchFilter]);

  useEffect(() => {
    loadData();
  }, [isAgente, page, debouncedSearch]);

  // Função para calcular dias de atraso
  const calcularDiasAtraso = (dataReembolso: string): number => {
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    const dataVencimento = new Date(dataReembolso);
    dataVencimento.setHours(0, 0, 0, 0);

    if (hoje > dataVencimento) {
      const diffTime = hoje.getTime() - dataVencimento.getTime();
      return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }
    return 0;
  };

  // Função para calcular juros de mora (taxa diária aplicada diretamente)
  const calcularJurosMora = (saldoDevedor: number, taxaMora: number, diasAtraso: number): number => {
    if (diasAtraso <= 0 || taxaMora <= 0) return 0;
    return saldoDevedor * (taxaMora / 100) * diasAtraso;
  };

  const loadData = async () => {
    const { data: { session: __s } } = await supabase.auth.getSession();
    const user = __s?.user;
    if (!user) return;

    // RPC paginada — RLS aplica-se automaticamente (SECURITY INVOKER)
    const { data, error } = await (supabase as any).rpc("list_emprestimos_pagamentos_paginated", {
      p_search: debouncedSearch || "",
      p_page: page,
      p_page_size: PAGE_SIZE,
    });

    if (error) {
      console.error("Erro ao carregar empréstimos:", error);
      return;
    }

    const rows: any[] = data?.rows || [];
    setTotalEmprestimos(data?.total || 0);

    const emprestimosComMora = rows.map((emp: any) => {
      const saldoDevedor = emp.valor_total - emp.valor_pago;
      const diasAtrasoBruto = calcularDiasAtraso(emp.data_reembolso);
      const taxa = Number(emp.taxa_mora || 0);
      const moraPaga = Number(emp.mora_paga || 0);
      const jurosMoraBruto = calcularJurosMora(saldoDevedor, taxa, diasAtrasoBruto);
      // Desconta automaticamente a mora já paga
      const jurosMora = Math.max(0, jurosMoraBruto - moraPaga);
      // Reduz dias de atraso visíveis proporcionalmente ao que já foi pago
      const moraDiaria = saldoDevedor * (taxa / 100);
      const diasAtraso = (moraDiaria > 0 && jurosMora > 0)
        ? Math.max(0, Math.ceil(jurosMora / moraDiaria))
        : (jurosMora <= 0 ? 0 : diasAtrasoBruto);
      return {
        ...emp,
        clientes: {
          nome_completo: emp.nome_completo,
          telefone: emp.telefone,
          email: emp.email,
          provincia: emp.provincia,
        },
        diasAtraso,
        jurosMora,
        moraPaga,
        saldoDevedorTotal: saldoDevedor + jurosMora,
      };
    });

    setEmprestimosAtivos(emprestimosComMora as Emprestimo[]);

    // Histórico de pagamentos só dos empréstimos visíveis (com nome do autor)
    const ids = rows.map((e: any) => e.id);
    if (ids.length > 0) {
      const { data: pagamentosData } = await supabase
        .from("pagamentos")
        .select("id, emprestimo_id, valor, data_pagamento, tipo, metodo_pagamento, codigo_transacao, agente_id, usuario_mae_id, created_at")
        .in("emprestimo_id", ids)
        .order("data_pagamento", { ascending: false })
        .limit(200);
      if (pagamentosData && pagamentosData.length > 0) {
        const autorIds = Array.from(new Set(
          pagamentosData.map((p: any) => p.agente_id || p.usuario_mae_id).filter(Boolean)
        ));
        let perfis: Record<string, { nome: string; role: string }> = {};
        if (autorIds.length > 0) {
          const { data: profs } = await supabase
            .from("user_profiles")
            .select("user_id, full_name, role")
            .in("user_id", autorIds as string[]);
          (profs || []).forEach((p: any) => {
            perfis[p.user_id] = { nome: p.full_name, role: p.role };
          });
        }
        const enriched = pagamentosData.map((p: any) => {
          const autorId = p.agente_id || p.usuario_mae_id;
          const info = autorId ? perfis[autorId] : null;
          return { ...p, registado_por_nome: info?.nome || "—", registado_por_role: info?.role || "" };
        });
        setPagamentos(enriched);
      } else {
        setPagamentos([]);
      }
    } else {
      setPagamentos([]);
    }
  };

  // Carrega TODOS os empréstimos com pagamentos (totais ou parciais), 200 mais recentes.
  // Só quando a aba "Pagos" é aberta, para não pesar o load principal.
  const loadEmprestimosPagos = async () => {
    setLoadingPagos(true);
    try {
      let q = supabase
        .from("emprestimos")
        .select("id, cliente_id, valor, taxa_juros, taxa_mora, duracao_meses, data_desembolso, data_reembolso, valor_total, parcela_mensal, valor_pago, status, tipo_juros, modalidade_desembolso, modalidade_reembolso, tipo_garantia, detalhes_garantia, observacoes, created_at, clientes(nome_completo, telefone, email, provincia)")
        .gt("valor_pago", 0)
        .order("created_at", { ascending: false })
        .limit(200);
      const { data } = await q;
      setEmprestimosPagos((data as any) || []);
    } finally {
      setLoadingPagos(false);
    }
  };

  useEffect(() => {
    if (aba === "pagos") loadEmprestimosPagos();
  }, [aba]);

  useRealtimeRefresh(["emprestimos", "pagamentos", "clientes", "contas_financeiras", "movimentos_conta"], () => {
    loadData();
    if (aba === "pagos") loadEmprestimosPagos();
    refetchContas();
  }, true, 900);

  const getSaldoDevedor = (emprestimoId: string): number => {
    const emprestimo = emprestimosAtivos.find(e => e.id === emprestimoId);
    if (!emprestimo) return 0;
    return emprestimo.valor_total - emprestimo.valor_pago;
  };

  // Obter saldo devedor total incluindo juros de mora
  const getSaldoDevedorTotal = (emprestimoId: string): number => {
    const emprestimo = emprestimosAtivos.find(e => e.id === emprestimoId);
    if (!emprestimo) return 0;
    return emprestimo.saldoDevedorTotal || (emprestimo.valor_total - emprestimo.valor_pago);
  };

  // Obter juros de mora do empréstimo
  const getJurosMora = (emprestimoId: string): number => {
    const emprestimo = emprestimosAtivos.find(e => e.id === emprestimoId);
    return emprestimo?.jurosMora || 0;
  };

  // Obter dias de atraso
  const getDiasAtraso = (emprestimoId: string): number => {
    const emprestimo = emprestimosAtivos.find(e => e.id === emprestimoId);
    return emprestimo?.diasAtraso || 0;
  };

  // Recalcula valor_pago do empréstimo somando os pagamentos reais na BD.
  // Fonte de verdade: tabela `pagamentos` (exclui 'Juros Mora' e 'Juros' que não abatem ao saldo).
  // Usar sempre após insert/update/delete para evitar dessincronização.
  const recomputeValorPago = async (emprestimoIdLocal: string, valorTotal: number) => {
    const { data: pgs, error } = await supabase
      .from("pagamentos")
      .select("valor, tipo")
      .eq("emprestimo_id", emprestimoIdLocal);
    if (error) {
      console.error("Erro ao recalcular valor_pago:", error);
      return null;
    }
    const soma = (pgs || [])
      .filter((p: any) => p.tipo !== 'Juros Mora' && p.tipo !== 'Juros')
      .reduce((s: number, p: any) => s + Number(p.valor || 0), 0);
    const novoValorPago = Math.max(0, soma);
    const novoStatus = novoValorPago >= valorTotal ? "Pago" : "Ativo";
    const { error: upErr } = await supabase
      .from("emprestimos")
      .update({ valor_pago: novoValorPago, status: novoStatus })
      .eq("id", emprestimoIdLocal);
    if (upErr) {
      console.error("Erro ao actualizar valor_pago:", upErr);
      return null;
    }
    return novoValorPago;
  };


  const handleSubmit = async () => {
    try {
      if (!emprestimoId || !valorPagamento) {
        toast.error("Preencha todos os campos obrigatórios!");
        return;
      }

      const valorPago = parseFloat(valorPagamento.replace(',', '.'));
      
      if (isNaN(valorPago) || valorPago <= 0) {
        toast.error("Valor do pagamento inválido!");
        return;
      }

      const emprestimo = emprestimosAtivos.find(e => e.id === emprestimoId);
      if (!emprestimo) {
        toast.error("Empréstimo não encontrado!");
        return;
      }

      const saldoDevedorTotal = getSaldoDevedorTotal(emprestimoId);
      const jurosMora = getJurosMora(emprestimoId);
      
      // Validar se o pagamento não excede o saldo devedor total (incluindo juros de mora)
      if (tipoPagamento === "normal" && valorPago > saldoDevedorTotal) {
        toast.error(`O valor do pagamento não pode exceder o saldo devedor total de ${formatCurrency(saldoDevedorTotal)}!`);
        return;
      }

      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      
      if (!user) {
        toast.error("Usuário não autenticado!");
        return;
      }

      // Buscar perfil do usuário para obter usuario_mae_id
      const { data: userProfile } = await supabase
        .from("user_profiles")
        .select("usuario_mae_id")
        .eq("user_id", user.id)
        .single();

      const contaId = metodoReembolso !== 'cash' ? metodoReembolso : null;
      const contaNome = contaId ? contas.find(c => c.id === contaId)?.nome || metodoReembolso : 'Cash';
      const obsUser = observacoes?.trim();
      const withMetodo = (texto?: string) => (texto && texto.length > 0 ? `${texto} | Método: ${contaNome}` : `Método: ${contaNome}`);

      type PagamentoInsert = {
        emprestimo_id: string;
        valor: number;
        data_pagamento: string;
        tipo: string;
        observacoes: string;
        agente_id: string | null;
        usuario_mae_id: string | null;
        conta_financeira_id: string | null;
      };

      const pagamentosParaInserir: PagamentoInsert[] = [];

      if (tipoPagamento === "juros") {
        // Pagamento de juros - registrar como tipo "Juros"
        pagamentosParaInserir.push({
          emprestimo_id: emprestimoId,
          valor: valorPago,
          data_pagamento: dataPagamento,
          tipo: 'Juros',
          observacoes: withMetodo(`Pagamento de juros - Recapitalização por +30 dias${obsUser ? ' | ' + obsUser : ''}`),
          agente_id: isAgente ? user.id : null,
          usuario_mae_id: isAgente ? userProfile?.usuario_mae_id : null,
          conta_financeira_id: contaId,
        });
      } else {
        // Pagamento normal - lógica existente
        let valorParaJurosMora = 0;
        let valorParaSaldoDevedor = valorPago;

        if (jurosMora > 0) {
          if (valorPago <= jurosMora) {
            valorParaJurosMora = valorPago;
            valorParaSaldoDevedor = 0;
          } else {
            valorParaJurosMora = jurosMora;
            valorParaSaldoDevedor = valorPago - jurosMora;
          }
        }

        if (valorParaJurosMora > 0) {
          const texto = `Pagamento de juros de mora (${emprestimo.diasAtraso || 0} dias de atraso)${obsUser ? ' | ' + obsUser : ''}`;
          pagamentosParaInserir.push({
            emprestimo_id: emprestimoId,
            valor: valorParaJurosMora,
            data_pagamento: dataPagamento,
            tipo: 'Juros Mora',
            observacoes: withMetodo(texto),
            agente_id: isAgente ? user.id : null,
            usuario_mae_id: isAgente ? userProfile?.usuario_mae_id : null,
            conta_financeira_id: contaId,
          });
        }

        if (valorParaSaldoDevedor > 0) {
          const texto = obsUser ? obsUser : undefined;
          pagamentosParaInserir.push({
            emprestimo_id: emprestimoId,
            valor: valorParaSaldoDevedor,
            data_pagamento: dataPagamento,
            tipo: 'Parcela',
            observacoes: withMetodo(texto),
            agente_id: isAgente ? user.id : null,
            usuario_mae_id: isAgente ? userProfile?.usuario_mae_id : null,
            conta_financeira_id: contaId,
          });
        }
      }

      if (pagamentosParaInserir.length === 0) {
        toast.error('Nada para registrar neste pagamento.');
        return;
      }

      const { data: insertedPagamentos, error: errorPagamento } = await supabase.from("pagamentos").insert(pagamentosParaInserir).select("id");

      if (errorPagamento) {
        console.error("Erro ao registrar pagamento:", errorPagamento);
        toast.error(`Erro ao registrar pagamento: ${errorPagamento.message}`);
        return;
      }

      // Registrar reembolso na conta financeira selecionada
      if (contaId && insertedPagamentos) {
        const totalPago = pagamentosParaInserir.reduce((sum, p) => sum + p.valor, 0);
        await registrarReembolso(contaId, totalPago, insertedPagamentos[0]?.id || '');
        refetchContas();
      }

      // Registrar atividade se for agente
      if (isAgente) {
        await supabase.rpc('registrar_atividade_agente', {
          p_agente_id: user.id,
          p_descricao: `Registrou pagamento de ${valorPago.toLocaleString('pt-MZ')} MT`
        });
      }

      if (tipoPagamento === "juros") {
        // Pagamento de juros: recapitalizar o empréstimo por +30 dias
        const novaDataDesembolso = dataPagamento;
        const novaDataReembolso = new Date(dataPagamento);
        novaDataReembolso.setDate(novaDataReembolso.getDate() + 30);

        const { error: errorRecap } = await supabase
          .from("emprestimos")
          .update({ 
            data_desembolso: novaDataDesembolso,
            data_reembolso: novaDataReembolso.toISOString().split('T')[0],
            status: "Ativo"
          })
          .eq("id", emprestimoId);

        if (errorRecap) {
          console.error("Erro ao recapitalizar:", errorRecap);
          toast.error(`Erro ao recapitalizar empréstimo: ${errorRecap.message}`);
          return;
        }

        toast.success("Pagamento de juros registrado! Empréstimo recapitalizado por +30 dias.");
      } else {
        // Pagamento normal: recalcular valor_pago a partir da soma real dos pagamentos
        const res = await recomputeValorPago(emprestimoId, emprestimo.valor_total);
        if (res === null) {
          toast.error("Erro ao actualizar valor pago do empréstimo");
          return;
        }
        toast.success("Pagamento registrado com sucesso!");
      }


      setDialogOpen(false);
      resetForm();
      await loadData();
      if (emprestimoSelecionado && emprestimoSelecionado.id === emprestimoId) {
        await verDetalhes(emprestimoSelecionado);
      }
    } catch (error: any) {
      console.error("Erro geral:", error);
      toast.error(`Erro ao processar pagamento: ${error.message}`);
    }
  };

  const resetForm = () => {
    setEmprestimoId("");
    setValorPagamento("");
    setMetodoReembolso("");
    setDataPagamento(new Date().toISOString().split('T')[0]);
    setObservacoes("");
    setTipoPagamento("normal");
  };

  const verDetalhes = async (emprestimo: Emprestimo) => {
    // Carregar pagamentos do empréstimo (com nome do autor)
    const { data: pagamentosData } = await supabase
      .from("pagamentos")
      .select("*")
      .eq("emprestimo_id", emprestimo.id)
      .order("data_pagamento", { ascending: false });

    // Reconciliar valor_pago no servidor a partir da soma real (fonte de verdade)
    let empSync = emprestimo;
    const somaReal = (pagamentosData || [])
      .filter((p: any) => p.tipo !== 'Juros Mora' && p.tipo !== 'Juros')
      .reduce((s: number, p: any) => s + Number(p.valor || 0), 0);
    if (Math.abs(somaReal - Number(emprestimo.valor_pago || 0)) > 0.001) {
      const novoStatus = somaReal >= emprestimo.valor_total ? "Pago" : "Ativo";
      await supabase
        .from("emprestimos")
        .update({ valor_pago: somaReal, status: novoStatus })
        .eq("id", emprestimo.id);
      empSync = { ...emprestimo, valor_pago: somaReal, status: novoStatus } as Emprestimo;
    }
    setEmprestimoSelecionado(empSync);

    if (pagamentosData) {
      const autorIds = Array.from(new Set(
        pagamentosData.map((p: any) => p.agente_id || p.usuario_mae_id).filter(Boolean)
      ));
      let perfis: Record<string, { nome: string; role: string }> = {};
      if (autorIds.length > 0) {
        const { data: profs } = await supabase
          .from("user_profiles")
          .select("user_id, full_name, role")
          .in("user_id", autorIds as string[]);
        (profs || []).forEach((p: any) => {
          perfis[p.user_id] = { nome: p.full_name, role: p.role };
        });
      }
      const enriched = pagamentosData.map((p: any) => {
        const autorId = p.agente_id || p.usuario_mae_id;
        const info = autorId ? perfis[autorId] : null;
        return { ...p, registado_por_nome: info?.nome || "—", registado_por_role: info?.role || "" };
      });
      setPagamentosEmprestimo(enriched as any);
    }
    setDetalhesOpen(true);
  };

  const abrirEditarPagamento = (pagamento: Pagamento) => {
    setPagamentoParaEditar(pagamento);
    setEditValor(pagamento.valor.toString());
    setEditData(pagamento.data_pagamento);
    setEditObservacoes(pagamento.observacoes || "");
    setEditDialogOpen(true);
  };

  const handleEditarPagamento = async () => {
    if (!pagamentoParaEditar || !emprestimoSelecionado) return;

    const novoValor = parseFloat(editValor.replace(',', '.'));
    
    if (isNaN(novoValor) || novoValor <= 0) {
      toast.error("Valor inválido!");
      return;
    }

    const diferencaValor = novoValor - pagamentoParaEditar.valor;

    try {
      // Atualizar pagamento
      const { error: errorPagamento } = await supabase
        .from("pagamentos")
        .update({
          valor: novoValor,
          data_pagamento: editData,
          observacoes: editObservacoes
        })
        .eq("id", pagamentoParaEditar.id);

      if (errorPagamento) {
        toast.error(`Erro ao atualizar pagamento: ${errorPagamento.message}`);
        return;
      }

      // Recalcular valor_pago a partir da soma real dos pagamentos
      let novoVPRecalc = emprestimoSelecionado.valor_pago;
      if (pagamentoParaEditar.tipo !== 'Juros Mora') {
        const res = await recomputeValorPago(emprestimoSelecionado.id, emprestimoSelecionado.valor_total);
        if (res !== null) novoVPRecalc = res;
      }

      // Ajustar saldo da conta financeira
      const contaId = (pagamentoParaEditar as any).conta_financeira_id;
      if (contaId && diferencaValor !== 0) {
        if (diferencaValor > 0) {
          // Aumentou o pagamento - registrar reembolso adicional
          await registrarReembolso(contaId, diferencaValor, pagamentoParaEditar.id);
        } else {
          // Diminuiu o pagamento - estornar a diferença
          await estornarReembolso(contaId, Math.abs(diferencaValor), pagamentoParaEditar.id);
        }
        refetchContas();
      }

      toast.success("Pagamento atualizado com sucesso!");
      setEditDialogOpen(false);
      setPagamentoParaEditar(null);
      
      await loadData();
      if (emprestimoSelecionado) {
        await verDetalhes({ ...emprestimoSelecionado, valor_pago: novoVPRecalc });
      }

    } catch (error: any) {
      toast.error(`Erro: ${error.message}`);
    }
  };

  const confirmarDeletarPagamento = (pagamento: Pagamento) => {
    setPagamentoParaDeletar(pagamento);
    setDeleteDialogOpen(true);
  };

  const handleDeletarPagamento = async () => {
    if (!pagamentoParaDeletar || !emprestimoSelecionado) return;

    try {
      // Deletar pagamento
      const { error: errorDelete } = await supabase
        .from("pagamentos")
        .delete()
        .eq("id", pagamentoParaDeletar.id);

      if (errorDelete) {
        toast.error(`Erro ao excluir pagamento: ${errorDelete.message}`);
        return;
      }

      // Recalcular valor_pago a partir da soma real dos pagamentos
      let novoVPRecalc = emprestimoSelecionado.valor_pago;
      if (pagamentoParaDeletar.tipo !== 'Juros Mora') {
        const res = await recomputeValorPago(emprestimoSelecionado.id, emprestimoSelecionado.valor_total);
        if (res !== null) novoVPRecalc = res;
      }

      // Estornar saldo da conta financeira
      const contaId = (pagamentoParaDeletar as any).conta_financeira_id;
      if (contaId) {
        await estornarReembolso(contaId, pagamentoParaDeletar.valor, pagamentoParaDeletar.id);
        refetchContas();
      }

      toast.success("Pagamento excluído e saldo devolvido com sucesso!");
      setDeleteDialogOpen(false);
      setPagamentoParaDeletar(null);
      
      await loadData();
      if (emprestimoSelecionado) {
        await verDetalhes({ ...emprestimoSelecionado, valor_pago: novoVPRecalc });
      }

    } catch (error: any) {
      toast.error(`Erro: ${error.message}`);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-MZ', {
      style: 'currency',
      currency: 'MZN',
    }).format(value);
  };

  const calcularProgresso = (emprestimo: Emprestimo) => {
    return (emprestimo.valor_pago / emprestimo.valor_total) * 100;
  };

  const totalReceber = emprestimosAtivos.reduce((sum, e) => sum + (e.saldoDevedorTotal || (e.valor_total - e.valor_pago)), 0);
  const totalJurosMora = emprestimosAtivos.reduce((sum, e) => sum + (e.jurosMora || 0), 0);
  const totalRecebido = emprestimosAtivos.reduce((sum, e) => sum + e.valor_pago, 0);

  // Server-side search; usar a lista atual diretamente
  const filteredEmprestimosAtivos = emprestimosAtivos;

  // Filter by client search in form (mantém em memória — só na página atual)
  const filteredForForm = useMemo(() => {
    if (clienteSearch.length < 3) return emprestimosAtivos;
    return emprestimosAtivos.filter(e => e.clientes.nome_completo.toLowerCase().includes(clienteSearch.toLowerCase()));
  }, [emprestimosAtivos, clienteSearch]);

  const totalPaginas = Math.max(1, Math.ceil(totalEmprestimos / PAGE_SIZE));

  const handleExportPagamentos = () => {
    const headers = ["Cliente", "Valor Total", "Pago", "Restante", "Juros Mora", "Total c/ Mora", "Status"];
    const data = emprestimosAtivos.map(e => [
      e.clientes.nome_completo,
      formatMZN(e.valor_total),
      formatMZN(e.valor_pago),
      formatMZN(e.valor_total - e.valor_pago),
      formatMZN(e.jurosMora || 0),
      formatMZN(e.saldoDevedorTotal || (e.valor_total - e.valor_pago)),
      e.status,
    ]);
    createFormattedExcel([{ headers, data }], `Pagamentos_${new Date().toISOString().split('T')[0]}.xlsx`, "Pagamentos");
    toast.success("Ficheiro exportado com sucesso!");
  };

  // Get selected empréstimo details for the form
  const selectedEmpForForm = emprestimosAtivos.find(e => e.id === emprestimoId);

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Receipt className="h-8 w-8 text-primary" />
            Gestão de Pagamentos
          </h1>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="mr-2 h-4 w-4" />Registrar Pagamento</Button>
            </DialogTrigger>
            <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Registrar Pagamento</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Procurar Cliente / Empréstimo *</Label>
                  <div className="relative" ref={(() => { const r = { current: null as HTMLDivElement | null }; return (el: HTMLDivElement | null) => { r.current = el; }; })()}>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        value={clienteSearch}
                        onChange={(e) => { 
                          setClienteSearch(e.target.value); 
                          if (e.target.value.length < 3) setEmprestimoId(""); 
                        }}
                        onFocus={() => clienteSearch.length >= 3 && setEmprestimoId("")}
                        placeholder="Digite 3 letras do nome do cliente..."
                        className="pl-10"
                      />
                    </div>
                    {clienteSearch.length >= 3 && !emprestimoId && filteredForForm.length > 0 && (
                      <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-lg max-h-60 overflow-y-auto">
                        {filteredForForm.map((emp) => (
                          <button
                            key={emp.id}
                            type="button"
                            className="w-full text-left px-3 py-2 hover:bg-accent text-sm transition-colors border-b last:border-b-0"
                            onClick={() => {
                              setEmprestimoId(emp.id);
                              setClienteSearch(emp.clientes.nome_completo);
                            }}
                          >
                            <div className="font-medium">{emp.clientes.nome_completo}</div>
                            <div className="text-xs text-muted-foreground">
                              Dívida: {formatCurrency(emp.saldoDevedorTotal || (emp.valor_total - emp.valor_pago))}
                              {emp.diasAtraso && emp.diasAtraso > 0 ? ` • ${emp.diasAtraso} dias atraso` : ''}
                            </div>
                          </button>
                        ))}
                      </div>
                    )}
                    {clienteSearch.length >= 3 && !emprestimoId && filteredForForm.length === 0 && (
                      <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-lg p-3 text-sm text-muted-foreground">
                        Nenhum empréstimo encontrado para este cliente
                      </div>
                    )}
                  </div>
                  {emprestimoId && selectedEmpForForm && (
                    <div className="mt-2 p-2 bg-muted rounded text-sm">
                      <span className="font-medium">{selectedEmpForForm.clientes.nome_completo}</span>
                      <span className="text-muted-foreground"> — Dívida: {formatCurrency(selectedEmpForForm.saldoDevedorTotal || (selectedEmpForForm.valor_total - selectedEmpForForm.valor_pago))}</span>
                    </div>
                  )}
                </div>

                {emprestimoId && (
                  <Collapsible defaultOpen>
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" className="w-full justify-between p-2 h-auto">
                        <span className="font-semibold text-xs">Detalhes do Empréstimo</span>
                        <ChevronDown className="h-4 w-4 transition-transform" />
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <div className="space-y-3 pt-2">
                        <div>
                          <Label className="text-xs">Tipo de Pagamento *</Label>
                          <Select value={tipoPagamento} onValueChange={(val: "normal" | "juros") => {
                            setTipoPagamento(val);
                            if (val === "juros") {
                              const emp = emprestimosAtivos.find(e => e.id === emprestimoId);
                              if (emp) {
                                const jurosVal = emp.valor * (emp.taxa_juros / 100);
                                setValorPagamento(jurosVal.toFixed(2));
                              }
                            } else {
                              // Auto-fill with current installment value
                              if (selectedEmpForForm) {
                                const sistema = (selectedEmpForForm as any).sistema_amortizacao || 'price';
                                if (selectedEmpForForm.duracao_meses > 1 && selectedEmpForForm.tipo_juros === 'Composto') {
                                  const parcelas = gerarTabelaAmortizacao(
                                    selectedEmpForForm.valor, selectedEmpForForm.taxa_juros,
                                    selectedEmpForForm.duracao_meses, selectedEmpForForm.modalidade_reembolso,
                                    selectedEmpForForm.data_desembolso, sistema, selectedEmpForForm.tipo_juros
                                  );
                                  const parcelaAtual = getParcelaAtual(parcelas, selectedEmpForForm.valor_pago);
                                  const parcela = parcelas.find(p => p.numero === parcelaAtual);
                                  if (parcela) setValorPagamento(parcela.prestacao.toFixed(2));
                                } else {
                                  setValorPagamento(selectedEmpForForm.parcela_mensal.toFixed(2));
                                }
                              } else {
                                setValorPagamento("");
                              }
                            }
                          }}>
                            <SelectTrigger className="h-8 text-xs">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="normal">Pagamento Normal (Capital + Juros)</SelectItem>
                              <SelectItem value="juros">Pagamento de Juros (Recapitaliza +30 dias)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {tipoPagamento === "juros" && (
                          <div className="p-2 bg-blue-50 dark:bg-blue-950 rounded border border-blue-200 dark:border-blue-800">
                            <p className="text-xs text-blue-700 dark:text-blue-300">
                              ℹ️ O empréstimo será recapitalizado por +30 dias.
                            </p>
                          </div>
                        )}

                        <div className="p-2 bg-muted rounded text-xs space-y-1">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Saldo devedor:</span>
                            <span className="font-medium">{formatCurrency(getSaldoDevedor(emprestimoId))}</span>
                          </div>

                          {selectedEmpForForm && (() => {
                            const sistema = (selectedEmpForForm as any).sistema_amortizacao || 'price';
                            const showSchedule = selectedEmpForForm.duracao_meses > 1 && selectedEmpForForm.tipo_juros === 'Composto';
                            
                            if (showSchedule) {
                              const parcelas = gerarTabelaAmortizacao(
                                selectedEmpForForm.valor, selectedEmpForForm.taxa_juros,
                                selectedEmpForForm.duracao_meses, selectedEmpForForm.modalidade_reembolso,
                                selectedEmpForForm.data_desembolso, sistema, selectedEmpForForm.tipo_juros
                              );
                              const parcelaAtual = getParcelaAtual(parcelas, selectedEmpForForm.valor_pago);
                              const parcela = parcelas.find(p => p.numero === parcelaAtual);
                              
                              return (
                                <>
                                  <div className="flex justify-between">
                                    <span className="text-muted-foreground">Sistema:</span>
                                    <span className="font-medium">{formatSistema(sistema)}</span>
                                  </div>
                                  {parcela && (
                                    <>
                                      <div className="flex justify-between text-primary font-semibold">
                                        <span>Parcela {parcela.numero}/{parcelas.length}:</span>
                                        <span>{formatCurrency(parcela.prestacao)}</span>
                                      </div>
                                      <div className="flex justify-between text-muted-foreground">
                                        <span>  Capital: {formatCurrency(parcela.amortizacao)}</span>
                                        <span>Juros: {formatCurrency(parcela.juros)}</span>
                                      </div>
                                      <div className="flex justify-between text-muted-foreground">
                                        <span>Vencimento:</span>
                                        <span>{new Date(parcela.dataVencimento).toLocaleDateString('pt-MZ')}</span>
                                      </div>
                                    </>
                                  )}
                                </>
                              );
                            }
                            
                            return (
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Prestação ({
                                  selectedEmpForForm.modalidade_reembolso === 'diaria' ? 'diária' :
                                  selectedEmpForForm.modalidade_reembolso === 'semanal' ? 'semanal' :
                                  selectedEmpForForm.modalidade_reembolso === 'quinzenal' ? 'quinzenal' : 'mensal'
                                }):</span>
                                <span className="font-medium text-primary">{formatCurrency(selectedEmpForForm.parcela_mensal)}</span>
                              </div>
                            );
                          })()}
                          
                          {getDiasAtraso(emprestimoId) > 0 && (
                            <>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Dias de atraso:</span>
                                <span className="font-medium text-destructive">{getDiasAtraso(emprestimoId)} dias</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Juros de mora:</span>
                                <span className="font-medium text-destructive">{formatCurrency(getJurosMora(emprestimoId))}</span>
                              </div>
                              <div className="border-t pt-1">
                                <div className="flex justify-between font-semibold">
                                  <span>Total a pagar (com mora):</span>
                                  <span className="text-warning">{formatCurrency((() => {
                                    let prestacao = selectedEmpForForm?.parcela_mensal || 0;
                                    if (selectedEmpForForm && selectedEmpForForm.duracao_meses > 1 && selectedEmpForForm.tipo_juros === 'Composto') {
                                      const sistema = (selectedEmpForForm as any).sistema_amortizacao || 'price';
                                      const parcelas = gerarTabelaAmortizacao(
                                        selectedEmpForForm.valor, selectedEmpForForm.taxa_juros,
                                        selectedEmpForForm.duracao_meses, selectedEmpForForm.modalidade_reembolso,
                                        selectedEmpForForm.data_desembolso, sistema, selectedEmpForForm.tipo_juros
                                      );
                                      const parcelaAtual = getParcelaAtual(parcelas, selectedEmpForForm.valor_pago);
                                      const p = parcelas.find(x => x.numero === parcelaAtual);
                                      if (p) prestacao = p.prestacao;
                                    }
                                    const saldoRestante = getSaldoDevedor(emprestimoId);
                                    return Math.min(prestacao, saldoRestante) + getJurosMora(emprestimoId);
                                  })())}</span>
                                </div>
                              </div>
                            </>
                          )}
                          
                          {getDiasAtraso(emprestimoId) === 0 && (
                            <div className="flex justify-between font-semibold">
                              <span>Total a pagar:</span>
                              <span className="text-warning">{formatCurrency(getSaldoDevedor(emprestimoId))}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                )}

                <div>
                  <Label>Valor do Pagamento (MT) *</Label>
                  <Input
                    type="number"
                    value={valorPagamento}
                    onChange={(e) => setValorPagamento(e.target.value)}
                    placeholder="0"
                    max={emprestimoId ? getSaldoDevedorTotal(emprestimoId) : undefined}
                  />
                  {emprestimoId && parseFloat(valorPagamento) > getSaldoDevedorTotal(emprestimoId) && (
                    <p className="text-xs text-destructive mt-1">
                      O valor não pode exceder {formatCurrency(getSaldoDevedorTotal(emprestimoId))}
                    </p>
                  )}
                </div>

                <div>
                  <Label>Método de Reembolso (Banco/Carteira) *</Label>
                  <Select value={metodoReembolso} onValueChange={setMetodoReembolso}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o banco ou carteira" />
                    </SelectTrigger>
                    <SelectContent>
                      {contas.map((conta) => (
                        <SelectItem key={conta.id} value={conta.id}>
                          {conta.nome} - {new Intl.NumberFormat("pt-MZ", { style: "currency", currency: "MZN", minimumFractionDigits: 0 }).format(conta.saldo_contabilistico)} contab.
                        </SelectItem>
                      ))}
                      <SelectItem value="cash">Cash (sem conta)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Collapsible>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-2 h-auto">
                      <span className="text-sm text-muted-foreground">Data e Observações</span>
                      <ChevronDown className="h-4 w-4 transition-transform" />
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <div className="space-y-4 pt-2">
                      <div>
                        <Label>Data do Pagamento</Label>
                        <Input
                          type="date"
                          value={dataPagamento}
                          onChange={(e) => setDataPagamento(e.target.value)}
                        />
                      </div>

                      <div>
                        <Label>Observações (Opcional)</Label>
                        <Textarea
                          value={observacoes}
                          onChange={(e) => setObservacoes(e.target.value)}
                          placeholder="Observações sobre o pagamento..."
                          rows={3}
                        />
                      </div>
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                <Button 
                  onClick={handleSubmit} 
                  className="w-full"
                  disabled={!emprestimoId || !valorPagamento || (emprestimoId && parseFloat(valorPagamento) > getSaldoDevedorTotal(emprestimoId))}
                >
                  Registrar Pagamento
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Cards de Resumo */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total a Receber (c/ Mora)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-warning">{formatCurrency(totalReceber)}</div>
              {totalJurosMora > 0 && (
                <p className="text-xs text-destructive mt-1">
                  Inclui {formatCurrency(totalJurosMora)} de juros de mora
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Juros de Mora</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">{formatCurrency(totalJurosMora)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Recebido</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">{formatCurrency(totalRecebido)}</div>
            </CardContent>
          </Card>
        </div>

        {/* Search + Download */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Pesquisar pagamentos por nome do cliente..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline" onClick={handleExportPagamentos}>
            <Download className="h-4 w-4 mr-2" /> Exportar Excel
          </Button>
        </div>

        {/* Abas: Empréstimos (Ativos/Vencidos/Pagos) e Histórico Permanente de Recibos */}
        <Tabs value={aba} onValueChange={(v) => setAba(v as any)} className="w-full">
          <TabsList className="grid w-full grid-cols-3 h-auto">
            <TabsTrigger value="ativos" className="text-xs sm:text-sm">Ativos & Vencidos</TabsTrigger>
            <TabsTrigger value="pagos" className="text-xs sm:text-sm">Empréstimos Pagos</TabsTrigger>
            <TabsTrigger value="arquivados" className="text-xs sm:text-sm">Histórico Permanente</TabsTrigger>
          </TabsList>

          <TabsContent value="ativos">
            <Card>
              <CardHeader>
                <CardTitle>Empréstimos (Ativos e Vencidos)</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Valor Total</TableHead>
                      <TableHead>Pago</TableHead>
                      <TableHead>Restante</TableHead>
                      <TableHead>Juros Mora</TableHead>
                      <TableHead>Total c/ Mora</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredEmprestimosAtivos.map((emp) => (
                      <TableRow key={emp.id} className={emp.diasAtraso && emp.diasAtraso > 0 ? "bg-destructive/10" : ""}>
                        <TableCell className="font-medium">
                          {emp.clientes.nome_completo}
                          {emp.diasAtraso && emp.diasAtraso > 0 ? (
                            <Badge variant="destructive" className="ml-2 text-xs">
                              {emp.diasAtraso} dias atraso
                            </Badge>
                          ) : null}
                        </TableCell>
                        <TableCell>{formatCurrency(emp.valor_total)}</TableCell>
                        <TableCell className="text-success">{formatCurrency(emp.valor_pago)}</TableCell>
                        <TableCell className="text-warning">{formatCurrency(emp.valor_total - emp.valor_pago)}</TableCell>
                        <TableCell className={emp.jurosMora && emp.jurosMora > 0 ? "text-destructive font-medium" : ""}>
                          {emp.jurosMora && emp.jurosMora > 0 ? formatCurrency(emp.jurosMora) : '-'}
                        </TableCell>
                        <TableCell className="font-bold">
                          {formatCurrency(emp.saldoDevedorTotal || (emp.valor_total - emp.valor_pago))}
                        </TableCell>
                        <TableCell>
                          <Badge className={emp.status === 'Vencido' || emp.status === 'Atrasado' ? "bg-destructive" : "bg-success"}>
                            {emp.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" onClick={() => verDetalhes(emp)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                <div className="flex items-center justify-between mt-4 pt-4 border-t">
                  <div className="text-sm text-muted-foreground">
                    {totalEmprestimos > 0
                      ? `Página ${page} de ${totalPaginas} • ${totalEmprestimos.toLocaleString('pt-MZ')} empréstimos`
                      : 'Nenhum empréstimo'}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => Math.max(1, p - 1))}>
                      Anterior
                    </Button>
                    <Button variant="outline" size="sm" disabled={page >= totalPaginas} onClick={() => setPage(p => Math.min(totalPaginas, p + 1))}>
                      Próxima
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pagos">
            <Card>
              <CardHeader>
                <CardTitle>Histórico - Empréstimos Pagos</CardTitle>
                <p className="text-sm text-muted-foreground">Todos os empréstimos com pagamentos registados (totais e parciais) — últimos 200.</p>
              </CardHeader>
              <CardContent>
                {loadingPagos ? (
                  <div className="text-center py-8 text-muted-foreground text-sm">A carregar...</div>
                ) : emprestimosPagos.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground text-sm">Nenhum pagamento registado ainda.</div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Cliente</TableHead>
                        <TableHead>Valor</TableHead>
                        <TableHead>Total a Pagar</TableHead>
                        <TableHead>Total Pago</TableHead>
                        <TableHead>Capital Pago</TableHead>
                        <TableHead>Juros Pagos</TableHead>
                        <TableHead>Em Dívida</TableHead>
                        <TableHead>Progresso</TableHead>
                        <TableHead>Data Reembolso</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {emprestimosPagos
                        .filter((e) => !debouncedSearch || e.clientes?.nome_completo?.toLowerCase().includes(debouncedSearch.toLowerCase()))
                        .map((emp) => {
                        const d = decomporPagamento(emp);
                        const total = d.total;
                        const pago = d.pago;
                        const divida = d.divida;
                        const pct = d.pct;
                        const liquidado = d.liquidado;
                        const vencido = !liquidado && emp.data_reembolso && new Date(emp.data_reembolso) < new Date();
                        return (
                        <TableRow key={emp.id}>
                          <TableCell className="font-medium">{emp.clientes?.nome_completo}</TableCell>
                          <TableCell>{formatCurrency(emp.valor)}</TableCell>
                          <TableCell>{formatCurrency(total)}</TableCell>
                          <TableCell className="text-success font-semibold">{formatCurrency(pago)}</TableCell>
                          <TableCell className="text-primary">{formatCurrency(d.capitalPago)}</TableCell>
                          <TableCell className="text-warning">{formatCurrency(d.jurosPagos)}</TableCell>

                          <TableCell className={divida > 0 ? "text-destructive font-semibold" : "text-muted-foreground"}>
                            {formatCurrency(divida)}
                          </TableCell>
                          <TableCell className="min-w-[110px]">
                            <div className="flex items-center gap-2">
                              <div className="h-2 w-16 rounded-full bg-muted overflow-hidden">
                                <div
                                  className={`h-full ${liquidado ? "bg-success" : "bg-warning"}`}
                                  style={{ width: `${pct}%` }}
                                />
                              </div>
                              <span className="text-xs text-muted-foreground">{pct.toFixed(0)}%</span>
                            </div>
                          </TableCell>
                          <TableCell>{emp.data_reembolso ? new Date(emp.data_reembolso).toLocaleDateString('pt-PT') : "—"}</TableCell>
                          <TableCell>
                            {liquidado ? (
                              <Badge className="bg-success text-success-foreground">Pago na totalidade</Badge>
                            ) : vencido ? (
                              <Badge variant="destructive">Parcial em atraso ({pct.toFixed(0)}%)</Badge>
                            ) : (
                              <Badge className="bg-warning text-warning-foreground">Pago parcialmente ({pct.toFixed(0)}%)</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm" onClick={() => verDetalhes(emp)}>
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>


          <TabsContent value="arquivados">
            {/* Recibos arquivados — carregam sob demanda dentro do próprio componente */}
            <RecibosArquivados />
          </TabsContent>
        </Tabs>





        {/* Dialog de Detalhes */}
        <Dialog open={detalhesOpen} onOpenChange={setDetalhesOpen}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            {emprestimoSelecionado && (
              <div className="space-y-6">
                <DialogHeader>
                  <DialogTitle>Detalhes do Empréstimo</DialogTitle>
                  <p className="text-sm text-muted-foreground">
                    Empréstimo #{emprestimoSelecionado.id.substring(0, 8)}
                  </p>
                </DialogHeader>

                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <Label className="text-muted-foreground text-xs">Cliente</Label>
                    <p className="font-medium text-sm">{emprestimoSelecionado.clientes.nome_completo}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground text-xs">Telefone</Label>
                    <p className="text-sm">{emprestimoSelecionado.clientes.telefone}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground text-xs">Valor Emprestado</Label>
                    <p className="text-sm">{formatCurrency(emprestimoSelecionado.valor)}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground text-xs">Taxa de Juros</Label>
                    <p className="text-sm">{emprestimoSelecionado.taxa_juros}%</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground text-xs">Duração</Label>
                    <p className="text-sm">{emprestimoSelecionado.duracao_meses} meses</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground text-xs">Total a Pagar</Label>
                    <p className="text-sm">{formatCurrency(emprestimoSelecionado.valor_total)}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground text-xs">Mod. Reembolso</Label>
                    <p className="text-sm capitalize">{(emprestimoSelecionado as any).modalidade_reembolso || 'Mensal'}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground text-xs">Sistema</Label>
                    <p className="text-sm">{(emprestimoSelecionado as any).sistema_amortizacao === 'sac' ? 'SAC' : 'Price'}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground text-xs">Status</Label>
                    <Badge className="bg-success text-xs">{emprestimoSelecionado.status}</Badge>
                  </div>
                  <div>
                    <Label className="text-muted-foreground text-xs">Pago / Restante</Label>
                    <p className="text-sm">
                      <span className="text-success">{formatCurrency(emprestimoSelecionado.valor_pago)}</span>
                      {' / '}
                      <span className="text-warning">{formatCurrency(emprestimoSelecionado.valor_total - emprestimoSelecionado.valor_pago)}</span>
                    </p>
                  </div>
                </div>

                {/* Plano de Amortização com estado das prestações e mora */}
                {(() => {
                  const sistema: SistemaAmortizacao = (emprestimoSelecionado as any).sistema_amortizacao === 'sac' ? 'sac' : 'price';
                  const totalPagoReal = pagamentosEmprestimo
                    .filter(p => p.tipo !== 'Juros Mora' && p.tipo !== 'Juros')
                    .reduce((s, p) => s + Number(p.valor || 0), 0);
                  return (
                    <PlanoAmortizacaoDetalhado
                      valor={emprestimoSelecionado.valor}
                      taxaJuros={emprestimoSelecionado.taxa_juros}
                      duracaoMeses={emprestimoSelecionado.duracao_meses}
                      modalidadeReembolso={emprestimoSelecionado.modalidade_reembolso}
                      dataDesembolso={emprestimoSelecionado.data_desembolso}
                      sistema={sistema}
                      tipoJuros={emprestimoSelecionado.tipo_juros}
                      taxaMora={emprestimoSelecionado.taxa_mora}
                      totalPago={totalPagoReal || emprestimoSelecionado.valor_pago}
                      defaultOpen
                    />
                  );
                })()}


                {(() => {
                  const totalPagoReal = pagamentosEmprestimo
                    .filter(p => p.tipo !== 'Juros Mora' && p.tipo !== 'Juros')
                    .reduce((s, p) => s + Number(p.valor || 0), 0);
                  const saldoRestante = Math.max(0, emprestimoSelecionado.valor_total - totalPagoReal);
                  const progresso = emprestimoSelecionado.valor_total > 0
                    ? Math.min(100, (totalPagoReal / emprestimoSelecionado.valor_total) * 100)
                    : 0;
                  const diasAtraso = emprestimoSelecionado.diasAtraso ?? 0;
                  return (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Resumo Financeiro</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Total Pago:</span>
                      <span className="font-bold text-success">
                        {formatCurrency(totalPagoReal)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Saldo Restante (sem mora):</span>
                      <span className="font-bold text-warning">
                        {formatCurrency(saldoRestante)}
                      </span>
                    </div>
                    
                    {diasAtraso > 0 && (
                      <>
                        <div className="border-t pt-2">
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-muted-foreground">Dias de Atraso:</span>
                            <Badge variant="destructive">{diasAtraso} dias</Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Taxa de Mora:</span>
                            <span className="font-medium">{emprestimoSelecionado.taxa_mora || 0}% / dia</span>
                          </div>
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>Fórmula:</span>
                            <span className="font-mono">Saldo × Taxa × Dias</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Juros de Mora:</span>
                            <span className="font-bold text-destructive">
                              {formatCurrency(emprestimoSelecionado.jurosMora || 0)}
                            </span>
                          </div>
                        </div>
                        <div className="border-t pt-2 bg-destructive/10 -mx-6 px-6 py-3 -mb-4 rounded-b-lg">
                          <div className="flex justify-between">
                            <span className="font-semibold">Total a Pagar (com mora):</span>
                            <span className="text-xl font-bold text-destructive">
                              {formatCurrency(emprestimoSelecionado.saldoDevedorTotal || 0)}
                            </span>
                          </div>
                        </div>
                      </>
                    )}
                    
                    {diasAtraso === 0 && (
                      <div>
                        <Label className="text-muted-foreground mb-2 block">Progresso:</Label>
                        <Progress value={progresso} className="h-3" />
                        <p className="text-sm text-right mt-1">{progresso.toFixed(1)}%</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
                  );
                })()}

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Histórico de Pagamentos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {pagamentosEmprestimo.length > 0 && (
                      <div className="p-3 bg-muted rounded-lg mb-4 space-y-1">
                        <div className="flex justify-between">
                          <span className="text-sm font-medium">Total Pago ({pagamentosEmprestimo.length} pagamento{pagamentosEmprestimo.length > 1 ? 's' : ''}):</span>
                          <span className="font-bold text-success">{formatCurrency(pagamentosEmprestimo.reduce((s, p) => s + p.valor, 0))}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Parcelas:</span>
                          <span>{formatCurrency(pagamentosEmprestimo.filter(p => p.tipo === 'Parcela' || p.tipo === 'Amortização').reduce((s, p) => s + p.valor, 0))}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Juros:</span>
                          <span>{formatCurrency(pagamentosEmprestimo.filter(p => p.tipo === 'Juros').reduce((s, p) => s + p.valor, 0))}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Juros Mora:</span>
                          <span>{formatCurrency(pagamentosEmprestimo.filter(p => p.tipo === 'Juros Mora').reduce((s, p) => s + p.valor, 0))}</span>
                        </div>
                      </div>
                    )}
                    {pagamentosEmprestimo.length > 0 ? (
                      <div className="space-y-2">
                        {pagamentosEmprestimo.map((pag) => (
                          <div key={pag.id} className="flex justify-between items-center p-3 border rounded-lg">
                            <div className="flex-1">
                              <p className="font-medium">{formatCurrency(pag.valor)}</p>
                              <p className="text-sm text-muted-foreground">
                                {new Date(pag.data_pagamento).toLocaleDateString('pt-MZ')} - {pag.tipo}
                              </p>
                              <p className="text-xs text-primary font-medium">
                                Registado por: {(pag as any).registado_por_nome || "—"}
                                {(pag as any).registado_por_role && (
                                  <span className="text-muted-foreground capitalize"> ({(pag as any).registado_por_role})</span>
                                )}
                              </p>
                              {pag.observacoes && (
                                <p className="text-sm text-muted-foreground">{pag.observacoes}</p>
                              )}
                            </div>
                            <div className="flex gap-1">
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => abrirEditarPagamento(pag)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => confirmarDeletarPagamento(pag)}
                                className="text-destructive hover:text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => {
                                  setPagamentoSelecionado({ 
                                    ...pag, 
                                    emprestimo_id: pag.emprestimo_id,
                                    cliente_id: emprestimoSelecionado?.cliente_id,
                                    emprestimo: { 
                                      ...emprestimoSelecionado, 
                                      cliente: emprestimoSelecionado?.clientes 
                                    } 
                                  });
                                  setReciboOpen(true);
                                }}
                              >
                                <FileText className="h-4 w-4 mr-1" />
                                Recibo
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-muted-foreground text-center py-4">Nenhum pagamento registrado</p>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Dialog de Edição */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Editar Pagamento</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Valor do Pagamento (MT) *</Label>
                <Input
                  type="number"
                  value={editValor}
                  onChange={(e) => setEditValor(e.target.value)}
                  placeholder="0"
                />
              </div>

              <div>
                <Label>Data do Pagamento</Label>
                <Input
                  type="date"
                  value={editData}
                  onChange={(e) => setEditData(e.target.value)}
                />
              </div>

              <div>
                <Label>Observações</Label>
                <Textarea
                  value={editObservacoes}
                  onChange={(e) => setEditObservacoes(e.target.value)}
                  placeholder="Observações sobre o pagamento..."
                  rows={3}
                />
              </div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setEditDialogOpen(false)} className="flex-1">
                  Cancelar
                </Button>
                <Button onClick={handleEditarPagamento} className="flex-1">
                  Salvar Alterações
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Dialog de Confirmação de Exclusão */}
        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
              <AlertDialogDescription>
                Tem certeza que deseja excluir este pagamento de{' '}
                <strong>{pagamentoParaDeletar && formatCurrency(pagamentoParaDeletar.valor)}</strong>?
                Esta ação não pode ser desfeita e o saldo devedor do empréstimo será recalculado.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDeletarPagamento} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Excluir
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {pagamentoSelecionado && (
          <ReciboPagamento 
            open={reciboOpen} 
            onOpenChange={setReciboOpen} 
            pagamento={pagamentoSelecionado}
          />
        )}
      </div>
    </DashboardLayout>
  );
}
