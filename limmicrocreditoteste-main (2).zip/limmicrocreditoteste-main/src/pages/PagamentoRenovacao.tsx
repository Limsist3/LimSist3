import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeft, ShieldCheck, Copy, Loader2, MessageCircle,
  CheckCircle2, Mail, User as UserIcon, History,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";

interface Pacote { id: string; nome: string; preco: number; duracao_dias: number; }
interface Config {
  numero_mpesa: string | null; numero_emola: string | null;
  nome_titular: string | null;
  nome_titular_mpesa: string | null; nome_titular_emola: string | null;
}
interface Renovacao {
  id: string; pacote_nome: string | null; valor: number | null;
  data_fim: string; created_at: string; tipo: string;
}

const SUPORTE = "875611599";

function maskName(name: string | null): string {
  if (!name) return "•••••";
  return name.split(" ").map(w => {
    if (w.length <= 2) return w.toUpperCase();
    return w[0].toUpperCase() + "*".repeat(Math.max(3, w.length - 2)) + w[w.length - 1].toUpperCase();
  }).join(" ");
}

export default function PagamentoRenovacao() {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [pacotes, setPacotes] = useState<Pacote[]>([]);
  const [config, setConfig] = useState<Config | null>(null);
  const [historico, setHistorico] = useState<Renovacao[]>([]);
  const [isNovoUsuario, setIsNovoUsuario] = useState(false);
  const [showHistory, setShowHistory] = useState(false);


  const [userId, setUserId] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [userName, setUserName] = useState("");

  // Wizard
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [selected, setSelected] = useState<Pacote | null>(null);
  const [metodo, setMetodo] = useState<"mpesa" | "emola" | null>(null);
  const [nameInput, setNameInput] = useState("");
  const [emailInput, setEmailInput] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState<{ message: string } | null>(null);


  useEffect(() => { void load(); }, []);

  const load = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) { navigate("/auth"); return; }
    setUserId(session.user.id);
    setUserEmail(session.user.email || "");
    setEmailInput(session.user.email || "");

    const [pacotesRes, configRes, profileRes, histRes, linkRes, pagRes, cupRes] = await Promise.all([
      supabase.from("pacotes_plataforma").select("id,nome,preco,duracao_dias").eq("ativo", true).order("preco"),
      supabase.from("configuracao_pagamento").select("*").maybeSingle(),
      supabase.from("user_profiles").select("full_name,created_at,expires_at").eq("user_id", session.user.id).maybeSingle(),
      supabase.from("historico_renovacoes").select("*").eq("user_id", session.user.id).order("created_at", { ascending: false }).limit(10),
      supabase.from("link_ativacao_uso").select("id", { count: "exact", head: true }).eq("user_id", session.user.id),
      supabase.from("pagamentos_plataforma").select("id", { count: "exact", head: true }).eq("user_id", session.user.id),
      supabase.from("cupoes_acesso").select("id", { count: "exact", head: true }).eq("resgatado_por", session.user.id),
    ]);
    setPacotes((pacotesRes.data as any) || []);
    setConfig((configRes.data as any) || null);
    const prof: any = profileRes.data;
    setUserName(prof?.full_name || "");
    setNameInput(prof?.full_name || "");
    setHistorico((histRes.data as any) || []);

    // Novo usuário = nunca teve qualquer acesso (incluindo trial grátis antigo)
    const histCount = (histRes.data as any[])?.length || 0;
    const linkCount = linkRes.count || 0;
    const pagCount = pagRes.count || 0;
    const cupCount = cupRes.count || 0;
    // Trial antigo dava expires_at = created_at + 24h. Se a janela for > 25h, já houve extensão.
    let trialEstendido = false;
    if (prof?.created_at && prof?.expires_at) {
      const diffH = (new Date(prof.expires_at).getTime() - new Date(prof.created_at).getTime()) / 36e5;
      trialEstendido = diffH > 25;
    }
    setIsNovoUsuario(
      histCount === 0 && linkCount === 0 && pagCount === 0 && cupCount === 0 && !trialEstendido
    );
    setLoading(false);
  };


  const copy = (t: string) => { navigator.clipboard.writeText(t); toast.success("Copiado"); };

  const formatPrice = (v: number) => new Intl.NumberFormat("pt-PT").format(v);

  const submeter = async () => {
    if (!selected || !metodo) return;
    setSubmitting(true);
    try {
      const { data, error } = await supabase.rpc("criar_pedido_subscricao", {
        p_pacote_id: selected.id,
        p_metodo: metodo,
      });
      if (error) throw error;
      const res: any = data;
      if (res?.success) {
        void supabase.functions.invoke("notificar-pedido-superadmin", {
          body: { tipo: "subscricao", pacote: selected.nome, valor: selected.preco, metodo },
        });
        setSuccess({
          message: "Pedido submetido com sucesso. O superadministrador foi notificado e o seu acesso será activado após a confirmação do pagamento.",
        });
        toast.success("Pedido submetido!");
      } else {
        toast.error(res?.error || "Não foi possível submeter o pedido.", { duration: 7000 });
      }
    } catch (e: any) {
      toast.error(e.message || "Erro de rede. Tente novamente.");
    } finally { setSubmitting(false); }
  };


  const numero = metodo === "mpesa" ? config?.numero_mpesa : config?.numero_emola;
  const titular = metodo === "mpesa"
    ? (config?.nome_titular_mpesa || config?.nome_titular)
    : (config?.nome_titular_emola || config?.nome_titular);

  const waMsg = encodeURIComponent(
    `Olá, preciso de ajuda com pagamento.\nEmail: ${userEmail}\nPacote: ${selected?.nome || "—"} (${selected?.preco || "—"} MT)\nMétodo: ${metodo || "—"}`
  );
  const whatsappLink = `https://wa.me/258${SUPORTE}?text=${waMsg}`;

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-background">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>;
  }

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 to-background p-4">
        <Card className="max-w-md w-full text-center">
          <CardContent className="pt-8 pb-6 space-y-4">
            <div className="mx-auto w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center">
              <CheckCircle2 className="h-9 w-9 text-emerald-600" />
            </div>
            <h2 className="text-2xl font-bold">Pedido submetido!</h2>
            <p className="text-muted-foreground">{success.message}</p>
            <Button className="w-full" onClick={() => navigate("/dashboard")}>Voltar ao painel</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 p-4">
      <div className="max-w-2xl mx-auto py-6">
        <Button variant="ghost" onClick={() => step > 1 ? setStep((step - 1) as any) : navigate(-1)} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
        </Button>

        {/* STEP 1 — escolher pacote */}
        {step === 1 && (
          <>
            <div className="text-center mb-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-2">
                <ShieldCheck className="h-3.5 w-3.5" /> Validação automática rigorosa
              </div>
              <h1 className="text-2xl font-bold">Escolha o seu plano</h1>
            </div>
            <div className="flex justify-end mb-3">
              <Button variant="outline" size="sm" onClick={() => setShowHistory(!showHistory)}>
                <History className="h-4 w-4 mr-2" /> {showHistory ? "Ocultar" : "Histórico"}
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {pacotes
                .filter(p => isNovoUsuario || !/teste/i.test(p.nome))
                .map(p => (
                <Card key={p.id} className="cursor-pointer hover:border-primary hover:shadow-md transition"
                  onClick={() => { setSelected(p); setStep(2); }}>
                  <CardHeader className="text-center pb-2"><CardTitle className="text-base">{p.nome}</CardTitle></CardHeader>
                  <CardContent className="text-center space-y-2 pt-0">
                    <div><span className="text-2xl font-bold">{formatPrice(p.preco)}</span><span className="text-xs text-muted-foreground ml-1">MT</span></div>
                    <p className="text-xs text-muted-foreground">{p.duracao_dias} dias</p>
                    {/teste/i.test(p.nome) && (
                      <p className="text-[10px] text-primary font-medium">Apenas novos cadastros</p>
                    )}
                    <Button size="sm" className="w-full">Pagar</Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {showHistory && historico.length > 0 && (
              <Card className="mt-6">
                <CardHeader><CardTitle className="text-sm">Últimas renovações</CardTitle></CardHeader>
                <CardContent className="space-y-2">
                  {historico.map(h => (
                    <div key={h.id} className="flex justify-between text-sm border-b pb-2 last:border-0">
                      <span>{h.pacote_nome || "—"}</span>
                      <span className="text-muted-foreground">Até {format(new Date(h.data_fim), "dd/MM/yyyy")}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </>
        )}

        {/* STEP 2 — checkout: dados + método */}
        {step === 2 && selected && (
          <Card>
            <CardContent className="pt-6 space-y-5">
              <div className="text-center pb-4 border-b">
                <div className="mx-auto w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                  <ShieldCheck className="h-10 w-10 text-primary" />
                </div>
                <h2 className="text-xl font-bold">{selected.nome}</h2>
                <p className="text-3xl font-bold text-primary mt-1">{formatPrice(selected.preco)} MZN</p>
              </div>
              <div>
                <Label htmlFor="name" className="text-xs uppercase tracking-wider">Nome (opcional)</Label>
                <div className="relative mt-1">
                  <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input id="name" value={nameInput} onChange={e => setNameInput(e.target.value)}
                    placeholder="Seu nome completo" className="pl-9" />
                </div>
              </div>
              <div>
                <Label htmlFor="email" className="text-xs uppercase tracking-wider">Email para recebimento</Label>
                <div className="relative mt-1">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input id="email" value={emailInput} onChange={e => setEmailInput(e.target.value)}
                    placeholder="exemplo@email.com" className="pl-9" disabled />
                </div>
              </div>
              <div>
                <Label className="text-xs uppercase tracking-wider mb-2 block">Método de pagamento</Label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    disabled={!config?.numero_mpesa}
                    onClick={() => { setMetodo("mpesa"); setStep(3); }}
                    className={`relative rounded-xl border-2 p-4 text-center transition hover:scale-[1.02] disabled:opacity-50 ${
                      metodo === "mpesa" ? "border-red-400 bg-red-50" : "border-red-200 bg-red-50/50"
                    }`}>
                    <div className="text-2xl mb-1">📱</div>
                    <div className="font-bold text-red-600">m-pesa</div>
                    <div className="text-xs text-foreground/70 mt-1">Pagar com M-Pesa</div>
                  </button>
                  <button
                    type="button"
                    disabled={!config?.numero_emola}
                    onClick={() => { setMetodo("emola"); setStep(3); }}
                    className={`relative rounded-xl border-2 p-4 text-center transition hover:scale-[1.02] disabled:opacity-50 ${
                      metodo === "emola" ? "border-orange-400 bg-orange-50" : "border-orange-200 bg-orange-50/50"
                    }`}>
                    <div className="text-2xl mb-1">📱</div>
                    <div className="font-bold text-orange-600">e-Mola</div>
                    <div className="text-xs text-foreground/70 mt-1">Pagar com e-Mola</div>
                  </button>
                </div>
              </div>
              <p className="text-xs text-center text-muted-foreground flex items-center justify-center gap-1">
                <ShieldCheck className="h-3 w-3" /> Pagamento processado de forma segura via M-Pesa e eMola
              </p>
            </CardContent>
          </Card>
        )}

        {/* STEP 3 — instruções de pagamento */}
        {step === 3 && selected && metodo && (
          <Card>
            <CardContent className="pt-6 space-y-5">
              {/* Cartão de instruções estilo screenshot */}
              <div className={`rounded-2xl border-2 p-4 ${metodo === "mpesa" ? "border-red-200 bg-red-50/40" : "border-orange-200 bg-orange-50/40"}`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">📱</span>
                    <span className={`font-bold text-sm ${metodo === "mpesa" ? "text-red-600" : "text-orange-600"}`}>
                      PAGUE {formatPrice(selected.preco)} MZN PARA
                    </span>
                  </div>
                  <Badge variant="destructive" className="bg-red-500">→ TRANSFERÊNCIA</Badge>
                </div>
                <p className="font-bold text-lg tracking-wider mb-3">{maskName(titular)}</p>
                <div className="space-y-2">
                  <div className="bg-background rounded-lg p-3 flex items-center justify-between">
                    <div>
                      <p className="text-[10px] uppercase text-muted-foreground tracking-wider">Número</p>
                      <p className="font-mono font-bold text-xl">{numero}</p>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => copy(numero || "")}>
                      <Copy className="h-3 w-3 mr-1" /> Copiar
                    </Button>
                  </div>
                  <div className="bg-background rounded-lg p-3">
                    <p className="text-[10px] uppercase text-muted-foreground tracking-wider">Valor exacto</p>
                    <p className="font-bold text-xl">{formatPrice(selected.preco)} MZN</p>
                  </div>
                </div>
              </div>

              <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 text-sm">
                Após efectuar o pagamento, clique no botão <strong>Submeter pedido</strong>.
                O superadministrador será notificado automaticamente e o seu acesso será activado
                logo após a confirmação.
              </div>

              <Button size="lg" className="w-full" disabled={submitting} onClick={submeter}>
                {submitting ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> A submeter…</> :
                  <><ShieldCheck className="h-4 w-4 mr-2" /> Submeter pedido</>}
              </Button>

              <a href={whatsappLink} target="_blank" rel="noopener"
                className="flex items-center justify-center gap-2 text-sm text-emerald-600 hover:underline border-t pt-3">
                <MessageCircle className="h-4 w-4" /> Suporte WhatsApp +258 {SUPORTE}
              </a>
            </CardContent>
          </Card>
        )}

      </div>
    </div>
  );
}
