import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, CreditCard, DollarSign, Calendar, Eye, Edit, Trash2, AlertTriangle, CheckCircle2, RefreshCw, Receipt, RotateCw, Search, Download } from "lucide-react";
import { ContratoEmprestimo } from "@/components/ContratoEmprestimo";
import { GarantiasForm, GarantiaItem, garantiasToJson, jsonToGarantias } from "@/components/GarantiasForm";
import { ClientSearchInput } from "@/components/ClientSearchInput";
import { createFormattedExcel, formatMZN, formatDatePT } from "@/lib/excelExport";
import { ReciboPagamento } from "@/components/ReciboPagamento";
import { ReciboVencido } from "@/components/ReciboVencido";
import { PlanoAmortizacaoDialog } from "@/components/PlanoAmortizacaoDialog";
import { emprestimoSchema } from "@/lib/validation";
import { handleError } from "@/lib/errorHandling";
import { gerarTabelaAmortizacao, calcularTotaisAmortizacao, getParcelaAtual, formatSistema, type SistemaAmortizacao, type ParcelaAmortizacao } from "@/lib/amortization";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useUserRole } from "@/hooks/useUserRole";
import { useContasFinanceiras } from "@/hooks/useContasFinanceiras";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";
import { decomporPagamento } from "@/lib/decomporPagamento";

interface Cliente {
  id: string;
  nome_completo: string;
}

interface Emprestimo {
  id: string;
  cliente_id: string;
  clientes: { nome_completo: string; telefone?: string };
  valor: number;
  taxa_juros: number;
  taxa_mora: number;
  duracao_meses: number;
  tipo_juros: string;
  data_desembolso: string;
  data_reembolso: string;
  status: string;
  valor_total: number;
  parcela_mensal: number;
  valor_pago: number;
  modalidade_desembolso: string;
  modalidade_reembolso: string;
  tipo_garantia: string;
  detalhes_garantia: string;
  observacoes: string;
  mora_paga?: number;
}

export default function Emprestimos() {
  const { isAgente, isSecretariado } = useUserRole();
  const isReadOnly = isAgente; // Secretariado can create/edit, agente cannot
  const { contas, desembolsar, estornarDesembolso, getOrCreateSystemAccount, refetch: refetchContas } = useContasFinanceiras();
  const navigate = useNavigate();
  const [emprestimos, setEmprestimos] = useState<Emprestimo[]>([]);
  const [emprestimosVencidos, setEmprestimosVencidos] = useState<Emprestimo[]>([]);
  const [emprestimosPagos, setEmprestimosPagos] = useState<Emprestimo[]>([]);
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [confirmCreateOpen, setConfirmCreateOpen] = useState(false);
  const [pendingCreateEvent, setPendingCreateEvent] = useState<React.FormEvent | null>(null);
  const [emprestimoToDelete, setEmprestimoToDelete] = useState<string | null>(null);
  const [editingEmprestimo, setEditingEmprestimo] = useState<Emprestimo | null>(null);
  const [reciboDialogOpen, setReciboDialogOpen] = useState(false);
  const [reciboData, setReciboData] = useState<any>(null);
  const [reciboVencidoOpen, setReciboVencidoOpen] = useState(false);
  const [reciboVencidoEmprestimo, setReciboVencidoEmprestimo] = useState<any>(null);
  const [reforcoDialogOpen, setReforcoDialogOpen] = useState(false);
  const [reforcoTipo, setReforcoTipo] = useState<"acrescentar" | "reduzir">("acrescentar");
  const [reforcoValor, setReforcoValor] = useState("");
  const [reforcoContaId, setReforcoContaId] = useState("");
  const [reforcoConfirmOpen, setReforcoConfirmOpen] = useState(false);
  const [reforcoLoading, setReforcoLoading] = useState(false);

  const [clienteId, setClienteId] = useState("");
  const [valor, setValor] = useState("");
  const [taxaJuros, setTaxaJuros] = useState("");
  const [taxaMora, setTaxaMora] = useState("");
  const [duracaoMeses, setDuracaoMeses] = useState("");
  const [tipoJuros, setTipoJuros] = useState("Simples");
  const [sistemaAmortizacao, setSistemaAmortizacao] = useState<"price" | "sac">("price");
  const [modalidadeDesembolso, setModalidadeDesembolso] = useState("");
  const [modalidadeReembolso, setModalidadeReembolso] = useState("mensal");
  const [tipoGarantia, setTipoGarantia] = useState("");
  const [detalhesGarantia, setDetalhesGarantia] = useState("");
  const [garantias, setGarantias] = useState<GarantiaItem[]>([{ tipo: "", descricao: "", preco: 0 }]);
  const [dataDesembolso, setDataDesembolso] = useState("");
  const [dataReembolso, setDataReembolso] = useState("");
  const [finalidade, setFinalidade] = useState("");
  const [observacoes, setObservacoes] = useState("");
  const [contaFinanceiraId, setContaFinanceiraId] = useState("");
  const [avalistaNome, setAvalistaNome] = useState("");
  const [avalistaBi, setAvalistaBi] = useState("");
  const [avalistaTelefone, setAvalistaTelefone] = useState("");
  const [avalistaEndereco, setAvalistaEndereco] = useState("");
  const [testemunhaNome, setTestemunhaNome] = useState("");
  const [testemunhaBi, setTestemunhaBi] = useState("");
  const [custosAdministrativos, setCustosAdministrativos] = useState("");

  const PAGE_SIZE = 50;
  const [searchFilter, setSearchFilter] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [activeTab, setActiveTab] = useState<"ativos" | "vencidos" | "pagos">("ativos");
  const [pageAtivos, setPageAtivos] = useState(1);
  const [pageVencidos, setPageVencidos] = useState(1);
  const [pagePagos, setPagePagos] = useState(1);
  const [totalAtivosCount, setTotalAtivosCount] = useState(0);
  const [totalVencidosCount, setTotalVencidosCount] = useState(0);
  const [totalPagosCount, setTotalPagosCount] = useState(0);

  useEffect(() => {
    const termo = searchFilter.trim();
    // Só pesquisa quando vazio (mostra tudo) ou com 3+ caracteres — evita queries pesadas a cada tecla
    if (termo.length > 0 && termo.length < 3) return;
    const t = setTimeout(() => {
      setDebouncedSearch(termo);
      setPageAtivos(1); setPageVencidos(1); setPagePagos(1);
    }, 600);
    return () => clearTimeout(t);
  }, [searchFilter]);

  useEffect(() => {
    loadData();
  }, [isAgente, isSecretariado, activeTab, pageAtivos, pageVencidos, pagePagos, debouncedSearch]);

  useEffect(() => {
    // Capitalização automática: executa no máximo 1x por sessão, em background (não bloqueia a UI)
    if (isAgente || isSecretariado) return;
    if (sessionStorage.getItem("capitalizacao_run") === "1") return;
    sessionStorage.setItem("capitalizacao_run", "1");
    (async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session?.user) return;
        const { data } = await (supabase as any).rpc("aplicar_capitalizacao_automatica", { p_user_id: session.user.id });
        if ((data?.emprestimos_capitalizados || 0) > 0) {
          toast.info(`${data.emprestimos_capitalizados} empréstimo(s) em atraso foram capitalizados automaticamente.`);
          loadData();
        }
      } catch {
        /* silencioso — não deve afetar o funcionamento normal */
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAgente, isSecretariado]);

  useEffect(() => {
    // Calcular data de reembolso SEMPRE quando data de desembolso ou duração muda
    if (dataDesembolso && duracaoMeses) {
      const dataCalculada = calcularDataReembolso(dataDesembolso, parseInt(duracaoMeses));
      setDataReembolso(dataCalculada);
    }
  }, [dataDesembolso, duracaoMeses]);

  const loadData = async () => {
    try {
      setLoading(true);

      const { data: { session: __s } } = await supabase.auth.getSession();
      const user = __s?.user;
      if (!user) throw new Error('Usuário não autenticado');

      const currentPage = activeTab === "ativos" ? pageAtivos : activeTab === "vencidos" ? pageVencidos : pagePagos;

      const { data, error } = await (supabase as any).rpc("search_emprestimos_paginated", {
        p_status: activeTab,
        p_search: debouncedSearch || "",
        p_page: currentPage,
        p_page_size: PAGE_SIZE,
      });
      if (error) throw error;

      const rows: any[] = (data?.rows || []).map((e: any) => ({
        ...e,
        clientes: { nome_completo: e.nome_completo, telefone: e.telefone },
      }));

      if (activeTab === "ativos") {
        setEmprestimos(rows);
        setTotalAtivosCount(data?.total || 0);
      } else if (activeTab === "vencidos") {
        setEmprestimosVencidos(rows);
        setTotalVencidosCount(data?.total || 0);
      } else {
        setEmprestimosPagos(rows);
        setTotalPagosCount(data?.total || 0);
      }

      // Carregar lista mínima de clientes para o select de criação (só uma vez por sessão)
      if (clientes.length === 0) {
        const { data: cls } = await supabase
          .from("clientes")
          .select("id, nome_completo")
          .eq("bloqueado", false)
          .order("nome_completo")
          .limit(500);
        if (cls) setClientes(cls as any);
      }
    } catch (error: any) {
      const errorMsg = handleError("Load Emprestimos", error);
      toast.error(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  useRealtimeRefresh(["emprestimos", "pagamentos", "clientes", "contas_financeiras"], loadData, true, 900);

  // Processa empréstimos (separa categorias e atualiza status em background)
  const processarResultado = (clientesData: any[], allEmprestimos: any[]) => {
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);

    const idsParaVencido: string[] = [];
    const idsParaPago: string[] = [];

    for (const emp of allEmprestimos) {
      if (emp.valor_pago >= emp.valor_total && emp.status !== "Pago") {
        idsParaPago.push(emp.id);
        emp.status = "Pago";
      } else if (emp.status === "Ativo" && emp.valor_pago < emp.valor_total && emp.data_reembolso) {
        const dataReemb = new Date(emp.data_reembolso);
        dataReemb.setHours(0, 0, 0, 0);
        if (dataReemb < hoje) {
          idsParaVencido.push(emp.id);
          emp.status = "Vencido";
        }
      }
    }

    // Categorizar e atualizar UI IMEDIATAMENTE (sem esperar updates ao servidor)
    setEmprestimos(allEmprestimos.filter(emp => emp.valor_pago < emp.valor_total && emp.status === "Ativo"));
    setEmprestimosVencidos(allEmprestimos.filter(emp => emp.valor_pago < emp.valor_total && emp.status === "Vencido"));
    setEmprestimosPagos(allEmprestimos.filter(emp => emp.valor_pago >= emp.valor_total || emp.status === "Pago"));
    setClientes(clientesData);

    // Atualizar status no servidor em background (sem bloquear a UI)
    if (idsParaVencido.length > 0) {
      supabase.from("emprestimos").update({ status: "Vencido" }).in("id", idsParaVencido).then();
    }
    if (idsParaPago.length > 0) {
      supabase.from("emprestimos").update({ status: "Pago" }).in("id", idsParaPago).then();
    }
  };

  const calcularEmprestimo = (
    valorNum: number,
    taxaNum: number,
    duracaoNum: number,
    tipo: string,
    modReembolso: string = "mensal"
  ) => {
    const taxaMensal = taxaNum / 100;
    let valorTotal = 0;

    if (tipo === "Simples") {
      // Flat interest: total = principal + (principal * rate * months)
      const jurosTotal = valorNum * taxaMensal * duracaoNum;
      valorTotal = valorNum + jurosTotal;
    } else if (tipo === "SobreSaldo") {
      // Interest on remaining balance (SAC-like): sum of interest on decreasing balance
      const amortConstante = valorNum / duracaoNum;
      let saldo = valorNum;
      let totalJuros = 0;
      for (let i = 0; i < duracaoNum; i++) {
        totalJuros += saldo * taxaMensal;
        saldo -= amortConstante;
      }
      valorTotal = valorNum + totalJuros;
    } else {
      // Compound interest
      valorTotal = valorNum * Math.pow(1 + taxaMensal, duracaoNum);
    }

    // Calcular prestação conforme modalidade de reembolso
    let totalPrestacoes = duracaoNum; // mensal por padrão
    if (modReembolso === "diaria") totalPrestacoes = duracaoNum * 30;
    else if (modReembolso === "semanal") totalPrestacoes = duracaoNum * 4;
    else if (modReembolso === "quinzenal") totalPrestacoes = duracaoNum * 2;

    const parcelaMensal = valorTotal / totalPrestacoes;
    return { valorTotal, parcelaMensal, totalPrestacoes };
  };

  const calcularDataReembolso = (dataDesemb: string, duracao: number) => {
    const data = new Date(dataDesemb);
    data.setMonth(data.getMonth() + duracao);
    return data.toISOString().split('T')[0];
  };

  const handlePreSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPendingCreateEvent(e);
    setConfirmCreateOpen(true);
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
    if (!user) {
      toast.error("Usuário não autenticado");
      return;
    }

    // Validações básicas antes de qualquer consulta
    if (!clienteId) {
      toast.error("Selecione um cliente");
      return;
    }
    if (!valor || isNaN(parseFloat(valor)) || parseFloat(valor) <= 0) {
      toast.error("Informe um valor válido para o empréstimo");
      return;
    }
    if (!taxaJuros || isNaN(parseFloat(taxaJuros))) {
      toast.error("Informe a taxa de juros");
      return;
    }
    if (!duracaoMeses || isNaN(parseInt(duracaoMeses)) || parseInt(duracaoMeses) < 1) {
      toast.error("Informe a duração em meses (mínimo 1)");
      return;
    }
    if (!dataDesembolso) {
      toast.error("Informe a data de desembolso");
      return;
    }

    // Buscar perfil do usuário para obter usuario_mae_id
    const { data: userProfile } = await supabase
      .from("user_profiles")
      .select("usuario_mae_id")
      .eq("user_id", user.id)
      .maybeSingle();

    const valorNum = parseFloat(valor);
    const taxaNum = parseFloat(taxaJuros);
    const duracaoNum = parseInt(duracaoMeses);
    const taxaMoraNum = parseFloat(taxaMora) || 0;

    const { valorTotal, parcelaMensal } = calcularEmprestimo(
      valorNum,
      taxaNum,
      duracaoNum,
      tipoJuros,
      modalidadeReembolso
    );

    const dataReembolsoFinal = dataReembolso || calcularDataReembolso(dataDesembolso, duracaoNum);

    const emprestimoData: any = {
      user_id: (isSecretariado && userProfile?.usuario_mae_id) ? userProfile.usuario_mae_id : user.id,
      cliente_id: clienteId,
      valor: valorNum,
      taxa_juros: taxaNum,
      taxa_mora: taxaMoraNum,
      duracao_meses: duracaoNum,
      tipo_juros: tipoJuros,
      modalidade_desembolso: modalidadeDesembolso.trim() || null,
      modalidade_reembolso: modalidadeReembolso || 'mensal',
      sistema_amortizacao: duracaoNum > 1 ? sistemaAmortizacao : 'price',
      tipo_garantia: tipoGarantia.trim() || null,
      detalhes_garantia: garantiasToJson(garantias) || null,
      data_desembolso: dataDesembolso,
      data_reembolso: dataReembolsoFinal,
      observacoes: finalidade ? `${finalidade}${observacoes ? ' - ' + observacoes : ''}` : observacoes.trim() || null,
      valor_total: valorTotal,
      parcela_mensal: parcelaMensal,
      status: "Ativo",
      usuario_mae_id: (isAgente || isSecretariado) ? userProfile?.usuario_mae_id : user.id,
      conta_financeira_id: contaFinanceiraId || null,
      avalista_nome: avalistaNome.trim() || null,
      avalista_bi: avalistaBi.trim() || null,
      avalista_telefone: avalistaTelefone.trim() || null,
      avalista_endereco: avalistaEndereco.trim() || null,
      testemunha_nome: testemunhaNome.trim() || null,
      testemunha_bi: testemunhaBi.trim() || null,
      custos_administrativos: parseFloat(custosAdministrativos) || 0,
    };

    try {
      const { data: insertedData, error } = await supabase.from("emprestimos").insert([emprestimoData]).select("id").single();

      if (error) throw error;

      // Determine which account to use for disbursement
      let contaParaDesembolso = contaFinanceiraId;
      
      if (contaParaDesembolso) {
        // Check if selected account has enough balance
        const contaSelecionada = contas.find(c => c.id === contaParaDesembolso);
        if (contaSelecionada && contaSelecionada.saldo_disponivel < valorNum) {
          // Selected account has insufficient balance - use system account
          const systemAccount = await getOrCreateSystemAccount(user.id);
          if (systemAccount && insertedData) {
            await desembolsar(systemAccount.id, valorNum, insertedData.id);
            // Update the loan to reference the system account
            await supabase.from("emprestimos").update({ conta_financeira_id: systemAccount.id }).eq("id", insertedData.id);
          }
        } else if (insertedData) {
          await desembolsar(contaParaDesembolso, valorNum, insertedData.id);
        }
      } else {
        // No account selected - use system account automatically
        const systemAccount = await getOrCreateSystemAccount(user.id);
        if (systemAccount && insertedData) {
          await desembolsar(systemAccount.id, valorNum, insertedData.id);
          await supabase.from("emprestimos").update({ conta_financeira_id: systemAccount.id }).eq("id", insertedData.id);
        }
      }
      
      refetchContas();
      
      if (isAgente) {
        await supabase.rpc('registrar_atividade_agente', {
          p_agente_id: user.id,
          p_descricao: `Criou empréstimo de ${formatCurrency(valorNum)} para cliente`
        });
      }
      
      toast.success("Empréstimo criado com sucesso!");
      resetForm();
      loadData();
      setDialogOpen(false);
    } catch (error: any) {
      const errorMsg = handleError("Create Emprestimo", error);
      toast.error(errorMsg);
    }
  };

  const handleEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEmprestimo) return;

    // Valor solicitado NÃO pode ser editado por aqui — só via Reforço
    const valorNum = editingEmprestimo.valor;
    const taxaNum = parseFloat(taxaJuros);
    const duracaoNum = parseInt(duracaoMeses);

    const { valorTotal, parcelaMensal } = calcularEmprestimo(
      valorNum, taxaNum, duracaoNum, tipoJuros, modalidadeReembolso
    );

    const dataReembolso = calcularDataReembolso(dataDesembolso, duracaoNum);
    const taxaMoraNum = parseFloat(taxaMora) || 0;

    const emprestimoData: any = {
      cliente_id: clienteId,
      taxa_juros: taxaNum,
      taxa_mora: taxaMoraNum,
      duracao_meses: duracaoNum,
      tipo_juros: tipoJuros,
      modalidade_desembolso: modalidadeDesembolso || null,
      modalidade_reembolso: modalidadeReembolso || 'mensal',
      sistema_amortizacao: duracaoNum > 1 ? sistemaAmortizacao : 'price',
      tipo_garantia: tipoGarantia || null,
      detalhes_garantia: garantiasToJson(garantias) || null,
      data_desembolso: dataDesembolso,
      data_reembolso: dataReembolso,
      observacoes: finalidade ? `${finalidade}${observacoes ? ' - ' + observacoes : ''}` : observacoes || null,
      valor_total: valorTotal,
      parcela_mensal: parcelaMensal,
      custos_administrativos: parseFloat(custosAdministrativos) || 0,
    };

    try {
      const { error } = await supabase
        .from("emprestimos")
        .update(emprestimoData)
        .eq("id", editingEmprestimo.id);

      if (error) throw error;

      toast.success("Empréstimo atualizado com sucesso!");
      resetForm();
      loadData();
      setEditDialogOpen(false);
      setEditingEmprestimo(null);
    } catch (error: any) {
      const errorMsg = handleError("Update Emprestimo", error);
      toast.error(errorMsg);
    }
  };

  const openReforcoDialog = () => {
    if (!editingEmprestimo) return;
    setReforcoTipo("acrescentar");
    setReforcoValor("");
    setReforcoContaId((editingEmprestimo as any).conta_financeira_id || "");
    setReforcoDialogOpen(true);
  };

  const executeReforco = async () => {
    if (!editingEmprestimo) return;
    const delta = parseFloat(reforcoValor);
    if (!delta || delta <= 0) { toast.error("Informe um valor válido"); return; }
    if (!reforcoContaId) { toast.error("Selecione uma conta (banco ou carteira móvel)"); return; }

    const conta = contas.find(c => c.id === reforcoContaId);
    if (!conta) { toast.error("Conta não encontrada"); return; }

    setReforcoLoading(true);
    try {
      let novoValor = editingEmprestimo.valor;
      if (reforcoTipo === "acrescentar") {
        if (conta.saldo_disponivel < delta) {
          const systemAccount = await getOrCreateSystemAccount(conta.user_id);
          if (systemAccount) await desembolsar(systemAccount.id, delta, editingEmprestimo.id);
        } else {
          await desembolsar(reforcoContaId, delta, editingEmprestimo.id);
        }
        novoValor = editingEmprestimo.valor + delta;
      } else {
        if (delta > editingEmprestimo.valor) {
          toast.error("Redução maior que o valor do empréstimo");
          setReforcoLoading(false);
          return;
        }
        await estornarDesembolso(reforcoContaId, delta, editingEmprestimo.id);
        novoValor = editingEmprestimo.valor - delta;
      }

      const taxaNum = parseFloat(taxaJuros) || editingEmprestimo.taxa_juros;
      const duracaoNum = parseInt(duracaoMeses) || editingEmprestimo.duracao_meses;
      const { valorTotal, parcelaMensal } = calcularEmprestimo(
        novoValor, taxaNum, duracaoNum,
        tipoJuros || editingEmprestimo.tipo_juros,
        modalidadeReembolso || editingEmprestimo.modalidade_reembolso
      );

      const { error } = await supabase
        .from("emprestimos")
        .update({
          valor: novoValor,
          valor_total: valorTotal,
          parcela_mensal: parcelaMensal,
          conta_financeira_id: reforcoContaId,
        })
        .eq("id", editingEmprestimo.id);
      if (error) throw error;

      try {
        await supabase.rpc("registrar_atividade_agente" as any, {
          p_descricao: `Reforço (${reforcoTipo}) de ${formatCurrency(delta)} no empréstimo`
        });
      } catch {}

      refetchContas();
      toast.success(`Reforço aplicado! Novo valor: ${formatCurrency(novoValor)}`);
      setEditingEmprestimo({ ...editingEmprestimo, valor: novoValor, valor_total: valorTotal, parcela_mensal: parcelaMensal });
      setValor(novoValor.toString());
      setReforcoConfirmOpen(false);
      setReforcoDialogOpen(false);
      loadData();
    } catch (error: any) {
      toast.error(handleError("Reforço", error));
    } finally {
      setReforcoLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!emprestimoToDelete) return;

    try {
      // Buscar empréstimo para devolver saldo à conta
      const { data: empData } = await supabase
        .from("emprestimos")
        .select("valor, conta_financeira_id")
        .eq("id", emprestimoToDelete)
        .maybeSingle();

      // NÃO apagar pagamentos: os recibos ficam preservados como prova de pagamento.
      // Um trigger na BD marca-os como 'arquivado=true' e guarda snapshot com nome/telefone/valores.

      // Apagar arquivos associados ao empréstimo
      await supabase
        .from("arquivos")
        .delete()
        .eq("emprestimo_id", emprestimoToDelete);

      // Agora apagar o empréstimo
      const { error } = await supabase
        .from("emprestimos")
        .delete()
        .eq("id", emprestimoToDelete);

      if (error) throw error;

      // Estornar valor para conta (vai para saldo contabilístico, disponível à meia-noite)
      if (empData?.conta_financeira_id) {
        await estornarDesembolso(empData.conta_financeira_id, empData.valor, emprestimoToDelete);
        refetchContas();
      }

      toast.success("Empréstimo deletado com sucesso!");
      loadData();
      setDeleteDialogOpen(false);
      setEmprestimoToDelete(null);
    } catch (error: any) {
      const errorMsg = handleError("Delete Emprestimo", error);
      toast.error(errorMsg);
    }
  };

  const handleGerarRecibo = async (emprestimo: Emprestimo) => {
    try {
      // Buscar o último pagamento do empréstimo para ter o histórico completo
      const { data: ultimoPagamento } = await supabase
        .from("pagamentos")
        .select("*")
        .eq("emprestimo_id", emprestimo.id)
        .order("data_pagamento", { ascending: false })
        .limit(1)
        .single();

      // Buscar dados do cliente completo
      const { data: cliente } = await supabase
        .from("clientes")
        .select("*")
        .eq("id", emprestimo.cliente_id)
        .single();

      // Criar estrutura compatível com ReciboPagamento
      const reciboDados = {
        id: ultimoPagamento?.id || emprestimo.id,
        valor: ultimoPagamento?.valor || emprestimo.valor_pago,
        data_pagamento: ultimoPagamento?.data_pagamento || emprestimo.data_reembolso,
        observacoes: ultimoPagamento?.observacoes || "Empréstimo totalmente pago",
        emprestimo_id: emprestimo.id,
        cliente_id: emprestimo.cliente_id,
        emprestimo: {
          id: emprestimo.id,
          valor: emprestimo.valor,
          taxa_juros: emprestimo.taxa_juros,
          valor_total: emprestimo.valor_total,
          valor_pago: emprestimo.valor_pago,
          cliente: {
            nome_completo: cliente?.nome_completo || emprestimo.clientes?.nome_completo || "Cliente",
            telefone: cliente?.telefone || "",
          },
        },
      };

      setReciboData(reciboDados);
      setReciboDialogOpen(true);
    } catch (error) {
      console.error("Erro ao gerar recibo:", error);
      toast.error("Erro ao carregar dados do recibo");
    }
  };

  const handleReativar = async (emprestimo: Emprestimo) => {
    // Preencher o formulário com os dados do empréstimo pago
    setClienteId(emprestimo.cliente_id);
    setValor(emprestimo.valor.toString());
    setTaxaJuros(emprestimo.taxa_juros.toString());
    setTaxaMora(emprestimo.taxa_mora?.toString() || "0");
    setCustosAdministrativos(((emprestimo as any).custos_administrativos ?? 0).toString());
    setDuracaoMeses(emprestimo.duracao_meses.toString());
    setTipoJuros(emprestimo.tipo_juros);
    setModalidadeDesembolso(emprestimo.modalidade_desembolso || "");
    setModalidadeReembolso((emprestimo as any).modalidade_reembolso || "mensal");
    setSistemaAmortizacao((emprestimo as any).sistema_amortizacao || "price");
    setTipoGarantia(emprestimo.tipo_garantia || "");
    setDetalhesGarantia(emprestimo.detalhes_garantia || "");
    setGarantias(jsonToGarantias(emprestimo.detalhes_garantia));
    setDataDesembolso("");
    setDataReembolso("");
    
    // Extrair finalidade e observações
    const obsCompleto = emprestimo.observacoes || "";
    const finalidades = ["Comércio", "Consumo", "Indústria", "Serviços", "Agricultura", "Pecuária", "Outros"];
    let finalidadeExtraida = "";
    let obsExtraida = obsCompleto;
    
    for (const fin of finalidades) {
      if (obsCompleto.startsWith(fin)) {
        finalidadeExtraida = fin;
        obsExtraida = obsCompleto.replace(fin, "").replace(/^\s*-\s*/, "");
        break;
      }
    }
    
    setFinalidade(finalidadeExtraida);
    setObservacoes(obsExtraida);
    
    // Abrir o diálogo de novo empréstimo
    setDialogOpen(true);
    toast.info("Dados do empréstimo pago carregados. Ajuste conforme necessário.");
  };

  const openEditDialog = (emprestimo: Emprestimo) => {
    setEditingEmprestimo(emprestimo);
    setClienteId(emprestimo.cliente_id);
    setValor(emprestimo.valor.toString());
    setTaxaJuros(emprestimo.taxa_juros.toString());
    setTaxaMora(emprestimo.taxa_mora?.toString() || "0");
    setCustosAdministrativos(((emprestimo as any).custos_administrativos ?? 0).toString());
    setDuracaoMeses(emprestimo.duracao_meses.toString());
    setTipoJuros(emprestimo.tipo_juros);
    setModalidadeDesembolso(emprestimo.modalidade_desembolso || "");
    setModalidadeReembolso((emprestimo as any).modalidade_reembolso || "mensal");
    setSistemaAmortizacao((emprestimo as any).sistema_amortizacao || "price");
    setTipoGarantia(emprestimo.tipo_garantia || "");
    setDetalhesGarantia(emprestimo.detalhes_garantia || "");
    setGarantias(jsonToGarantias(emprestimo.detalhes_garantia));
    setDataDesembolso(emprestimo.data_desembolso);
    setDataReembolso(emprestimo.data_reembolso);
    
    // Extrair finalidade e observações do campo observacoes
    const obsCompleto = emprestimo.observacoes || "";
    const finalidades = ["Comércio", "Consumo", "Indústria", "Serviços", "Agricultura", "Pecuária", "Outros"];
    let finalidadeExtraida = "";
    let obsExtraida = obsCompleto;
    
    for (const fin of finalidades) {
      if (obsCompleto.startsWith(fin)) {
        finalidadeExtraida = fin;
        obsExtraida = obsCompleto.replace(fin, "").replace(/^\s*-\s*/, "");
        break;
      }
    }
    
    setFinalidade(finalidadeExtraida);
    setObservacoes(obsExtraida);
    setEditDialogOpen(true);
  };

  const resetForm = () => {
    setClienteId("");
    setValor("");
    setTaxaJuros("");
    setTaxaMora("");
    setCustosAdministrativos("");
    setDuracaoMeses("");
    setTipoJuros("Simples");
    setModalidadeDesembolso("");
    setModalidadeReembolso("mensal");
    setSistemaAmortizacao("price");
    setTipoGarantia("");
    setDetalhesGarantia("");
    setGarantias([{ tipo: "", descricao: "", preco: 0 }]);
    setDataDesembolso("");
    setDataReembolso("");
    setFinalidade("");
    setObservacoes("");
    setContaFinanceiraId("");
    setAvalistaNome("");
    setAvalistaBi("");
    setAvalistaTelefone("");
    setAvalistaEndereco("");
    setTestemunhaNome("");
    setTestemunhaBi("");
  };

  const [renovarConfirmOpen, setRenovarConfirmOpen] = useState(false);
  const [emprestimoToRenovar, setEmprestimoToRenovar] = useState<Emprestimo | null>(null);

  const executeRenovar30Dias = async (emprestimo: Emprestimo) => {

    try {
      const hoje = new Date();
      const novaDataDesembolso = hoje.toISOString().split('T')[0];
      const novaDataReembolso = new Date(hoje);
      novaDataReembolso.setDate(novaDataReembolso.getDate() + 30);

      const { error } = await supabase
        .from("emprestimos")
        .update({
          data_desembolso: novaDataDesembolso,
          data_reembolso: novaDataReembolso.toISOString().split('T')[0],
          status: "Ativo"
        })
        .eq("id", emprestimo.id);

      if (error) throw error;

      toast.success(`Empréstimo atualizado! Novo reembolso: ${novaDataReembolso.toLocaleDateString('pt-MZ')}`);
      await loadData();
    } catch (error: any) {
      const errorMsg = handleError("Atualizar Empréstimo +30 dias", error);
      toast.error(errorMsg);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-MZ", {
      style: "currency",
      currency: "MZN",
    }).format(value);
  };

  const calcularStatusExpiracao = (dataReembolso: string, valorPago: number, valorTotal: number, taxaMora: number, valor: number, status: string, moraPaga: number = 0) => {
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    const dataReemb = new Date(dataReembolso);
    dataReemb.setHours(0, 0, 0, 0);
    const diffTime = hoje.getTime() - dataReemb.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

    if (valorPago >= valorTotal) {
      return { expirado: false, diasExpirados: 0, jurosMora: 0, status: "Pago" };
    }

    // Se passou da data de reembolso, está vencido
    if (diffDays > 0 || status === "Vencido") {
      const saldoDevedor = valorTotal - valorPago;
      const jurosMoraBruto = (taxaMora / 100) * saldoDevedor * diffDays;
      // Desconta automaticamente a mora já paga
      const jurosMora = Math.max(0, jurosMoraBruto - (moraPaga || 0));
      const moraDiaria = saldoDevedor * (taxaMora / 100);
      const diasExpirados = (moraDiaria > 0 && jurosMora > 0)
        ? Math.max(0, Math.ceil(jurosMora / moraDiaria))
        : (jurosMora <= 0 ? 0 : diffDays);

      return {
        expirado: jurosMora > 0,
        diasExpirados,
        jurosMora,
        status: jurosMora > 0 ? "Vencido" : "Ativo"
      };
    }

    return { expirado: false, diasExpirados: 0, jurosMora: 0, status: "Ativo" };
  };

  // Server-side: já vem filtrado e paginado
  const filteredEmprestimos = emprestimos;
  const filteredVencidos = emprestimosVencidos;
  const filteredPagos = emprestimosPagos;

  const totalEmprestado = useMemo(() => emprestimos.reduce((sum, e) => sum + e.valor, 0), [emprestimos]);
  const totalReceber = useMemo(() => emprestimos.reduce((sum, e) => sum + e.valor_total, 0), [emprestimos]);
  const totalAtivos = emprestimos.length;

  const handleExportExcel = (list: Emprestimo[], titulo: string) => {
    const headers = ["Cliente", "Valor", "Taxa", "Duração", "Total", "Pago", "Status", "Data Desembolso", "Data Reembolso"];
    const data = list.map(e => [
      e.clientes?.nome_completo || "-",
      formatMZN(e.valor),
      `${e.taxa_juros}%`,
      `${e.duracao_meses} meses`,
      formatMZN(e.valor_total),
      formatMZN(e.valor_pago),
      e.status,
      e.data_desembolso ? new Date(e.data_desembolso).toLocaleDateString('pt-PT') : '-',
      e.data_reembolso ? new Date(e.data_reembolso).toLocaleDateString('pt-PT') : '-',
    ]);
    createFormattedExcel([{ headers, data }], `${titulo}_${new Date().toISOString().split('T')[0]}.xlsx`, titulo);
    toast.success("Ficheiro exportado com sucesso!");
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="p-4 md:p-6 space-y-4 md:space-y-6">



        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-3">
            <CreditCard className="h-6 w-6 md:h-8 md:w-8 text-primary" />
            {isReadOnly ? "Empréstimos dos Meus Clientes" : "Gestão de Empréstimos"}
          </h1>
          {!isReadOnly && (
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="w-full sm:w-auto">
                  <Plus className="mr-2 h-4 w-4" />
                  Novo Empréstimo
                </Button>
              </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Novo Empréstimo</DialogTitle>
              </DialogHeader>
              <form onSubmit={handlePreSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label>Cliente *</Label>
                    <ClientSearchInput
                      clientes={clientes}
                      value={clienteId}
                      onSelect={setClienteId}
                    />
                  </div>

                  <div>
                    <Label>Valor (MZN) *</Label>
                    <Input
                      type="number"
                      value={valor}
                      onChange={(e) => setValor(e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <Label>Taxa de Juros (%) *</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={taxaJuros}
                      onChange={(e) => setTaxaJuros(e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <Label>Taxa de Mora (%) *</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={taxaMora}
                      onChange={(e) => setTaxaMora(e.target.value)}
                      placeholder="Taxa aplicada após 30 dias"
                      required
        />

        <ConfirmDialog
          open={confirmCreateOpen}
          onOpenChange={(open) => { setConfirmCreateOpen(open); if (!open) setPendingCreateEvent(null); }}
          title="Confirmar criação"
          description="Tem a certeza que deseja criar este empréstimo?"
          confirmLabel="Sim, criar"
          cancelLabel="Cancelar"
          onConfirm={() => { setConfirmCreateOpen(false); handleSubmit(); }}
        />
                  </div>

                  <div>
                    <Label>Custos Administrativos (MZN)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={custosAdministrativos}
                      onChange={(e) => setCustosAdministrativos(e.target.value)}
                      placeholder="Ex: 500"
                    />
                  </div>

                  <div>
                    <Label>Duração (meses) *</Label>
                    <Input
                      type="number"
                      min="1"
                      step="1"
                      inputMode="numeric"
                      placeholder="Ex: 6"
                      value={duracaoMeses}
                      onChange={(e) => setDuracaoMeses(e.target.value.replace(/[^0-9]/g, ""))}
                      required
                    />
                  </div>


                  <div>
                    <Label>Tipo de Juros *</Label>
                    <Select value={tipoJuros} onValueChange={setTipoJuros}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Simples">Juros Simples (Flat)</SelectItem>
                        <SelectItem value="Composto">Juros Composto</SelectItem>
                        <SelectItem value="SobreSaldo">Juros sobre Saldo Devedor</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground mt-1">
                      {tipoJuros === "Simples" && "Juros calculados sobre o valor total do empréstimo, divididos igualmente"}
                      {tipoJuros === "Composto" && "Juros compostos com capitalização"}
                      {tipoJuros === "SobreSaldo" && "Juros calculados apenas sobre o saldo que falta pagar"}
                    </p>
                  </div>

                  <div>
                    <Label>Modalidade de Desembolso *</Label>
                    <Select value={contaFinanceiraId} onValueChange={(val) => {
                      setContaFinanceiraId(val);
                      const conta = contas.find(c => c.id === val);
                      if (conta) setModalidadeDesembolso(conta.nome);
                    }}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione banco/carteira" />
                      </SelectTrigger>
                      <SelectContent>
                        {contas.filter(c => c.saldo_disponivel > 0).map((conta) => (
                          <SelectItem key={conta.id} value={conta.id}>
                            {conta.nome} - {new Intl.NumberFormat("pt-MZ", { style: "currency", currency: "MZN", minimumFractionDigits: 0 }).format(conta.saldo_disponivel)} disponível
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {contaFinanceiraId && valor && (() => {
                      const conta = contas.find(c => c.id === contaFinanceiraId);
                      const valorNum = parseFloat(valor);
                      if (conta && !isNaN(valorNum) && valorNum > conta.saldo_disponivel) {
                        return <p className="text-xs text-destructive mt-1">Saldo insuficiente nesta conta!</p>;
                      }
                      return null;
                    })()}
                  </div>

                  <div>
                    <Label>Modalidade de Reembolso *</Label>
                    <Select value={modalidadeReembolso} onValueChange={setModalidadeReembolso}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="diaria">Diária</SelectItem>
                        <SelectItem value="semanal">Semanal</SelectItem>
                        <SelectItem value="quinzenal">Quinzenal</SelectItem>
                        <SelectItem value="mensal">Mensal</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {parseInt(duracaoMeses) > 1 && (tipoJuros === "Composto" || tipoJuros === "SobreSaldo") && (
                    <div className="col-span-2">
                      <Label>Sistema de Amortização *</Label>
                      <Select value={sistemaAmortizacao} onValueChange={(val: "price" | "sac") => setSistemaAmortizacao(val)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="price">Parcelas Fixas (Sistema Price)</SelectItem>
                          <SelectItem value="sac">Parcelas Variáveis (SAC - Amortização Constante)</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground mt-1">
                        {sistemaAmortizacao === 'price' 
                          ? 'Todas as prestações têm o mesmo valor' 
                          : 'A amortização é constante, os juros diminuem a cada prestação'}
                      </p>
                    </div>
                  )}

                  <div className="col-span-2">
                    <GarantiasForm garantias={garantias} onChange={setGarantias} />
                  </div>

                   <div>
                    <Label>Data de Desembolso *</Label>
                    <Input
                      type="date"
                      value={dataDesembolso}
                      onChange={(e) => setDataDesembolso(e.target.value)}
                      required
                    />
                  </div>

                   <div>
                    <Label>Data de Reembolso *</Label>
                    <Input
                      type="date"
                      value={dataReembolso}
                      onChange={(e) => setDataReembolso(e.target.value)}
                      required
                      placeholder="Será calculada automaticamente"
                    />
                  </div>

                  <div className="col-span-2">
                    <Label>Finalidade *</Label>
                    <Select value={finalidade} onValueChange={setFinalidade} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a finalidade" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Comércio">Comércio</SelectItem>
                        <SelectItem value="Consumo">Consumo</SelectItem>
                        <SelectItem value="Indústria">Indústria</SelectItem>
                        <SelectItem value="Serviços">Serviços</SelectItem>
                        <SelectItem value="Agricultura">Agricultura</SelectItem>
                        <SelectItem value="Pecuária">Pecuária</SelectItem>
                        <SelectItem value="Outros">Outros</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="col-span-2">
                    <Label>Observações</Label>
                    <Textarea
                      value={observacoes}
                      onChange={(e) => setObservacoes(e.target.value)}
                      placeholder="Observações adicionais..."
                      rows={2}
                    />
                  </div>

                  {/* Avalista */}
                  <div className="col-span-2 border-t pt-4 mt-2">
                    <p className="font-semibold text-sm mb-2">Avalista (opcional)</p>
                  </div>
                  <div>
                    <Label>Nome do Avalista</Label>
                    <Input value={avalistaNome} onChange={(e) => setAvalistaNome(e.target.value)} placeholder="Nome completo" />
                  </div>
                  <div>
                    <Label>BI do Avalista</Label>
                    <Input value={avalistaBi} onChange={(e) => setAvalistaBi(e.target.value)} placeholder="Nº do BI" />
                  </div>
                  <div>
                    <Label>Telefone do Avalista</Label>
                    <Input value={avalistaTelefone} onChange={(e) => setAvalistaTelefone(e.target.value)} placeholder="84XXXXXXX" />
                  </div>
                  <div>
                    <Label>Endereço do Avalista</Label>
                    <Input value={avalistaEndereco} onChange={(e) => setAvalistaEndereco(e.target.value)} placeholder="Endereço" />
                  </div>

                  {/* Testemunha */}
                  <div className="col-span-2 border-t pt-4 mt-2">
                    <p className="font-semibold text-sm mb-2">Testemunha (opcional)</p>
                  </div>
                  <div>
                    <Label>Nome da Testemunha</Label>
                    <Input value={testemunhaNome} onChange={(e) => setTestemunhaNome(e.target.value)} placeholder="Nome completo" />
                  </div>
                  <div>
                    <Label>BI da Testemunha</Label>
                    <Input value={testemunhaBi} onChange={(e) => setTestemunhaBi(e.target.value)} placeholder="Nº do BI" />
                  </div>
                </div>

                <Button type="submit" className="w-full">
                  Criar Empréstimo
                </Button>
              </form>
            </DialogContent>
          </Dialog>
          )}
        </div>

        {/* Cards de Resumo */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <DollarSign className="h-4 w-4" />
                Total Emprestado
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(totalEmprestado)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Total a Receber
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(totalReceber)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                Empréstimos Ativos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalAtivos}</div>
            </CardContent>
          </Card>
        </div>

        {/* Search + Download */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Digite 3 letras para pesquisar..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="pl-10"
            />
            {searchFilter.length > 0 && searchFilter.length < 3 && (
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">
                Mín. 3 letras
              </span>
            )}
          </div>
          <Button variant="outline" onClick={() => handleExportExcel([...emprestimos, ...emprestimosVencidos, ...emprestimosPagos], "Emprestimos")}>
            <Download className="h-4 w-4 mr-2" /> Exportar Excel
          </Button>
        </div>

        {/* Tabs de Empréstimos */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="ativos">Ativos ({totalAtivosCount.toLocaleString('pt-MZ')})</TabsTrigger>
            <TabsTrigger value="vencidos">Vencidos ({totalVencidosCount.toLocaleString('pt-MZ')})</TabsTrigger>
            <TabsTrigger value="pagos">Pagos ({totalPagosCount.toLocaleString('pt-MZ')})</TabsTrigger>
          </TabsList>

          <TabsContent value="ativos">
            <Card>
              <CardHeader>
                <CardTitle>Lista de Empréstimos Ativos</CardTitle>
              </CardHeader>
              <CardContent>
                {filteredEmprestimos.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    Nenhum empréstimo ativo encontrado.
                  </div>
                ) : (
              <>
                {/* Vista Mobile - Cards */}
                <div className="lg:hidden space-y-4">
                {filteredEmprestimos.map((emp) => {
                    const statusExp = calcularStatusExpiracao(emp.data_reembolso, emp.valor_pago, emp.valor_total, emp.taxa_mora, emp.valor, emp.status, emp.mora_paga);
                    return (
                      <Card key={emp.id} className={`border-l-4 ${statusExp.expirado ? 'border-l-destructive' : 'border-l-primary'}`}>
                        <CardContent className="pt-6 space-y-3">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <p className="font-semibold text-lg">{emp.clientes?.nome_completo || 'Cliente não encontrado'}</p>
                              <p className="text-sm text-muted-foreground">
                                Duração: {emp.duracao_meses} meses | Taxa: {emp.taxa_juros}%
                              </p>
                            </div>
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              statusExp.expirado ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'
                            }`}>
                              {statusExp.expirado ? (
                                <><AlertTriangle className="h-3 w-3 mr-1" />{statusExp.status}</>
                              ) : (
                                statusExp.status
                              )}
                            </span>
                          </div>
                          
                          {statusExp.expirado && (
                            <div className="bg-destructive/10 p-3 rounded-md border border-destructive/20">
                              <p className="text-xs font-semibold text-destructive mb-1">
                                ⚠️ Empréstimo Atrasado há {statusExp.diasExpirados} dias
                              </p>
                              <p className="text-xs text-muted-foreground">
                                Juros de Mora Acumulados: <span className="font-bold text-destructive">{formatCurrency(statusExp.jurosMora)}</span>
                              </p>
                              <p className="text-xs text-muted-foreground mt-1">
                                Total a Pagar (com mora): <span className="font-bold">{formatCurrency(emp.valor_total - emp.valor_pago + statusExp.jurosMora)}</span>
                              </p>
                            </div>
                          )}
                          
                          <div className="grid grid-cols-2 gap-2 pt-2 border-t">
                            <div>
                              <p className="text-xs text-muted-foreground">Valor</p>
                              <p className="font-semibold">{formatCurrency(emp.valor)}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Total</p>
                              <p className="font-semibold">{formatCurrency(emp.valor_total)}</p>
                            </div>
                            <div className="col-span-2">
                              <p className="text-xs text-muted-foreground">Data Reembolso</p>
                              <p className="text-sm">
                                {emp.data_reembolso ? new Date(emp.data_reembolso).toLocaleDateString('pt-MZ') : '-'}
                              </p>
                            </div>
                          </div>

                        <div className="flex flex-wrap gap-2 pt-2">
                          <ContratoEmprestimo emprestimoId={emp.id} />
                          <PlanoAmortizacaoDialog emprestimo={emp as any} />
                          {!isReadOnly && (
                            <>
                              <Button variant="outline" size="sm" onClick={() => { setEmprestimoToRenovar(emp); setRenovarConfirmOpen(true); }} className="flex-1">
                                <RotateCw className="h-4 w-4 mr-2" />
                                +30 dias
                              </Button>
                              <Button variant="outline" size="sm" onClick={() => openEditDialog(emp)} className="flex-1">
                                <Edit className="h-4 w-4 mr-2" />
                                Editar
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setEmprestimoToDelete(emp.id);
                                  setDeleteDialogOpen(true);
                                }}
                                className="text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                  })}
                </div>

                {/* Vista Desktop - Tabela */}
                <div className="hidden lg:block overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Cliente</TableHead>
                        <TableHead>Valor</TableHead>
                        <TableHead>Taxa</TableHead>
                        <TableHead>Duração</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Data Reembolso</TableHead>
                        <TableHead>Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                    {filteredEmprestimos.map((emp) => {
                        const statusExp = calcularStatusExpiracao(emp.data_reembolso, emp.valor_pago, emp.valor_total, emp.taxa_mora, emp.valor, emp.status, emp.mora_paga);
                        return (
                          <TableRow key={emp.id} className={statusExp.expirado ? 'bg-destructive/5' : ''}>
                            <TableCell className="font-medium">{emp.clientes?.nome_completo || 'Cliente não encontrado'}</TableCell>
                            <TableCell>{formatCurrency(emp.valor)}</TableCell>
                            <TableCell>{emp.taxa_juros}%</TableCell>
                            <TableCell>{emp.duracao_meses} meses</TableCell>
                            <TableCell>
                              <div>
                                <div>{formatCurrency(emp.valor_total)}</div>
                                {statusExp.expirado && (
                                  <div className="text-xs text-destructive mt-1">
                                    + {formatCurrency(statusExp.jurosMora)} (mora)
                                  </div>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                statusExp.expirado ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'
                              }`}>
                                {statusExp.expirado ? (
                                  <>
                                    <AlertTriangle className="h-3 w-3 mr-1" />
                                    {statusExp.status} ({statusExp.diasExpirados}d)
                                  </>
                                ) : (
                                  statusExp.status
                                )}
                              </span>
                            </TableCell>
                            <TableCell>
                              {emp.data_reembolso ? new Date(emp.data_reembolso).toLocaleDateString('pt-MZ') : '-'}
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                <ContratoEmprestimo emprestimoId={emp.id} />
                                <PlanoAmortizacaoDialog emprestimo={emp as any} compact />
                                {!isReadOnly && (
                                  <>
                                    <Button variant="ghost" size="sm" onClick={() => { setEmprestimoToRenovar(emp); setRenovarConfirmOpen(true); }} title="Atualizar +30 dias">
                                      <RotateCw className="h-4 w-4" />
                                    </Button>
                                    <Button variant="ghost" size="sm" onClick={() => openEditDialog(emp)}>
                                      <Edit className="h-4 w-4" />
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => {
                                        setEmprestimoToDelete(emp.id);
                                        setDeleteDialogOpen(true);
                                      }}
                                    >
                                      <Trash2 className="h-4 w-4 text-destructive" />
                                    </Button>
                                  </>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="vencidos">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="h-5 w-5" />
                Empréstimos Vencidos
              </CardTitle>
            </CardHeader>
            <CardContent>
              {filteredVencidos.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  Nenhum empréstimo vencido encontrado.
                </div>
              ) : (
                <>
                  {/* Vista Mobile - Cards */}
                  <div className="lg:hidden space-y-4">
                    {filteredVencidos.map((emp) => {
                      const statusExp = calcularStatusExpiracao(emp.data_reembolso, emp.valor_pago, emp.valor_total, emp.taxa_mora, emp.valor, emp.status, emp.mora_paga);
                      return (
                        <Card key={emp.id} className="border-l-4 border-l-destructive">
                          <CardContent className="pt-6 space-y-3">
                            <div className="flex items-start justify-between">
                              <div className="space-y-1">
                                <p className="font-semibold text-lg">{emp.clientes?.nome_completo || 'Cliente não encontrado'}</p>
                                <p className="text-sm text-muted-foreground">
                                  Duração: {emp.duracao_meses} meses | Taxa: {emp.taxa_juros}%
                                </p>
                              </div>
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-destructive/10 text-destructive">
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                Vencido
                              </span>
                            </div>
                            
                            <div className="bg-destructive/10 p-3 rounded-md border border-destructive/20">
                              <p className="text-xs font-semibold text-destructive mb-1">
                                ⚠️ Vencido há {statusExp.diasExpirados} dias
                              </p>
                              <p className="text-xs text-muted-foreground">
                                Juros de Mora Acumulados: <span className="font-bold text-destructive">{formatCurrency(statusExp.jurosMora)}</span>
                              </p>
                              <p className="text-xs text-muted-foreground mt-1">
                                Saldo Devedor: <span className="font-bold">{formatCurrency(emp.valor_total - emp.valor_pago)}</span>
                              </p>
                              <p className="text-xs text-muted-foreground mt-1">
                                Total a Pagar (com mora): <span className="font-bold text-destructive">{formatCurrency(emp.valor_total - emp.valor_pago + statusExp.jurosMora)}</span>
                              </p>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-2 pt-2 border-t">
                              <div>
                                <p className="text-xs text-muted-foreground">Valor Original</p>
                                <p className="font-semibold">{formatCurrency(emp.valor)}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Total</p>
                                <p className="font-semibold">{formatCurrency(emp.valor_total)}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Valor Pago</p>
                                <p className="font-semibold text-green-600">{formatCurrency(emp.valor_pago)}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Data Reembolso</p>
                                <p className="text-sm text-destructive font-semibold">
                                  {emp.data_reembolso ? new Date(emp.data_reembolso).toLocaleDateString('pt-MZ') : '-'}
                                </p>
                              </div>
                            </div>

                            <div className="flex gap-2 pt-2">
                              <Button 
                                variant="default" 
                                size="sm" 
                                onClick={() => navigate('/pagamentos')}
                                className="flex-1"
                              >
                                <Receipt className="h-4 w-4 mr-2" />
                                Registrar Pagamento
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => { setReciboVencidoEmprestimo(emp); setReciboVencidoOpen(true); }}
                                className="text-destructive"
                              >
                                <Receipt className="h-4 w-4 mr-1" />
                                Recibo Dívida
                              </Button>
                              <ContratoEmprestimo emprestimoId={emp.id} />
                              <PlanoAmortizacaoDialog emprestimo={emp as any} />
                              {!isReadOnly && (
                                <>
                                  <Button variant="outline" size="sm" onClick={() => { setEmprestimoToRenovar(emp); setRenovarConfirmOpen(true); }}>
                                    <RotateCw className="h-4 w-4 mr-1" />
                                    +30d
                                  </Button>
                                  <Button variant="outline" size="sm" onClick={() => openEditDialog(emp)}>
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setEmprestimoToDelete(emp.id);
                                      setDeleteDialogOpen(true);
                                    }}
                                    className="text-destructive"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>

                  {/* Vista Desktop - Tabela */}
                  <div className="hidden lg:block overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Cliente</TableHead>
                          <TableHead>Valor</TableHead>
                          <TableHead>Taxa</TableHead>
                          <TableHead>Total</TableHead>
                          <TableHead>Valor Pago</TableHead>
                          <TableHead>Saldo Devedor</TableHead>
                          <TableHead>Dias Vencidos</TableHead>
                          <TableHead>Juros Mora</TableHead>
                          <TableHead>Data Reembolso</TableHead>
                          <TableHead>Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredVencidos.map((emp) => {
                          const statusExp = calcularStatusExpiracao(emp.data_reembolso, emp.valor_pago, emp.valor_total, emp.taxa_mora, emp.valor, emp.status, emp.mora_paga);
                          return (
                            <TableRow key={emp.id} className="bg-destructive/5">
                              <TableCell className="font-medium">{emp.clientes?.nome_completo || 'Cliente não encontrado'}</TableCell>
                              <TableCell>{formatCurrency(emp.valor)}</TableCell>
                              <TableCell>{emp.taxa_juros}%</TableCell>
                              <TableCell>{formatCurrency(emp.valor_total)}</TableCell>
                              <TableCell className="text-green-600">{formatCurrency(emp.valor_pago)}</TableCell>
                              <TableCell className="font-semibold">{formatCurrency(emp.valor_total - emp.valor_pago)}</TableCell>
                              <TableCell>
                                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-destructive/10 text-destructive">
                                  <AlertTriangle className="h-3 w-3 mr-1" />
                                  {statusExp.diasExpirados} dias
                                </span>
                              </TableCell>
                              <TableCell className="text-destructive font-semibold">
                                {formatCurrency(statusExp.jurosMora)}
                              </TableCell>
                              <TableCell className="text-destructive font-semibold">
                                {emp.data_reembolso ? new Date(emp.data_reembolso).toLocaleDateString('pt-MZ') : '-'}
                              </TableCell>
                              <TableCell>
                                <div className="flex gap-2">
                                  <Button 
                                    variant="default" 
                                    size="sm" 
                                    onClick={() => navigate('/pagamentos')}
                                  >
                                    <Receipt className="h-4 w-4 mr-2" />
                                    Registrar Pagamento
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => { setReciboVencidoEmprestimo(emp); setReciboVencidoOpen(true); }}
                                    className="text-destructive"
                                    title="Recibo de Dívida"
                                  >
                                    <Receipt className="h-4 w-4" />
                                  </Button>
                                  <ContratoEmprestimo emprestimoId={emp.id} />
                                  <PlanoAmortizacaoDialog emprestimo={emp as any} compact />
                                  {!isReadOnly && (
                                    <>
                                      <Button variant="ghost" size="sm" onClick={() => { setEmprestimoToRenovar(emp); setRenovarConfirmOpen(true); }} title="Atualizar +30 dias">
                                        <RotateCw className="h-4 w-4" />
                                      </Button>
                                      <Button variant="ghost" size="sm" onClick={() => openEditDialog(emp)}>
                                        <Edit className="h-4 w-4" />
                                      </Button>
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => {
                                          setEmprestimoToDelete(emp.id);
                                          setDeleteDialogOpen(true);
                                        }}
                                      >
                                        <Trash2 className="h-4 w-4 text-destructive" />
                                      </Button>
                                    </>
                                  )}
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pagos">
          <Card>
            <CardHeader>
              <CardTitle>Histórico - Empréstimos Pagos</CardTitle>
            </CardHeader>
            <CardContent>
              {filteredPagos.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  Nenhum empréstimo pago encontrado.
                </div>
              ) : (
                <>
                  {/* Vista Mobile - Cards */}
                  <div className="lg:hidden space-y-4">
                    {filteredPagos.map((emp) => {
                      const d = decomporPagamento(emp);
                      return (
                      <Card key={emp.id} className="border-l-4 border-l-green-500">
                        <CardContent className="pt-6 space-y-3">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <p className="font-semibold text-lg">{emp.clientes?.nome_completo || 'Cliente não encontrado'}</p>
                              <p className="text-sm text-muted-foreground">
                                Duração: {emp.duracao_meses} meses | Taxa: {emp.taxa_juros}%
                              </p>
                            </div>
                            {d.liquidado ? (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700">
                                <CheckCircle2 className="h-3 w-3 mr-1" />
                                Pago na totalidade
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700">
                                Parcial ({d.pct.toFixed(0)}%)
                              </span>
                            )}
                          </div>
                          
                          <div className="grid grid-cols-2 gap-2 pt-2 border-t">
                            <div>
                              <p className="text-xs text-muted-foreground">Valor</p>
                              <p className="font-semibold">{formatCurrency(emp.valor)}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Total a Pagar</p>
                              <p className="font-semibold">{formatCurrency(d.total)}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Total Pago</p>
                              <p className="font-semibold text-green-600">{formatCurrency(d.pago)}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Em Dívida</p>
                              <p className={`font-semibold ${d.divida > 0.01 ? 'text-destructive' : 'text-muted-foreground'}`}>{formatCurrency(d.divida)}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Capital Pago</p>
                              <p className="font-semibold text-blue-600">{formatCurrency(d.capitalPago)}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Juros Pagos</p>
                              <p className="font-semibold text-amber-600">{formatCurrency(d.jurosPagos)}</p>
                            </div>
                            <div className="col-span-2">
                              <p className="text-xs text-muted-foreground">Data Desembolso</p>
                              <p className="text-sm">
                                {emp.data_desembolso ? new Date(emp.data_desembolso).toLocaleDateString('pt-MZ') : '-'}
                              </p>
                            </div>
                          </div>


                          <div className="flex gap-2 pt-2">
                            <ContratoEmprestimo emprestimoId={emp.id} />
                            <PlanoAmortizacaoDialog emprestimo={emp as any} />
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleGerarRecibo(emp)}
                              className="text-green-600 hover:text-green-700"
                            >
                              <Receipt className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openEditDialog(emp)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleReativar(emp)}
                              className="text-blue-600 hover:text-blue-700"
                            >
                              <RefreshCw className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setEmprestimoToDelete(emp.id);
                                setDeleteDialogOpen(true);
                              }}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                      );
                    })}
                  </div>

                  {/* Vista Desktop - Tabela */}
                  <div className="hidden lg:block overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Cliente</TableHead>
                          <TableHead>Valor</TableHead>
                          <TableHead>Taxa</TableHead>
                          <TableHead>Duração</TableHead>
                          <TableHead>Total a Pagar</TableHead>
                          <TableHead>Total Pago</TableHead>
                          <TableHead>Capital Pago</TableHead>
                          <TableHead>Juros Pagos</TableHead>
                          <TableHead>Em Dívida</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Data Desembolso</TableHead>
                          <TableHead>Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredPagos.map((emp) => {
                          const d = decomporPagamento(emp);
                          return (
                          <TableRow key={emp.id} className="bg-green-50">
                            <TableCell className="font-medium">{emp.clientes?.nome_completo || 'Cliente não encontrado'}</TableCell>
                            <TableCell>{formatCurrency(emp.valor)}</TableCell>
                            <TableCell>{emp.taxa_juros}%</TableCell>
                            <TableCell>{emp.duracao_meses} meses</TableCell>
                            <TableCell>{formatCurrency(d.total)}</TableCell>
                            <TableCell className="text-green-600 font-semibold">{formatCurrency(d.pago)}</TableCell>
                            <TableCell className="text-blue-600">{formatCurrency(d.capitalPago)}</TableCell>
                            <TableCell className="text-amber-600">{formatCurrency(d.jurosPagos)}</TableCell>
                            <TableCell className={d.divida > 0.01 ? "text-destructive font-semibold" : "text-muted-foreground"}>
                              {formatCurrency(d.divida)}
                            </TableCell>
                            <TableCell>
                              {d.liquidado ? (
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700">
                                  <CheckCircle2 className="h-3 w-3 mr-1" />
                                  Pago na totalidade
                                </span>
                              ) : (
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700">
                                  Pago parcialmente ({d.pct.toFixed(0)}%)
                                </span>
                              )}
                            </TableCell>
                            <TableCell>
                              {emp.data_desembolso ? new Date(emp.data_desembolso).toLocaleDateString('pt-MZ') : '-'}
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <ContratoEmprestimo emprestimoId={emp.id} />
                                <PlanoAmortizacaoDialog emprestimo={emp as any} compact />
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleGerarRecibo(emp)}
                                  className="text-green-600 hover:text-green-700"
                                >
                                  <Receipt className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => openEditDialog(emp)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleReativar(emp)}
                                  className="text-blue-600 hover:text-blue-700"
                                >
                                  <RefreshCw className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setEmprestimoToDelete(emp.id);
                                    setDeleteDialogOpen(true);
                                  }}
                                  className="text-destructive hover:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        {(() => {
          const total = activeTab === "ativos" ? totalAtivosCount : activeTab === "vencidos" ? totalVencidosCount : totalPagosCount;
          const cur = activeTab === "ativos" ? pageAtivos : activeTab === "vencidos" ? pageVencidos : pagePagos;
          const setCur = activeTab === "ativos" ? setPageAtivos : activeTab === "vencidos" ? setPageVencidos : setPagePagos;
          const totalP = Math.max(1, Math.ceil(total / PAGE_SIZE));
          return (
            <div className="flex items-center justify-between mt-4 px-2">
              <span className="text-sm text-muted-foreground">Página {cur} de {totalP} • {total.toLocaleString('pt-MZ')} registos</span>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled={cur <= 1} onClick={() => setCur(p => Math.max(1, p - 1))}>Anterior</Button>
                <Button variant="outline" size="sm" disabled={cur >= totalP} onClick={() => setCur(p => Math.min(totalP, p + 1))}>Próxima</Button>
              </div>
            </div>
          );
        })()}
      </Tabs>

        {/* Dialog de Edição */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Editar Empréstimo</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleEdit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                    <Label>Cliente *</Label>
                    <ClientSearchInput
                      clientes={clientes}
                      value={clienteId}
                      onSelect={setClienteId}
                    />
                  </div>

                <div className="col-span-2">
                  <Label>Valor do Empréstimo (MZN)</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      value={editingEmprestimo?.valor || valor}
                      readOnly
                      disabled
                      className="bg-muted cursor-not-allowed"
                    />
                    <Button type="button" variant="secondary" onClick={openReforcoDialog}>
                      <Plus className="w-4 h-4 mr-1" /> Reforço
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    O valor solicitado só pode ser alterado por reforço (acrescentar ou reduzir), em sintonia com banco/carteira móvel.
                  </p>
                </div>

                <div>
                  <Label>Taxa de Juros (%) *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={taxaJuros}
                    onChange={(e) => setTaxaJuros(e.target.value)}
                    required
                  />
                </div>

                <div>
                  <Label>Taxa de Mora (%) *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={taxaMora}
                    onChange={(e) => setTaxaMora(e.target.value)}
                    placeholder="Taxa aplicada após 30 dias"
                    required
                  />
                </div>

                <div>
                  <Label>Custos Administrativos (MZN)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    value={custosAdministrativos}
                    onChange={(e) => setCustosAdministrativos(e.target.value)}
                    placeholder="Ex: 500"
                  />
                </div>

                <div>
                  <Label>Duração (meses) *</Label>
                  <Input
                    type="number"
                    min="1"
                    step="1"
                    inputMode="numeric"
                    placeholder="Ex: 6"
                    value={duracaoMeses}
                    onChange={(e) => setDuracaoMeses(e.target.value.replace(/[^0-9]/g, ""))}
                    required
                  />
                </div>


                <div>
                  <Label>Tipo de Juros *</Label>
                  <Select value={tipoJuros} onValueChange={setTipoJuros}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Simples">Juros Simples (Flat)</SelectItem>
                      <SelectItem value="Composto">Juros Composto</SelectItem>
                      <SelectItem value="SobreSaldo">Juros sobre Saldo Devedor</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">
                    {tipoJuros === "Simples" && "Juros calculados sobre o valor total, divididos igualmente"}
                    {tipoJuros === "Composto" && "Juros compostos com capitalização"}
                    {tipoJuros === "SobreSaldo" && "Juros calculados apenas sobre o saldo que falta pagar"}
                  </p>
                </div>

                <div>
                  <Label>Modalidade de Desembolso</Label>
                  <Select value={modalidadeDesembolso} onValueChange={setModalidadeDesembolso}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Carteira Móvel">Carteira Móvel</SelectItem>
                      <SelectItem value="Cash">Cash</SelectItem>
                      <SelectItem value="Depósito">Depósito</SelectItem>
                      <SelectItem value="Transferência">Transferência</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Modalidade de Reembolso *</Label>
                  <Select value={modalidadeReembolso} onValueChange={setModalidadeReembolso}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="diaria">Diária</SelectItem>
                      <SelectItem value="semanal">Semanal</SelectItem>
                      <SelectItem value="quinzenal">Quinzenal</SelectItem>
                      <SelectItem value="mensal">Mensal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {parseInt(duracaoMeses) > 1 && (tipoJuros === "Composto" || tipoJuros === "SobreSaldo") && (
                  <div className="col-span-2">
                    <Label>Sistema de Amortização *</Label>
                    <Select value={sistemaAmortizacao} onValueChange={(val: "price" | "sac") => setSistemaAmortizacao(val)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="price">Parcelas Fixas (Sistema Price)</SelectItem>
                        <SelectItem value="sac">Parcelas Variáveis (SAC - Amortização Constante)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="col-span-2">
                  <GarantiasForm garantias={garantias} onChange={setGarantias} />
                </div>

                <div>
                  <Label>Data de Desembolso *</Label>
                  <Input
                    type="date"
                    value={dataDesembolso}
                    onChange={(e) => setDataDesembolso(e.target.value)}
                    required
                  />
                </div>

                <div>
                  <Label>Data de Reembolso *</Label>
                  <Input
                    type="date"
                    value={dataReembolso}
                    onChange={(e) => setDataReembolso(e.target.value)}
                    required
                  />
                </div>

                <div className="col-span-2">
                  <Label>Finalidade *</Label>
                  <Select value={finalidade} onValueChange={setFinalidade} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a finalidade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Comércio">Comércio</SelectItem>
                      <SelectItem value="Consumo">Consumo</SelectItem>
                      <SelectItem value="Indústria">Indústria</SelectItem>
                      <SelectItem value="Serviços">Serviços</SelectItem>
                      <SelectItem value="Agricultura">Agricultura</SelectItem>
                      <SelectItem value="Pecuária">Pecuária</SelectItem>
                      <SelectItem value="Outros">Outros</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="col-span-2">
                  <Label>Observações</Label>
                  <Textarea
                    value={observacoes}
                    onChange={(e) => setObservacoes(e.target.value)}
                    placeholder="Observações adicionais..."
                    rows={2}
                  />
                </div>
              </div>

              <Button type="submit" className="w-full">
                Atualizar Empréstimo
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        {/* Dialog de Confirmação de Exclusão */}
        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Tem certeza?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta ação não pode ser desfeita. O empréstimo será permanentemente deletado.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-destructive">
                Deletar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Recibo de Pagamento */}
        {reciboData && (
          <ReciboPagamento
            open={reciboDialogOpen}
            onOpenChange={setReciboDialogOpen}
            pagamento={reciboData}
          />
        )}

        {/* Recibo de Dívida Vencido */}
        {reciboVencidoEmprestimo && (
          <ReciboVencido
            open={reciboVencidoOpen}
            onOpenChange={setReciboVencidoOpen}
            emprestimo={reciboVencidoEmprestimo}
          />
        )}

        <ConfirmDialog
          open={renovarConfirmOpen}
          onOpenChange={setRenovarConfirmOpen}
          description={`Deseja atualizar o empréstimo de ${emprestimoToRenovar?.clientes?.nome_completo || ""} por mais 30 dias?`}
          confirmLabel="Atualizar"
          onConfirm={() => { if (emprestimoToRenovar) executeRenovar30Dias(emprestimoToRenovar); setRenovarConfirmOpen(false); setEmprestimoToRenovar(null); }}
        />

        {/* Diálogo de Reforço */}
        <Dialog open={reforcoDialogOpen} onOpenChange={setReforcoDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Reforço do Empréstimo</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="rounded-md bg-muted p-3 text-sm">
                Valor atual: <span className="font-semibold">{editingEmprestimo ? formatCurrency(editingEmprestimo.valor) : "-"}</span>
              </div>
              <div>
                <Label>Tipo de Reforço *</Label>
                <Select value={reforcoTipo} onValueChange={(v: "acrescentar" | "reduzir") => setReforcoTipo(v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="acrescentar">Acrescentar (retira da conta)</SelectItem>
                    <SelectItem value="reduzir">Reduzir (devolve à conta)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Conta (Banco / Carteira Móvel) *</Label>
                <Select value={reforcoContaId} onValueChange={setReforcoContaId}>
                  <SelectTrigger><SelectValue placeholder="Selecione a conta" /></SelectTrigger>
                  <SelectContent>
                    {contas.filter(c => c.tipo === "banco" || c.tipo === "carteira_movel").map(c => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.nome} — {formatCurrency(c.saldo_disponivel)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Valor do Reforço (MZN) *</Label>
                <Input
                  type="number"
                  min="0"
                  step="0.01"
                  value={reforcoValor}
                  onChange={(e) => setReforcoValor(e.target.value)}
                  placeholder="Ex: 5000"
                />
              </div>
              {reforcoValor && !isNaN(parseFloat(reforcoValor)) && editingEmprestimo && (
                <div className="rounded-md border p-3 text-sm">
                  Novo valor do empréstimo:{" "}
                  <span className="font-bold">
                    {formatCurrency(
                      reforcoTipo === "acrescentar"
                        ? editingEmprestimo.valor + parseFloat(reforcoValor)
                        : editingEmprestimo.valor - parseFloat(reforcoValor)
                    )}
                  </span>
                </div>
              )}
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setReforcoDialogOpen(false)} disabled={reforcoLoading}>
                  Cancelar
                </Button>
                <Button onClick={() => setReforcoConfirmOpen(true)} disabled={reforcoLoading || !reforcoValor || !reforcoContaId}>
                  Aplicar Reforço
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <ConfirmDialog
          open={reforcoConfirmOpen}
          onOpenChange={setReforcoConfirmOpen}
          description={`Confirma ${reforcoTipo === "acrescentar" ? "acrescentar" : "reduzir"} ${reforcoValor || 0} MZN ao empréstimo? A conta selecionada será ${reforcoTipo === "acrescentar" ? "debitada" : "creditada"} automaticamente.`}
          confirmLabel="Confirmar"
          onConfirm={executeReforco}
        />
      </div>
    </DashboardLayout>
  );
}
