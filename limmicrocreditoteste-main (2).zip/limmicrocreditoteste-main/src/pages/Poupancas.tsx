import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, PiggyBank, Users, TrendingUp, Edit, Trash2 } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { RelatorioGrupoPoupanca } from "@/components/RelatorioGrupoPoupanca";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";
import { PoupancasInvestimentoSection } from "@/components/PoupancasInvestimentoSection";
import { PoupancaGrupo2Section } from "@/components/poupanca-grupo/PoupancaGrupo2Section";


export default function Poupancas() {
  const [grupos, setGrupos] = useState<any[]>([]);
  const [grupoSelecionado, setGrupoSelecionado] = useState<any>(null);
  const [membros, setMembros] = useState<any[]>([]);
  const [dialogGrupoOpen, setDialogGrupoOpen] = useState(false);
  const [dialogEditGrupoOpen, setDialogEditGrupoOpen] = useState(false);
  const [grupoEditando, setGrupoEditando] = useState<any>(null);
  const [dialogMembroOpen, setDialogMembroOpen] = useState(false);
  const [dialogEditMembroOpen, setDialogEditMembroOpen] = useState(false);
  const [membroEditando, setMembroEditando] = useState<any>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [membroParaExcluir, setMembroParaExcluir] = useState<any>(null);
  
  // Grupo form
  const [nome, setNome] = useState("");
  const [local, setLocal] = useState("");
  const [presidente, setPresidente] = useState("");
  const [secretario, setSecretario] = useState("");
  const [dataInicio, setDataInicio] = useState("");
  const [dataFim, setDataFim] = useState("");
  
  // Membro form
  const [nomeMembro, setNomeMembro] = useState("");
  const [telefoneMembro, setTelefoneMembro] = useState("");
  const [valorPoupado, setValorPoupado] = useState("");
  const [valorEmprestimo, setValorEmprestimo] = useState("");
  const [valorPago, setValorPago] = useState("");
  const [divida, setDivida] = useState("");
  const [producao, setProducao] = useState("");
  const [bonus, setBonus] = useState("");
  const [outros1, setOutros1] = useState("");
  const [outros2, setOutros2] = useState("");

  useEffect(() => {
    loadGrupos();
  }, []);

  // Calcular automaticamente Produção (50%) quando não há dívida
  useEffect(() => {
    const emprestimo = parseFloat(valorEmprestimo.replace(',', '.')) || 0;
    const dividaVal = parseFloat(divida.replace(',', '.')) || 0;
    
    if (dividaVal === 0 && emprestimo > 0 && !membroEditando) {
      const producaoCalculada = (emprestimo * 0.10) / 2;
      setProducao(producaoCalculada.toFixed(2));
    }
  }, [valorEmprestimo, divida, membroEditando]);

  useEffect(() => {
    if (grupoSelecionado) {
      loadMembros(grupoSelecionado.id);
    }
  }, [grupoSelecionado]);

  const loadGrupos = async () => {
    const { data } = await supabase.from("grupos_poupanca").select("*").order("created_at", { ascending: false });
    setGrupos(data || []);
  };

  const loadMembros = async (grupoId: string) => {
    const { data } = await supabase.from("membros_poupanca").select("*").eq("grupo_id", grupoId).order("created_at", { ascending: false });
    setMembros(data || []);
  };

  useRealtimeRefresh(["grupos_poupanca", "membros_poupanca"], () => {
    loadGrupos();
    if (grupoSelecionado?.id) loadMembros(grupoSelecionado.id);
  }, true, 900);

  const handleSubmitGrupo = async (e: React.FormEvent) => {
    e.preventDefault();
    const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
    
    const { error } = await supabase.from("grupos_poupanca").insert([{
      user_id: user?.id,
      nome,
      local,
      presidente,
      secretario,
      data_inicio: dataInicio || null,
      data_fim: dataFim || null
    }]);

    if (error) {
      toast.error("Erro ao criar grupo");
    } else {
      toast.success("Grupo criado com sucesso!");
      setDialogGrupoOpen(false);
      setNome(""); setLocal(""); setPresidente(""); setSecretario(""); setDataInicio(""); setDataFim("");
      loadGrupos();
    }
  };

  const handleEditGrupo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!grupoEditando) return;

    const { error } = await supabase.from("grupos_poupanca").update({
      nome,
      local,
      presidente,
      secretario,
      data_inicio: dataInicio || null,
      data_fim: dataFim || null
    }).eq("id", grupoEditando.id);

    if (error) {
      toast.error("Erro ao atualizar grupo");
    } else {
      toast.success("Grupo atualizado!");
      setDialogEditGrupoOpen(false);
      setGrupoEditando(null);
      setNome(""); setLocal(""); setPresidente(""); setSecretario(""); setDataInicio(""); setDataFim("");
      loadGrupos();
    }
  };

  const [deleteGrupoConfirmOpen, setDeleteGrupoConfirmOpen] = useState(false);
  const [grupoToDelete, setGrupoToDelete] = useState<string | null>(null);

  const handleDeleteGrupo = async () => {
    if (!grupoToDelete) return;
    const { error } = await supabase.from("grupos_poupanca").delete().eq("id", grupoToDelete);
    if (error) toast.error("Erro ao excluir");
    else { toast.success("Grupo excluído!"); setGrupoSelecionado(null); loadGrupos(); }
    setDeleteGrupoConfirmOpen(false);
    setGrupoToDelete(null);
  };

  const openEditGrupo = (grupo: any) => {
    setGrupoEditando(grupo);
    setNome(grupo.nome);
    setLocal(grupo.local || "");
    setPresidente(grupo.presidente || "");
    setSecretario(grupo.secretario || "");
    setDataInicio(grupo.data_inicio || "");
    setDataFim(grupo.data_fim || "");
    setDialogEditGrupoOpen(true);
  };

  const handleSubmitMembro = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const { error } = await supabase.from("membros_poupanca").insert([{
      grupo_id: grupoSelecionado.id,
      nome: nomeMembro,
      telefone: telefoneMembro || null,
      valor_poupado: parseFloat(valorPoupado.replace(',', '.')) || 0,
      valor_emprestimo: parseFloat(valorEmprestimo.replace(',', '.')) || 0,
      valor_pago: parseFloat(valorPago.replace(',', '.')) || 0,
      divida: parseFloat(divida.replace(',', '.')) || 0,
      producao: parseFloat(producao.replace(',', '.')) || 0,
      bonus: parseFloat(bonus.replace(',', '.')) || 0,
      outros1: parseFloat(outros1.replace(',', '.')) || 0,
      outros2: parseFloat(outros2.replace(',', '.')) || 0,
    }]);

    if (error) {
      toast.error("Erro ao adicionar membro");
      console.error(error);
    } else {
      toast.success("Membro adicionado com sucesso!");
      setDialogMembroOpen(false);
      setNomeMembro(""); setTelefoneMembro(""); setValorPoupado(""); 
      setValorEmprestimo(""); setValorPago(""); setDivida("");
      setProducao(""); setBonus(""); setOutros1(""); setOutros2("");
      loadMembros(grupoSelecionado.id);
      atualizarTotaisGrupo(grupoSelecionado.id);
    }
  };

  const atualizarTotaisGrupo = async (grupoId: string) => {
    const { data: membrosData } = await supabase
      .from("membros_poupanca")
      .select("*")
      .eq("grupo_id", grupoId);
    
    if (membrosData) {
      const totalPoupado = membrosData.reduce((sum, m) => sum + (m.valor_poupado || 0), 0);
      const totalEmprestado = membrosData.reduce((sum, m) => sum + (m.valor_emprestimo || 0), 0);
      
      await supabase
        .from("grupos_poupanca")
        .update({ 
          total_poupado: totalPoupado,
          total_emprestado: totalEmprestado 
        })
        .eq("id", grupoId);
      
      loadGrupos();
    }
  };

  const calcularTotalGeral = (membro: any) => {
    const divida = membro.divida || 0;
    const producao = divida === 0 ? (membro.producao || 0) : 0;
    
    return (membro.valor_poupado || 0) + 
           (membro.valor_pago || 0) - 
           divida + 
           producao +
           (membro.bonus || 0) + 
           (membro.outros1 || 0) + 
           (membro.outros2 || 0);
  };

  const totalGeralGrupo = membros.reduce((sum, m) => sum + calcularTotalGeral(m), 0);

  const editarMembro = (membro: any) => {
    setMembroEditando(membro);
    setNomeMembro(membro.nome);
    setTelefoneMembro(membro.telefone || "");
    setValorPoupado("");
    setValorEmprestimo("");
    setValorPago("");
    setDivida("");
    setProducao("");
    setBonus("");
    setOutros1("");
    setOutros2("");
    setDialogEditMembroOpen(true);
  };

  const handleEditMembro = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Prepare update data - only update non-empty fields by adding to existing values
    const updateData: any = {
      nome: nomeMembro,
      telefone: telefoneMembro || null,
    };

    // Add to existing values if provided
    if (valorPoupado) {
      updateData.valor_poupado = (membroEditando.valor_poupado || 0) + parseFloat(valorPoupado.replace(',', '.'));
    }
    if (valorEmprestimo) {
      updateData.valor_emprestimo = (membroEditando.valor_emprestimo || 0) + parseFloat(valorEmprestimo.replace(',', '.'));
    }
    if (valorPago) {
      updateData.valor_pago = (membroEditando.valor_pago || 0) + parseFloat(valorPago.replace(',', '.'));
    }
    if (divida) {
      updateData.divida = (membroEditando.divida || 0) + parseFloat(divida.replace(',', '.'));
    }
    if (producao) {
      updateData.producao = (membroEditando.producao || 0) + parseFloat(producao.replace(',', '.'));
    }
    if (bonus) {
      updateData.bonus = (membroEditando.bonus || 0) + parseFloat(bonus.replace(',', '.'));
    }
    if (outros1) {
      updateData.outros1 = (membroEditando.outros1 || 0) + parseFloat(outros1.replace(',', '.'));
    }
    if (outros2) {
      updateData.outros2 = (membroEditando.outros2 || 0) + parseFloat(outros2.replace(',', '.'));
    }

    const { error } = await supabase
      .from("membros_poupanca")
      .update(updateData)
      .eq("id", membroEditando.id);

    if (error) {
      toast.error("Erro ao atualizar membro");
      console.error(error);
    } else {
      toast.success("Membro atualizado com sucesso!");
      setDialogEditMembroOpen(false);
      setMembroEditando(null);
      setNomeMembro(""); setTelefoneMembro(""); setValorPoupado(""); 
      setValorEmprestimo(""); setValorPago(""); setDivida("");
      setProducao(""); setBonus(""); setOutros1(""); setOutros2("");
      loadMembros(grupoSelecionado.id);
      atualizarTotaisGrupo(grupoSelecionado.id);
    }
  };

  const confirmarExclusao = (membro: any) => {
    setMembroParaExcluir(membro);
    setDeleteDialogOpen(true);
  };

  const excluirMembro = async () => {
    if (!membroParaExcluir) return;

    const { error } = await supabase
      .from("membros_poupanca")
      .delete()
      .eq("id", membroParaExcluir.id);

    if (error) {
      toast.error("Erro ao excluir membro");
      console.error(error);
    } else {
      toast.success("Membro excluído com sucesso!");
      setDeleteDialogOpen(false);
      setMembroParaExcluir(null);
      loadMembros(grupoSelecionado.id);
      atualizarTotaisGrupo(grupoSelecionado.id);
    }
  };

  if (!grupoSelecionado) {
    return (
      <DashboardLayout>
        <div className="p-6 space-y-6">
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <PiggyBank className="h-8 w-8 text-primary" />
            Gestão de Poupanças
          </h1>

          <Tabs defaultValue="grupos">
            <TabsList className="flex-wrap">
              <TabsTrigger value="grupos">Grupos de Poupança</TabsTrigger>
              <TabsTrigger value="grupo2">Poupança em Grupo 2.0</TabsTrigger>
              <TabsTrigger value="investimento">Poupança Investimento</TabsTrigger>
            </TabsList>

            <TabsContent value="grupo2" className="mt-4">
              <PoupancaGrupo2Section />
            </TabsContent>

            <TabsContent value="investimento" className="mt-4">
              <PoupancasInvestimentoSection />
            </TabsContent>


            <TabsContent value="grupos" className="mt-4 space-y-6">
          <div className="flex items-center justify-end">
            <Dialog open={dialogGrupoOpen} onOpenChange={setDialogGrupoOpen}>
              <DialogTrigger asChild>
                <Button><Plus className="mr-2 h-4 w-4" />Novo Grupo</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Criar Grupo de Poupança</DialogTitle>
                  <DialogDescription>Preencha os dados do novo grupo</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmitGrupo} className="space-y-4">
                  <div><Label>Nome do Grupo *</Label><Input value={nome} onChange={(e) => setNome(e.target.value)} required /></div>
                  <div><Label>Local</Label><Input value={local} onChange={(e) => setLocal(e.target.value)} /></div>
                  <div><Label>Presidente</Label><Input value={presidente} onChange={(e) => setPresidente(e.target.value)} /></div>
                  <div><Label>Secretário</Label><Input value={secretario} onChange={(e) => setSecretario(e.target.value)} /></div>
                  <div className="grid grid-cols-2 gap-4">
                    <div><Label>Data de Início</Label><Input type="date" value={dataInicio} onChange={(e) => setDataInicio(e.target.value)} /></div>
                    <div><Label>Data do Fim</Label><Input type="date" value={dataFim} onChange={(e) => setDataFim(e.target.value)} /></div>
                  </div>
                  <Button type="submit" className="w-full">Criar Grupo</Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {grupos.map((grupo) => (
              <Card key={grupo.id} className="hover:shadow-lg transition-shadow group">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 justify-between">
                    <span className="flex items-center gap-2 cursor-pointer" onClick={() => setGrupoSelecionado(grupo)}>
                      <Users className="h-5 w-5" />
                      {grupo.nome}
                    </span>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100">
                      <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); openEditGrupo(grupo); }}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); setGrupoToDelete(grupo.id); setDeleteGrupoConfirmOpen(true); }}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 cursor-pointer" onClick={() => setGrupoSelecionado(grupo)}>
                  <p className="text-sm"><strong>Local:</strong> {grupo.local || "-"}</p>
                  <p className="text-sm"><strong>Presidente:</strong> {grupo.presidente || "-"}</p>
                  <p className="text-sm text-primary font-semibold">Total: {grupo.total_poupado?.toFixed(2) || "0.00"} MZN</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <Dialog open={dialogEditGrupoOpen} onOpenChange={setDialogEditGrupoOpen}>
            <DialogContent>
              <DialogHeader><DialogTitle>Editar Grupo</DialogTitle></DialogHeader>
              <form onSubmit={handleEditGrupo} className="space-y-4">
                <div><Label>Nome *</Label><Input value={nome} onChange={(e) => setNome(e.target.value)} required /></div>
                <div><Label>Local</Label><Input value={local} onChange={(e) => setLocal(e.target.value)} /></div>
                <div><Label>Presidente</Label><Input value={presidente} onChange={(e) => setPresidente(e.target.value)} /></div>
                <div><Label>Secretário</Label><Input value={secretario} onChange={(e) => setSecretario(e.target.value)} /></div>
                <div className="grid grid-cols-2 gap-4">
                  <div><Label>Data de Início</Label><Input type="date" value={dataInicio} onChange={(e) => setDataInicio(e.target.value)} /></div>
                  <div><Label>Data do Fim</Label><Input type="date" value={dataFim} onChange={(e) => setDataFim(e.target.value)} /></div>
                </div>
                <Button type="submit" className="w-full">Atualizar</Button>
              </form>
            </DialogContent>
          </Dialog>
            </TabsContent>
          </Tabs>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Button variant="ghost" onClick={() => setGrupoSelecionado(null)} className="mb-2">← Voltar</Button>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <PiggyBank className="h-8 w-8 text-primary" />
              {grupoSelecionado.nome}
            </h1>
          </div>
          <div className="flex gap-2">
            <RelatorioGrupoPoupanca grupo={grupoSelecionado} membros={membros} />
            <Dialog open={dialogMembroOpen} onOpenChange={setDialogMembroOpen}>
              <DialogTrigger asChild>
                <Button><Plus className="mr-2 h-4 w-4" />Adicionar Membro</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Adicionar Membro</DialogTitle>
                  <DialogDescription>Preencha os dados do membro</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmitMembro} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div><Label>Nome *</Label><Input value={nomeMembro} onChange={(e) => setNomeMembro(e.target.value)} required /></div>
                    <div><Label>Telefone</Label><Input value={telefoneMembro} onChange={(e) => setTelefoneMembro(e.target.value)} /></div>
                    <div><Label>Valor Poupado</Label><Input value={valorPoupado} onChange={(e) => setValorPoupado(e.target.value)} placeholder="0" /></div>
                    <div><Label>Empréstimo Recebido</Label><Input value={valorEmprestimo} onChange={(e) => setValorEmprestimo(e.target.value)} placeholder="0" /></div>
                    <div><Label>Valor Pago (AT)</Label><Input value={valorPago} onChange={(e) => setValorPago(e.target.value)} placeholder="0" /></div>
                    <div><Label>Dívida</Label><Input value={divida} onChange={(e) => setDivida(e.target.value)} placeholder="0" /></div>
                    <div><Label>Produção (50%)</Label><Input value={producao} onChange={(e) => setProducao(e.target.value)} placeholder="0" /></div>
                    <div><Label>Bónus</Label><Input value={bonus} onChange={(e) => setBonus(e.target.value)} placeholder="0" /></div>
                    <div><Label>Outros 1</Label><Input value={outros1} onChange={(e) => setOutros1(e.target.value)} placeholder="0" /></div>
                    <div><Label>Outros 2</Label><Input value={outros2} onChange={(e) => setOutros2(e.target.value)} placeholder="0" /></div>
                  </div>
                  <Button type="submit" className="w-full">Adicionar Membro</Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader><CardTitle className="text-sm">Total Poupado</CardTitle></CardHeader>
            <CardContent><p className="text-2xl font-bold text-primary">{grupoSelecionado.total_poupado?.toFixed(2) || "0.00"} MZN</p></CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle className="text-sm">Total Emprestado</CardTitle></CardHeader>
            <CardContent><p className="text-2xl font-bold">{grupoSelecionado.total_emprestado?.toFixed(2) || "0.00"} MZN</p></CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle className="text-sm">Total Geral</CardTitle></CardHeader>
            <CardContent><p className="text-2xl font-bold text-green-600">{totalGeralGrupo.toFixed(2)} MZN</p></CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader><CardTitle>Membros do Grupo</CardTitle></CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Telefone</TableHead>
                    <TableHead className="text-right">Poupado</TableHead>
                    <TableHead className="text-right">Empréstimo</TableHead>
                    <TableHead className="text-right">Pago (AT)</TableHead>
                    <TableHead className="text-right">Dívida</TableHead>
                    <TableHead className="text-right">Produção (50%)</TableHead>
                    <TableHead className="text-right">Bónus</TableHead>
                    <TableHead className="text-right">Outros 1</TableHead>
                    <TableHead className="text-right">Outros 2</TableHead>
                    <TableHead className="text-right font-bold">Total Geral</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {membros.map((membro) => (
                    <TableRow key={membro.id}>
                      <TableCell className="font-medium">{membro.nome}</TableCell>
                      <TableCell>{membro.telefone || "-"}</TableCell>
                      <TableCell className="text-right">{membro.valor_poupado?.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{membro.valor_emprestimo?.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{membro.valor_pago?.toFixed(2)}</TableCell>
                      <TableCell className="text-right text-red-600">{membro.divida?.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{membro.producao?.toFixed(2)}</TableCell>
                      <TableCell className="text-right text-green-600">{membro.bonus?.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{membro.outros1?.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{membro.outros2?.toFixed(2)}</TableCell>
                      <TableCell className="text-right font-bold text-primary">{calcularTotalGeral(membro).toFixed(2)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex gap-1">
                          <Button variant="ghost" size="sm" onClick={() => editarMembro(membro)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => confirmarExclusao(membro)}>
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Dialog de Edição de Membro */}
        <Dialog open={dialogEditMembroOpen} onOpenChange={setDialogEditMembroOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Editar Membro</DialogTitle>
              <DialogDescription>Adicione valores para somar aos existentes. Valores em branco não serão alterados.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleEditMembro} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Nome *</Label><Input value={nomeMembro} onChange={(e) => setNomeMembro(e.target.value)} required /></div>
                <div><Label>Telefone</Label><Input value={telefoneMembro} onChange={(e) => setTelefoneMembro(e.target.value)} /></div>
                <div>
                  <Label>Adicionar ao Valor Poupado</Label>
                  <Input value={valorPoupado} onChange={(e) => setValorPoupado(e.target.value)} placeholder="0" />
                  {membroEditando && <p className="text-xs text-muted-foreground mt-1">Atual: {membroEditando.valor_poupado?.toFixed(2)}</p>}
                </div>
                <div>
                  <Label>Adicionar ao Empréstimo</Label>
                  <Input value={valorEmprestimo} onChange={(e) => setValorEmprestimo(e.target.value)} placeholder="0" />
                  {membroEditando && <p className="text-xs text-muted-foreground mt-1">Atual: {membroEditando.valor_emprestimo?.toFixed(2)}</p>}
                </div>
                <div>
                  <Label>Adicionar ao Valor Pago (AT)</Label>
                  <Input value={valorPago} onChange={(e) => setValorPago(e.target.value)} placeholder="0" />
                  {membroEditando && <p className="text-xs text-muted-foreground mt-1">Atual: {membroEditando.valor_pago?.toFixed(2)}</p>}
                </div>
                <div>
                  <Label>Adicionar à Dívida</Label>
                  <Input value={divida} onChange={(e) => setDivida(e.target.value)} placeholder="0" />
                  {membroEditando && <p className="text-xs text-muted-foreground mt-1">Atual: {membroEditando.divida?.toFixed(2)}</p>}
                </div>
                <div>
                  <Label>Adicionar à Produção (50%)</Label>
                  <Input value={producao} onChange={(e) => setProducao(e.target.value)} placeholder="0" />
                  {membroEditando && <p className="text-xs text-muted-foreground mt-1">Atual: {membroEditando.producao?.toFixed(2)}</p>}
                </div>
                <div>
                  <Label>Adicionar ao Bónus</Label>
                  <Input value={bonus} onChange={(e) => setBonus(e.target.value)} placeholder="0" />
                  {membroEditando && <p className="text-xs text-muted-foreground mt-1">Atual: {membroEditando.bonus?.toFixed(2)}</p>}
                </div>
                <div>
                  <Label>Adicionar a Outros 1</Label>
                  <Input value={outros1} onChange={(e) => setOutros1(e.target.value)} placeholder="0" />
                  {membroEditando && <p className="text-xs text-muted-foreground mt-1">Atual: {membroEditando.outros1?.toFixed(2)}</p>}
                </div>
                <div>
                  <Label>Adicionar a Outros 2</Label>
                  <Input value={outros2} onChange={(e) => setOutros2(e.target.value)} placeholder="0" />
                  {membroEditando && <p className="text-xs text-muted-foreground mt-1">Atual: {membroEditando.outros2?.toFixed(2)}</p>}
                </div>
              </div>
              <Button type="submit" className="w-full">Atualizar Membro</Button>
            </form>
          </DialogContent>
        </Dialog>

        {/* Dialog de Confirmação de Exclusão */}
        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
              <AlertDialogDescription>
                Tem certeza que deseja excluir o membro {membroParaExcluir?.nome}? Esta ação não pode ser desfeita.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={excluirMembro} className="bg-destructive hover:bg-destructive/90">
                Excluir
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        <ConfirmDialog
          open={deleteGrupoConfirmOpen}
          onOpenChange={setDeleteGrupoConfirmOpen}
          description="Excluir grupo? Todos os membros serão removidos. Esta ação não pode ser desfeita."
          confirmLabel="Excluir"
          onConfirm={handleDeleteGrupo}
          variant="destructive"
        />
      </div>
    </DashboardLayout>
  );
}
