import { useCallback, useEffect, useMemo, useState } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Lock, Unlock, Download, FileSpreadsheet, Printer, RefreshCw,
  TrendingUp, TrendingDown, Wallet, PiggyBank, ArrowUpRight, ArrowDownRight, Landmark,
} from "lucide-react";
import { useAccessControl } from "@/hooks/useAccessControl";
import { AccountBlocked } from "@/components/AccountBlocked";
import { useUserRole } from "@/hooks/useUserRole";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { createFormattedExcel } from "@/lib/excelExport";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, CartesianGrid, Legend } from "recharts";
import {
  agregarPeriodo, carteiraAte, calcularPeriodo, periodoAnterior, periodoAnoAnterior,
  type FechoAgregado, type CarteiraSnapshot, type PeriodoPreset,
} from "@/lib/fechoContas";

const fmt = (v: number) =>
  new Intl.NumberFormat("pt-MZ", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v || 0);
const pct = (v: number) => `${(v || 0).toFixed(2)}%`;
const fmtDate = (d?: string | null) => (d ? new Date(d).toLocaleDateString("pt-PT") : "-");
const safeDiv = (a: number, b: number) => (b > 0 ? (a / b) * 100 : 0);

const PRESETS: { value: PeriodoPreset; label: string }[] = [
  { value: "hoje", label: "Hoje" },
  { value: "ontem", label: "Ontem" },
  { value: "semana", label: "Esta semana" },
  { value: "semana-passada", label: "Semana passada" },
  { value: "mes", label: "Este mês" },
  { value: "mes-passado", label: "Mês passado" },
  { value: "trimestre", label: "Este trimestre" },
  { value: "ano", label: "Este ano" },
  { value: "personalizado", label: "Intervalo personalizado" },
];

interface Saldos {
  caixa: number;
  banco: number;
  mpesa: number;
  emola: number;
}

const CHART_COLORS = ["hsl(var(--primary))", "#16a34a", "#f59e0b", "#dc2626", "#0ea5e9", "#8b5cf6", "#64748b"];

export default function FechoContas() {
  const { accessStatus, loading: accessLoading } = useAccessControl();
  const { isSuperAdmin } = useUserRole();

  const inicial = calcularPeriodo("mes");
  const [preset, setPreset] = useState<PeriodoPreset>("mes");
  const [ini, setIni] = useState(inicial.ini);
  const [fim, setFim] = useState(inicial.fim);
  const [loading, setLoading] = useState(false);
  const [obs, setObs] = useState("");
  const [fechado, setFechado] = useState(false);
  const [confirmFechar, setConfirmFechar] = useState(false);
  const [confirmReabrir, setConfirmReabrir] = useState(false);

  const [atual, setAtual] = useState<FechoAgregado | null>(null);
  const [anterior, setAnterior] = useState<FechoAgregado | null>(null);
  const [anoAnterior, setAnoAnterior] = useState<FechoAgregado | null>(null);
  const [carteira, setCarteira] = useState<CarteiraSnapshot | null>(null);
  const [saldos, setSaldos] = useState<Saldos>({ caixa: 0, banco: 0, mpesa: 0, emola: 0 });
  const [empresa, setEmpresa] = useState<any>(null);
  const [utilizador, setUtilizador] = useState("");

  const aplicarPreset = (p: PeriodoPreset) => {
    setPreset(p);
    if (p !== "personalizado") {
      const r = calcularPeriodo(p);
      setIni(r.ini);
      setFim(r.fim);
    }
  };

  const carregar = useCallback(async () => {
    setLoading(true);
    try {
      const ant = periodoAnterior(ini, fim);
      const anoAnt = periodoAnoAnterior(ini, fim);
      const [a, b, c, cart, contas, cfg, sess] = await Promise.all([
        agregarPeriodo(ini, fim),
        agregarPeriodo(ant.ini, ant.fim),
        agregarPeriodo(anoAnt.ini, anoAnt.fim),
        carteiraAte(fim),
        supabase.from("contas_financeiras").select("tipo, nome, saldo_disponivel").eq("ativo", true),
        supabase.from("configuracoes_empresa").select("nome_empresa, nuit, endereco, telefone, email").maybeSingle(),
        supabase.auth.getSession(),
      ]);

      setAtual(a);
      setAnterior(b);
      setAnoAnterior(c);
      setCarteira(cart);
      setEmpresa(cfg.data || null);
      setUtilizador(sess.data.session?.user?.email || "");

      const s: Saldos = { caixa: 0, banco: 0, mpesa: 0, emola: 0 };
      (contas.data || []).forEach((k: any) => {
        const v = Number(k.saldo_disponivel) || 0;
        const nome = String(k.nome || "").toLowerCase();
        if (k.tipo === "banco") s.banco += v;
        else if (nome.includes("mpesa") || nome.includes("m-pesa")) s.mpesa += v;
        else if (nome.includes("mola")) s.emola += v;
        else s.caixa += v;
      });
      setSaldos(s);
    } catch (e) {
      console.error(e);
      toast.error("Erro ao consolidar o fecho de contas");
    } finally {
      setLoading(false);
    }
  }, [ini, fim]);

  useEffect(() => { carregar(); }, [carregar]);

  // Recalcula automaticamente quando há alterações nos módulos financeiros
  useRealtimeRefresh(
    ["pagamentos", "emprestimos", "despesas", "entradas_capital", "contas_financeiras", "clientes"],
    carregar,
    !fechado,
    1200
  );

  const calc = useMemo(() => {
    const a = atual;
    const cart = carteira;
    if (!a || !cart) return null;

    const receitaJuros = a.jurosRecebidos;
    const receitaMultas = a.multasRecebidas;
    const receitaTotal = receitaJuros + receitaMultas + a.receitasDiversas;
    const lucroBruto = receitaJuros + receitaMultas;
    const lucroLiquido = receitaTotal - a.totalDespesas;
    const margem = safeDiv(lucroLiquido, receitaTotal);

    const entradas = a.totalRecebido + a.receitasDiversas;
    const saidas = a.totalDespesas + a.valorEmprestado;
    const fluxoLiquido = entradas - saidas;

    const saldoConsolidado = saldos.caixa + saldos.banco + saldos.mpesa + saldos.emola;
    const saldoFinal = saldoConsolidado;
    const saldoInicial = saldoFinal - fluxoLiquido;

    const capitalDisponivel = saldoConsolidado;
    const capitalEmprestado = a.valorEmprestado;
    const capitalRecuperado = a.capitalRecebido;
    const capitalTotal = capitalDisponivel + cart.emDivida;

    return {
      receitaJuros, receitaMultas, receitaTotal, lucroBruto, lucroLiquido, margem,
      entradas, saidas, fluxoLiquido, saldoConsolidado, saldoInicial, saldoFinal,
      capitalDisponivel, capitalEmprestado, capitalRecuperado, capitalTotal,
      taxaRecuperacao: safeDiv(cart.totalPagoCarteira, cart.totalCarteira),
      taxaIncumprimento: safeDiv(cart.capitalAtraso, cart.totalCarteira),
      jurosSobreCapital: safeDiv(receitaJuros, capitalTotal),
      rentabilidade: safeDiv(lucroLiquido, capitalTotal),
      liquidez: safeDiv(capitalDisponivel, cart.emDivida + capitalDisponivel),
      resultadoOperacional: lucroBruto - a.totalDespesas,
    };
  }, [atual, carteira, saldos]);

  const comparativo = useMemo(() => {
    if (!atual) return [];
    const linhas = (ref: FechoAgregado | null, rotulo: string) => {
      if (!ref) return [];
      const rec = (x: FechoAgregado) => x.jurosRecebidos + x.multasRecebidas + x.receitasDiversas;
      const items = [
        { nome: "Valor emprestado", a: atual.valorEmprestado, b: ref.valorEmprestado },
        { nome: "Total recebido", a: atual.totalRecebido, b: ref.totalRecebido },
        { nome: "Receita total", a: rec(atual), b: rec(ref) },
        { nome: "Despesas", a: atual.totalDespesas, b: ref.totalDespesas },
        { nome: "Lucro líquido", a: rec(atual) - atual.totalDespesas, b: rec(ref) - ref.totalDespesas },
      ];
      return items.map((i) => ({
        rotulo, nome: i.nome, atual: i.a, ref: i.b,
        dif: i.a - i.b, difPct: i.b !== 0 ? ((i.a - i.b) / Math.abs(i.b)) * 100 : 0,
      }));
    };
    return [...linhas(anterior, "Período anterior"), ...linhas(anoAnterior, "Ano anterior")];
  }, [atual, anterior, anoAnterior]);

  const despesasChart = useMemo(
    () => Object.entries(atual?.despesasPorCategoria || {}).map(([name, value]) => ({ name, value })),
    [atual]
  );
  const fluxoChart = useMemo(
    () => (calc ? [
      { name: "Entradas", valor: calc.entradas },
      { name: "Saídas", valor: calc.saidas },
      { name: "Resultado", valor: calc.fluxoLiquido },
    ] : []),
    [calc]
  );

  const secoesExport = () => {
    if (!atual || !carteira || !calc) return [];
    return [
      {
        title: "RESUMO FINANCEIRO",
        headers: ["Indicador", "Valor (MZN)"],
        data: [
          ["Saldo Inicial", fmt(calc.saldoInicial)],
          ["Saldo Final", fmt(calc.saldoFinal)],
          ["Saldo em Caixa", fmt(saldos.caixa)],
          ["Saldo Bancário", fmt(saldos.banco)],
          ["Saldo M-Pesa", fmt(saldos.mpesa)],
          ["Saldo e-Mola", fmt(saldos.emola)],
          ["Saldo Consolidado", fmt(calc.saldoConsolidado)],
          ["Capital Disponível", fmt(calc.capitalDisponivel)],
          ["Capital Emprestado", fmt(calc.capitalEmprestado)],
          ["Capital Recuperado", fmt(calc.capitalRecuperado)],
          ["Capital em Circulação", fmt(carteira.capitalCirculacao)],
          ["Capital em Atraso", fmt(carteira.capitalAtraso)],
        ],
      },
      {
        title: "EMPRÉSTIMOS",
        headers: ["Indicador", "Valor"],
        data: [
          ["Empréstimos concedidos", String(atual.qtdEmprestimos)],
          ["Valor total emprestado", fmt(atual.valorEmprestado)],
          ["Capital recuperado", fmt(atual.capitalRecebido)],
          ["Capital em dívida (carteira)", fmt(carteira.emDivida)],
          ["Empréstimos pagos", String(carteira.qtdPagos)],
          ["Empréstimos ativos", String(carteira.qtdAtivos)],
          ["Empréstimos vencidos", String(carteira.qtdVencidos)],
          ["Em incumprimento (>90 dias)", String(carteira.qtdIncumprimento)],
          ["Taxa de recuperação", pct(calc.taxaRecuperacao)],
          ["Taxa de incumprimento", pct(calc.taxaIncumprimento)],
        ],
      },
      {
        title: "PAGAMENTOS",
        headers: ["Indicador", "Valor"],
        data: [
          ["Pagamentos realizados", String(atual.qtdPagamentos)],
          ["Capital recebido", fmt(atual.capitalRecebido)],
          ["Juros recebidos", fmt(atual.jurosRecebidos)],
          ["Multas (mora) recebidas", fmt(atual.multasRecebidas)],
          ["Total recebido", fmt(atual.totalRecebido)],
          ["Valor por receber (carteira)", fmt(carteira.emDivida)],
        ],
      },
      {
        title: "RECEITAS",
        headers: ["Origem", "Valor (MZN)"],
        data: [
          ["Juros de empréstimos", fmt(atual.jurosRecebidos)],
          ["Multas / juros de mora", fmt(atual.multasRecebidas)],
          ...Object.entries(atual.receitasPorDescricao).map(([k, v]) => [k, fmt(v)]),
          ["RECEITA TOTAL", fmt(calc.receitaTotal)],
        ],
      },
      {
        title: "DESPESAS",
        headers: ["Categoria", "Valor (MZN)"],
        data: [
          ...Object.entries(atual.despesasPorCategoria).map(([k, v]) => [k, fmt(v)]),
          ["TOTAL DAS DESPESAS", fmt(atual.totalDespesas)],
        ],
      },
      {
        title: "FLUXO DE CAIXA",
        headers: ["Item", "Valor (MZN)"],
        data: [
          ["Saldo Inicial", fmt(calc.saldoInicial)],
          ["(+) Entradas", fmt(calc.entradas)],
          ["(-) Saídas", fmt(calc.saidas)],
          ["Saldo Líquido do período", fmt(calc.fluxoLiquido)],
          ["Saldo Final", fmt(calc.saldoFinal)],
        ],
      },
      {
        title: "RESULTADO E INDICADORES",
        headers: ["Indicador", "Valor"],
        data: [
          ["Receita Total", fmt(calc.receitaTotal)],
          ["Despesas Totais", fmt(atual.totalDespesas)],
          ["Lucro Bruto", fmt(calc.lucroBruto)],
          ["Resultado Operacional", fmt(calc.resultadoOperacional)],
          ["LUCRO LÍQUIDO", fmt(calc.lucroLiquido)],
          ["Margem de lucro", pct(calc.margem)],
          ["Rentabilidade sobre capital", pct(calc.rentabilidade)],
          ["% Recuperação", pct(calc.taxaRecuperacao)],
          ["% Inadimplência", pct(calc.taxaIncumprimento)],
          ["% Juros sobre capital", pct(calc.jurosSobreCapital)],
          ["Liquidez", pct(calc.liquidez)],
          ["Capital disponível p/ novos empréstimos", fmt(calc.capitalDisponivel)],
          ["Valor comprometido", fmt(carteira.emDivida)],
        ],
      },
      {
        title: "COMPARATIVO",
        headers: ["Base", "Indicador", "Período actual", "Referência", "Diferença", "%"],
        data: comparativo.map((c) => [c.rotulo, c.nome, fmt(c.atual), fmt(c.ref), fmt(c.dif), pct(c.difPct)]),
      },
    ];
  };

  const exportarPDF = async () => {
    if (!atual || !calc) return;
    try {
      const [{ default: jsPDF }, { default: autoTable }, lhMod] = await Promise.all([
        import("jspdf"),
        import("jspdf-autotable"),
        import("@/lib/letterhead"),
      ]);
      const { loadLetterhead, applyLetterheadAllPages, LETTERHEAD_CONTENT_TOP, LETTERHEAD_CONTENT_BOTTOM } = lhMod;
      const lh = await loadLetterhead();
      const doc = new jsPDF({ compress: true });
      const pageW = doc.internal.pageSize.getWidth();
      let y = LETTERHEAD_CONTENT_TOP;

      doc.setFont("helvetica", "bold");
      doc.setFontSize(15);
      doc.text("FECHO DE CONTAS", pageW / 2, y, { align: "center" });
      y += 6;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.text(`Periodo: ${fmtDate(ini)} a ${fmtDate(fim)}`, pageW / 2, y, { align: "center" });
      y += 5;
      doc.setFontSize(9);
      doc.text(
        `Emitido em ${new Date().toLocaleDateString("pt-PT")} as ${new Date().toLocaleTimeString("pt-PT")} | Responsavel: ${utilizador}`,
        pageW / 2, y, { align: "center" }
      );
      y += 7;

      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      doc.text("RESUMO EXECUTIVO", 14, y);
      y += 4;
      autoTable(doc, {
        startY: y,
        body: [
          ["Receita Total", fmt(calc.receitaTotal), "Despesas Totais", fmt(atual.totalDespesas)],
          ["Lucro Liquido", fmt(calc.lucroLiquido), "Margem de lucro", pct(calc.margem)],
          ["Total recebido", fmt(atual.totalRecebido), "Valor emprestado", fmt(atual.valorEmprestado)],
          ["Saldo consolidado", fmt(calc.saldoConsolidado), "Capital em divida", fmt(carteira?.emDivida || 0)],
        ],
        styles: { fontSize: 9 },
        margin: { bottom: LETTERHEAD_CONTENT_BOTTOM },
      });

      for (const sec of secoesExport()) {
        const last = (doc as any).lastAutoTable?.finalY || y;
        let top = last + 8;
        if (top > doc.internal.pageSize.getHeight() - LETTERHEAD_CONTENT_BOTTOM - 30) {
          doc.addPage();
          top = LETTERHEAD_CONTENT_TOP;
        }
        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.text(sec.title, 14, top);
        autoTable(doc, {
          startY: top + 3,
          head: [sec.headers as string[]],
          body: sec.data as any,
          styles: { fontSize: 8 },
          headStyles: { fillColor: [91, 79, 191] },
          margin: { bottom: LETTERHEAD_CONTENT_BOTTOM },
        });
      }

      if (obs.trim()) {
        const last = (doc as any).lastAutoTable?.finalY || y;
        let top = last + 8;
        if (top > doc.internal.pageSize.getHeight() - LETTERHEAD_CONTENT_BOTTOM - 30) {
          doc.addPage();
          top = LETTERHEAD_CONTENT_TOP;
        }
        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.text("OBSERVACOES", 14, top);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.text(doc.splitTextToSize(obs, pageW - 28), 14, top + 6);
      }

      const hFinal = doc.internal.pageSize.getHeight();
      doc.setFont("helvetica", "normal");
      doc.setFontSize(9);
      doc.text("_______________________________", 20, hFinal - LETTERHEAD_CONTENT_BOTTOM - 6);
      doc.text("Responsavel Financeiro", 20, hFinal - LETTERHEAD_CONTENT_BOTTOM - 2);
      doc.text("_______________________________", pageW - 90, hFinal - LETTERHEAD_CONTENT_BOTTOM - 6);
      doc.text("Direccao", pageW - 90, hFinal - LETTERHEAD_CONTENT_BOTTOM - 2);

      applyLetterheadAllPages(doc, lh);
      doc.save(`fecho-contas-${ini}-a-${fim}.pdf`);
      toast.success("Relatório de fecho gerado");
    } catch (e) {
      console.error(e);
      toast.error("Erro ao gerar PDF");
    }
  };

  const exportarExcel = () => {
    if (!atual) return;
    createFormattedExcel(secoesExport() as any, `fecho-contas-${ini}-a-${fim}.xlsx`, "Fecho de Contas", {
      nomeEmpresa: empresa?.nome_empresa || "LIM SIST",
      endereco: empresa?.endereco || "",
      telefone: empresa?.telefone || "",
      email: empresa?.email || "",
      nuit: empresa?.nuit || "",
      titulo: "FECHO DE CONTAS",
      subtitulo: `Período: ${fmtDate(ini)} a ${fmtDate(fim)}`,
      data: new Date().toLocaleDateString("pt-PT"),
    });
    toast.success("Excel exportado");
  };

  if (accessLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
        </div>
      </DashboardLayout>
    );
  }
  if (!accessStatus?.isActive) {
    return <AccountBlocked reason={accessStatus?.reason || "inactive"} expiresAt={accessStatus?.expiresAt} />;
  }

  const Kpi = ({ label, value, icon: Icon, tone = "default" }: { label: string; value: string; icon?: any; tone?: string }) => (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          {Icon && <Icon className="h-3 w-3" />}
          {label}
        </div>
        <div
          className={`text-lg font-bold ${
            tone === "positive" ? "text-green-600" : tone === "negative" ? "text-red-600" : "text-foreground"
          }`}
        >
          {value}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <DashboardLayout>
      <div className="space-y-4 print:space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h1 className="text-2xl font-bold">Fecho de Contas</h1>
            <p className="text-sm text-muted-foreground">
              Consolidação automática de todos os movimentos do período — sem alterar nenhum dado.
            </p>
          </div>
          {fechado ? (
            <Badge className="bg-green-600">Período fechado</Badge>
          ) : (
            <Badge variant="outline">Em aberto</Badge>
          )}
        </div>

        <Card className="print:hidden">
          <CardContent className="p-4 grid gap-3 md:grid-cols-5">
            <div>
              <Label>Período</Label>
              <Select value={preset} onValueChange={(v) => aplicarPreset(v as PeriodoPreset)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PRESETS.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Data inicial</Label>
              <Input type="date" value={ini} onChange={(e) => { setPreset("personalizado"); setIni(e.target.value); }} />
            </div>
            <div>
              <Label>Data final</Label>
              <Input type="date" value={fim} onChange={(e) => { setPreset("personalizado"); setFim(e.target.value); }} />
            </div>
            <div className="flex items-end gap-2">
              <Button onClick={carregar} disabled={loading} variant="outline">
                <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} />
                Recalcular
              </Button>
            </div>
            <div className="flex items-end gap-2 flex-wrap">
              {!fechado ? (
                <Button onClick={() => setConfirmFechar(true)} disabled={loading || !calc}>
                  <Lock className="h-4 w-4 mr-1" />Fechar Contas
                </Button>
              ) : isSuperAdmin ? (
                <Button variant="outline" onClick={() => setConfirmReabrir(true)}>
                  <Unlock className="h-4 w-4 mr-1" />Reabrir Fecho
                </Button>
              ) : (
                <span className="text-xs text-muted-foreground">Reabertura só pelo Super Administrador</span>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-wrap gap-2 print:hidden">
          <Button variant="outline" onClick={exportarPDF} disabled={!calc}><Download className="h-4 w-4 mr-1" />PDF</Button>
          <Button variant="outline" onClick={exportarExcel} disabled={!calc}><FileSpreadsheet className="h-4 w-4 mr-1" />Excel</Button>
          <Button variant="outline" onClick={() => window.print()}><Printer className="h-4 w-4 mr-1" />Imprimir</Button>
        </div>

        {calc && atual && carteira && (
          <>
            <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
              <Kpi label="Receita Total" value={fmt(calc.receitaTotal)} icon={TrendingUp} tone="positive" />
              <Kpi label="Despesas Totais" value={fmt(atual.totalDespesas)} icon={TrendingDown} tone="negative" />
              <Kpi label="Lucro Líquido" value={fmt(calc.lucroLiquido)} icon={PiggyBank} tone={calc.lucroLiquido >= 0 ? "positive" : "negative"} />
              <Kpi label="Saldo Consolidado" value={fmt(calc.saldoConsolidado)} icon={Wallet} />
              <Kpi label="Capital Emprestado" value={fmt(calc.capitalEmprestado)} icon={ArrowUpRight} />
              <Kpi label="Capital Recuperado" value={fmt(calc.capitalRecuperado)} icon={ArrowDownRight} tone="positive" />
              <Kpi label="Capital em Atraso" value={fmt(carteira.capitalAtraso)} tone="negative" />
              <Kpi label="Capital em Circulação" value={fmt(carteira.capitalCirculacao)} icon={Landmark} />
            </div>

            <Tabs defaultValue="resumo">
              <TabsList className="flex-wrap h-auto">
                <TabsTrigger value="resumo">Resumo Financeiro</TabsTrigger>
                <TabsTrigger value="emprestimos">Empréstimos</TabsTrigger>
                <TabsTrigger value="pagamentos">Pagamentos</TabsTrigger>
                <TabsTrigger value="receitas">Receitas</TabsTrigger>
                <TabsTrigger value="despesas">Despesas</TabsTrigger>
                <TabsTrigger value="fluxo">Fluxo de Caixa</TabsTrigger>
                <TabsTrigger value="indicadores">Indicadores</TabsTrigger>
                <TabsTrigger value="comparativo">Comparativo</TabsTrigger>
              </TabsList>

              {secoesExport().slice(0, 1).map((s) => (
                <TabsContent key="resumo" value="resumo" className="mt-3">
                  <TabelaSimples titulo={s.title} headers={s.headers} rows={s.data as string[][]} />
                </TabsContent>
              ))}

              <TabsContent value="emprestimos" className="mt-3">
                <TabelaSimples titulo="Empréstimos" headers={["Indicador", "Valor"]} rows={secoesExport()[1].data as string[][]} />
              </TabsContent>
              <TabsContent value="pagamentos" className="mt-3">
                <TabelaSimples titulo="Pagamentos" headers={["Indicador", "Valor"]} rows={secoesExport()[2].data as string[][]} />
              </TabsContent>
              <TabsContent value="receitas" className="mt-3">
                <TabelaSimples titulo="Receitas" headers={["Origem", "Valor (MZN)"]} rows={secoesExport()[3].data as string[][]} />
              </TabsContent>
              <TabsContent value="despesas" className="mt-3 space-y-3">
                <TabelaSimples titulo="Despesas" headers={["Categoria", "Valor (MZN)"]} rows={secoesExport()[4].data as string[][]} />
                {despesasChart.length > 0 && (
                  <Card>
                    <CardHeader><CardTitle className="text-base">Distribuição das despesas</CardTitle></CardHeader>
                    <CardContent className="h-72">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie data={despesasChart} dataKey="value" nameKey="name" outerRadius={90} label>
                            {despesasChart.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                          </Pie>
                          <Tooltip formatter={(v: any) => fmt(Number(v))} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
              <TabsContent value="fluxo" className="mt-3 space-y-3">
                <TabelaSimples titulo="Fluxo de Caixa" headers={["Item", "Valor (MZN)"]} rows={secoesExport()[5].data as string[][]} />
                <Card>
                  <CardHeader><CardTitle className="text-base">Entradas vs Saídas</CardTitle></CardHeader>
                  <CardContent className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={fluxoChart}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis tickFormatter={(v) => fmt(Number(v))} width={90} />
                        <Tooltip formatter={(v: any) => fmt(Number(v))} />
                        <Bar dataKey="valor" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="indicadores" className="mt-3">
                <TabelaSimples titulo="Resultado e Indicadores" headers={["Indicador", "Valor"]} rows={secoesExport()[6].data as string[][]} />
              </TabsContent>
              <TabsContent value="comparativo" className="mt-3">
                <Card>
                  <CardHeader><CardTitle className="text-base">Comparativo</CardTitle></CardHeader>
                  <CardContent className="overflow-x-auto p-0">
                    <table className="w-full text-sm">
                      <thead className="bg-muted">
                        <tr>
                          <th className="p-2 text-left">Base</th>
                          <th className="p-2 text-left">Indicador</th>
                          <th className="p-2 text-right">Actual</th>
                          <th className="p-2 text-right">Referência</th>
                          <th className="p-2 text-right">Diferença</th>
                          <th className="p-2 text-right">%</th>
                        </tr>
                      </thead>
                      <tbody>
                        {comparativo.map((c, i) => (
                          <tr key={i} className="border-t">
                            <td className="p-2">{c.rotulo}</td>
                            <td className="p-2">{c.nome}</td>
                            <td className="p-2 text-right">{fmt(c.atual)}</td>
                            <td className="p-2 text-right">{fmt(c.ref)}</td>
                            <td className={`p-2 text-right ${c.dif >= 0 ? "text-green-600" : "text-red-600"}`}>{fmt(c.dif)}</td>
                            <td className={`p-2 text-right ${c.dif >= 0 ? "text-green-600" : "text-red-600"}`}>
                              {c.dif >= 0 ? "▲" : "▼"} {pct(Math.abs(c.difPct))}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            <Card>
              <CardHeader><CardTitle className="text-base">Observações do fecho</CardTitle></CardHeader>
              <CardContent>
                <Textarea
                  rows={3}
                  value={obs}
                  onChange={(e) => setObs(e.target.value)}
                  placeholder="Notas do responsável (aparecem no relatório em PDF)"
                />
              </CardContent>
            </Card>
          </>
        )}
      </div>

      <ConfirmDialog
        open={confirmFechar}
        onOpenChange={setConfirmFechar}
        title="Fechar contas do período?"
        description="O fecho apenas consolida e gera o relatório — nenhum dado financeiro é alterado. O recálculo automático fica suspenso até reabrir."
        onConfirm={() => { setFechado(true); exportarPDF(); }}
      />
      <ConfirmDialog
        open={confirmReabrir}
        onOpenChange={setConfirmReabrir}
        title="Reabrir o fecho?"
        description="O período volta a recalcular automaticamente com base nos dados actuais."
        onConfirm={() => { setFechado(false); carregar(); }}
      />
    </DashboardLayout>
  );
}

function TabelaSimples({ titulo, headers, rows }: { titulo: string; headers?: string[]; rows: string[][] }) {
  return (
    <Card>
      <CardHeader><CardTitle className="text-base">{titulo}</CardTitle></CardHeader>
      <CardContent className="p-0 overflow-x-auto">
        <table className="w-full text-sm">
          {headers && (
            <thead className="bg-muted">
              <tr>{headers.map((h, i) => <th key={i} className={`p-2 ${i === 0 ? "text-left" : "text-right"}`}>{h}</th>)}</tr>
            </thead>
          )}
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className="border-t">
                {r.map((c, j) => (
                  <td key={j} className={`p-2 ${j === 0 ? "" : "text-right font-medium"}`}>{c}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </CardContent>
    </Card>
  );
}
