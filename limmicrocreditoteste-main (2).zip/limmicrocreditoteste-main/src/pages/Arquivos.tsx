import { DashboardLayout } from "@/components/DashboardLayout";
import { compressIfImage } from "@/lib/imageCompression";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FolderOpen, Upload, Loader2, Eye, Trash2, FileText } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { format } from "date-fns";

export default function Arquivos() {
  const [open, setOpen] = useState(false);
  const [clienteId, setClienteId] = useState("");
  const [tipoDocumento, setTipoDocumento] = useState("");
  const [arquivo, setArquivo] = useState<File | null>(null);
  const queryClient = useQueryClient();

  const { data: clientes } = useQuery({
    queryKey: ["clientes"],
    queryFn: async () => {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) throw new Error("Usuário não autenticado");

      const { data, error } = await supabase
        .from("clientes")
        .select("id, nome_completo")
        .eq("user_id", user.id)
        .order("nome_completo");

      if (error) throw error;
      return data;
    },
  });

  const { data: arquivos, isLoading } = useQuery({
    queryKey: ["arquivos"],
    queryFn: async () => {
      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) throw new Error("Usuário não autenticado");

      const { data, error } = await supabase
        .from("arquivos")
        .select(`
          *,
          clientes(nome_completo)
        `)
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async () => {
      if (!clienteId || !tipoDocumento || !arquivo) {
        throw new Error("Preencha todos os campos");
      }

      const { data: { session: __s } } = await supabase.auth.getSession(); const user = __s?.user;
      if (!user) throw new Error("Usuário não autenticado");

      // Comprimir imagem se aplicável (transparente para outros formatos)
      const fileToUpload = await compressIfImage(arquivo);
      const fileExt = fileToUpload.name.split('.').pop();
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
      
      // Upload para o storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('documentos')
        .upload(fileName, fileToUpload, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        throw new Error("Erro ao fazer upload: " + uploadError.message);
      }

      // Obter URL pública
      const { data: { publicUrl } } = supabase.storage
        .from('documentos')
        .getPublicUrl(fileName);

      // Salvar no banco
      const { error: dbError } = await supabase
        .from("arquivos")
        .insert({
          user_id: user.id,
          cliente_id: clienteId,
          tipo: tipoDocumento,
          nome_arquivo: arquivo.name,
          url_arquivo: publicUrl,
          tamanho: arquivo.size,
        });

      if (dbError) {
        console.error('Database error:', dbError);
        throw new Error("Erro ao salvar: " + dbError.message);
      }
    },
    onSuccess: () => {
      toast.success("Documento enviado!");
      setOpen(false);
      setClienteId("");
      setTipoDocumento("");
      setArquivo(null);
      queryClient.invalidateQueries({ queryKey: ["arquivos"] });
    },
    onError: (error: any) => {
      toast.error(error.message);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const arquivo = arquivos?.find(a => a.id === id);
      if (!arquivo) throw new Error("Arquivo não encontrado");

      // Extrair o nome do arquivo da URL
      const fileName = arquivo.url_arquivo.split('/').pop();
      
      if (fileName) {
        // Deletar do storage
        const { error: storageError } = await supabase.storage
          .from('documentos')
          .remove([fileName]);

        if (storageError) {
          console.error('Storage delete error:', storageError);
        }
      }

      // Deletar do banco
      const { error: dbError } = await supabase
        .from("arquivos")
        .delete()
        .eq("id", id);

      if (dbError) {
        console.error('Database delete error:', dbError);
        throw new Error("Erro ao deletar: " + dbError.message);
      }
    },
    onSuccess: () => {
      toast.success("Documento excluído!");
      queryClient.invalidateQueries({ queryKey: ["arquivos"] });
    },
    onError: (error: any) => {
      toast.error(error.message);
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        toast.error("Arquivo muito grande. Máximo 10MB.");
        return;
      }
      setArquivo(file);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <FolderOpen className="h-8 w-8 text-primary" />
            Gestão de Arquivos
          </h1>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button><Upload className="mr-2 h-4 w-4" />Upload</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Upload de Documento</DialogTitle></DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Cliente</Label>
                  <Select value={clienteId} onValueChange={setClienteId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      {clientes?.map((cliente) => (
                        <SelectItem key={cliente.id} value={cliente.id}>
                          {cliente.nome_completo}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Tipo</Label>
                  <Select value={tipoDocumento} onValueChange={setTipoDocumento}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BI">BI</SelectItem>
                      <SelectItem value="Comprovante">Comprovante</SelectItem>
                      <SelectItem value="Renda">Renda</SelectItem>
                      <SelectItem value="Garantia">Garantia</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Arquivo (PDF/Imagem - máx 10MB)</Label>
                  <Input 
                    type="file" 
                    accept=".jpg,.jpeg,.png,.pdf" 
                    onChange={handleFileChange}
                  />
                </div>
                <Button 
                  className="w-full" 
                  onClick={() => uploadMutation.mutate()}
                  disabled={uploadMutation.isPending}
                >
                  {uploadMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Enviando...
                    </>
                  ) : (
                    "Enviar"
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Documentos</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : arquivos && arquivos.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Arquivo</TableHead>
                    <TableHead>Tamanho</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {arquivos.map((arquivo) => (
                    <TableRow key={arquivo.id}>
                      <TableCell>{arquivo.clientes?.nome_completo}</TableCell>
                      <TableCell>{arquivo.tipo}</TableCell>
                      <TableCell className="flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        {arquivo.nome_arquivo}
                      </TableCell>
                      <TableCell>{formatFileSize(arquivo.tamanho || 0)}</TableCell>
                      <TableCell>
                        {format(new Date(arquivo.created_at), "dd/MM/yyyy")}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex gap-2 justify-end">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => window.open(arquivo.url_arquivo, '_blank')}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => deleteMutation.mutate(arquivo.id)}
                            disabled={deleteMutation.isPending}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-muted-foreground text-center py-8">
                Nenhum documento enviado ainda
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
