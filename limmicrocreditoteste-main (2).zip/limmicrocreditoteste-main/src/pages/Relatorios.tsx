import { lazy, Suspense } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { FileText } from "lucide-react";

const RelatorioResumoGeral = lazy(() => import("@/components/RelatorioResumoGeral").then(m => ({ default: m.RelatorioResumoGeral })));
const RelatorioMensalBM = lazy(() => import("@/components/RelatorioMensalBM").then(m => ({ default: m.RelatorioMensalBM })));
const RelatorioTrimestralBM = lazy(() => import("@/components/RelatorioTrimestralBM").then(m => ({ default: m.RelatorioTrimestralBM })));
const RelatorioFinanceiro = lazy(() => import("@/components/RelatorioFinanceiro").then(m => ({ default: m.RelatorioFinanceiro })));
const RelatorioClientes = lazy(() => import("@/components/RelatorioClientes").then(m => ({ default: m.RelatorioClientes })));
const RelatorioRisco = lazy(() => import("@/components/RelatorioRisco").then(m => ({ default: m.RelatorioRisco })));
const RelatorioAtividadesDia = lazy(() => import("@/components/RelatorioAtividadesDia").then(m => ({ default: m.RelatorioAtividadesDia })));
const RelatorioMora = lazy(() => import("@/components/RelatorioMora").then(m => ({ default: m.RelatorioMora })));
const RelatorioContabilidade = lazy(() => import("@/components/RelatorioContabilidade").then(m => ({ default: m.RelatorioContabilidade })));
const DeclaracaoISPC = lazy(() => import("@/components/DeclaracaoISPC").then(m => ({ default: m.DeclaracaoISPC })));

const Loader = () => <Skeleton className="h-24 w-full" />;

export default function Relatorios() {
  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <h1 className="text-3xl font-bold flex items-center gap-3">
          <FileText className="h-8 w-8 text-primary" />
          Relatórios
        </h1>

        <Suspense fallback={<Loader />}><RelatorioResumoGeral /></Suspense>
        <Suspense fallback={<Loader />}><RelatorioAtividadesDia /></Suspense>
        <Suspense fallback={<Loader />}><RelatorioMora /></Suspense>
        <Suspense fallback={<Loader />}><RelatorioMensalBM /></Suspense>
        <Suspense fallback={<Loader />}><RelatorioTrimestralBM /></Suspense>

        <div className="grid gap-4 md:grid-cols-3">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader><CardTitle>Relatório Financeiro</CardTitle></CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">Empréstimos, recebimentos e carteira</p>
              <Suspense fallback={<Loader />}><RelatorioFinanceiro /></Suspense>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader><CardTitle>Análise de Clientes</CardTitle></CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">Clientes ativos, novos e inativos</p>
              <Suspense fallback={<Loader />}><RelatorioClientes /></Suspense>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader><CardTitle>Análise de Risco</CardTitle></CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">Inadimplência e carteira vencida</p>
              <Suspense fallback={<Loader />}><RelatorioRisco /></Suspense>
            </CardContent>
          </Card>
        </div>

        <Suspense fallback={<Loader />}><RelatorioContabilidade /></Suspense>
        <Suspense fallback={<Loader />}><DeclaracaoISPC /></Suspense>
      </div>
    </DashboardLayout>
  );
}
