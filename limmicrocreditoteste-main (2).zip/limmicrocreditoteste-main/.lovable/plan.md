# Plano: Checkout próprio + Validação automática rigorosa de comprovativos

Vou substituir o fluxo actual de pagamento por um checkout interno (semelhante aos screenshots enviados) com validação automática rigorosa via IA multimodal.

## 1. Novo fluxo do utilizador

1. Em `/pagamento-renovacao` (ou no botão "Pagar" actual), em vez de abrir links externos, abrir o **checkout interno** com 2 ecrãs:
   - **Ecrã 1 — Identificação + Método** (igual à 2ª foto):
     - Foto/avatar do plano + nome do plano + valor
     - Nome completo (pré-preenchido do perfil, editável)
     - Email (pré-preenchido)
     - 2 botões: **Pagar com M-Pesa** / **Pagar com e-Mola**
   - **Ecrã 2 — Instruções + Upload comprovativo** (igual à 1ª foto):
     - Cartão com: nome do destinatário (mascarado tipo `PE*****NA E***U`), número da carteira (com botão Copiar), valor exacto
     - Área de upload do screenshot do SMS
     - Botão **Validar pagamento**
     - Mensagem: "Validação automática rigorosa — entrega imediata ao aprovar"

WhatsApp suporte `+258 856 696 100` sempre visível.

## 2. Validação automática rigorosa (edge function `validar-comprovativo-rigoroso`)

Reescrever a edge function actual para implementar TODAS as regras pedidas:

**Extracção IA multimodal** (Gemini 2.5 Flash com tool calling):
- ID transação, valor, taxa, nome destinatário, número destinatário, data/hora ISO, operador, suspeita de fraude + razão

**Validações em ordem (rejeita à primeira falha):**
1. Limite de tentativas (3 em 30 min por email+link)
2. Operador extraído == operador escolhido
3. Formato do ID:
   - M-Pesa: `^[A-Z0-9]{10,11}$`
   - e-Mola: `^PP\d{6}\.\d{4}\.[A-Za-z]\d+$`
4. ID único (constraint UNIQUE + check explícito)
5. Fraude visual (apenas evidência clara — lista de sinais e excepções OCR conforme pedido)
6. Valor: diferença ≤ 0.50 MZN do esperado
7. Data/hora: ≤ 20 min no passado, ≤ 5 min no futuro
8. Número destinatário == carteira configurada (match exacto)
9. Nome destinatário: normalizado, aceita primeiro nome OU sobrenome OU similaridade ≥ 60% OU wildcard

**Se aprovado** — executar atomicamente via RPC PostgreSQL:
- Insert em `payment_proofs` (status `approved`)
- Insert em `transactions` (status `successful`)
- Activar plano: criar/estender `subscription` + actualizar `user_profiles.expires_at`
- Registar em `historico_renovacoes`
- Se já tem plano activo e expira no futuro → somar duração à data actual de expiração

**Se rejeitado:**
- Insert em `payment_proofs` (status `rejected`) com motivo
- Insert em `transactions` (status `failed`)
- Incrementar `payment_attempts.attempt_count`
- Devolver mensagem específica + (na 3ª) botão WhatsApp pré-preenchido

## 3. Mudanças na base de dados

Migration nova:

- `payment_proofs` — nova tabela com todos os campos pedidos + UNIQUE parcial em `transaction_id WHERE validation_status = 'approved'`
- `payment_attempts` — nova tabela (link/email + janela 30 min + blocked_until)
- `pagamentos_plataforma` — adicionar colunas em falta (`fee`, `recipient_name`, `recipient_number`, `transaction_datetime`, `fraud_suspected`, `fraud_reason`)
- RPC `aprovar_pagamento_rigoroso(...)` — função transaccional que faz proof+transaction+subscription activation atomicamente
- Configuração da carteira destinatário (nome + número) por método em `configuracao_pagamento` (campos `mpesa_numero`, `mpesa_nome`, `emola_numero`, `emola_nome`)

## 4. Ficheiros afectados

**Novos:**
- `src/pages/CheckoutInterno.tsx` — 2 ecrãs do checkout
- `supabase/functions/validar-comprovativo-rigoroso/index.ts` — nova validação
- Migration SQL com as tabelas/RPC acima

**Editados:**
- `src/pages/PagamentoRenovacao.tsx` — substituir UI actual pelo novo checkout
- `src/App.tsx` — rota `/checkout/:pacoteId`
- `supabase/config.toml` — registar nova função
- `src/pages/ConfiguracaoPagamentos.tsx` — campos do nome do titular por método

## 5. Mensagens ao cliente (todas implementadas tal como pedido)

Sucesso, falha geral, ID duplicado, comprovativo expirado, valor incorreto, método incorreto, destinatário incorreto, última tentativa, bloqueio.

## 6. O que NÃO faço (conforme restrição §16)

Sem emails de compra, SMS de compra, notificação ao vendedor, UTMify ou webhooks externos. Apenas: validação → registo → activação → acesso.

## Notas técnicas

- Mantenho a integração SMS interna existente (`receber-pagamento-sms`) a funcionar em paralelo como fallback de match por código.
- A UI segue o estilo das fotos enviadas (cartão rosa M-Pesa, cartão laranja e-Mola, dark/light tokens existentes).
- Toda activação dentro de RPC PL/pgSQL para garantir atomicidade real.

Confirmas para avançar?
